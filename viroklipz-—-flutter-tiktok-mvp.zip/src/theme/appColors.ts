export const APP_COLORS = {
  orange: '#FF5722',
  magenta: '#E91E63',
  deepPurple: '#673AB7',
  darkBg: '#121212',
  surface: '#1E1E1E',
  brandGradient: 'linear-gradient(135deg, #FF5722 0%, #E91E63 52%, #673AB7 100%)',
  brandGlow: '0 0 20px rgba(255, 87, 34, 0.55), 0 0 36px rgba(233, 30, 99, 0.45)',
} as const;
