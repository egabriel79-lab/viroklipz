import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowDownToLine,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Home,
  Loader2,
  MessageSquare,
  Sparkles,
  User,
  Users,
  Video,
} from 'lucide-react';
import { CURRENT_USER_ID, VideoComment, VideoItem } from './data/mockVideos';
import { APP_COLORS } from './theme/appColors';
import { useAuthProvider } from './hooks/useAuthProvider';
import { useVideoProvider } from './hooks/useVideoProvider';
import { VideoCard } from './components/VideoCard';
import { CommentsSheet } from './components/CommentsSheet';
import { BottomNavTab, SecondaryTabView } from './components/SecondaryTabs';
import { FriendsFeedScreen } from './components/FriendsFeedScreen';
import { CreateVideoModal } from './components/CreateVideoModal';
import { AuthGateDemo } from './components/AuthGateDemo';
import { LandingScreen } from './components/LandingScreen';
import { RegisterFormScreen } from './components/RegisterFormScreen';
import { FlutterBlueprintPanel } from './components/FlutterBlueprintPanel';

type TopFeedTab = 'siguiendo' | 'para_ti';
type EntryStage = 'landing' | 'register' | 'auth' | 'app';

export default function App() {
  const [entryStage, setEntryStage] = useState<EntryStage>('landing');
  const {
    savedAccounts,
    currentUser: authUser,
    switchAccount,
    addAccount,
    deleteAccount,
    signOut,
    ensureActiveUser,
    updateCurrentUserProfile,
  } = useAuthProvider();
  const currentUser = authUser ?? {
    id: 'acc-gabriel',
    username: 'gabriel_12343',
    displayName: 'Eloy',
    email: 'gabriel_12343@viroklipz.app',
    avatarUrl: '/src/assets/images/avatar_creator_mateo_1794604321715.jpg',
    unreadCount: 0,
  };
  const {
    forYouFeed,
    friendsFeed,
    isFollowing,
    toggleFollow,
    loadMoreVideos,
    incrementCommentsCount,
    uploadVideo,
  } = useVideoProvider(CURRENT_USER_ID, currentUser.username);
  const [activeBottomTab, setActiveBottomTab] = useState<BottomNavTab>('inicio');
  const [isCreateModalOpen, setIsCreateModalOpen] = useState<boolean>(false);
  const [activeTopTab, setActiveTopTab] = useState<TopFeedTab>('para_ti');
  const [activeVideoIndex, setActiveVideoIndex] = useState<number>(0);
  const [isMuted, setIsMuted] = useState<boolean>(true);
  const [likedIds, setLikedIds] = useState<Record<string, boolean>>({});
  const [commentsByVideo, setCommentsByVideo] = useState<Record<string, VideoComment[]>>({});
  const [activeCommentVideo, setActiveCommentVideo] = useState<VideoItem | null>(null);
  const [toastState, setToastState] = useState<{
    message: string;
    variant?: 'default' | 'downloading' | 'success' | 'error';
  } | null>(null);
  const toastTimerRef = useRef<number | null>(null);

  const feedScrollRef = useRef<HTMLDivElement | null>(null);

  const visibleVideos = useMemo(() => {
    return activeTopTab === 'siguiendo' ? friendsFeed : forYouFeed;
  }, [activeTopTab, friendsFeed, forYouFeed]);

  const userVideos = useMemo(
    () => forYouFeed.filter((v) => v.authorId === CURRENT_USER_ID),
    [forYouFeed]
  );

  const likedVideos = useMemo(
    () => forYouFeed.filter((v) => Boolean(likedIds[v.id])),
    [forYouFeed, likedIds]
  );

  // Reset to first slide when switching top tab
  useEffect(() => {
    setActiveVideoIndex(0);
    if (feedScrollRef.current) {
      feedScrollRef.current.scrollTo({ top: 0, behavior: 'auto' });
    }
  }, [activeTopTab]);

  // Clamp activeVideoIndex if Siguiendo shrinks after unfollowing
  useEffect(() => {
    if (visibleVideos.length > 0 && activeVideoIndex >= visibleVideos.length) {
      const clamped = visibleVideos.length - 1;
      setActiveVideoIndex(clamped);
      if (feedScrollRef.current) {
        feedScrollRef.current.scrollTo({
          top: clamped * feedScrollRef.current.clientHeight,
          behavior: 'auto',
        });
      }
    }
  }, [visibleVideos.length, activeVideoIndex]);

  // Track which video is currently snapped in viewport + infinite load near bottom on Para ti
  useEffect(() => {
    const container = feedScrollRef.current;
    if (!container) return;

    const handleScroll = () => {
      const height = container.clientHeight;
      if (height === 0) return;
      const nextIndex = Math.round(container.scrollTop / height);
      if (nextIndex !== activeVideoIndex && nextIndex >= 0 && nextIndex < visibleVideos.length) {
        setActiveVideoIndex(nextIndex);
      }
      if (activeTopTab === 'para_ti' && nextIndex >= visibleVideos.length - 2) {
        loadMoreVideos();
      }
    };

    container.addEventListener('scroll', handleScroll, { passive: true });
    return () => container.removeEventListener('scroll', handleScroll);
  }, [activeTopTab, activeVideoIndex, loadMoreVideos, visibleVideos.length]);

  const scrollToVideoIndex = (targetIndex: number) => {
    const container = feedScrollRef.current;
    if (!container) return;
    if (activeTopTab === 'para_ti' && targetIndex >= visibleVideos.length - 2) {
      loadMoreVideos();
    }
    const clamped = Math.max(0, Math.min(visibleVideos.length - 1, targetIndex));
    container.scrollTo({
      top: clamped * container.clientHeight,
      behavior: 'smooth',
    });
    setActiveVideoIndex(clamped);
  };

  const showToast = (
    msg: string,
    options?: {
      variant?: 'default' | 'downloading' | 'success' | 'error';
      persistent?: boolean;
    }
  ) => {
    if (toastTimerRef.current) {
      window.clearTimeout(toastTimerRef.current);
      toastTimerRef.current = null;
    }
    setToastState({ message: msg, variant: options?.variant ?? 'default' });
    if (!options?.persistent) {
      toastTimerRef.current = window.setTimeout(() => {
        setToastState((prev) => (prev?.message === msg ? null : prev));
      }, 2400);
    }
  };

  const handleToggleLike = (id: string) => {
    setLikedIds((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const handleToggleFollow = (video: VideoItem) => {
    if (video.authorId === CURRENT_USER_ID) return;
    const next = toggleFollow(video.authorId);
    showToast(next ? `Siguiendo a @${video.username}` : `Dejaste de seguir a @${video.username}`);
  };

  const handleShare = (_video: VideoItem) => {
    showToast('Descargando video...', { variant: 'downloading', persistent: true });
  };

  const handleAddComment = (videoId: string, text: string) => {
    const newComment: VideoComment = {
      id: `local-${Date.now()}`,
      username: currentUser.username,
      text,
      timeAgo: 'ahora',
      likes: 0,
    };
    setCommentsByVideo((prev) => ({
      ...prev,
      [videoId]: [newComment, ...(prev[videoId] ?? [])],
    }));
    incrementCommentsCount(videoId);
  };

  const handlePublishVideo = (payload: {
    videoUrl: string;
    description: string;
    hashtags?: string[];
    audioName: string;
    audioUrl?: string;
    effectUsed?: string;
    effectVideoUrl?: string;
    cssFilter?: string;
  }) => {
    uploadVideo({
      ...payload,
      avatarUrl: currentUser.avatarUrl,
    });
    setIsCreateModalOpen(false);
    setActiveTopTab('para_ti');
    setActiveBottomTab('inicio');
    setActiveVideoIndex(0);
    showToast('Video publicado en Viroklipz');
    window.setTimeout(() => {
      feedScrollRef.current?.scrollTo({ top: 0, behavior: 'auto' });
    }, 50);
  };

  const isFeedVisible = entryStage === 'app' && !isCreateModalOpen && activeBottomTab === 'inicio';
  const isFriendsVisible = entryStage === 'app' && !isCreateModalOpen && activeBottomTab === 'amigos';

  return (
    <div className="min-h-[100dvh] bg-zinc-950 text-zinc-100">
      <div className="mx-auto flex h-[100dvh] max-w-[1440px] flex-col lg:grid lg:grid-cols-[410px_1fr] lg:gap-6 lg:p-6">
        {/* Columna Izquierda (Móvil completo en pantallas pequeñas, simulador limpio en escritorio) */}
        <div className="relative flex h-full w-full flex-col items-center justify-center">
          <div className="relative flex h-full w-full flex-col overflow-hidden bg-black lg:h-[min(820px,calc(100dvh-3rem))] lg:w-[390px] lg:rounded-[34px] lg:border lg:border-zinc-800 lg:shadow-2xl">
            {entryStage === 'landing' ? (
              <LandingScreen
                onGetStarted={() => setEntryStage('register')}
                onCreateAccount={() => setEntryStage('register')}
                onGoHome={() => {
                  ensureActiveUser();
                  setEntryStage('auth');
                }}
              />
            ) : entryStage === 'register' ? (
              <RegisterFormScreen
                onBack={() => setEntryStage('landing')}
                onGoToLogin={() => setEntryStage('auth')}
                onRegistered={(profile) => {
                  const baseHandle = `${profile.firstName}.${profile.lastName}`
                    .toLowerCase()
                    .replace(/\s+/g, '')
                    .replace(/[^a-z0-9._]/g, '');
                  const resolvedUsername = baseHandle || 'creador';
                  const res = addAccount({
                    id: `acc-${Date.now()}`,
                    username: resolvedUsername,
                    displayName: `${profile.firstName} ${profile.lastName}`.trim() || resolvedUsername,
                    email: `${resolvedUsername}@viroklipz.app`,
                    avatarUrl: '/src/assets/images/avatar_creator_valeria_1794604321625.jpg',
                    unreadCount: 0,
                  });
                  if (!res.ok) {
                    showToast(res.error ?? 'Límite de cuentas alcanzado');
                    return;
                  }
                  setEntryStage('app');
                  setActiveBottomTab('inicio');
                  showToast(
                    profile.isMinor && profile.tutor
                      ? `Cuenta creada (tutor: ${profile.tutor.nombre}) · ${profile.country}`
                      : `Cuenta creada · ${profile.firstName} (${profile.country})`
                  );
                }}
              />
            ) : entryStage === 'auth' ? (
              <AuthGateDemo
                onBack={() => setEntryStage('landing')}
                onAuthenticated={(username, email) => {
                  const res = addAccount({
                    id: `acc-${username}`,
                    username,
                    displayName: username,
                    email,
                    avatarUrl: '/src/assets/images/avatar_creator_mateo_1794604321715.jpg',
                    unreadCount: 0,
                  });
                  if (!res.ok) {
                    showToast(res.error ?? 'Límite de cuentas alcanzado');
                    return;
                  }
                  setEntryStage('app');
                  setActiveBottomTab('inicio');
                  showToast(`Bienvenido @${username}`);
                }}
              />
            ) : (
              <>
                {/* Área Principal (Feed o Pantallas Secundarias) */}
                <div className="relative flex-1 min-h-0 overflow-hidden">
              {activeBottomTab === 'inicio' ? (
                <>
                  {/* Tabs Superiores: Círculo | Radar */}
                  <header className="pointer-events-none absolute inset-x-0 top-0 z-30 flex items-center justify-center pt-3.5">
                    <div className="pointer-events-auto flex items-center gap-6">
                      <button
                        type="button"
                        onClick={() => setActiveTopTab('siguiendo')}
                        className="flex min-h-[40px] flex-col items-center justify-center px-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white rounded-md"
                      >
                        <span
                          className={`text-[15.5px] transition-colors drop-shadow whitespace-nowrap ${
                            activeTopTab === 'siguiendo'
                              ? 'font-bold text-white'
                              : 'font-medium text-white/65 hover:text-white/90'
                          }`}
                        >
                          Círculo
                        </span>
                        <span
                          style={
                            activeTopTab === 'siguiendo'
                              ? { background: APP_COLORS.brandGradient }
                              : undefined
                          }
                          className={`mt-1 h-[3px] rounded-full transition-all duration-200 ${
                            activeTopTab === 'siguiendo' ? 'w-8 opacity-100' : 'w-0 opacity-0'
                          }`}
                        />
                      </button>

                      <button
                        type="button"
                        onClick={() => setActiveTopTab('para_ti')}
                        className="flex min-h-[40px] flex-col items-center justify-center px-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white rounded-md"
                      >
                        <span
                          className={`text-[15.5px] transition-colors drop-shadow whitespace-nowrap ${
                            activeTopTab === 'para_ti'
                              ? 'font-bold text-white'
                              : 'font-medium text-white/65 hover:text-white/90'
                          }`}
                        >
                          Radar
                        </span>
                        <span
                          style={
                            activeTopTab === 'para_ti'
                              ? { background: APP_COLORS.brandGradient }
                              : undefined
                          }
                          className={`mt-1 h-[3px] rounded-full transition-all duration-200 ${
                            activeTopTab === 'para_ti' ? 'w-8 opacity-100' : 'w-0 opacity-0'
                          }`}
                        />
                      </button>
                    </div>
                  </header>

                  {/* Controles discretos de navegación rápida en escritorio (arriba/abajo) */}
                  <div className="hidden lg:flex flex-col gap-1.5 absolute left-3 top-1/2 -translate-y-1/2 z-30">
                    <button
                      type="button"
                      onClick={() => scrollToVideoIndex(activeVideoIndex - 1)}
                      disabled={activeVideoIndex === 0}
                      aria-label="Video anterior"
                      className="flex h-9 w-9 items-center justify-center rounded-full bg-black/45 text-white backdrop-blur-sm transition-opacity hover:bg-black/70 disabled:opacity-25"
                    >
                      <ChevronUp className="h-4 w-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => scrollToVideoIndex(activeVideoIndex + 1)}
                      disabled={
                        activeTopTab !== 'para_ti' &&
                        activeVideoIndex >= visibleVideos.length - 1
                      }
                      aria-label="Siguiente video"
                      className="flex h-9 w-9 items-center justify-center rounded-full bg-black/45 text-white backdrop-blur-sm transition-opacity hover:bg-black/70 disabled:opacity-25"
                    >
                      <ChevronDown className="h-4 w-4" />
                    </button>
                  </div>

                  {/* PageView Vertical con Snap Scroll e Infinite Loading */}
                  {visibleVideos.length === 0 ? (
                    forYouFeed.length === 0 ? (
                      <div className="flex h-full flex-col items-center justify-center px-8 text-center">
                        <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-zinc-900 text-[#FF5722]">
                          <Video className="h-7 w-7" />
                        </div>
                        <p className="text-base font-bold text-white">
                          Aún no hay videos. ¡Sé el primero en subir uno!
                        </p>
                        <p className="mt-1.5 text-xs leading-relaxed text-zinc-400">
                          Graba o selecciona un video desde tu cámara y compártelo en Viroklipz.
                        </p>
                        <button
                          type="button"
                          onClick={() => setIsCreateModalOpen(true)}
                          style={{ background: APP_COLORS.brandGradient }}
                          className="mt-5 inline-flex items-center gap-2 rounded-full px-5 py-2.5 text-xs font-bold text-white shadow-lg transition-transform active:scale-95"
                        >
                          <Video className="h-4 w-4" />
                          <span>Subir primer video</span>
                        </button>
                      </div>
                    ) : (
                      <div className="flex h-full flex-col items-center justify-center px-8 text-center">
                        <p className="text-base font-bold text-white">
                          Aún no hay clips en tu Círculo
                        </p>
                        <p className="mt-1.5 text-xs text-zinc-400">
                          Sigue a creadores en &quot;Radar&quot; para ver sus videos aquí.
                        </p>
                        <button
                          type="button"
                          onClick={() => setActiveTopTab('para_ti')}
                          style={{ background: APP_COLORS.brandGradient }}
                          className="mt-5 rounded-full px-5 py-2.5 text-xs font-bold text-white shadow-lg"
                        >
                          Ir a Radar
                        </button>
                      </div>
                    )
                  ) : (
                    <div
                      ref={feedScrollRef}
                      className="h-full w-full snap-y snap-mandatory overflow-y-scroll no-scrollbar"
                    >
                      {visibleVideos.map((video, index) => (
                        <VideoCard
                          key={video.id}
                          video={video}
                          currentUserAvatarUrl={currentUser.avatarUrl}
                          isActive={index === activeVideoIndex}
                          isFeedVisible={isFeedVisible}
                          isMuted={isMuted}
                          onToggleMute={() => setIsMuted((prev) => !prev)}
                          isLiked={Boolean(likedIds[video.id])}
                          onToggleLike={() => handleToggleLike(video.id)}
                          isFollowing={isFollowing(video.authorId)}
                          onToggleFollow={() => handleToggleFollow(video)}
                          onOpenComments={() => setActiveCommentVideo(video)}
                          onShare={() => handleShare(video)}
                          onNotify={showToast}
                        />
                      ))}
                    </div>
                  )}
                </>
              ) : activeBottomTab === 'amigos' ? (
                <FriendsFeedScreen
                  videos={friendsFeed}
                  hasAnyVideos={forYouFeed.length > 0}
                  currentUserAvatarUrl={currentUser.avatarUrl}
                  isFeedVisible={isFriendsVisible}
                  isMuted={isMuted}
                  onToggleMute={() => setIsMuted((prev) => !prev)}
                  likedIds={likedIds}
                  onToggleLike={handleToggleLike}
                  isFollowing={isFollowing}
                  onToggleFollow={handleToggleFollow}
                  onOpenComments={(video) => setActiveCommentVideo(video)}
                  onShare={handleShare}
                  onExploreForYou={() => {
                    setActiveBottomTab('inicio');
                    setActiveTopTab('para_ti');
                  }}
                  onOpenCamera={() => setIsCreateModalOpen(true)}
                  onNotify={showToast}
                />
              ) : (
                <SecondaryTabView
                  tab={activeBottomTab}
                  currentUsername={currentUser.username}
                  currentEmail={currentUser.email}
                  savedAccounts={savedAccounts}
                  currentUser={authUser}
                  userVideos={userVideos}
                  likedVideos={likedVideos}
                  onSelectVideo={(videoId) => {
                    const targetIndex = forYouFeed.findIndex((v) => v.id === videoId);
                    setActiveBottomTab('inicio');
                    setActiveTopTab('para_ti');
                    if (targetIndex >= 0) {
                      window.setTimeout(() => scrollToVideoIndex(targetIndex), 60);
                    }
                  }}
                  onSwitchAccount={(account) => {
                    switchAccount(account);
                  }}
                  onAddAccount={() => {
                    if (savedAccounts.length >= 10) {
                      showToast('Error: máximo 10 cuentas guardadas');
                      return;
                    }
                    showToast('Función para añadir cuenta');
                    setEntryStage('auth');
                  }}
                  onDeleteAccount={(account) => {
                    const { signedOut } = deleteAccount(account);
                    showToast(`Cuenta @${account.username} eliminada`);
                    if (signedOut) {
                      setEntryStage('landing');
                      setActiveBottomTab('inicio');
                    }
                  }}
                  onUpdateUserProfile={updateCurrentUserProfile}
                  onBackToFeed={() => setActiveBottomTab('inicio')}
                  onSignOut={() => {
                    signOut();
                    setEntryStage('landing');
                    setActiveBottomTab('inicio');
                    showToast('Sesión cerrada');
                  }}
                  onOpenCamera={() => setIsCreateModalOpen(true)}
                  onNotify={showToast}
                />
              )}

              {/* Toast / Overlay superior flotante de feedback */}
              {toastState && (
                <div className="pointer-events-none absolute left-1/2 top-16 z-40 flex -translate-x-1/2 items-center gap-2 rounded-full border border-white/15 bg-zinc-900/95 px-4 py-2 text-xs font-semibold text-white shadow-xl backdrop-blur-md whitespace-nowrap">
                  {toastState.variant === 'downloading' && (
                    <>
                      <ArrowDownToLine className="h-3.5 w-3.5 text-[#FF5722]" />
                      <Loader2 className="h-3.5 w-3.5 animate-spin text-[#FF5722]" />
                    </>
                  )}
                  {toastState.variant === 'success' && (
                    <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
                  )}
                  <span>{toastState.message}</span>
                </div>
              )}

              {/* Sheet de comentarios */}
              <CommentsSheet
                video={activeCommentVideo}
                extraComments={
                  activeCommentVideo ? (commentsByVideo[activeCommentVideo.id] ?? []) : []
                }
                onClose={() => setActiveCommentVideo(null)}
                onAddComment={handleAddComment}
              />
            </div>

            {/* Barra de Navegación Inferior Viroklipz (Inicio, Comunidad, Botón Circular Glow, Mensajes, Perfil) */}
            <nav
              aria-label="Navegación principal de Viroklipz"
              className="grid h-[62px] shrink-0 grid-cols-5 items-center border-t border-white/10 bg-[#121212] px-1"
            >
              <button
                type="button"
                onClick={() => setActiveBottomTab('inicio')}
                className={`flex min-h-[44px] flex-col items-center justify-center gap-0.5 transition-colors ${
                  activeBottomTab === 'inicio'
                    ? 'text-[#FF5722]'
                    : 'text-zinc-500 hover:text-zinc-300'
                }`}
              >
                <Home className="h-5 w-5" />
                <span className="text-[10.5px] font-semibold">Inicio</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveBottomTab('amigos')}
                className={`flex min-h-[44px] flex-col items-center justify-center gap-0.5 transition-colors ${
                  activeBottomTab === 'amigos'
                    ? 'text-[#FF5722]'
                    : 'text-zinc-500 hover:text-zinc-300'
                }`}
              >
                <Users className="h-5 w-5" />
                <span className="text-[10.5px] font-semibold">Comunidad</span>
              </button>

              <button
                type="button"
                onClick={() => setIsCreateModalOpen(true)}
                aria-label="Crear video en Viroklipz"
                className="flex min-h-[44px] items-center justify-center transition-transform active:scale-95"
              >
                <div
                  style={{
                    background: APP_COLORS.brandGradient,
                    boxShadow: APP_COLORS.brandGlow,
                  }}
                  className="flex h-11 w-11 items-center justify-center rounded-full border border-white/25 text-white"
                >
                  <Sparkles className="h-5 w-5 stroke-[2.2]" />
                </div>
              </button>

              <button
                type="button"
                onClick={() => setActiveBottomTab('mensajes')}
                className={`flex min-h-[44px] flex-col items-center justify-center gap-0.5 transition-colors ${
                  activeBottomTab === 'mensajes'
                    ? 'text-[#FF5722]'
                    : 'text-zinc-500 hover:text-zinc-300'
                }`}
              >
                <MessageSquare className="h-5 w-5" />
                <span className="text-[10.5px] font-semibold">Mensajes</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveBottomTab('perfil')}
                className={`flex min-h-[44px] flex-col items-center justify-center gap-0.5 transition-colors ${
                  activeBottomTab === 'perfil'
                    ? 'text-[#FF5722]'
                    : 'text-zinc-500 hover:text-zinc-300'
                }`}
              >
                <User className="h-5 w-5" />
                <span className="text-[10.5px] font-semibold">Perfil</span>
              </button>
            </nav>

            {/* Modal Full-Screen de Creación (sin BottomNavigationBar) */}
            <CreateVideoModal
              isOpen={isCreateModalOpen}
              currentUsername={currentUser.username}
              onClose={() => setIsCreateModalOpen(false)}
              onPublishVideo={handlePublishVideo}
            />
              </>
            )}
          </div>
        </div>

        {/* Columna Derecha en Escritorio: Blueprint & Código Flutter MVP */}
        <div className="hidden lg:block h-[calc(100dvh-3rem)] min-h-0">
          <FlutterBlueprintPanel />
        </div>
      </div>
    </div>
  );
}
