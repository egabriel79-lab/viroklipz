import React, { useState } from 'react';
import {
  ArrowLeft,
  ChevronDown,
  ChevronRight,
  MoreVertical,
  Play,
  Search,
  Trash2,
  X,
} from 'lucide-react';

type DateFilterOption =
  | 'Cualquier fecha'
  | 'Ayer'
  | 'Semana pasada'
  | 'Último mes'
  | 'Rango de fechas';

interface WatchedVideoItem {
  id: string;
  thumbUrl: string;
  views: string;
  creator: string;
  bucket: 'Hoy' | 'Ayer' | 'Semana pasada' | 'Último mes';
}

const WATCHED_VIDEOS: WatchedVideoItem[] = [
  {
    id: 'vh-1',
    thumbUrl: '/src/assets/images/story_hinduismo_temple_1794607243976.jpg',
    views: '1.6M',
    creator: '@mateo.cine',
    bucket: 'Hoy',
  },
  {
    id: 'vh-2',
    thumbUrl: '/src/assets/images/avatar_creator_valeria_1794604321625.jpg',
    views: '842K',
    creator: '@valeria.beats',
    bucket: 'Hoy',
  },
  {
    id: 'vh-3',
    thumbUrl: '/src/assets/images/avatar_creator_lucas_1794604322245.jpg',
    views: '215K',
    creator: '@lucas.urbano',
    bucket: 'Hoy',
  },
  {
    id: 'vh-4',
    thumbUrl: '/src/assets/images/avatar_creator_sofia_1794604322145.jpg',
    views: '94.2K',
    creator: '@sofia.fit',
    bucket: 'Hoy',
  },
  {
    id: 'vh-5',
    thumbUrl: '/src/assets/images/avatar_creator_diego_1794604323122.jpg',
    views: '310K',
    creator: '@diego.35mm',
    bucket: 'Hoy',
  },
  {
    id: 'vh-6',
    thumbUrl: '/src/assets/images/avatar_creator_mateo_1794604321715.jpg',
    views: '1.1M',
    creator: '@mateo.cine',
    bucket: 'Hoy',
  },
  {
    id: 'vh-7',
    thumbUrl: '/src/assets/images/avatar_creator_valeria_1794604321625.jpg',
    views: '56.8K',
    creator: '@valeria.beats',
    bucket: 'Ayer',
  },
  {
    id: 'vh-8',
    thumbUrl: '/src/assets/images/avatar_creator_diego_1794604323122.jpg',
    views: '429K',
    creator: '@diego.35mm',
    bucket: 'Semana pasada',
  },
  {
    id: 'vh-9',
    thumbUrl: '/src/assets/images/avatar_creator_sofia_1794604322145.jpg',
    views: '712K',
    creator: '@sofia.fit',
    bucket: 'Último mes',
  },
];

const DATE_FILTER_OPTIONS: DateFilterOption[] = [
  'Cualquier fecha',
  'Ayer',
  'Semana pasada',
  'Último mes',
  'Rango de fechas',
];

interface VideoHistoryScreenProps {
  onBack: () => void;
  onNotify?: (message: string) => void;
}

export const VideoHistoryScreen: React.FC<VideoHistoryScreenProps> = ({
  onBack,
  onNotify,
}) => {
  const [appliedFilter, setAppliedFilter] =
    useState<DateFilterOption>('Cualquier fecha');
  const [pendingFilter, setPendingFilter] =
    useState<DateFilterOption>('Cualquier fecha');
  const [isFilterSheetOpen, setIsFilterSheetOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const openFilterSheet = () => {
    setPendingFilter(appliedFilter);
    setIsFilterSheetOpen(true);
  };

  const applyFilter = () => {
    setAppliedFilter(pendingFilter);
    setIsFilterSheetOpen(false);
    onNotify?.(`Filtro aplicado: ${pendingFilter}`);
  };

  const filteredVideos = WATCHED_VIDEOS.filter((item) => {
    const matchesSearch =
      searchQuery.trim().length === 0 ||
      item.creator.toLowerCase().includes(searchQuery.trim().toLowerCase());

    if (!matchesSearch) return false;
    if (appliedFilter === 'Cualquier fecha' || appliedFilter === 'Rango de fechas') {
      return true;
    }
    if (appliedFilter === 'Ayer') return item.bucket === 'Ayer';
    if (appliedFilter === 'Semana pasada') {
      return item.bucket === 'Hoy' || item.bucket === 'Ayer' || item.bucket === 'Semana pasada';
    }
    return true;
  });

  const sectionTitle =
    appliedFilter === 'Cualquier fecha' ? 'Hoy' : appliedFilter;

  return (
    <div className="relative flex h-full w-full flex-col bg-[#121212] text-white select-none overflow-hidden">
      {/* AppBar */}
      <header className="flex h-12 shrink-0 items-center justify-between border-b border-white/10 px-1.5">
        <div className="flex min-w-0 items-center gap-1">
          <button
            type="button"
            onClick={onBack}
            aria-label="Volver al centro de actividades"
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <h1 className="truncate text-[15px] font-bold text-white">
            Historial de videos vistos
          </h1>
        </div>

        <div className="relative flex shrink-0 items-center">
          <button
            type="button"
            onClick={() => setIsSearchOpen((prev) => !prev)}
            aria-label="Buscar en historial"
            className="flex h-9 w-9 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
          >
            {isSearchOpen ? (
              <X className="h-4 w-4" />
            ) : (
              <Search className="h-5 w-5" />
            )}
          </button>
          <button
            type="button"
            onClick={() => setIsMenuOpen((prev) => !prev)}
            aria-label="Más opciones"
            className="flex h-9 w-9 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
          >
            <MoreVertical className="h-5 w-5" />
          </button>

          {isMenuOpen && (
            <div className="absolute right-1 top-10 z-30 w-44 overflow-hidden rounded-xl border border-white/10 bg-[#1F1F23] py-1 shadow-2xl">
              <button
                type="button"
                onClick={() => {
                  setIsMenuOpen(false);
                  onNotify?.('Seleccionar videos para borrar');
                }}
                className="flex w-full items-center gap-2 px-3.5 py-2.5 text-left text-xs font-medium text-white hover:bg-white/10"
              >
                <Trash2 className="h-4 w-4 text-rose-400" />
                <span>Borrar historial</span>
              </button>
            </div>
          )}
        </div>
      </header>

      {/* Buscador opcional */}
      {isSearchOpen && (
        <div className="border-b border-white/10 px-3 py-2">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Filtrar por @creador..."
            autoFocus
            className="w-full rounded-xl border border-white/15 bg-[#1E1E22] px-3 py-2 text-xs text-white placeholder:text-zinc-500 focus:border-white/35 focus:outline-none"
          />
        </div>
      )}

      {/* Chip "Filtrar por fecha ⌄" debajo del AppBar */}
      <div className="shrink-0 px-3 pt-3 pb-1">
        <button
          type="button"
          onClick={openFilterSheet}
          className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-semibold transition-colors ${
            appliedFilter === 'Cualquier fecha'
              ? 'border-white/15 bg-[#1E1E22] text-zinc-200 hover:bg-[#27272C]'
              : 'border-[#FF2D55]/60 bg-[#FF2D55]/15 text-white'
          }`}
        >
          <span>
            {appliedFilter === 'Cualquier fecha'
              ? 'Filtrar por fecha'
              : appliedFilter}
          </span>
          <ChevronDown className="h-3.5 w-3.5" />
        </button>
      </div>

      {/* Grid de 3 columnas con sección "Hoy" */}
      <div className="flex-1 min-h-0 overflow-y-auto px-2 pb-4 no-scrollbar">
        <h2 className="px-1.5 pb-2 pt-2.5 text-sm font-bold text-white">
          {sectionTitle}
        </h2>

        <div className="grid grid-cols-3 gap-1">
          {filteredVideos.map((video) => (
            <button
              key={video.id}
              type="button"
              onClick={() => onNotify?.(`Reproduciendo clip de ${video.creator}`)}
              className="group relative aspect-[9/16] w-full overflow-hidden rounded-[6px] bg-zinc-900"
            >
              <img
                src={video.thumbUrl}
                alt={`Video de ${video.creator}`}
                className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
              />
              <div
                aria-hidden="true"
                className="pointer-events-none absolute inset-x-0 bottom-0 h-10 bg-gradient-to-t from-black/75 to-transparent"
              />
              <div className="absolute bottom-1.5 left-1.5 flex items-center gap-1 text-white">
                <Play className="h-3 w-3 fill-white" />
                <span className="text-[11px] font-semibold tabular-nums">
                  {video.views}
                </span>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Bottom Sheet de Filtro por fecha */}
      {isFilterSheetOpen && (
        <div
          className="absolute inset-0 z-30 flex items-end bg-black/60 backdrop-blur-[1px]"
          onClick={() => setIsFilterSheetOpen(false)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full rounded-t-2xl bg-[#1C1C1E] pb-5 pt-2 text-white shadow-2xl"
          >
            <div className="mx-auto mb-2 h-1 w-9 rounded-full bg-white/20" />

            {/* Header: Cancelar | Filtrar por fecha | Aplicar */}
            <div className="flex items-center justify-between border-b border-white/10 px-4 py-2.5">
              <button
                type="button"
                onClick={() => setIsFilterSheetOpen(false)}
                className="text-xs font-medium text-zinc-400 hover:text-white"
              >
                Cancelar
              </button>
              <span className="text-sm font-bold text-white">
                Filtrar por fecha
              </span>
              <button
                type="button"
                onClick={applyFilter}
                className="text-xs font-bold text-[#FF2D55] hover:opacity-90"
              >
                Aplicar
              </button>
            </div>

            {/* Opciones tipo RadioListTile */}
            <div className="divide-y divide-white/5 px-2 pt-1">
              {DATE_FILTER_OPTIONS.map((option) => {
                const isSelected = pendingFilter === option;
                const isRange = option === 'Rango de fechas';
                return (
                  <button
                    key={option}
                    type="button"
                    onClick={() => setPendingFilter(option)}
                    className="flex w-full items-center justify-between px-3 py-3.5 text-left transition-colors hover:bg-white/5"
                  >
                    <div className="flex items-center gap-3">
                      <span
                        className={`flex h-5 w-5 items-center justify-center rounded-full border-2 transition-colors ${
                          isSelected
                            ? 'border-[#FF2D55]'
                            : 'border-zinc-500'
                        }`}
                      >
                        {isSelected && (
                          <span className="h-2.5 w-2.5 rounded-full bg-[#FF2D55]" />
                        )}
                      </span>
                      <span className="text-sm font-medium text-white">
                        {option}
                      </span>
                    </div>

                    {isRange && (
                      <ChevronRight className="h-4 w-4 text-zinc-400" />
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
