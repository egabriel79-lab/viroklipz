import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Ban,
  ChevronDown,
  ChevronLeft,
  Filter,
  Grid3x3,
  Loader2,
  Music2,
  Play,
  RefreshCw,
  Search,
  Sparkles,
  Square,
  SwitchCamera,
  Timer,
  UserPlus,
  VideoOff,
  X,
} from 'lucide-react';

interface CreateVideoModalProps {
  isOpen: boolean;
  currentUsername: string;
  onClose: () => void;
  onPublishVideo: (payload: {
    videoUrl: string;
    description: string;
    hashtags?: string[];
    audioName: string;
    audioUrl?: string;
    effectUsed?: string;
    effectVideoUrl?: string;
    cssFilter?: string;
  }) => void;
}

type CameraDuration = '10 min' | '60 s' | '15 s';
type CameraBottomMode = 'CÁMARA' | 'CREAR';

interface RoyaltyFreeSoundItem {
  id: string;
  title: string;
  artist: string;
  duration: string;
  audioUrl: string;
  category: 'music' | 'sfx';
}

interface VisualEffectItem {
  id: string;
  name: string;
  tag: string;
  thumbnailUrl: string;
  videoUrl: string;
}

const ROYALTY_FREE_SOUNDS: RoyaltyFreeSoundItem[] = [
  {
    id: 'jam-1',
    title: 'Neon Horizon (Synthwave)',
    artist: 'Jamendo · Studio Horizon',
    duration: '0:32',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
    category: 'music',
  },
  {
    id: 'jam-2',
    title: 'Midnight Pulse',
    artist: 'Jamendo · Creative Audio',
    duration: '0:45',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3',
    category: 'music',
  },
  {
    id: 'jam-3',
    title: 'Urban Drift Lo-Fi',
    artist: 'Jamendo · BeatLab Libre',
    duration: '0:28',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3',
    category: 'music',
  },
  {
    id: 'fs-1',
    title: 'Transición Whoosh Cine',
    artist: 'Freesound · @sfx_cinema',
    duration: '0:02',
    audioUrl: 'https://assets.mixkit.co/active_storage/sfx/2568/2568-preview.mp3',
    category: 'sfx',
  },
  {
    id: 'fs-2',
    title: 'Destello Mágico',
    artist: 'Freesound · @magic_fx',
    duration: '0:03',
    audioUrl: 'https://assets.mixkit.co/active_storage/sfx/2019/2019-preview.mp3',
    category: 'sfx',
  },
  {
    id: 'fs-3',
    title: 'Impacto Bass Drop',
    artist: 'Freesound · @sub_designer',
    duration: '0:02',
    audioUrl: 'https://assets.mixkit.co/active_storage/sfx/2571/2571-preview.mp3',
    category: 'sfx',
  },
];

const VISUAL_EFFECT_OVERLAYS: VisualEffectItem[] = [
  {
    id: 'light_leaks',
    name: 'Destellos Cálidos',
    tag: 'Light Leak',
    thumbnailUrl:
      'https://images.pexels.com/photos/3377405/pexels-photo-3377405.jpeg?auto=compress&cs=tinysrgb&w=400',
    videoUrl:
      'https://assets.mixkit.co/videos/preview/mixkit-warm-light-leaks-overlay-34597-large.mp4',
  },
  {
    id: 'neon_particles',
    name: 'Partículas Neón',
    tag: 'Neón',
    thumbnailUrl:
      'https://images.pexels.com/photos/2156881/pexels-photo-2156881.jpeg?auto=compress&cs=tinysrgb&w=400',
    videoUrl:
      'https://assets.mixkit.co/videos/preview/mixkit-glittering-golden-particles-background-41213-large.mp4',
  },
  {
    id: 'bokeh_nights',
    name: 'Bokeh Nocturno',
    tag: 'Bokeh',
    thumbnailUrl:
      'https://images.pexels.com/photos/1763075/pexels-photo-1763075.jpeg?auto=compress&cs=tinysrgb&w=400',
    videoUrl:
      'https://assets.mixkit.co/videos/preview/mixkit-colorful-bokeh-lights-blurred-background-41214-large.mp4',
  },
  {
    id: 'vhs_retro',
    name: 'Estática Retro',
    tag: 'VHS',
    thumbnailUrl:
      'https://images.pexels.com/photos/2510428/pexels-photo-2510428.jpeg?auto=compress&cs=tinysrgb&w=400',
    videoUrl:
      'https://assets.mixkit.co/videos/preview/mixkit-old-film-scratches-and-dust-overlay-42748-large.mp4',
  },
];

type CameraFilterId = 'none' | 'bw' | 'vintage' | 'neon';

interface CameraImageFilterOption {
  id: CameraFilterId;
  label: string;
  css: string;
  overlayClass: string;
  swatchStyle: React.CSSProperties;
}

const CAMERA_IMAGE_FILTERS: CameraImageFilterOption[] = [
  {
    id: 'none',
    label: 'Normal',
    css: 'none',
    overlayClass: '',
    swatchStyle: {
      background: 'linear-gradient(135deg, #27272a 0%, #52525b 100%)',
    },
  },
  {
    id: 'bw',
    label: 'B&W',
    css: 'grayscale(100%) contrast(1.15)',
    overlayClass: 'bg-zinc-950/15 mix-blend-color',
    swatchStyle: {
      background: 'linear-gradient(135deg, #fafafa 0%, #18181b 100%)',
    },
  },
  {
    id: 'vintage',
    label: 'Vintage',
    css: 'sepia(0.65) contrast(1.08) brightness(0.95) saturate(0.85)',
    overlayClass: 'bg-amber-700/20 mix-blend-multiply',
    swatchStyle: {
      background: 'linear-gradient(135deg, #f59e0b 0%, #78350f 100%)',
    },
  },
  {
    id: 'neon',
    label: 'Neon',
    css: 'saturate(2.1) contrast(1.25) hue-rotate(15deg)',
    overlayClass: 'bg-gradient-to-tr from-[#25F4EE]/20 via-transparent to-[#E91E63]/25 mix-blend-screen',
    swatchStyle: {
      background: 'linear-gradient(135deg, #25F4EE 0%, #E91E63 100%)',
    },
  },
];

const CAMERA_SAMPLE_MP4 =
  'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4';

export const CreateVideoModal: React.FC<CreateVideoModalProps> = ({
  isOpen,
  currentUsername,
  onClose,
  onPublishVideo,
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const uploadTimerRef = useRef<number | null>(null);
  const liveVideoRef = useRef<HTMLVideoElement | null>(null);
  const previewAudioRef = useRef<HTMLAudioElement | null>(null);
  const cameraLoopAudioRef = useRef<HTMLAudioElement | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  const [step, setStep] = useState<'camera' | 'publish'>('camera');

  // Estados de Cámara
  const [selectedDuration, setSelectedDuration] = useState<CameraDuration>('15 s');
  const [cameraMode, setCameraMode] = useState<CameraBottomMode>('CÁMARA');
  const [selectedSound, setSelectedSound] = useState<RoyaltyFreeSoundItem | null>(null);
  const [selectedAudioUrl, setSelectedAudioUrl] = useState<string | null>(null);
  const [selectedAudioName, setSelectedAudioName] = useState<string | null>(null);
  const [soundSheetOpen, setSoundSheetOpen] = useState(false);
  const [soundTab, setSoundTab] = useState<'music' | 'sfx'>('music');
  const [soundQuery, setSoundQuery] = useState('');
  const [playingSoundId, setPlayingSoundId] = useState<string | null>(null);

  const [effectsSheetOpen, setEffectsSheetOpen] = useState(false);
  const [selectedEffectId, setSelectedEffectId] = useState<string>('Ninguno');
  const [selectedEffectOverlay, setSelectedEffectOverlay] =
    useState<VisualEffectItem | null>(null);

  const [showGridOverlay, setShowGridOverlay] = useState(false);
  const [activeEffect, setActiveEffect] = useState<string | null>(null);
  const [activeImageFilter, setActiveImageFilter] = useState<CameraFilterId>('none');
  const [filterTrayOpen, setFilterTrayOpen] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [recordSeconds, setRecordSeconds] = useState(0);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [isCameraLoading, setIsCameraLoading] = useState(false);
  const [cameraPermissionError, setCameraPermissionError] = useState<string | null>(null);
  const [cameraSnackBar, setCameraSnackBar] = useState<string | null>(null);
  const [showSettingsDialog, setShowSettingsDialog] = useState(false);
  const [cameraRetryTick, setCameraRetryTick] = useState(0);
  const [tempFilePath, setTempFilePath] = useState<string | null>(null);

  // Tarjetica de texto (TEXTO)
  const [textModalOpen, setTextModalOpen] = useState(false);
  const [draftText, setDraftText] = useState('');
  const [overlayText, setOverlayText] = useState('');

  // Estados de Publicación
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [description, setDescription] = useState('');
  const [audioName, setAudioName] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);

  const filteredSounds = useMemo(() => {
    const q = soundQuery.trim().toLowerCase();
    return ROYALTY_FREE_SOUNDS.filter(
      (item) =>
        item.category === soundTab &&
        (!q ||
          item.title.toLowerCase().includes(q) ||
          item.artist.toLowerCase().includes(q))
    );
  }, [soundTab, soundQuery]);

  const stopPreviewAudio = () => {
    if (previewAudioRef.current) {
      previewAudioRef.current.pause();
      previewAudioRef.current.currentTime = 0;
      previewAudioRef.current = null;
    }
    setPlayingSoundId(null);
  };

  const stopCameraLoopAudio = () => {
    if (cameraLoopAudioRef.current) {
      cameraLoopAudioRef.current.pause();
      cameraLoopAudioRef.current.currentTime = 0;
      cameraLoopAudioRef.current = null;
    }
  };

  const startCameraLoopAudio = (url: string) => {
    stopCameraLoopAudio();
    const audio = new Audio(url);
    audio.loop = true;
    cameraLoopAudioRef.current = audio;
    audio.play().catch(() => {
      // Autoplay o red restringida: se ignora silenciosamente
    });
  };

  const stopCameraStream = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      try {
        mediaRecorderRef.current.stop();
      } catch {
        // Ignorar si ya estaba detenido
      }
    }
    mediaRecorderRef.current = null;
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null;
    }
    if (liveVideoRef.current) {
      liveVideoRef.current.srcObject = null;
    }
  };

  useEffect(() => {
    return () => {
      stopPreviewAudio();
      stopCameraLoopAudio();
      stopCameraStream();
      if (uploadTimerRef.current !== null) {
        window.clearInterval(uploadTimerRef.current);
        uploadTimerRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    if (!isOpen || step !== 'camera') {
      stopCameraLoopAudio();
    } else if (selectedAudioUrl && !soundSheetOpen) {
      startCameraLoopAudio(selectedAudioUrl);
    }
  }, [isOpen, step, selectedAudioUrl, soundSheetOpen]);

  useEffect(() => {
    if (!isOpen) {
      stopPreviewAudio();
      stopCameraLoopAudio();
      stopCameraStream();
      if (uploadTimerRef.current !== null) {
        window.clearInterval(uploadTimerRef.current);
        uploadTimerRef.current = null;
      }
      setStep('camera');
      setSelectedDuration('15 s');
      setCameraMode('CÁMARA');
      setSelectedSound(null);
      setSelectedAudioUrl(null);
      setSelectedAudioName(null);
      setSoundSheetOpen(false);
      setSoundTab('music');
      setSoundQuery('');
      setEffectsSheetOpen(false);
      setSelectedEffectId('Ninguno');
      setSelectedEffectOverlay(null);
      setShowGridOverlay(false);
      setActiveEffect(null);
      setActiveImageFilter('none');
      setFilterTrayOpen(false);
      setIsRecording(false);
      setRecordSeconds(0);
      setFacingMode('environment');
      setIsCameraLoading(false);
      setCameraPermissionError(null);
      setCameraSnackBar(null);
      setShowSettingsDialog(false);
      setTempFilePath(null);
      setTextModalOpen(false);
      setDraftText('');
      setOverlayText('');
      setDescription('');
      setAudioName('');
      setIsUploading(false);
      setUploadProgress(0);
      setPreviewUrl(null);
    }
  }, [isOpen]);

  // Inicializar cámara real con getUserMedia cuando el paso activo es 'camera'
  useEffect(() => {
    if (!isOpen || step !== 'camera') {
      stopCameraStream();
      return;
    }

    let cancelled = false;

    const initCamera = async () => {
      if (!navigator.mediaDevices?.getUserMedia) {
        setCameraPermissionError('Necesitamos acceso a la cámara para grabar');
        if (cameraRetryTick > 0) {
          setCameraSnackBar('No se puede grabar sin acceso a la cámara.');
        }
        return;
      }

      setIsCameraLoading(true);
      setCameraPermissionError(null);
      stopCameraStream();

      try {
        let stream: MediaStream;
        try {
          stream = await navigator.mediaDevices.getUserMedia({
            video: { facingMode: { ideal: facingMode } },
            audio: true,
          });
        } catch {
          stream = await navigator.mediaDevices.getUserMedia({
            video: { facingMode: { ideal: facingMode } },
            audio: false,
          });
        }

        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }

        mediaStreamRef.current = stream;
        if (liveVideoRef.current) {
          liveVideoRef.current.srcObject = stream;
          await liveVideoRef.current.play().catch(() => {});
        }
        setCameraSnackBar(null);
        setShowSettingsDialog(false);
      } catch (err) {
        if (!cancelled) {
          setCameraPermissionError('Necesitamos acceso a la cámara para grabar');
          if (cameraRetryTick > 0) {
            const errorName = err instanceof DOMException ? err.name : '';
            if (errorName === 'NotAllowedError' || errorName === 'PermissionDeniedError' || errorName === 'SecurityError') {
              setShowSettingsDialog(true);
            } else {
              setCameraSnackBar('No se puede grabar sin acceso a la cámara.');
            }
          }
        }
      } finally {
        if (!cancelled) {
          setIsCameraLoading(false);
        }
      }
    };

    initCamera();

    return () => {
      cancelled = true;
      stopCameraStream();
    };
  }, [isOpen, step, facingMode, cameraRetryTick]);

  // Re-evaluar permisos automáticamente al regresar de ajustes / cambiar de pestaña
  useEffect(() => {
    if (!isOpen || step !== 'camera' || !cameraPermissionError) return;

    const handleReturnToFocus = async () => {
      if (document.visibilityState === 'hidden') return;
      if (navigator.permissions?.query) {
        try {
          const status = await navigator.permissions.query({
            name: 'camera' as PermissionName,
          });
          if (status.state === 'granted') {
            setCameraPermissionError(null);
            setShowSettingsDialog(false);
            setCameraRetryTick((t) => t + 1);
          }
        } catch {
          // Algunos navegadores no soportan permissions.query('camera')
        }
      }
    };

    window.addEventListener('focus', handleReturnToFocus);
    document.addEventListener('visibilitychange', handleReturnToFocus);
    return () => {
      window.removeEventListener('focus', handleReturnToFocus);
      document.removeEventListener('visibilitychange', handleReturnToFocus);
    };
  }, [isOpen, step, cameraPermissionError]);

  useEffect(() => {
    if (!cameraSnackBar) return;
    const id = window.setTimeout(() => setCameraSnackBar(null), 3200);
    return () => window.clearTimeout(id);
  }, [cameraSnackBar]);

  useEffect(() => {
    if (!isRecording) return;
    const id = window.setInterval(() => {
      setRecordSeconds((s) => s + 1);
    }, 1000);
    return () => window.clearInterval(id);
  }, [isRecording]);

  if (!isOpen) return null;

  const triggerSystemPicker = () => {
    if (isUploading) return;
    fileInputRef.current?.click();
  };

  const triggerSoundPicker = () => {
    setSoundSheetOpen(true);
  };

  const handleTogglePlaySound = (sound: RoyaltyFreeSoundItem) => {
    if (playingSoundId === sound.id) {
      stopPreviewAudio();
      return;
    }
    stopPreviewAudio();
    const audio = new Audio(sound.audioUrl);
    previewAudioRef.current = audio;
    setPlayingSoundId(sound.id);
    audio.onended = () => {
      setPlayingSoundId(null);
    };
    audio.play().catch(() => {
      setPlayingSoundId(null);
    });
  };

  const handleUseSound = (sound: RoyaltyFreeSoundItem) => {
    stopPreviewAudio();
    setSelectedSound(sound);
    setSelectedAudioUrl(sound.audioUrl);
    setSelectedAudioName(sound.title);
    setAudioName(`${sound.title} · ${sound.artist}`);
    setSoundSheetOpen(false);
    startCameraLoopAudio(sound.audioUrl);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const url = URL.createObjectURL(file);
    setPreviewUrl(url);
    if (selectedSound && !audioName) {
      setAudioName(`${selectedSound.title} · ${selectedSound.artist}`);
    }
    setStep('publish');
    e.target.value = '';
  };

  const handleFlipCamera = () => {
    if (isRecording || isCameraLoading) return;
    const nextFacing = facingMode === 'environment' ? 'user' : 'environment';
    setFacingMode(nextFacing);
    setActiveEffect(nextFacing === 'user' ? 'Cámara frontal' : 'Cámara trasera');
  };

  const handleToggleRecord = () => {
    if (isCameraLoading || cameraPermissionError) return;

    if (!isRecording) {
      setRecordSeconds(0);
      recordedChunksRef.current = [];

      if (mediaStreamRef.current && typeof MediaRecorder !== 'undefined') {
        try {
          const supportedMime = [
            'video/mp4',
            'video/webm;codecs=vp8,opus',
            'video/webm;codecs=vp9,opus',
            'video/webm',
          ].find((mime) => {
            try {
              return MediaRecorder.isTypeSupported(mime);
            } catch {
              return false;
            }
          });
          const recorder = supportedMime
            ? new MediaRecorder(mediaStreamRef.current, { mimeType: supportedMime })
            : new MediaRecorder(mediaStreamRef.current);
          recorder.ondataavailable = (event) => {
            if (event.data && event.data.size > 0) {
              recordedChunksRef.current.push(event.data);
            }
          };
          recorder.onstop = () => {
            const blob = new Blob(recordedChunksRef.current, {
              type: recorder.mimeType || supportedMime || 'video/webm',
            });
            const url =
              blob.size > 1024 ? URL.createObjectURL(blob) : CAMERA_SAMPLE_MP4;
            setPreviewUrl(url);
            setTempFilePath(
              `/tmp/viroklipz_${Date.now()}.mp4`
            );
            if (selectedSound) {
              setAudioName(`${selectedSound.title} · ${selectedSound.artist}`);
            }
            if (overlayText && !description) {
              setDescription(overlayText);
            }
            setStep('publish');
          };
          mediaRecorderRef.current = recorder;
          recorder.start(200);
          setIsRecording(true);
          return;
        } catch {
          // Fallback al flujo simulado si el codec no es soportado
        }
      }

      setIsRecording(true);
    } else {
      setIsRecording(false);
      if (
        mediaRecorderRef.current &&
        mediaRecorderRef.current.state !== 'inactive'
      ) {
        mediaRecorderRef.current.stop();
      } else {
        setPreviewUrl(CAMERA_SAMPLE_MP4);
        setTempFilePath(`/tmp/viroklipz_${Date.now()}.mp4`);
        if (selectedSound) {
          setAudioName(`${selectedSound.title} · ${selectedSound.artist}`);
        }
        if (overlayText && !description) {
          setDescription(overlayText);
        }
        setStep('publish');
      }
    }
  };

  const handleContinueWithoutCamera = () => {
    setCameraPermissionError(null);
    setShowSettingsDialog(false);
    setCameraSnackBar(null);
    setPreviewUrl(CAMERA_SAMPLE_MP4);
    setTempFilePath(`/tmp/viroklipz_web_preview_${Date.now()}.mp4`);
    if (selectedSound) {
      setAudioName(`${selectedSound.title} · ${selectedSound.artist}`);
    }
    if (overlayText && !description) {
      setDescription(overlayText);
    }
    setStep('publish');
  };

  const handleConfirmText = (e: React.FormEvent) => {
    e.preventDefault();
    setOverlayText(draftText.trim());
    setTextModalOpen(false);
  };

  const extractHashtags = (text: string): string[] => {
    const matches = text.match(/#[\p{L}\p{N}_]+/gu) ?? [];
    return Array.from(
      new Set(matches.map((tag) => tag.slice(1).toLowerCase()).filter(Boolean))
    );
  };

  const handlePublish = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedDescription = description.trim();
    if (!previewUrl || isUploading || !trimmedDescription) return;

    if (uploadTimerRef.current !== null) {
      window.clearInterval(uploadTimerRef.current);
      uploadTimerRef.current = null;
    }

    let progress = 15;
    const finalVideoUrl = previewUrl;
    const finalDescription = trimmedDescription;
    const extractedHashtags = extractHashtags(finalDescription);
    const finalAudioName = audioName.trim() || `Sonido original — @${currentUsername}`;

    setIsUploading(true);
    setUploadProgress(progress);

    uploadTimerRef.current = window.setInterval(() => {
      progress = Math.min(100, progress + 25);
      setUploadProgress(progress);

      if (progress >= 100) {
        if (uploadTimerRef.current !== null) {
          window.clearInterval(uploadTimerRef.current);
          uploadTimerRef.current = null;
        }
        setIsUploading(false);
        const selectedFilterObj = CAMERA_IMAGE_FILTERS.find(
          (f) => f.id === activeImageFilter
        );
        onPublishVideo({
          videoUrl: finalVideoUrl,
          description: finalDescription,
          hashtags: extractedHashtags,
          audioName: finalAudioName,
          audioUrl: selectedAudioUrl ?? selectedSound?.audioUrl,
          effectUsed: selectedEffectId,
          effectVideoUrl:
            selectedEffectId !== 'Ninguno' ? selectedEffectOverlay?.videoUrl : undefined,
          cssFilter:
            selectedFilterObj && selectedFilterObj.id !== 'none'
              ? selectedFilterObj.css
              : undefined,
        });
      }
    }, 170);
  };

  const currentImageFilter =
    CAMERA_IMAGE_FILTERS.find((f) => f.id === activeImageFilter) ??
    CAMERA_IMAGE_FILTERS[0];

  return (
    <div className="absolute inset-0 z-50 flex flex-col bg-black text-white overflow-hidden">
      <input
        ref={fileInputRef}
        type="file"
        accept="video/*"
        onChange={handleFileChange}
        className="hidden"
      />

      {step === 'camera' && (
        <div className="relative flex h-full w-full flex-col bg-black select-none">
          {/* CameraPreview real */}
          {!cameraPermissionError && (
            <video
              ref={liveVideoRef}
              autoPlay
              playsInline
              muted
              style={{
                filter:
                  currentImageFilter.id !== 'none'
                    ? currentImageFilter.css
                    : undefined,
              }}
              className={`absolute inset-0 h-full w-full object-cover transition-[filter] duration-200 ${
                facingMode === 'user' ? '-scale-x-100' : ''
              }`}
            />
          )}

          {/* Overlay CSS del filtro en tiempo real (B&W, Vintage, Neon) */}
          {currentImageFilter.id !== 'none' && (
            <div
              aria-hidden="true"
              className={`pointer-events-none absolute inset-0 z-[4] transition-opacity duration-200 ${currentImageFilter.overlayClass}`}
            />
          )}

          {/* Overlay Visual seleccionado (Stack con BlendMode.screen sobre cámara) */}
          {selectedEffectId !== 'Ninguno' && (
            <>
              <div
                aria-hidden="true"
                className="pointer-events-none absolute inset-0 z-[5] opacity-40 mix-blend-screen"
                style={{
                  background:
                    selectedEffectId === 'neon_particles'
                      ? 'linear-gradient(135deg, rgba(37,244,238,0.6) 0%, rgba(233,30,99,0.5) 100%)'
                      : selectedEffectId === 'bokeh_nights'
                        ? 'linear-gradient(135deg, rgba(103,58,183,0.65) 0%, rgba(233,30,99,0.5) 100%)'
                        : selectedEffectId === 'vhs_retro'
                          ? 'linear-gradient(180deg, rgba(255,255,255,0.3) 0%, rgba(255,87,34,0.35) 100%)'
                          : 'linear-gradient(135deg, rgba(255,87,34,0.65) 0%, rgba(233,30,99,0.45) 100%)',
                }}
              />
              {selectedEffectOverlay && (
                <video
                  src={selectedEffectOverlay.videoUrl}
                  autoPlay
                  loop
                  playsInline
                  muted
                  aria-hidden="true"
                  className="pointer-events-none absolute inset-0 z-[5] h-full w-full object-cover opacity-45 mix-blend-screen"
                />
              )}
            </>
          )}

          {/* Estado de carga sin parpadeo mientras inicializa la cámara */}
          {isCameraLoading && (
            <div className="absolute inset-0 z-30 flex flex-col items-center justify-center gap-3 bg-black">
              <Loader2 className="h-9 w-9 animate-spin text-[#25F4EE]" />
              <p className="text-xs font-medium text-zinc-300">
                Inicializando cámara...
              </p>
            </div>
          )}

          {/* Pantalla minimalista cuando la cámara no está disponible en navegador */}
          {cameraPermissionError && !isCameraLoading && (
            <div className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-[#09090B] px-7 text-center">
              <button
                type="button"
                onClick={() => {
                  setIsRecording(false);
                  stopCameraStream();
                  onClose();
                }}
                aria-label="Cerrar cámara"
                className="absolute left-4 top-3.5 flex h-10 w-10 items-center justify-center rounded-full text-white/80 transition hover:bg-white/10 hover:text-white"
              >
                <X className="h-6 w-6" />
              </button>
              <div className="mb-6 flex h-24 w-24 items-center justify-center rounded-full border border-white/10 bg-white/[0.04] text-zinc-300">
                <VideoOff className="h-11 w-11 stroke-[1.5]" />
              </div>
              <p className="text-lg font-semibold tracking-tight text-white">
                Cámara en vista previa
              </p>
              <p className="mt-2 max-w-[260px] text-xs leading-relaxed text-zinc-400">
                Activa el permiso para usar tu cámara o continúa directamente con un clip de prueba o de tu galería.
              </p>

              <div className="mt-6 flex w-full max-w-[270px] flex-col gap-2.5">
                <button
                  type="button"
                  onClick={handleContinueWithoutCamera}
                  className="rounded-xl bg-[#FE2C55] px-4 py-3 text-xs font-bold text-white shadow-lg shadow-[#FE2C55]/20 transition hover:opacity-95 active:scale-[0.98]"
                >
                  Continuar sin cámara (para pruebas en web)
                </button>
                <button
                  type="button"
                  onClick={triggerSystemPicker}
                  className="rounded-xl border border-white/10 bg-white/[0.06] px-4 py-2.5 text-xs font-semibold text-zinc-200 transition hover:bg-white/10"
                >
                  Seleccionar de galería
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setCameraSnackBar(null);
                    setCameraRetryTick((t) => t + 1);
                  }}
                  className="rounded-xl py-2 text-xs font-medium text-zinc-400 transition hover:text-white"
                >
                  Solicitar permiso
                </button>
              </div>

              <p className="mt-5 max-w-[265px] text-[11px] leading-relaxed text-zinc-500">
                Nota: La cámara solo funciona en la app instalada en tu teléfono, no en la vista previa web.
              </p>

              {cameraSnackBar && (
                <p className="mt-2 max-w-[265px] text-[11px] leading-relaxed text-zinc-400">
                  {cameraSnackBar}
                </p>
              )}

              {showSettingsDialog && (
                <div
                  role="dialog"
                  aria-modal="true"
                  className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 px-6"
                >
                  <div className="w-full max-w-[300px] rounded-2xl border border-white/10 bg-[#1E1E1E] p-5 text-left shadow-2xl">
                    <h4 className="text-base font-bold text-white">
                      Permiso requerido
                    </h4>
                    <p className="mt-2 text-xs leading-relaxed text-zinc-300">
                      Ve a Ajustes para habilitar la cámara y el micrófono antes de grabar.
                    </p>
                    <div className="mt-4 flex justify-end gap-2">
                      <button
                        type="button"
                        onClick={() => setShowSettingsDialog(false)}
                        className="rounded-lg px-3 py-2 text-xs font-medium text-zinc-400 hover:text-white"
                      >
                        Cerrar
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setShowSettingsDialog(false);
                          setCameraSnackBar(
                            'Abre la configuración del sitio (ícono de candado) o los ajustes del teléfono para permitir cámara y micrófono.'
                          );
                        }}
                        className="rounded-lg bg-[#FE2C55] px-3.5 py-2 text-xs font-bold text-white"
                      >
                        Ir a Ajustes
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {showGridOverlay && (
            <div
              aria-hidden="true"
              className="pointer-events-none absolute inset-0 z-10 grid grid-cols-3 grid-rows-3"
            >
              {Array.from({ length: 9 }).map((_, idx) => (
                <div key={idx} className="border border-white/15" />
              ))}
            </div>
          )}

          {/* Barra Superior de Cámara */}
          <div className="relative z-20 flex items-center justify-between px-4 pt-3.5">
            <button
              type="button"
              onClick={() => {
                setIsRecording(false);
                stopCameraStream();
                onClose();
              }}
              aria-label="Cerrar cámara"
              className="flex h-10 w-10 items-center justify-center rounded-full text-white transition-opacity hover:opacity-75"
            >
              <X className="h-6 w-6" />
            </button>

            <button
              type="button"
              onClick={triggerSoundPicker}
              className={`inline-flex h-9 items-center gap-2 rounded-full px-4 text-xs font-medium text-white backdrop-blur-sm transition-colors ${
                selectedAudioName
                  ? 'bg-[#E91E63]/85 hover:bg-[#E91E63]'
                  : 'bg-white/10 hover:bg-white/20'
              }`}
            >
              <Music2 className="h-3.5 w-3.5" />
              <span className="max-w-[150px] truncate">
                {selectedAudioName ?? 'Agregar sonido'}
              </span>
            </button>

            <div className="w-10" aria-hidden="true" />
          </div>

          {/* Texto agregado mediante TEXTO */}
          {overlayText && (
            <div className="pointer-events-none absolute inset-0 z-10 flex items-center justify-center px-8">
              <button
                type="button"
                onClick={() => {
                  setDraftText(overlayText);
                  setTextModalOpen(true);
                }}
                className="pointer-events-auto rounded-xl bg-black/55 px-4 py-2 text-center text-2xl font-bold text-white backdrop-blur-sm"
              >
                {overlayText}
              </button>
            </div>
          )}

          {/* Indicador flotante de canción seleccionada, grabación o filtro/efecto activo */}
          {(selectedAudioName ||
            isRecording ||
            activeImageFilter !== 'none' ||
            selectedEffectId !== 'Ninguno' ||
            activeEffect) && (
            <div className="relative z-20 mt-3 flex flex-col items-center gap-1.5">
              {selectedAudioName && (
                <div className="inline-flex items-center gap-2 rounded-full border border-[#E91E63]/40 bg-black/65 px-3 py-1 text-xs font-semibold text-white backdrop-blur-sm">
                  <span>🎵 {selectedAudioName}</span>
                  <button
                    type="button"
                    aria-label="Quitar sonido"
                    onClick={() => {
                      stopCameraLoopAudio();
                      setSelectedSound(null);
                      setSelectedAudioUrl(null);
                      setSelectedAudioName(null);
                      setAudioName('');
                    }}
                    className="rounded-full p-0.5 text-white/70 hover:text-white"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              )}
              {(isRecording ||
                activeImageFilter !== 'none' ||
                selectedEffectId !== 'Ninguno' ||
                activeEffect) && (
                <span className="pointer-events-none rounded-full bg-black/55 px-3 py-1 text-xs font-semibold tracking-wide text-white/95 tabular-nums backdrop-blur-sm">
                  {isRecording
                    ? `Grabando 00:${String(recordSeconds).padStart(2, '0')}`
                    : activeImageFilter !== 'none'
                      ? `Filtro: ${currentImageFilter.label}`
                      : selectedEffectId !== 'Ninguno' && selectedEffectOverlay
                        ? `Efecto: ${selectedEffectOverlay.name}`
                        : activeEffect}
                </span>
              )}
            </div>
          )}

          {/* Barra Lateral Derecha de Herramientas */}
          <div className="absolute right-3.5 top-20 z-20 flex flex-col items-center gap-4">
            <button
              type="button"
              onClick={handleFlipCamera}
              aria-label="Voltear cámara"
              className="flex h-9 w-9 items-center justify-center text-white transition-transform active:scale-90"
            >
              <SwitchCamera className="h-6 w-6" />
            </button>
            <button
              type="button"
              onClick={() => setEffectsSheetOpen(true)}
              aria-label="Efectos"
              className={`flex h-9 w-9 items-center justify-center transition-transform active:scale-90 ${
                selectedEffectOverlay ? 'text-[#25F4EE]' : 'text-white'
              }`}
            >
              <Sparkles className="h-6 w-6" />
            </button>
            <button
              type="button"
              onClick={() =>
                setActiveEffect((prev) => (prev === 'Temporizador 3s' ? null : 'Temporizador 3s'))
              }
              aria-label="Temporizador"
              className={`flex h-9 w-9 items-center justify-center transition-transform active:scale-90 ${
                activeEffect === 'Temporizador 3s' ? 'text-[#25F4EE]' : 'text-white'
              }`}
            >
              <Timer className="h-6 w-6" />
            </button>
            <button
              type="button"
              onClick={() => setShowGridOverlay((prev) => !prev)}
              aria-label="Cuadrícula"
              className={`flex h-9 w-9 items-center justify-center transition-transform active:scale-90 ${
                showGridOverlay ? 'text-[#25F4EE]' : 'text-white'
              }`}
            >
              <Grid3x3 className="h-6 w-6" />
            </button>
            <button
              type="button"
              onClick={() => setActiveEffect('Modo Dúo')}
              aria-label="Invitar amigo"
              className="flex h-9 w-9 items-center justify-center text-white transition-transform active:scale-90"
            >
              <UserPlus className="h-6 w-6" />
            </button>
            <button
              type="button"
              onClick={() => setFilterTrayOpen((prev) => !prev)}
              aria-label="Filtros de imagen"
              className={`flex h-9 w-9 items-center justify-center transition-transform active:scale-90 ${
                activeImageFilter !== 'none' || filterTrayOpen
                  ? 'text-[#25F4EE]'
                  : 'text-white'
              }`}
            >
              <Filter className="h-6 w-6" />
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveEffect(null);
                setFilterTrayOpen((prev) => !prev);
              }}
              aria-label="Más herramientas"
              className="flex h-9 w-9 items-center justify-center text-white/80"
            >
              <ChevronDown className="h-6 w-6" />
            </button>
          </div>

          {/* Controles Inferiores */}
          <div className="relative z-20 mt-auto pb-5 pt-4 flex flex-col gap-4">
            {/* Selector de Filtros CSS en Tiempo Real (Normal, B&W, Vintage, Neon) */}
            {filterTrayOpen && (
              <div className="mx-auto flex items-center gap-2 rounded-2xl border border-white/15 bg-black/70 px-3 py-2 backdrop-blur-md">
                {CAMERA_IMAGE_FILTERS.map((filterOption) => {
                  const isActive = activeImageFilter === filterOption.id;
                  return (
                    <button
                      key={filterOption.id}
                      type="button"
                      onClick={() =>
                        setActiveImageFilter((prev) =>
                          prev === filterOption.id && filterOption.id !== 'none'
                            ? 'none'
                            : filterOption.id
                        )
                      }
                      className={`flex flex-col items-center gap-1 rounded-xl px-2.5 py-1.5 transition-colors ${
                        isActive
                          ? 'bg-white/20 text-[#25F4EE]'
                          : 'text-white/75 hover:bg-white/10 hover:text-white'
                      }`}
                    >
                      <span
                        aria-hidden="true"
                        style={filterOption.swatchStyle}
                        className={`h-6 w-6 rounded-lg border ${
                          isActive ? 'border-[#25F4EE]' : 'border-white/25'
                        }`}
                      />
                      <span className="text-[10.5px] font-bold tracking-tight">
                        {filterOption.label}
                      </span>
                    </button>
                  );
                })}
              </div>
            )}
            {/* Selector de tiempo y acciones (10 min, 60 s, 15 s, FOTO, TEXTO) */}
            <div className="flex items-center justify-center gap-2">
              {(['10 min', '60 s', '15 s'] as const).map((option) => {
                const isSelected = selectedDuration === option;
                return (
                  <button
                    key={option}
                    type="button"
                    onClick={() => setSelectedDuration(option)}
                    className={`rounded-md px-2.5 py-1 text-[13px] transition-colors ${
                      isSelected
                        ? 'bg-white/20 font-bold text-white'
                        : 'font-normal text-white/55 hover:text-white/85'
                    }`}
                  >
                    {option}
                  </button>
                );
              })}

              <button
                type="button"
                onClick={triggerSystemPicker}
                className="rounded-md px-2.5 py-1 text-[13px] font-bold text-white hover:bg-white/10"
              >
                FOTO
              </button>

              <button
                type="button"
                onClick={() => {
                  setDraftText(overlayText);
                  setTextModalOpen(true);
                }}
                className="rounded-md px-2.5 py-1 text-[13px] font-bold text-white hover:bg-white/10"
              >
                TEXTO
              </button>
            </div>

            {/* Galería | Botón Grabar | Efectos */}
            <div className="flex items-center justify-evenly px-6">
              <button
                type="button"
                onClick={triggerSystemPicker}
                aria-label="Abrir galería nativa"
                className="flex flex-col items-center gap-1 transition-transform active:scale-95"
              >
                <div className="h-11 w-11 overflow-hidden rounded-lg border border-white/30 bg-zinc-800">
                  <img
                    src="/src/assets/images/avatar_creator_mateo_1794604321715.jpg"
                    alt="Galería"
                    referrerPolicy="no-referrer"
                    className="h-full w-full object-cover"
                  />
                </div>
                <span className="text-[11px] font-medium text-white">Galería</span>
              </button>

              <button
                type="button"
                onClick={handleToggleRecord}
                aria-label={isRecording ? 'Detener grabación' : 'Grabar video'}
                className="flex h-20 w-20 items-center justify-center rounded-full border-4 border-white transition-transform active:scale-95"
              >
                <span
                  className={`transition-all duration-150 ${
                    isRecording
                      ? 'h-7 w-7 rounded-md bg-[#FE2C55]'
                      : 'h-[60px] w-[60px] rounded-full bg-red-500'
                  }`}
                />
              </button>

              <button
                type="button"
                onClick={() => setEffectsSheetOpen(true)}
                aria-label="Galería de efectos visuales"
                className="flex flex-col items-center gap-1 transition-transform active:scale-95"
              >
                <div
                  className={`flex h-11 w-11 items-center justify-center overflow-hidden rounded-full border bg-zinc-800 ${
                    selectedEffectOverlay
                      ? 'border-2 border-[#25F4EE] bg-gradient-to-br from-[#25F4EE]/30 to-[#E91E63]/30'
                      : 'border-white/40 bg-zinc-900'
                  }`}
                >
                  <Sparkles
                    className={`h-5 w-5 ${
                      selectedEffectOverlay ? 'text-[#25F4EE]' : 'text-white'
                    }`}
                  />
                </div>
                <span
                  className={`text-[11px] font-medium ${
                    selectedEffectOverlay ? 'text-[#25F4EE]' : 'text-white'
                  }`}
                >
                  {selectedEffectOverlay ? 'Activo' : 'Efectos'}
                </span>
              </button>
            </div>

            {/* Tabs inferiores (Sin LIVE: solo CÁMARA y CREAR) */}
            <div className="flex items-center justify-evenly px-12">
              {(['CÁMARA', 'CREAR'] as const).map((mode) => {
                const isSelected = cameraMode === mode;
                return (
                  <button
                    key={mode}
                    type="button"
                    onClick={() => {
                      setCameraMode(mode);
                      if (mode === 'CREAR') {
                        triggerSystemPicker();
                      }
                    }}
                    className={`min-h-[36px] text-sm font-bold tracking-wide transition-colors ${
                      isSelected ? 'text-white' : 'text-white/55 hover:text-white/85'
                    }`}
                  >
                    {mode}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Tarjetica modal de TEXTO ("Escribe tu texto") */}
          {textModalOpen && (
            <div className="absolute inset-0 z-40 flex flex-col justify-end bg-black/55">
              <button
                type="button"
                aria-label="Cerrar tarjetica de texto"
                onClick={() => setTextModalOpen(false)}
                className="flex-1 w-full cursor-default"
              />
              <form
                onSubmit={handleConfirmText}
                className="rounded-t-[20px] bg-[#2C2C2C] px-4 pb-5 pt-5 text-white shadow-2xl"
              >
                <h3 className="text-center text-lg font-bold text-white">Escribe tu texto</h3>
                <input
                  type="text"
                  autoFocus
                  value={draftText}
                  onChange={(e) => setDraftText(e.target.value)}
                  placeholder="Escribe aquí..."
                  className="mt-4 w-full bg-transparent text-center text-2xl font-semibold text-white placeholder:text-white/50 focus:outline-none"
                />
                <button
                  type="submit"
                  className="mt-5 flex h-12 w-full items-center justify-center rounded-xl bg-red-500 text-base font-bold text-white transition-opacity hover:opacity-95"
                >
                  Listo
                </button>
              </form>
            </div>
          )}

          {/* Bottom Sheet: Galería de Sonidos (Música Jamendo / Efectos Freesound) */}
          {soundSheetOpen && (
            <div className="absolute inset-0 z-40 flex flex-col justify-end bg-black/65">
              <button
                type="button"
                aria-label="Cerrar galería de sonidos"
                onClick={() => {
                  stopPreviewAudio();
                  setSoundSheetOpen(false);
                }}
                className="flex-1 w-full cursor-default"
              />
              <div className="flex max-h-[76%] flex-col rounded-t-[22px] bg-[#121212] px-4 pb-5 pt-3 text-white shadow-2xl border-t border-white/10">
                <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-white/25" />
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-bold text-white">
                    Sonidos libres de derechos
                  </h3>
                  <button
                    type="button"
                    onClick={() => {
                      stopPreviewAudio();
                      setSoundSheetOpen(false);
                    }}
                    className="rounded-full p-1 text-white/60 hover:text-white"
                  >
                    <X className="h-5 w-5" />
                  </button>
                </div>

                <div className="mt-3 flex items-center gap-2 rounded-xl bg-[#1E1E1E] px-3 py-2">
                  <Search className="h-4 w-4 text-white/45" />
                  <input
                    type="text"
                    value={soundQuery}
                    onChange={(e) => setSoundQuery(e.target.value)}
                    placeholder="Buscar en Jamendo o Freesound..."
                    className="w-full bg-transparent text-xs text-white placeholder:text-white/40 focus:outline-none"
                  />
                </div>

                <div className="mt-3 grid grid-cols-2 border-b border-white/10">
                  <button
                    type="button"
                    onClick={() => setSoundTab('music')}
                    className={`border-b-2 py-2 text-xs font-bold transition-colors ${
                      soundTab === 'music'
                        ? 'border-[#E91E63] text-white'
                        : 'border-transparent text-white/55'
                    }`}
                  >
                    Música (Jamendo)
                  </button>
                  <button
                    type="button"
                    onClick={() => setSoundTab('sfx')}
                    className={`border-b-2 py-2 text-xs font-bold transition-colors ${
                      soundTab === 'sfx'
                        ? 'border-[#E91E63] text-white'
                        : 'border-transparent text-white/55'
                    }`}
                  >
                    Efectos (Freesound)
                  </button>
                </div>

                <div className="mt-3 flex-1 space-y-2.5 overflow-y-auto pr-0.5">
                  {filteredSounds.map((sound) => {
                    const isPlaying = playingSoundId === sound.id;
                    const isChosen = selectedSound?.id === sound.id;
                    return (
                      <div
                        key={sound.id}
                        className={`flex items-center gap-3 rounded-xl border p-2.5 bg-[#1E1E1E] ${
                          isChosen ? 'border-[#E91E63]' : 'border-white/10'
                        }`}
                      >
                        <button
                          type="button"
                          onClick={() => handleTogglePlaySound(sound)}
                          aria-label={isPlaying ? 'Detener' : 'Reproducir'}
                          className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-white ${
                            isPlaying
                              ? 'bg-gradient-to-br from-[#FF5722] to-[#E91E63]'
                              : 'bg-white/10 hover:bg-white/15'
                          }`}
                        >
                          {isPlaying ? (
                            <Square className="h-4 w-4 fill-white" />
                          ) : (
                            <Play className="h-4 w-4 fill-white ml-0.5" />
                          )}
                        </button>
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-xs font-bold text-white">
                            {sound.title}
                          </p>
                          <p className="truncate text-[11px] text-white/60">
                            {sound.artist} · {sound.duration}
                          </p>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleTogglePlaySound(sound)}
                          className="text-[11px] font-semibold text-[#25F4EE] hover:underline"
                        >
                          {isPlaying ? 'Detener' : 'Reproducir'}
                        </button>
                        <button
                          type="button"
                          onClick={() => handleUseSound(sound)}
                          className="rounded-lg bg-[#E91E63] px-2.5 py-1.5 text-[11px] font-bold text-white hover:opacity-95"
                        >
                          Usar
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* Bottom Sheet: Galería de Efectos Visuales (Overlays MP4) */}
          {effectsSheetOpen && (
            <div className="absolute inset-0 z-40 flex flex-col justify-end bg-black/65">
              <button
                type="button"
                aria-label="Cerrar galería de efectos"
                onClick={() => setEffectsSheetOpen(false)}
                className="flex-1 w-full cursor-default"
              />
              <div className="flex max-h-[62%] flex-col rounded-t-[22px] bg-[#121212] px-4 pb-5 pt-3 text-white shadow-2xl border-t border-white/10">
                <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-white/25" />
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-bold text-white">
                    Efectos visuales (Overlays)
                  </h3>
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedEffectId('Ninguno');
                      setSelectedEffectOverlay(null);
                      setEffectsSheetOpen(false);
                    }}
                    className="text-xs font-bold text-[#E91E63]"
                  >
                    Quitar efecto
                  </button>
                </div>

                <div className="mt-4 grid grid-cols-3 gap-2.5 overflow-y-auto">
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedEffectId('Ninguno');
                      setSelectedEffectOverlay(null);
                      setEffectsSheetOpen(false);
                    }}
                    className={`flex aspect-[4/5] flex-col items-center justify-center gap-2 rounded-xl border bg-[#1E1E1E] ${
                      selectedEffectId === 'Ninguno'
                        ? 'border-2 border-[#25F4EE]'
                        : 'border-white/10'
                    }`}
                  >
                    <Ban className="h-6 w-6 text-white/70" />
                    <span className="text-[11px] font-semibold text-white">
                      Ninguno
                    </span>
                  </button>

                  {VISUAL_EFFECT_OVERLAYS.map((effect) => {
                    const isSelected = selectedEffectId === effect.id;
                    return (
                      <button
                        key={effect.id}
                        type="button"
                        onClick={() => {
                          setSelectedEffectId(effect.id);
                          setSelectedEffectOverlay(effect);
                          setEffectsSheetOpen(false);
                        }}
                        className="flex flex-col items-center gap-1.5 text-left"
                      >
                        <div
                          className={`relative flex aspect-[4/5] w-full items-center justify-center overflow-hidden rounded-xl border ${
                            isSelected
                              ? 'border-2 border-[#25F4EE]'
                              : 'border-white/15'
                          }`}
                          style={{
                            background:
                              effect.id === 'light_leaks'
                                ? 'linear-gradient(135deg, #FF6B35 0%, #E91E63 100%)'
                                : effect.id === 'neon_particles'
                                  ? 'linear-gradient(135deg, #25F4EE 0%, #673AB7 100%)'
                                  : effect.id === 'bokeh_nights'
                                    ? 'linear-gradient(135deg, #E91E63 0%, #38BDF8 100%)'
                                    : 'linear-gradient(135deg, #F59E0B 0%, #EF4444 100%)',
                          }}
                        >
                          <Sparkles className="h-7 w-7 text-white/90" />
                          <span className="absolute left-1.5 top-1.5 rounded bg-black/70 px-1.5 py-0.5 text-[9px] font-bold text-[#25F4EE]">
                            {effect.tag}
                          </span>
                        </div>
                        <span
                          className={`w-full truncate text-center text-[11px] ${
                            isSelected
                              ? 'font-bold text-[#25F4EE]'
                              : 'font-medium text-white'
                          }`}
                        >
                          {effect.name}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {step === 'publish' && (
        <>
          <div className="absolute inset-0">
            {previewUrl && (
              <video
                src={previewUrl}
                autoPlay
                loop
                playsInline
                muted
                style={{
                  filter:
                    currentImageFilter.id !== 'none'
                      ? currentImageFilter.css
                      : undefined,
                }}
                className="h-full w-full object-cover"
              />
            )}
            {currentImageFilter.id !== 'none' && (
              <div
                aria-hidden="true"
                className={`pointer-events-none absolute inset-0 ${currentImageFilter.overlayClass}`}
              />
            )}
            {selectedEffectId !== 'Ninguno' && (
              <>
                <div
                  aria-hidden="true"
                  className="pointer-events-none absolute inset-0 opacity-40 mix-blend-screen"
                  style={{
                    background:
                      selectedEffectId === 'neon_particles'
                        ? 'linear-gradient(135deg, rgba(37,244,238,0.6) 0%, rgba(233,30,99,0.5) 100%)'
                        : selectedEffectId === 'bokeh_nights'
                          ? 'linear-gradient(135deg, rgba(103,58,183,0.65) 0%, rgba(233,30,99,0.5) 100%)'
                          : selectedEffectId === 'vhs_retro'
                            ? 'linear-gradient(180deg, rgba(255,255,255,0.3) 0%, rgba(255,87,34,0.35) 100%)'
                            : 'linear-gradient(135deg, rgba(255,87,34,0.65) 0%, rgba(233,30,99,0.45) 100%)',
                  }}
                />
                {selectedEffectOverlay && (
                  <video
                    src={selectedEffectOverlay.videoUrl}
                    autoPlay
                    loop
                    playsInline
                    muted
                    aria-hidden="true"
                    className="pointer-events-none absolute inset-0 h-full w-full object-cover opacity-45 mix-blend-screen"
                  />
                )}
              </>
            )}
          </div>

          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-0"
            style={{
              background:
                'linear-gradient(180deg, rgba(0,0,0,0.55) 0%, rgba(0,0,0,0) 22%, rgba(0,0,0,0) 50%, rgba(0,0,0,0.88) 100%)',
            }}
          />

          <div className="relative z-20 flex items-center justify-between px-3.5 pt-3.5">
            <button
              type="button"
              onClick={() => {
                if (isUploading) return;
                setStep('camera');
                setPreviewUrl(null);
                setTempFilePath(null);
              }}
              disabled={isUploading}
              aria-label="Volver atrás"
              className="flex h-11 w-11 items-center justify-center rounded-full bg-black/35 text-white backdrop-blur-sm transition-colors hover:bg-black/60 disabled:opacity-40"
            >
              <ChevronLeft className="h-6 w-6" />
            </button>

            {tempFilePath && (
              <span className="max-w-[180px] truncate rounded-full bg-black/45 px-3 py-1 text-[10px] font-mono text-zinc-200 backdrop-blur-sm">
                Previsualización · {tempFilePath.split('/').pop()}
              </span>
            )}

            {!isUploading && (
              <button
                type="button"
                onClick={triggerSystemPicker}
                className="inline-flex h-10 items-center gap-1.5 rounded-full bg-black/45 px-3.5 text-xs font-medium text-white backdrop-blur-sm hover:bg-black/65"
              >
                <RefreshCw className="h-3.5 w-3.5" />
                <span>Cambiar</span>
              </button>
            )}
          </div>

          <form
            onSubmit={handlePublish}
            className="relative z-20 mt-auto flex flex-col gap-3 px-4 pb-6 pt-4"
          >
            <div className="flex items-center gap-2">
              <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-zinc-800 text-xs font-bold text-white">
                {currentUsername.slice(0, 1).toUpperCase()}
              </div>
              <span className="truncate text-sm font-bold text-white">
                {currentUsername}
              </span>
            </div>

            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              disabled={isUploading}
              placeholder="Describe tu video y agrega hashtags (ej. #humor #baile #musica)"
              className="w-full resize-none border-b border-white/20 bg-transparent pb-2 text-[14.5px] leading-snug text-white placeholder:text-white/55 focus:border-white/70 focus:outline-none"
            />

            <div className="flex items-center gap-2 border-b border-white/20 pb-2 focus-within:border-white/70">
              <Music2 className="h-4 w-4 shrink-0 text-white/80" />
              <input
                type="text"
                value={audioName}
                onChange={(e) => setAudioName(e.target.value)}
                disabled={isUploading}
                placeholder="Nombre del audio (opcional)"
                className="w-full bg-transparent text-sm text-white placeholder:text-white/60 focus:outline-none"
              />
            </div>

            {isUploading && (
              <div className="space-y-1.5 pt-1">
                <div className="h-1 w-full overflow-hidden rounded-full bg-white/20">
                  <div
                    className="h-full bg-[#FE2C55] transition-all duration-150"
                    style={{ width: `${uploadProgress}%` }}
                  />
                </div>
                <p className="text-right text-[11px] font-medium text-white/80 tabular-nums">
                  Publicando... {uploadProgress}%
                </p>
              </div>
            )}

            <button
              type="submit"
              disabled={!previewUrl || isUploading || !description.trim()}
              className="mt-1 flex h-12 w-full items-center justify-center rounded-xl bg-[#FE2C55] text-[15px] font-bold text-white shadow-lg shadow-[#FE2C55]/25 transition-all active:scale-[0.98] disabled:cursor-not-allowed disabled:bg-[#FE2C55]/35 disabled:text-white/50 disabled:shadow-none"
            >
              {isUploading ? 'Publicando...' : 'Publicar'}
            </button>
          </form>
        </>
      )}
    </div>
  );
};
