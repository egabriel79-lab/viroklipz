import React, { useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  ChevronRight,
  Eye,
  EyeOff,
  FileText,
  Settings,
  SlidersHorizontal,
  X,
} from 'lucide-react';
import { CoinBadge } from './GetCoinsScreen';
import { TransactionHistoryScreen } from './TransactionHistoryScreen';

interface BalanceScreenProps {
  onBack: () => void;
  onOpenGetCoins: () => void;
  onNotify?: (message: string) => void;
}

let hasShownBalanceIntroSheet = false;

export const BalanceScreen: React.FC<BalanceScreenProps> = ({
  onBack,
  onOpenGetCoins,
  onNotify,
}) => {
  const [showBalance, setShowBalance] = useState(true);
  const [showTransactionHistory, setShowTransactionHistory] = useState(false);
  const [showInfoSheet, setShowInfoSheet] = useState(() => {
    if (!hasShownBalanceIntroSheet) {
      hasShownBalanceIntroSheet = true;
      return true;
    }
    return false;
  });

  if (showTransactionHistory) {
    return (
      <TransactionHistoryScreen
        onBack={() => setShowTransactionHistory(false)}
        onNotify={onNotify}
      />
    );
  }

  return (
    <div className="relative flex h-full w-full flex-col bg-gradient-to-b from-[#FFF1F4] via-[#F7F5FC] to-[#F4F4F5] text-zinc-950 select-none overflow-hidden">
      {/* AppBar */}
      <header className="flex h-12 shrink-0 items-center justify-between px-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Atrás"
          className="flex h-10 w-10 items-center justify-center rounded-full text-zinc-900 transition-colors hover:bg-black/5"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>

        <h1 className="text-[15.5px] font-bold tracking-tight text-zinc-950">
          Saldo
        </h1>

        <button
          type="button"
          onClick={() => setShowInfoSheet(true)}
          aria-label="Configuración y filtros de saldo"
          className="flex h-10 w-10 items-center justify-center rounded-full text-zinc-800 transition-colors hover:bg-black/5"
        >
          <Settings className="h-5 w-5" />
        </button>
      </header>

      {/* Cuerpo */}
      <main className="flex-1 min-h-0 overflow-y-auto px-4 pt-3 pb-6 space-y-4 no-scrollbar">
        {/* Saldo estimado VES */}
        <section className="px-1 pt-1 pb-2">
          <div className="flex items-center gap-1.5 text-xs font-medium text-zinc-600">
            <span>Saldo estimado VES</span>
            <button
              type="button"
              onClick={() => setShowBalance((prev) => !prev)}
              aria-label={showBalance ? 'Ocultar saldo' : 'Mostrar saldo'}
              className="rounded-full p-1 text-zinc-500 transition-colors hover:bg-black/5 hover:text-zinc-900"
            >
              {showBalance ? (
                <Eye className="h-4 w-4" />
              ) : (
                <EyeOff className="h-4 w-4" />
              )}
            </button>
          </div>

          <button
            type="button"
            onClick={onOpenGetCoins}
            className="mt-1.5 flex w-full items-center justify-between text-left group"
          >
            <span className="text-[34px] leading-none font-extrabold tracking-tight text-zinc-950 tabular-nums">
              {showBalance ? '0.00' : '••••'}
            </span>
            <ChevronRight className="h-5 w-5 text-zinc-400 transition-transform group-hover:translate-x-0.5 group-hover:text-zinc-800" />
          </button>
        </section>

        {/* Tarjeta 1: Monedas */}
        <section className="rounded-2xl border border-zinc-200/70 bg-white p-4 shadow-sm">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-amber-50">
                <CoinBadge size="md" />
              </div>
              <div>
                <p className="text-xs font-semibold text-zinc-500">Monedas</p>
                <p className="mt-0.5 text-2xl leading-none font-extrabold text-zinc-950 tabular-nums">
                  {showBalance ? '0' : '••'}
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={onOpenGetCoins}
              className="flex shrink-0 items-center gap-1 rounded-lg px-2.5 py-1.5 text-xs font-bold text-[#FE2C55] transition-colors hover:bg-rose-50"
            >
              <span>Obtener Monedas</span>
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </section>

        {/* Tarjeta 2: Transacciones */}
        <button
          type="button"
          onClick={() => setShowTransactionHistory(true)}
          className="flex w-full items-center justify-between rounded-2xl border border-zinc-200/70 bg-white p-4 text-left shadow-sm transition-colors hover:bg-zinc-50/90 active:scale-[0.99]"
        >
          <span className="text-sm font-bold text-zinc-950">Transacciones</span>
          <span className="flex items-center gap-0.5 text-xs font-semibold text-zinc-500">
            Ver todo
            <ChevronRight className="h-4 w-4 text-zinc-400" />
          </span>
        </button>
      </main>

      {/* Parte 2: Bottom Sheet Informativo */}
      {showInfoSheet && (
        <div
          className="absolute inset-0 z-30 flex items-end bg-black/45"
          onClick={() => setShowInfoSheet(false)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full rounded-t-3xl bg-white px-5 pt-4 pb-6 text-center shadow-2xl"
          >
            <div className="flex justify-end">
              <button
                type="button"
                onClick={() => setShowInfoSheet(false)}
                aria-label="Cerrar aviso"
                className="flex h-8 w-8 items-center justify-center rounded-full text-zinc-500 transition-colors hover:bg-zinc-100 hover:text-zinc-900"
              >
                <X className="h-4.5 w-4.5" />
              </button>
            </div>

            {/* Ilustración central: documento con filtro */}
            <div className="mx-auto mt-1 flex h-20 w-20 items-center justify-center rounded-2xl bg-gradient-to-br from-rose-50 to-purple-50 border border-rose-100/80 relative">
              <FileText className="h-10 w-10 text-zinc-800 stroke-[1.6]" />
              <div className="absolute -right-1.5 -bottom-1.5 flex h-8 w-8 items-center justify-center rounded-full bg-[#FE2C55] text-white shadow-md ring-4 ring-white">
                <SlidersHorizontal className="h-3.5 w-3.5" />
              </div>
            </div>

            <h2 className="mt-5 text-[17px] font-extrabold tracking-tight text-zinc-950">
              Administra mejor tus transacciones
            </h2>
            <p className="mt-2 px-2 text-xs leading-relaxed text-zinc-500">
              Filtra tus transacciones por tipos de transacción o tipos de
              actividad.
            </p>

            <button
              type="button"
              onClick={() => setShowInfoSheet(false)}
              className="mt-6 w-full rounded-xl bg-[#FE2C55] py-3.5 text-sm font-bold text-white shadow-md shadow-[#FE2C55]/25 transition-opacity hover:opacity-95 active:scale-[0.99]"
            >
              Entendido
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
