import React, { useState } from 'react';
import { ArrowLeft, ChevronRight } from 'lucide-react';

interface ReuseContentScreenProps {
  onBack: () => void;
  onNotify?: (message: string) => void;
}

export const ReuseContentScreen: React.FC<ReuseContentScreenProps> = ({
  onBack,
  onNotify,
}) => {
  const [audience, setAudience] = useState<'Todo el m...' | 'Seguidores' | 'Solo tú'>('Todo el m...');

  const cycleAudience = () => {
    const order: Array<'Todo el m...' | 'Seguidores' | 'Solo tú'> = [
      'Todo el m...',
      'Seguidores',
      'Solo tú',
    ];
    const next = order[(order.indexOf(audience) + 1) % order.length];
    setAudience(next);
    onNotify?.(`Reutilizar contenido: ${next === 'Todo el m...' ? 'Todo el mundo' : next}`);
  };

  return (
    <div className="flex h-full w-full flex-col bg-[#121212] text-white select-none overflow-hidden">
      <header className="relative flex h-12 shrink-0 items-center justify-center border-b border-white/10 bg-[#121212] px-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Atrás"
          className="absolute left-2 flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="text-[15px] font-bold text-white">Reutilizar contenido</h1>
      </header>

      <div className="flex-1 min-h-0 overflow-y-auto px-4 py-4 no-scrollbar">
        <div className="divide-y divide-white/5 overflow-hidden rounded-xl bg-[#1E1E1E]">
          <button
            type="button"
            onClick={cycleAudience}
            className="flex w-full items-start justify-between gap-3 px-4 py-4 text-left transition-colors hover:bg-white/5"
          >
            <div className="min-w-0 flex-1">
              <p className="text-[14px] font-medium text-white">
                Permite reutilizar contenido desde
              </p>
              <p className="mt-1 text-xs leading-relaxed text-zinc-400">
                Elige quién puede hacer dúos, pegar o crear stickers con tus videos y fotos públicas.
              </p>
            </div>
            <div className="flex shrink-0 items-center gap-1 pt-0.5">
              <span className="text-xs text-zinc-400">{audience}</span>
              <ChevronRight className="h-4 w-4 text-zinc-500" />
            </div>
          </button>

          <button
            type="button"
            onClick={() => onNotify?.('Historial de reutilización de contenido')}
            className="flex w-full items-start justify-between gap-3 px-4 py-4 text-left transition-colors hover:bg-white/5"
          >
            <div className="min-w-0 flex-1">
              <p className="text-[14px] font-medium text-white">
                Historial de reutilización de contenido
              </p>
              <p className="mt-1 text-xs leading-relaxed text-zinc-400">
                Consulta qué creadores utilizaron tus clips o audios en sus propias publicaciones.
              </p>
            </div>
            <ChevronRight className="mt-0.5 h-4 w-4 shrink-0 text-zinc-500" />
          </button>
        </div>
      </div>
    </div>
  );
};
