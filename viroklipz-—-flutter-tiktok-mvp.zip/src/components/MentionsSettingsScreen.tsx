import React from 'react';
import { ArrowLeft, ChevronRight } from 'lucide-react';

interface MentionsSettingsScreenProps {
  onBack: () => void;
  onNotify?: (message: string) => void;
}

export const MentionsSettingsScreen: React.FC<MentionsSettingsScreenProps> = ({
  onBack,
  onNotify,
}) => {
  return (
    <div className="flex h-full w-full flex-col bg-[#121212] text-white select-none overflow-hidden">
      {/* AppBar */}
      <header className="relative flex h-12 shrink-0 items-center justify-center border-b border-white/10 bg-[#121212] px-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Atrás"
          className="absolute left-2 flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="text-[15px] font-bold text-white">Menciones</h1>
      </header>

      {/* Cuerpo */}
      <div className="flex-1 min-h-0 overflow-y-auto px-4 py-5 no-scrollbar">
        <button
          type="button"
          onClick={() => onNotify?.('Menciones: Todo el mundo')}
          className="w-full rounded-xl bg-[#1E1E1E] p-4 text-left transition-colors hover:bg-white/[0.04]"
        >
          <div className="flex items-center justify-between gap-3">
            <span className="text-[14px] font-semibold text-white">
              Permite las menciones desde
            </span>
            <div className="flex shrink-0 items-center gap-1.5">
              <span className="text-xs text-zinc-400">Todo el m...</span>
              <ChevronRight className="h-4 w-4 text-zinc-500" />
            </div>
          </div>
          <p className="mt-2 text-xs leading-relaxed text-zinc-400">
            Elige quién puede mencionarte en sus descripciones, stickers,
            comentarios y Stories
          </p>
        </button>
      </div>
    </div>
  );
};
