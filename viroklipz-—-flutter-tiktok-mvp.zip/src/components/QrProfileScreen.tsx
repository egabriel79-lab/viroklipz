import React, { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import {
  ArrowLeft,
  Check,
  Flashlight,
  Link2,
  QrCode,
  ScanLine,
  Share2,
  Sparkles,
  X,
} from 'lucide-react';

interface QrProfileScreenProps {
  nombreUsuario: string;
  arroba: string;
  avatarUrl: string;
  onBack: () => void;
  onOpenScannedProfile?: (username: string) => void;
  onNotify?: (message: string) => void;
}

export const QrProfileScreen: React.FC<QrProfileScreenProps> = ({
  nombreUsuario,
  arroba,
  avatarUrl,
  onBack,
  onOpenScannedProfile,
  onNotify,
}) => {
  const cleanHandle = arroba.startsWith('@') ? arroba : `@${arroba}`;
  const profileUrl = `https://viroklipz.app/profile/${cleanHandle}`;

  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [copied, setCopied] = useState(false);
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [isTorchOn, setIsTorchOn] = useState(false);
  const [isShareSheetOpen, setIsShareSheetOpen] = useState(false);

  useEffect(() => {
    let active = true;
    QRCode.toDataURL(profileUrl, {
      width: 240,
      margin: 1,
      errorCorrectionLevel: 'M',
      color: {
        dark: '#0A1329',
        light: '#FFFFFF',
      },
    })
      .then((url) => {
        if (active) setQrDataUrl(url);
      })
      .catch(() => {
        if (active) setQrDataUrl('');
      });

    return () => {
      active = false;
    };
  }, [profileUrl]);

  const handleCopyLink = async () => {
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(profileUrl);
      }
    } catch {
      // Fallback silencioso en iframes con permisos restringidos
    }
    setCopied(true);
    onNotify?.('Enlace copiado al portapapeles');
    window.setTimeout(() => setCopied(false), 2000);
  };

  const handleShareLink = async () => {
    if (typeof navigator !== 'undefined' && navigator.share) {
      try {
        await navigator.share({
          title: `${nombreUsuario} (${cleanHandle}) en Viroklipz`,
          text: `¡Mira mi perfil en Viroklipz! ${profileUrl}`,
          url: profileUrl,
        });
        return;
      } catch {
        // Si el usuario cancela o el iframe bloquea Web Share, abrimos hoja simulada
      }
    }
    setIsShareSheetOpen(true);
  };

  return (
    <div
      className="relative flex h-full w-full flex-col text-white select-none overflow-hidden"
      style={{
        background:
          'linear-gradient(160deg, #061026 0%, #0D2558 48%, #091736 100%)',
      }}
    >
      {/* AppBar superior */}
      <header className="flex h-12 shrink-0 items-center justify-between px-2 pt-1">
        <button
          type="button"
          onClick={onBack}
          aria-label="Volver al perfil"
          className="flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>

        <span className="text-sm font-semibold tracking-wide text-white/90">
          Código QR
        </span>

        <button
          type="button"
          onClick={() => {
            setIsTorchOn(false);
            setIsScannerOpen(true);
          }}
          aria-label="Escanear código QR"
          className="flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ScanLine className="h-5 w-5" />
        </button>
      </header>

      {/* Contenido central centrado y seguro contra desbordamiento */}
      <div className="flex flex-1 min-h-0 overflow-y-auto px-5 py-3 no-scrollbar">
        <div className="my-auto mx-auto flex w-full max-w-[276px] flex-col items-center pt-10 pb-2">
          {/* Tarjeta blanca ajustada al contenido con padding uniforme (24px) */}
          <div className="relative w-full rounded-3xl bg-white p-6 text-center text-zinc-950 shadow-[0_24px_60px_rgba(0,0,0,0.45)]">
            {/* Avatar superpuesto sin salirse de los límites */}
            <div className="absolute -top-9 left-1/2 -translate-x-1/2">
              <div className="h-[72px] w-[72px] overflow-hidden rounded-full border-4 border-white bg-zinc-200 shadow-lg">
                <img
                  src={avatarUrl}
                  alt={`Avatar de ${nombreUsuario}`}
                  className="h-full w-full object-cover"
                />
              </div>
            </div>

            <div className="pt-5">
              <h1 className="text-xl font-extrabold tracking-tight text-zinc-950">
                {nombreUsuario}
              </h1>
              <p className="mt-0.5 text-xs font-medium text-zinc-500">
                {cleanHandle}
              </p>

              {/* Contenedor del QR compacto con padding alrededor */}
              <div className="mx-auto mt-3.5 flex h-[176px] w-[176px] items-center justify-center rounded-2xl border border-zinc-100 bg-white p-3 shadow-inner">
                {qrDataUrl ? (
                  <img
                    src={qrDataUrl}
                    alt={`Código QR de ${cleanHandle}`}
                    className="h-full w-full rounded-lg object-contain"
                  />
                ) : (
                  <QrCode className="h-24 w-24 text-zinc-900" />
                )}
              </div>

              {/* Logo de Viroklipz al pie de la tarjeta */}
              <div className="mt-4 flex items-center justify-center gap-1.5 border-t border-zinc-100 pt-3">
                <span
                  className="flex h-5 w-5 items-center justify-center rounded-md text-white shadow-sm"
                  style={{
                    background:
                      'linear-gradient(135deg, #25F4EE 0%, #FF2D55 100%)',
                  }}
                >
                  <Sparkles className="h-3 w-3" />
                </span>
                <span className="text-sm font-black tracking-tight text-zinc-900">
                  Viroklipz
                </span>
              </div>
            </div>
          </div>

          {/* Aire de 20px entre tarjeta y botones inferiores */}
          <div className="mt-5 grid w-full grid-cols-2 gap-3">
            <button
              type="button"
              onClick={handleCopyLink}
              className="flex items-center justify-center gap-1.5 rounded-2xl bg-white px-3 py-3 text-xs font-bold text-zinc-950 shadow-md transition-transform active:scale-95"
            >
              {copied ? (
                <Check className="h-4 w-4 shrink-0 text-emerald-600" />
              ) : (
                <Link2 className="h-4 w-4 shrink-0 text-zinc-900" />
              )}
              <span className="truncate">
                {copied ? '¡Copiado!' : 'Copiar enlace'}
              </span>
            </button>

            <button
              type="button"
              onClick={handleShareLink}
              className="flex items-center justify-center gap-1.5 rounded-2xl bg-white px-3 py-3 text-xs font-bold text-zinc-950 shadow-md transition-transform active:scale-95"
            >
              <Share2 className="h-4 w-4 shrink-0 text-zinc-900" />
              <span className="truncate">Compartir enlace</span>
            </button>
          </div>
        </div>
      </div>

      {/* SnackBar flotante interno con ícono de check al copiar enlace */}
      {copied && (
        <div
          role="status"
          className="pointer-events-none absolute bottom-4 left-4 right-4 z-20 flex items-center gap-2 rounded-xl bg-zinc-900/95 px-3.5 py-2.5 text-xs font-medium text-white shadow-lg ring-1 ring-white/10"
        >
          <Check className="h-4 w-4 shrink-0 text-emerald-400" />
          <span>Enlace copiado al portapapeles</span>
        </div>
      )}

      {/* Pantalla de Escáner QR (QrScannerScreen · mobile_scanner) */}
      {isScannerOpen && (
        <div
          className={`absolute inset-0 z-30 flex flex-col justify-between bg-black text-white transition-colors ${
            isTorchOn ? 'bg-zinc-900' : 'bg-black'
          }`}
        >
          {/* Botón X en la esquina superior izquierda */}
          <div className="flex h-14 items-center px-3 pt-1">
            <button
              type="button"
              onClick={() => {
                setIsTorchOn(false);
                setIsScannerOpen(false);
              }}
              aria-label="Cerrar escáner"
              className="flex h-10 w-10 items-center justify-center rounded-full bg-white/10 text-white transition-colors hover:bg-white/20"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          {/* Centro: Texto guía + recuadro transparente con bordes blancos/marca */}
          <div className="flex flex-1 flex-col items-center justify-center px-6 text-center">
            <p className="mb-5 text-sm font-semibold tracking-tight text-white">
              Escanea el código QR de un amigo
            </p>

            <div
              className={`relative flex h-56 w-56 items-center justify-center rounded-2xl border border-white/25 transition-all ${
                isTorchOn
                  ? 'bg-white/10 shadow-[0_0_50px_rgba(255,255,255,0.12)]'
                  : 'bg-zinc-950/60'
              }`}
            >
              <ScanLine className="h-14 w-14 animate-pulse text-[#25F4EE]/80" />
              <span className="absolute -top-0.5 -left-0.5 h-6 w-6 rounded-tl-2xl border-l-[3px] border-t-[3px] border-white" />
              <span className="absolute -top-0.5 -right-0.5 h-6 w-6 rounded-tr-2xl border-r-[3px] border-t-[3px] border-white" />
              <span className="absolute -bottom-0.5 -left-0.5 h-6 w-6 rounded-bl-2xl border-b-[3px] border-l-[3px] border-white" />
              <span className="absolute -bottom-0.5 -right-0.5 h-6 w-6 rounded-br-2xl border-b-[3px] border-r-[3px] border-white" />
            </div>

            <button
              type="button"
              onClick={() => {
                const rawUrl = 'https://viroklipz.app/profile/@mateo';
                const extracted = rawUrl.split('/').filter(Boolean).pop() ?? '@mateo';
                const username = extracted.startsWith('@')
                  ? extracted
                  : `@${extracted}`;
                setIsTorchOn(false);
                setIsScannerOpen(false);
                if (onOpenScannedProfile) {
                  onOpenScannedProfile(username);
                  onNotify?.(`Perfil cargado: ${username}`);
                } else {
                  onNotify?.(`Escaneado: ${username}`);
                }
              }}
              className="mt-6 rounded-xl bg-[#FE2C55] px-4 py-2.5 text-xs font-bold text-white shadow-lg transition-transform active:scale-95"
            >
              Simular lectura QR (@mateo)
            </button>
          </div>

          {/* Botón de linterna (flash) en la parte inferior */}
          <div className="flex flex-col items-center pb-8 pt-4">
            <button
              type="button"
              onClick={() => setIsTorchOn((prev) => !prev)}
              aria-label={isTorchOn ? 'Apagar linterna' : 'Encender linterna'}
              className={`flex h-12 w-12 items-center justify-center rounded-full border transition-colors ${
                isTorchOn
                  ? 'border-amber-300 bg-amber-400/20 text-amber-300'
                  : 'border-white/20 bg-white/10 text-white hover:bg-white/20'
              }`}
            >
              <Flashlight className="h-5 w-5" />
            </button>
            <span
              className={`mt-2 text-[11px] font-medium transition-colors ${
                isTorchOn ? 'text-amber-300 font-semibold' : 'text-zinc-400'
              }`}
            >
              {isTorchOn ? 'Linterna activada' : 'Linterna'}
            </span>
          </div>
        </div>
      )}

      {/* Hoja simulada de Compartir (share_plus fallback) */}
      {isShareSheetOpen && (
        <div
          className="absolute inset-0 z-30 flex items-end bg-black/60"
          onClick={() => setIsShareSheetOpen(false)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full rounded-t-3xl bg-[#18181B] p-4 pb-6 text-white"
          >
            <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-white/20" />
            <p className="text-center text-sm font-bold">Compartir perfil</p>
            <p className="mt-1 truncate text-center text-xs text-zinc-400">
              {profileUrl}
            </p>

            <div className="mt-4 grid grid-cols-4 gap-2 text-center text-[11px]">
              {['WhatsApp', 'Instagram', 'Mensajes', 'Copiar'].map((target) => (
                <button
                  key={target}
                  type="button"
                  onClick={() => {
                    setIsShareSheetOpen(false);
                    if (target === 'Copiar') {
                      handleCopyLink();
                    } else {
                      onNotify?.(`Compartiendo perfil por ${target}...`);
                    }
                  }}
                  className="flex flex-col items-center gap-1.5 rounded-2xl bg-white/5 p-2.5 hover:bg-white/10"
                >
                  <span className="flex h-9 w-9 items-center justify-center rounded-full bg-white/10">
                    <Share2 className="h-4 w-4 text-[#25F4EE]" />
                  </span>
                  <span>{target}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
