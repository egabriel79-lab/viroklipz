import React, { useState } from 'react';
import { ArrowLeft } from 'lucide-react';

interface PrivateAccountScreenProps {
  onBack: () => void;
  onNotify?: (message: string) => void;
}

export const PrivateAccountScreen: React.FC<PrivateAccountScreenProps> = ({
  onBack,
  onNotify,
}) => {
  const [isPrivate, setIsPrivate] = useState(false);

  const togglePrivate = () => {
    const next = !isPrivate;
    setIsPrivate(next);
    onNotify?.(
      next ? 'Cuenta privada activada' : 'Cuenta privada desactivada'
    );
  };

  return (
    <div className="flex h-full w-full flex-col bg-[#121212] text-white select-none overflow-hidden">
      {/* AppBar */}
      <header className="relative flex h-12 shrink-0 items-center justify-center border-b border-white/10 bg-[#121212] px-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Atrás"
          className="absolute left-2 flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="text-[15px] font-bold text-white">Cuenta privada</h1>
      </header>

      {/* Cuerpo */}
      <div className="flex-1 min-h-0 overflow-y-auto px-4 py-5 no-scrollbar">
        <div
          onClick={togglePrivate}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              togglePrivate();
            }
          }}
          className="flex cursor-pointer items-start justify-between gap-4 rounded-xl bg-[#1E1E1E] p-4 transition-colors hover:bg-white/[0.04]"
        >
          <div className="min-w-0 flex-1">
            <p className="text-[15px] font-semibold text-white">
              Cuenta privada
            </p>
            <p className="mt-1.5 text-xs leading-relaxed text-zinc-400">
              Con una cuenta privada, solo los usuarios que apruebes podrán
              seguirte y ver tus videos. Esto no afectará a tus seguidores
              actuales.
            </p>
          </div>

          <button
            type="button"
            role="switch"
            aria-checked={isPrivate}
            aria-label="Cuenta privada"
            onClick={(e) => {
              e.stopPropagation();
              togglePrivate();
            }}
            className={`relative mt-0.5 inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors ${
              isPrivate ? 'bg-[#25F4EE]' : 'bg-zinc-600'
            }`}
          >
            <span
              className={`inline-block h-4 w-4 transform rounded-full bg-white shadow transition-transform ${
                isPrivate ? 'translate-x-6' : 'translate-x-1'
              }`}
            />
          </button>
        </div>
      </div>
    </div>
  );
};
