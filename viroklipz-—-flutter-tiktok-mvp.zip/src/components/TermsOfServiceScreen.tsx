import React from 'react';
import { ArrowLeft, FileText } from 'lucide-react';

interface TermsOfServiceScreenProps {
  onBack: () => void;
}

export const TermsOfServiceScreen: React.FC<TermsOfServiceScreenProps> = ({
  onBack,
}) => {
  return (
    <div className="flex h-full w-full flex-col bg-[#121212] text-zinc-100 select-none overflow-hidden">
      {/* AppBar */}
      <header className="flex h-12 shrink-0 items-center gap-2 border-b border-white/10 bg-[#121212] px-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Volver"
          className="flex h-9 w-9 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="text-[15px] font-bold text-white">
          Términos y políticas
        </h1>
      </header>

      {/* SingleChildScrollView equivalente */}
      <div className="flex-1 min-h-0 overflow-y-auto px-4 py-5 space-y-5 no-scrollbar">
        <div className="flex items-center gap-3 rounded-2xl border border-white/10 bg-[#1C1C1E] p-4">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-[#FF5722] via-[#E91E63] to-[#673AB7]">
            <FileText className="h-5 w-5 text-white" />
          </div>
          <div>
            <p className="text-sm font-bold text-white">
              Términos del Servicio de Viroklipz
            </p>
            <p className="text-xs text-zinc-400">
              Vigente desde Noviembre 2026
            </p>
          </div>
        </div>

        <section className="space-y-2 rounded-2xl border border-white/10 bg-[#1C1C1E] p-4">
          <h2 className="text-sm font-bold text-white">
            1. Aceptación de los Términos de Viroklipz
          </h2>
          <p className="text-xs leading-relaxed text-zinc-300">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Al acceder o
            utilizar la aplicación móvil Viroklipz, aceptas cumplir estos
            Términos del Servicio y nuestras Normas de la Comunidad. Los usuarios
            menores de 18 años requieren la autorización expresa de su tutor
            legal durante el registro.
          </p>
        </section>

        <section className="space-y-2 rounded-2xl border border-white/10 bg-[#1C1C1E] p-4">
          <h2 className="text-sm font-bold text-white">
            2. Contenido generado por usuarios y propiedad intelectual
          </h2>
          <p className="text-xs leading-relaxed text-zinc-300">
            Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
            enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi
            ut aliquip ex ea commodo consequat. Eres responsable de los videos,
            audios y comentarios que publiques en Viroklipz.
          </p>
        </section>

        <section className="space-y-2 rounded-2xl border border-white/10 bg-[#1C1C1E] p-4">
          <h2 className="text-sm font-bold text-white">
            3. Artículos virtuales, monedas y cancelación de cuenta
          </h2>
          <p className="text-xs leading-relaxed text-zinc-300">
            Duis aute irure dolor in reprehenderit in voluptate velit esse cillum
            dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat
            non proident, sunt in culpa qui officia deserunt mollit anim id est
            laborum. Viroklipz se reserva el derecho de suspender cuentas que
            infrinjan estos términos.
          </p>
        </section>

        <p className="pb-4 text-center text-[11px] text-zinc-500">
          © 2026 Viroklipz · Términos del Servicio
        </p>
      </div>
    </div>
  );
};
