import React, { useState } from 'react';
import { ArrowLeft, ChevronRight } from 'lucide-react';

interface DirectMessagesSettingsScreenProps {
  onBack: () => void;
  onNotify?: (message: string) => void;
}

export const DirectMessagesSettingsScreen: React.FC<DirectMessagesSettingsScreenProps> = ({
  onBack,
  onNotify,
}) => {
  const [readStatus, setReadStatus] = useState(true);
  const [safeMode, setSafeMode] = useState(true);
  const [activityStatus, setActivityStatus] = useState<'Público' | 'Solo amigos' | 'Desactivado'>('Público');

  const cycleActivityStatus = () => {
    const order: Array<'Público' | 'Solo amigos' | 'Desactivado'> = [
      'Público',
      'Solo amigos',
      'Desactivado',
    ];
    const next = order[(order.indexOf(activityStatus) + 1) % order.length];
    setActivityStatus(next);
    onNotify?.(`Estado de actividad: ${next}`);
  };

  return (
    <div className="flex h-full w-full flex-col bg-[#121212] text-white select-none overflow-hidden">
      <header className="relative flex h-12 shrink-0 items-center justify-center border-b border-white/10 bg-[#121212] px-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Atrás"
          className="absolute left-2 flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="text-[15px] font-bold text-white">Mensajes directos</h1>
      </header>

      <div className="flex-1 min-h-0 overflow-y-auto px-4 py-4 space-y-5 no-scrollbar">
        <div className="overflow-hidden rounded-xl bg-[#1E1E1E]">
          <button
            type="button"
            onClick={() => onNotify?.('Ajustes de permisos de mensajes')}
            className="flex w-full items-center justify-between px-4 py-3.5 text-left transition-colors hover:bg-white/5"
          >
            <span className="text-[14px] font-medium text-white">
              Ajustes de permisos
            </span>
            <ChevronRight className="h-4 w-4 text-zinc-500" />
          </button>
        </div>

        <section>
          <h2 className="mb-2 px-1 text-xs font-semibold tracking-wide text-zinc-400">
            Preferencias de mensajes
          </h2>
          <div className="divide-y divide-white/5 overflow-hidden rounded-xl bg-[#1E1E1E]">
            <div className="flex items-start justify-between gap-4 px-4 py-3.5">
              <div className="min-w-0 flex-1">
                <p className="text-[14px] font-medium text-white">Estado de lectura</p>
                <p className="mt-1 text-xs leading-relaxed text-zinc-400">
                  Las personas pueden ver cuándo leíste sus mensajes si ambos tienen esta función activada.
                </p>
              </div>
              <button
                type="button"
                role="switch"
                aria-checked={readStatus}
                onClick={() => {
                  const next = !readStatus;
                  setReadStatus(next);
                  onNotify?.(`Estado de lectura ${next ? 'activado' : 'desactivado'}`);
                }}
                className={`relative mt-0.5 inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors ${
                  readStatus ? 'bg-[#FF5722]' : 'bg-zinc-600'
                }`}
              >
                <span
                  className={`inline-block h-5 w-5 transform rounded-full bg-white shadow transition-transform ${
                    readStatus ? 'translate-x-5' : 'translate-x-0.5'
                  }`}
                />
              </button>
            </div>

            <button
              type="button"
              onClick={cycleActivityStatus}
              className="flex w-full items-center justify-between px-4 py-3.5 text-left transition-colors hover:bg-white/5"
            >
              <span className="text-[14px] font-medium text-white">
                Estado de actividad
              </span>
              <div className="flex items-center gap-1.5">
                <span className="text-xs text-zinc-400">{activityStatus}</span>
                <ChevronRight className="h-4 w-4 text-zinc-500" />
              </div>
            </button>
          </div>
        </section>

        <section>
          <h2 className="mb-2 px-1 text-xs font-semibold tracking-wide text-zinc-400">
            Herramientas de seguridad
          </h2>
          <div className="divide-y divide-white/5 overflow-hidden rounded-xl bg-[#1E1E1E]">
            <div className="flex items-start justify-between gap-4 px-4 py-3.5">
              <div className="min-w-0 flex-1">
                <p className="text-[14px] font-medium text-white">Modo seguro</p>
                <p className="mt-1 text-xs leading-relaxed text-zinc-400">
                  Filtra automáticamente mensajes que podrían contener contenido ofensivo o no deseado.
                </p>
              </div>
              <button
                type="button"
                role="switch"
                aria-checked={safeMode}
                onClick={() => {
                  const next = !safeMode;
                  setSafeMode(next);
                  onNotify?.(`Modo seguro ${next ? 'activado' : 'desactivado'}`);
                }}
                className={`relative mt-0.5 inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors ${
                  safeMode ? 'bg-[#FF5722]' : 'bg-zinc-600'
                }`}
              >
                <span
                  className={`inline-block h-5 w-5 transform rounded-full bg-white shadow transition-transform ${
                    safeMode ? 'translate-x-5' : 'translate-x-0.5'
                  }`}
                />
              </button>
            </div>

            <button
              type="button"
              onClick={() => onNotify?.('Palabras clave filtradas en mensajes')}
              className="flex w-full items-center justify-between px-4 py-3.5 text-left transition-colors hover:bg-white/5"
            >
              <span className="text-[14px] font-medium text-white">
                Palabras clave filtradas
              </span>
              <ChevronRight className="h-4 w-4 text-zinc-500" />
            </button>
          </div>
        </section>
      </div>
    </div>
  );
};
