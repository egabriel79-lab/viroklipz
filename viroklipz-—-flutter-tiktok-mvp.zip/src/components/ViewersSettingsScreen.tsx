import React, { useState } from 'react';
import { ArrowLeft, X } from 'lucide-react';

interface ViewersSettingsScreenProps {
  initialEnabled?: boolean;
  onBack: () => void;
  onToggleEnabled?: (enabled: boolean) => void;
  onNotify?: (message: string) => void;
}

export const ViewersSettingsScreen: React.FC<ViewersSettingsScreenProps> = ({
  initialEnabled = true,
  onBack,
  onToggleEnabled,
  onNotify,
}) => {
  const [showMergeBanner, setShowMergeBanner] = useState(true);
  const [viewerHistory, setViewerHistory] = useState(initialEnabled);

  const handleToggle = () => {
    const next = !viewerHistory;
    setViewerHistory(next);
    onToggleEnabled?.(next);
    onNotify?.(`Historial de espectadores ${next ? 'activado' : 'desactivado'}`);
  };

  return (
    <div className="flex h-full w-full flex-col bg-[#121212] text-white select-none overflow-hidden">
      <header className="relative flex h-12 shrink-0 items-center justify-center border-b border-white/10 bg-[#121212] px-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Atrás"
          className="absolute left-2 flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="text-[15px] font-bold text-white">Espectadores</h1>
      </header>

      <div className="flex-1 min-h-0 overflow-y-auto px-4 py-4 space-y-4 no-scrollbar">
        {showMergeBanner && (
          <div className="relative rounded-xl bg-[#27272A] p-4 pr-10">
            <button
              type="button"
              onClick={() => setShowMergeBanner(false)}
              aria-label="Cerrar aviso"
              className="absolute right-2.5 top-2.5 flex h-7 w-7 items-center justify-center rounded-full text-zinc-400 hover:bg-white/10 hover:text-white"
            >
              <X className="h-4 w-4" />
            </button>
            <p className="text-xs leading-relaxed text-zinc-300">
              Ahora los historiales de visitas al perfil y visualizaciones de publicaciones se fusionan en un único panel de espectadores para mayor claridad y control.
            </p>
          </div>
        )}

        <div className="overflow-hidden rounded-xl bg-[#1E1E1E]">
          <div className="flex items-start justify-between gap-4 px-4 py-4">
            <div className="min-w-0 flex-1">
              <p className="text-[14px] font-medium text-white">
                Historial de espectadores
              </p>
              <p className="mt-1.5 text-xs leading-relaxed text-zinc-400">
                Mira quién vio tus publicaciones durante los últimos 7 días y permite que tus seguidores vean cuando tú visualizas sus clips. Solo tú puedes ver la lista completa de espectadores.
              </p>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={viewerHistory}
              onClick={handleToggle}
              className={`relative mt-0.5 inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors ${
                viewerHistory ? 'bg-[#FF5722]' : 'bg-zinc-600'
              }`}
            >
              <span
                className={`inline-block h-5 w-5 transform rounded-full bg-white shadow transition-transform ${
                  viewerHistory ? 'translate-x-5' : 'translate-x-0.5'
                }`}
              />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
