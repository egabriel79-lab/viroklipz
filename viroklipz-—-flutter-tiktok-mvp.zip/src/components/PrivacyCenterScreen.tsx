import React, { useRef, useState } from 'react';
import {
  ArrowDown,
  ArrowLeft,
  ArrowUpRight,
  Menu,
  Shield,
} from 'lucide-react';

interface PrivacyCenterScreenProps {
  onBack: () => void;
  onNotify?: (message: string) => void;
}

const FOOTER_SECTIONS = [
  {
    title: 'Compañía',
    links: ['Acerca de Viroklipz', 'Sala de prensa', 'Empleos', 'Contacto'],
  },
  {
    title: 'Programas',
    links: ['Viroklipz for Good', 'Viroklipz Plus', 'Creadores', 'Publicidad'],
  },
  {
    title: 'Recursos',
    links: [
      'Centro de ayuda',
      'Centro de seguridad',
      'Normas de la comunidad',
      'Transparencia',
    ],
  },
  {
    title: 'Avisos legales',
    links: [
      'Términos del servicio',
      'Política de privacidad',
      'Política de cookies',
      'Propiedad intelectual',
    ],
  },
];

export const PrivacyCenterScreen: React.FC<PrivacyCenterScreenProps> = ({
  onBack,
  onNotify,
}) => {
  const [language, setLanguage] = useState<'ES' | 'EN' | 'PT'>('ES');
  const contentBlockRef = useRef<HTMLDivElement | null>(null);

  const cycleLanguage = () => {
    const next = language === 'ES' ? 'EN' : language === 'EN' ? 'PT' : 'ES';
    setLanguage(next);
    onNotify?.(`Idioma del Centro de privacidad: ${next}`);
  };

  const scrollToInfo = () => {
    contentBlockRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="flex h-full w-full flex-col bg-[#121212] text-white select-none overflow-hidden">
      {/* AppBar Personalizada */}
      <header className="flex h-12 shrink-0 items-center justify-between border-b border-white/10 bg-[#121212] px-2">
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={onBack}
            aria-label="Atrás"
            className="flex h-9 w-9 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <h1 className="text-[13px] font-bold text-white">
            Centro de privacidad
          </h1>
        </div>

        <div className="flex items-center gap-2 pr-1">
          <button
            type="button"
            onClick={() => onNotify?.('Menú del Centro de privacidad')}
            aria-label="Menú"
            className="flex h-8 w-8 items-center justify-center rounded-full text-zinc-200 hover:bg-white/10"
          >
            <Menu className="h-4 w-4" />
          </button>
          <div className="flex h-6 w-6 items-center justify-center rounded-md bg-gradient-to-br from-[#FF5722] via-[#E91E63] to-[#673AB7] shadow">
            <Shield className="h-3.5 w-3.5 text-white" />
          </div>
          <button
            type="button"
            onClick={cycleLanguage}
            className="rounded border border-white/20 px-1.5 py-0.5 text-[11px] font-bold text-white hover:bg-white/10"
          >
            {language}
          </button>
        </div>
      </header>

      {/* Scroll vertical largo */}
      <div className="flex-1 min-h-0 overflow-y-auto no-scrollbar">
        {/* 4. Hero Section */}
        <section className="relative flex h-[340px] w-full flex-col items-center justify-center overflow-hidden px-6 text-center">
          <img
            src="/src/assets/images/hero_cyber_astronaut_1794614449948.jpg"
            alt="Viroklipz protege tu privacidad"
            className="absolute inset-0 h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-black/65" />

          <div className="relative z-10 flex flex-col items-center">
            <h2 className="text-3xl font-extrabold leading-tight tracking-tight text-white">
              Viroklipz protege tu privacidad
            </h2>
          </div>

          <button
            type="button"
            onClick={scrollToInfo}
            aria-label="Desplazar abajo"
            className="absolute bottom-5 z-10 flex h-9 w-9 items-center justify-center rounded-full border border-white/30 bg-black/40 text-white transition-transform hover:translate-y-0.5"
          >
            <ArrowDown className="h-4 w-4" />
          </button>
        </section>

        {/* 5. Bloque de Texto (fondo negro puro) */}
        <section
          ref={contentBlockRef}
          className="bg-black px-6 py-10 text-center"
        >
          <p className="mx-auto max-w-xs text-sm leading-relaxed text-zinc-200">
            En Viroklipz, tu privacidad es una prioridad absoluta. Trabajamos cada
            día para resguardar tu información personal, ofrecerte controles claros
            y darte total transparencia sobre cómo gestionamos tus datos.
          </p>
        </section>

        {/* 6. Imagen Central (dos personas usando laptops) */}
        <section className="bg-black px-4 pb-8">
          <div className="overflow-hidden rounded-2xl border border-white/10 bg-zinc-900">
            <img
              src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=900&auto=format&fit=crop"
              alt="Equipo de privacidad Viroklipz usando laptops"
              className="h-52 w-full object-cover"
            />
          </div>
        </section>

        {/* 7. Sección "Qué hacemos" */}
        <section className="bg-black px-6 pb-10 pt-2 text-center">
          <h3 className="text-2xl font-extrabold tracking-tight text-white">
            Qué hacemos
          </h3>
          <p className="mx-auto mt-3 max-w-xs text-xs leading-relaxed text-zinc-400">
            Diseñamos herramientas de seguridad y privacidad integradas en tu
            cuenta: desde el control de quién puede ver tus videos o enviarte
            mensajes, hasta la gestión de permisos, descargas y preferencias de
            anuncios en Viroklipz.
          </p>
        </section>

        {/* 8. Sección Política de privacidad en diferentes idiomas (fondo claro) */}
        <section className="bg-[#F4F4F5] px-6 py-10 text-center text-black">
          <h3 className="text-xl font-extrabold leading-snug text-zinc-950">
            La Política de privacidad está disponible en diferentes idiomas
          </h3>
          <button
            type="button"
            onClick={() =>
              onNotify?.('Abriendo Política de privacidad multilingüe')
            }
            className="mt-5 inline-flex items-center gap-1.5 rounded-full bg-black px-6 py-3 text-xs font-bold text-white transition-opacity hover:opacity-85"
          >
            <span>Más información</span>
            <ArrowUpRight className="h-3.5 w-3.5" />
          </button>
        </section>

        {/* 9. Footer Menu + 10. Copyright */}
        <footer className="bg-black px-6 pb-10 pt-8 text-center">
          <div className="space-y-6">
            {FOOTER_SECTIONS.map((section) => (
              <div key={section.title}>
                <h4 className="text-sm font-bold text-white">
                  {section.title}
                </h4>
                <ul className="mt-2 space-y-1.5">
                  {section.links.map((link) => (
                    <li key={link}>
                      <button
                        type="button"
                        onClick={() => onNotify?.(`${section.title}: ${link}`)}
                        className="text-xs text-zinc-400 transition-colors hover:text-white"
                      >
                        {link}
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <p className="mt-8 border-t border-white/10 pt-6 text-xs font-medium text-zinc-500">
            © 2026 Viroklipz
          </p>
        </footer>
      </div>
    </div>
  );
};
