import React, { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import {
  ArrowLeft,
  ChevronRight,
  Link2,
  MessageCircle,
  MessageSquare,
  Search,
  Sparkles,
} from 'lucide-react';

interface InviteFamilyScreenProps {
  isGuardian: boolean;
  onBack: () => void;
  onNotify?: (message: string) => void;
}

export const InviteFamilyScreen: React.FC<InviteFamilyScreenProps> = ({
  isGuardian,
  onBack,
  onNotify,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [qrDataUrl, setQrDataUrl] = useState('');

  const inviteUrl = isGuardian
    ? 'https://viroklipz.app/family-sync/invite-teen-7841'
    : 'https://viroklipz.app/family-sync/invite-guardian-7841';

  useEffect(() => {
    let active = true;
    QRCode.toDataURL(inviteUrl, {
      width: 220,
      margin: 1,
      errorCorrectionLevel: 'M',
      color: {
        dark: '#111827',
        light: '#FFFFFF',
      },
    })
      .then((url) => {
        if (active) setQrDataUrl(url);
      })
      .catch(() => {
        if (active) setQrDataUrl('');
      });

    return () => {
      active = false;
    };
  }, [inviteUrl]);

  const handleCopyInvite = async () => {
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(inviteUrl);
      }
    } catch {
      // Fallback en entornos sin permiso de portapapeles
    }
    onNotify?.('Enlace de invitación copiado');
  };

  return (
    <div className="flex h-full w-full flex-col bg-[#121212] text-white select-none overflow-hidden">
      {/* AppBar */}
      <header className="relative flex h-12 shrink-0 items-center justify-center border-b border-white/10 bg-[#121212] px-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Atrás"
          className="absolute left-2 flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="text-[15px] font-bold text-white">
          {isGuardian ? 'Invita a tu adolescente' : 'Invita a tu tutor legal'}
        </h1>
      </header>

      {/* Contenido scrolleable */}
      <div className="flex-1 min-h-0 overflow-y-auto px-4 pt-4 pb-8 space-y-5 no-scrollbar">
        {/* Barra de búsqueda */}
        <div className="flex items-center gap-2.5 rounded-xl bg-[#1E1E1E] px-3.5 py-2.5">
          <Search className="h-4 w-4 shrink-0 text-zinc-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Buscar por nombre..."
            className="w-full bg-transparent text-sm text-white placeholder-zinc-500 focus:outline-none"
          />
        </div>

        {/* Texto explicativo en gris */}
        <p className="px-1 text-xs leading-relaxed text-zinc-400">
          {isGuardian
            ? 'Envía una invitación directa o muestra este código QR para vincular la cuenta de tu adolescente con tu perfil de tutor legal.'
            : 'Envía una invitación directa o comparte este código QR con tu madre, padre o tutor legal para activar la Sincronización familiar.'}
        </p>

        {/* Sección de compartir */}
        <div
          onClick={handleCopyInvite}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') handleCopyInvite();
          }}
          className="flex cursor-pointer items-center justify-between gap-3 rounded-2xl bg-[#1E1E1E] px-4 py-3.5 transition-colors hover:bg-[#252528]"
        >
          <span className="truncate text-sm font-semibold text-white">
            Compartir enlace...
          </span>

          <div className="flex shrink-0 items-center gap-2">
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                handleCopyInvite();
              }}
              aria-label="Copiar enlace"
              className="flex h-9 w-9 items-center justify-center rounded-full bg-sky-500 text-white shadow transition-transform active:scale-90"
            >
              <Link2 className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onNotify?.('Compartir invitación por WhatsApp');
              }}
              aria-label="WhatsApp"
              className="flex h-9 w-9 items-center justify-center rounded-full bg-emerald-500 text-white shadow transition-transform active:scale-90"
            >
              <MessageCircle className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onNotify?.('Compartir invitación por Mensaje');
              }}
              aria-label="Mensaje"
              className="flex h-9 w-9 items-center justify-center rounded-full bg-blue-600 text-white shadow transition-transform active:scale-90"
            >
              <MessageSquare className="h-4 w-4" />
            </button>
            <ChevronRight className="h-4 w-4 text-zinc-500" />
          </div>
        </div>

        {/* Sección QR */}
        <div className="rounded-2xl bg-[#1E1E1E] p-5 text-center">
          <p className="mb-4 text-sm font-bold text-white">
            Escanear o mostrar código QR
          </p>

          <div className="mx-auto inline-flex items-center justify-center rounded-2xl bg-white p-3.5 shadow-lg">
            <div className="relative flex h-44 w-44 items-center justify-center">
              {qrDataUrl ? (
                <img
                  src={qrDataUrl}
                  alt="Código QR de Sincronización familiar"
                  className="h-full w-full rounded-lg object-contain"
                />
              ) : (
                <div className="h-full w-full animate-pulse rounded-lg bg-zinc-200" />
              )}

              {/* Logo de Viroklipz centrado sobre el QR */}
              <div className="absolute flex h-10 w-10 items-center justify-center rounded-xl border-2 border-white bg-zinc-950 shadow-md">
                <Sparkles className="h-5 w-5 text-[#25F4EE]" />
              </div>
            </div>
          </div>

          <p className="mt-4 text-xs leading-relaxed text-zinc-400">
            {isGuardian
              ? 'Pídele al adolescente que escanee este código QR. Este código expirará el 21 nov.'
              : 'Pídele a tu tutor legal que escanee este código QR. Este código expirará el 21 nov.'}
          </p>
        </div>
      </div>
    </div>
  );
};
