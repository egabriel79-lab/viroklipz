import React, { useState } from 'react';
import { ArrowLeft } from 'lucide-react';

interface DisplaySettingsScreenProps {
  onBack: () => void;
  onNotify?: (message: string) => void;
}

export const DisplaySettingsScreen: React.FC<DisplaySettingsScreenProps> = ({
  onBack,
  onNotify,
}) => {
  const [themeMode, setThemeMode] = useState<'claro' | 'oscuro'>('oscuro');
  const [useDeviceSettings, setUseDeviceSettings] = useState(false);

  const selectTheme = (mode: 'claro' | 'oscuro') => {
    setThemeMode(mode);
    onNotify?.(`Aspecto: ${mode === 'claro' ? 'Claro' : 'Oscuro'}`);
  };

  return (
    <div className="flex h-full w-full flex-col bg-[#121212] text-white select-none overflow-hidden">
      <header className="relative flex h-12 shrink-0 items-center justify-center border-b border-white/10 bg-[#121212] px-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Atrás"
          className="absolute left-2 flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="text-[15px] font-bold text-white">Mostrar</h1>
      </header>

      <div className="flex-1 min-h-0 overflow-y-auto px-4 py-4 space-y-5 no-scrollbar">
        <section>
          <h2 className="mb-2.5 px-1 text-xs font-semibold tracking-wide text-zinc-400">
            Aspecto
          </h2>
          <div className="rounded-xl bg-[#1E1E1E] p-4">
            <div className="grid grid-cols-2 gap-4">
              {/* Mockup Claro */}
              <button
                type="button"
                onClick={() => selectTheme('claro')}
                className="flex flex-col items-center gap-2.5 focus-visible:outline-none"
              >
                <div
                  className={`flex h-36 w-24 flex-col justify-between rounded-2xl border-2 bg-zinc-100 p-2.5 transition-all ${
                    themeMode === 'claro'
                      ? 'border-[#FF5722] shadow-lg shadow-[#FF5722]/20'
                      : 'border-white/10 opacity-75'
                  }`}
                >
                  <div className="space-y-1.5">
                    <div className="h-2 w-10 rounded bg-zinc-300" />
                    <div className="h-12 w-full rounded-lg bg-white shadow-sm" />
                    <div className="h-2 w-12 rounded bg-zinc-300" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="h-2.5 w-2.5 rounded-full bg-zinc-300" />
                    <span className="h-2.5 w-6 rounded-full bg-[#FF5722]" />
                    <span className="h-2.5 w-2.5 rounded-full bg-zinc-300" />
                  </div>
                </div>
                <span className="text-xs font-semibold text-white">Claro</span>
                <span
                  className={`flex h-5 w-5 items-center justify-center rounded-full border-2 ${
                    themeMode === 'claro' ? 'border-[#FF5722]' : 'border-zinc-500'
                  }`}
                >
                  {themeMode === 'claro' && (
                    <span className="h-2.5 w-2.5 rounded-full bg-[#FF5722]" />
                  )}
                </span>
              </button>

              {/* Mockup Oscuro */}
              <button
                type="button"
                onClick={() => selectTheme('oscuro')}
                className="flex flex-col items-center gap-2.5 focus-visible:outline-none"
              >
                <div
                  className={`flex h-36 w-24 flex-col justify-between rounded-2xl border-2 bg-[#0E0E10] p-2.5 transition-all ${
                    themeMode === 'oscuro'
                      ? 'border-[#FF5722] shadow-lg shadow-[#FF5722]/20'
                      : 'border-white/10 opacity-75'
                  }`}
                >
                  <div className="space-y-1.5">
                    <div className="h-2 w-10 rounded bg-zinc-700" />
                    <div className="h-12 w-full rounded-lg bg-zinc-800" />
                    <div className="h-2 w-12 rounded bg-zinc-700" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="h-2.5 w-2.5 rounded-full bg-zinc-700" />
                    <span className="h-2.5 w-6 rounded-full bg-[#FF5722]" />
                    <span className="h-2.5 w-2.5 rounded-full bg-zinc-700" />
                  </div>
                </div>
                <span className="text-xs font-semibold text-white">Oscuro</span>
                <span
                  className={`flex h-5 w-5 items-center justify-center rounded-full border-2 ${
                    themeMode === 'oscuro' ? 'border-[#FF5722]' : 'border-zinc-500'
                  }`}
                >
                  {themeMode === 'oscuro' && (
                    <span className="h-2.5 w-2.5 rounded-full bg-[#FF5722]" />
                  )}
                </span>
              </button>
            </div>
          </div>
        </section>

        <div className="overflow-hidden rounded-xl bg-[#1E1E1E]">
          <div className="flex items-start justify-between gap-4 px-4 py-3.5">
            <div className="min-w-0 flex-1">
              <p className="text-[14px] font-medium text-white">
                Usar ajustes del dispositivo
              </p>
              <p className="mt-1 text-xs leading-relaxed text-zinc-400">
                Adapta automáticamente el tema según la configuración de pantalla de tu teléfono.
              </p>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={useDeviceSettings}
              onClick={() => {
                const next = !useDeviceSettings;
                setUseDeviceSettings(next);
                onNotify?.(
                  `Usar ajustes del dispositivo ${next ? 'activado' : 'desactivado'}`
                );
              }}
              className={`relative mt-0.5 inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors ${
                useDeviceSettings ? 'bg-[#FF5722]' : 'bg-zinc-600'
              }`}
            >
              <span
                className={`inline-block h-5 w-5 transform rounded-full bg-white shadow transition-transform ${
                  useDeviceSettings ? 'translate-x-5' : 'translate-x-0.5'
                }`}
              />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
