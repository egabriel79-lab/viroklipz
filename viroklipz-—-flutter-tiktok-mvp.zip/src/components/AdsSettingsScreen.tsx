import React, { useState } from 'react';
import { ArrowLeft, ChevronRight } from 'lucide-react';

interface AdsSettingsScreenProps {
  onBack: () => void;
  onNotify?: (message: string) => void;
}

export const AdsSettingsScreen: React.FC<AdsSettingsScreenProps> = ({
  onBack,
  onNotify,
}) => {
  const [offAppTargetedAds, setOffAppTargetedAds] = useState(true);
  const [personalizedAds, setPersonalizedAds] = useState(true);

  return (
    <div className="flex h-full w-full flex-col bg-[#121212] text-white select-none overflow-hidden">
      <header className="relative flex h-12 shrink-0 items-center justify-center border-b border-white/10 bg-[#121212] px-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Atrás"
          className="absolute left-2 flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="text-[15px] font-bold text-white">Plan y anuncios</h1>
      </header>

      <div className="flex-1 min-h-0 overflow-y-auto px-4 py-4 space-y-6 no-scrollbar">
        <section>
          <h2 className="mb-2 px-1 text-xs font-semibold tracking-wide text-zinc-400">
            Administra los anuncios que ves
          </h2>
          <div className="divide-y divide-white/5 overflow-hidden rounded-xl bg-[#1E1E1E]">
            <button
              type="button"
              onClick={() => onNotify?.('Gestionar los temas de los anuncios')}
              className="flex w-full items-start justify-between gap-3 px-4 py-3.5 text-left transition-colors hover:bg-white/5"
            >
              <div className="min-w-0 flex-1">
                <p className="text-[14px] font-medium text-white">
                  Gestionar los temas de los anuncios
                </p>
                <p className="mt-1 text-xs leading-relaxed text-zinc-400">
                  Elige los intereses y categorías de anuncios que prefieres ver en tu feed.
                </p>
              </div>
              <ChevronRight className="mt-0.5 h-4 w-4 shrink-0 text-zinc-500" />
            </button>

            <button
              type="button"
              onClick={() => onNotify?.('Modificar los datos personales')}
              className="flex w-full items-start justify-between gap-3 px-4 py-3.5 text-left transition-colors hover:bg-white/5"
            >
              <div className="min-w-0 flex-1">
                <p className="text-[14px] font-medium text-white">
                  Modificar los datos personales
                </p>
                <p className="mt-1 text-xs leading-relaxed text-zinc-400">
                  Actualiza cómo se utiliza tu perfil e historial básico para personalizar promociones.
                </p>
              </div>
              <ChevronRight className="mt-0.5 h-4 w-4 shrink-0 text-zinc-500" />
            </button>

            <button
              type="button"
              onClick={() => onNotify?.('Silenciar anunciantes')}
              className="flex w-full items-start justify-between gap-3 px-4 py-3.5 text-left transition-colors hover:bg-white/5"
            >
              <div className="min-w-0 flex-1">
                <p className="text-[14px] font-medium text-white">
                  Silenciar anunciantes
                </p>
                <p className="mt-1 text-xs leading-relaxed text-zinc-400">
                  Revisa y silencia marcas específicas cuyos anuncios no deseas volver a ver.
                </p>
              </div>
              <ChevronRight className="mt-0.5 h-4 w-4 shrink-0 text-zinc-500" />
            </button>
          </div>
        </section>

        <section>
          <h2 className="mb-2 px-1 text-xs font-semibold tracking-wide text-zinc-400">
            Administra tus datos fuera de Viroklipz
          </h2>
          <div className="divide-y divide-white/5 overflow-hidden rounded-xl bg-[#1E1E1E]">
            <div className="flex items-start justify-between gap-4 px-4 py-4">
              <div className="min-w-0 flex-1">
                <p className="text-[14px] font-medium text-white">
                  Anuncios dirigidos fuera de Viroklipz
                </p>
                <p className="mt-1.5 text-xs leading-relaxed text-zinc-400">
                  Cuando está activado, los socios de medición y anunciantes externos pueden asociar tu actividad en sitios web o apps de terceros para mostrarte anuncios más relevantes fuera de Viroklipz.
                </p>
              </div>
              <button
                type="button"
                role="switch"
                aria-checked={offAppTargetedAds}
                onClick={() => {
                  const next = !offAppTargetedAds;
                  setOffAppTargetedAds(next);
                  onNotify?.(
                    `Anuncios dirigidos fuera de Viroklipz ${next ? 'activados' : 'desactivados'}`
                  );
                }}
                className={`relative mt-0.5 inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors ${
                  offAppTargetedAds ? 'bg-[#FF5722]' : 'bg-zinc-600'
                }`}
              >
                <span
                  className={`inline-block h-5 w-5 transform rounded-full bg-white shadow transition-transform ${
                    offAppTargetedAds ? 'translate-x-5' : 'translate-x-0.5'
                  }`}
                />
              </button>
            </div>

            <div className="flex items-start justify-between gap-4 px-4 py-4">
              <div className="min-w-0 flex-1">
                <p className="text-[14px] font-medium text-white">
                  Anuncios personalizados
                </p>
                <p className="mt-1.5 text-xs leading-relaxed text-zinc-400">
                  Permite adaptar los anuncios que ves en Viroklipz según tu actividad e intereses en la plataforma.
                </p>
              </div>
              <button
                type="button"
                role="switch"
                aria-checked={personalizedAds}
                onClick={() => {
                  const next = !personalizedAds;
                  setPersonalizedAds(next);
                  onNotify?.(
                    `Anuncios personalizados ${next ? 'activados' : 'desactivados'}`
                  );
                }}
                className={`relative mt-0.5 inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors ${
                  personalizedAds ? 'bg-[#FF5722]' : 'bg-zinc-600'
                }`}
              >
                <span
                  className={`inline-block h-5 w-5 transform rounded-full bg-white shadow transition-transform ${
                    personalizedAds ? 'translate-x-5' : 'translate-x-0.5'
                  }`}
                />
              </button>
            </div>

            <button
              type="button"
              onClick={() => onNotify?.('Desconectar anunciantes')}
              className="flex w-full items-center justify-between px-4 py-3.5 text-left transition-colors hover:bg-white/5"
            >
              <span className="text-[14px] font-medium text-white">
                Desconectar anunciantes
              </span>
              <ChevronRight className="h-4 w-4 shrink-0 text-zinc-500" />
            </button>

            <button
              type="button"
              onClick={() =>
                onNotify?.('Datos de actividad fuera de Viroklipz borrados')
              }
              className="flex w-full items-center justify-between px-4 py-3.5 text-left transition-colors hover:bg-white/5"
            >
              <span className="text-[14px] font-medium text-white">
                Borrar datos de actividad fuera de Viroklipz
              </span>
              <ChevronRight className="h-4 w-4 shrink-0 text-zinc-500" />
            </button>
          </div>
        </section>
      </div>
    </div>
  );
};
