import React, { useState } from 'react';
import { ArrowLeft, ChevronRight } from 'lucide-react';

interface AccessibilitySettingsScreenProps {
  onBack: () => void;
  onNotify?: (message: string) => void;
}

export const AccessibilitySettingsScreen: React.FC<AccessibilitySettingsScreenProps> = ({
  onBack,
  onNotify,
}) => {
  const [highContrast, setHighContrast] = useState(false);
  const [skipPhotosensitive, setSkipPhotosensitive] = useState(false);
  const [captions, setCaptions] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(true);
  const [fasterScroll, setFasterScroll] = useState(true);
  const [animatedThumbnails, setAnimatedThumbnails] = useState(false);

  const renderSwitchRow = (
    title: string,
    checked: boolean,
    onToggle: () => void,
    subtitle?: string
  ) => (
    <div className="flex items-start justify-between gap-4 px-4 py-3.5">
      <div className="min-w-0 flex-1">
        <p className="text-[14px] font-medium text-white">{title}</p>
        {subtitle && (
          <p className="mt-1 text-xs leading-relaxed text-zinc-400">{subtitle}</p>
        )}
      </div>
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        onClick={onToggle}
        className={`relative mt-0.5 inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors ${
          checked ? 'bg-[#FF5722]' : 'bg-zinc-600'
        }`}
      >
        <span
          className={`inline-block h-5 w-5 transform rounded-full bg-white shadow transition-transform ${
            checked ? 'translate-x-5' : 'translate-x-0.5'
          }`}
        />
      </button>
    </div>
  );

  return (
    <div className="flex h-full w-full flex-col bg-[#121212] text-white select-none overflow-hidden">
      <header className="relative flex h-12 shrink-0 items-center justify-center border-b border-white/10 bg-[#121212] px-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Atrás"
          className="absolute left-2 flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="text-[15px] font-bold text-white">Accesibilidad</h1>
      </header>

      <div className="flex-1 min-h-0 overflow-y-auto px-4 py-4 space-y-5 no-scrollbar">
        <section>
          <h2 className="mb-2 px-1 text-xs font-semibold tracking-wide text-zinc-400">
            Aspecto
          </h2>
          <div className="divide-y divide-white/5 overflow-hidden rounded-xl bg-[#1E1E1E]">
            <button
              type="button"
              onClick={() => onNotify?.('Tamaño de texto')}
              className="flex w-full items-center justify-between px-4 py-3.5 text-left transition-colors hover:bg-white/5"
            >
              <span className="text-[14px] font-medium text-white">Tamaño de texto</span>
              <ChevronRight className="h-4 w-4 text-zinc-500" />
            </button>
            {renderSwitchRow(
              'Aumenta el contraste de color',
              highContrast,
              () => {
                const next = !highContrast;
                setHighContrast(next);
                onNotify?.(`Contraste de color ${next ? 'activado' : 'desactivado'}`);
              },
              'Mejora la legibilidad entre botones, íconos y fondos.'
            )}
          </div>
        </section>

        <section>
          <h2 className="mb-2 px-1 text-xs font-semibold tracking-wide text-zinc-400">
            Contenido
          </h2>
          <div className="divide-y divide-white/5 overflow-hidden rounded-xl bg-[#1E1E1E]">
            {renderSwitchRow(
              'Omitir publicaciones no aptas para fotosensibles',
              skipPhotosensitive,
              () => {
                const next = !skipPhotosensitive;
                setSkipPhotosensitive(next);
                onNotify?.(`Filtro fotosensible ${next ? 'activado' : 'desactivado'}`);
              },
              'Omite videos con destellos intensos o patrones visuales rápidos.'
            )}
            {renderSwitchRow(
              'Subtítulos',
              captions,
              () => {
                const next = !captions;
                setCaptions(next);
                onNotify?.(`Subtítulos ${next ? 'activados' : 'desactivados'}`);
              },
              'Muestra subtítulos generados cuando estén disponibles.'
            )}
          </div>
        </section>

        <section>
          <h2 className="mb-2 px-1 text-xs font-semibold tracking-wide text-zinc-400">
            Movimiento
          </h2>
          <div className="divide-y divide-white/5 overflow-hidden rounded-xl bg-[#1E1E1E]">
            {renderSwitchRow(
              'Reduced motion',
              reducedMotion,
              () => {
                const next = !reducedMotion;
                setReducedMotion(next);
                onNotify?.(`Reduced motion ${next ? 'activado' : 'desactivado'}`);
              }
            )}
            {renderSwitchRow(
              'Mayor velocidad de desplazamiento',
              fasterScroll,
              () => {
                const next = !fasterScroll;
                setFasterScroll(next);
                onNotify?.(
                  `Mayor velocidad de desplazamiento ${next ? 'activada' : 'desactivada'}`
                );
              }
            )}
            {renderSwitchRow(
              'Miniaturas animadas',
              animatedThumbnails,
              () => {
                const next = !animatedThumbnails;
                setAnimatedThumbnails(next);
                onNotify?.(`Miniaturas animadas ${next ? 'activadas' : 'desactivadas'}`);
              }
            )}
          </div>
        </section>
      </div>
    </div>
  );
};
