import React from 'react';
import { ArrowLeft, ChevronRight } from 'lucide-react';

interface AccountSettingsScreenProps {
  onBack: () => void;
  onNotify?: (message: string) => void;
}

interface AccountOptionItem {
  id: string;
  title: string;
  subtitle?: string;
  isDestructive?: boolean;
}

const ACCOUNT_OPTIONS: AccountOptionItem[] = [
  {
    id: 'account_info',
    title: 'Información de la cuenta',
  },
  {
    id: 'password',
    title: 'Contraseña',
  },
  {
    id: 'verification',
    title: 'Verificación',
  },
  {
    id: 'business_account',
    title: 'Pasar a Cuenta de empresa verificada',
    subtitle:
      'Estás usando una cuenta personal actualmente. Cambia a una cuenta de empresa para acceder a más herramientas.',
  },
  {
    id: 'account_legacy',
    title: 'Legado de la cuenta',
    subtitle:
      'Planifica con antelación qué ocurrirá con tu cuenta si algo llega a suceder.',
  },
  {
    id: 'download_data',
    title: 'Descargar tus datos',
    subtitle: 'Obtén una copia de tus datos de Viroklipz.',
  },
  {
    id: 'deactivate_delete',
    title: 'Desactivar o eliminar la cuenta',
    isDestructive: true,
  },
];

export const AccountSettingsScreen: React.FC<AccountSettingsScreenProps> = ({
  onBack,
  onNotify,
}) => {
  return (
    <div className="flex h-full w-full flex-col bg-[#121212] text-white select-none overflow-hidden">
      {/* AppBar oscura */}
      <header className="relative flex h-12 shrink-0 items-center justify-center border-b border-white/10 bg-[#121212] px-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Atrás"
          className="absolute left-2 flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="text-[15px] font-bold text-white">Cuenta</h1>
      </header>

      {/* Lista de opciones */}
      <div className="flex-1 min-h-0 overflow-y-auto px-4 py-5 no-scrollbar">
        <div className="divide-y divide-white/5 overflow-hidden rounded-xl bg-[#1E1E1E]">
          {ACCOUNT_OPTIONS.map((option) => (
            <button
              key={option.id}
              type="button"
              onClick={() => onNotify?.(`Cuenta: ${option.title}`)}
              className="flex w-full items-center justify-between gap-3 px-4 py-3.5 text-left transition-colors hover:bg-white/5 active:bg-white/10"
            >
              <div className="min-w-0 flex-1">
                <p
                  className={`text-[14px] font-medium leading-snug ${
                    option.isDestructive ? 'text-rose-400' : 'text-zinc-100'
                  }`}
                >
                  {option.title}
                </p>
                {option.subtitle && (
                  <p className="mt-1 text-xs leading-relaxed text-zinc-400">
                    {option.subtitle}
                  </p>
                )}
              </div>
              <ChevronRight className="h-4 w-4 shrink-0 text-zinc-500" />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
