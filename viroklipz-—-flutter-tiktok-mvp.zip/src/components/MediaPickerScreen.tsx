import React, { useState } from 'react';
import { Check, ChevronDown, Play, X } from 'lucide-react';

export interface MediaPublicationItem {
  id: string;
  url: string;
  views: string;
  category: 'Recientes' | 'Más vistos' | 'Favoritos';
}

const USER_PUBLICATIONS: MediaPublicationItem[] = [
  {
    id: 'pub-1',
    url: '/src/assets/images/avatar_creator_mateo_1794604321715.jpg',
    views: '157',
    category: 'Recientes',
  },
  {
    id: 'pub-2',
    url: '/src/assets/images/story_hinduismo_temple_1794607243976.jpg',
    views: '412',
    category: 'Recientes',
  },
  {
    id: 'pub-3',
    url: '/src/assets/images/avatar_creator_valeria_1794604321625.jpg',
    views: '1.2K',
    category: 'Más vistos',
  },
  {
    id: 'pub-4',
    url: '/src/assets/images/avatar_creator_lucas_1794604322245.jpg',
    views: '893',
    category: 'Recientes',
  },
  {
    id: 'pub-5',
    url: '/src/assets/images/avatar_creator_sofia_1794604322145.jpg',
    views: '2.4K',
    category: 'Más vistos',
  },
  {
    id: 'pub-6',
    url: '/src/assets/images/avatar_creator_diego_1794604323122.jpg',
    views: '645',
    category: 'Favoritos',
  },
];

interface MediaPickerScreenProps {
  onClose: () => void;
  onSelectMedia: (url: string) => void;
}

export const MediaPickerScreen: React.FC<MediaPickerScreenProps> = ({
  onClose,
  onSelectMedia,
}) => {
  const [selectedId, setSelectedId] = useState<string>(USER_PUBLICATIONS[0].id);
  const [filter, setFilter] = useState<'Recientes' | 'Más vistos' | 'Favoritos'>(
    'Recientes'
  );
  const [isFilterOpen, setIsFilterOpen] = useState(false);

  const visibleItems =
    filter === 'Recientes'
      ? USER_PUBLICATIONS
      : USER_PUBLICATIONS.filter((item) => item.category === filter);

  const selectedItem =
    USER_PUBLICATIONS.find((item) => item.id === selectedId) ??
    visibleItems[0] ??
    USER_PUBLICATIONS[0];

  return (
    <div className="relative flex h-full w-full flex-col bg-white text-zinc-950 select-none overflow-hidden">
      {/* AppBar: X a la izquierda, "Recientes" + flecha abajo en el centro */}
      <header className="relative z-20 flex h-12 shrink-0 items-center justify-between border-b border-zinc-100 bg-white px-2">
        <button
          type="button"
          onClick={onClose}
          aria-label="Cerrar selector de publicaciones"
          className="flex h-10 w-10 items-center justify-center rounded-full text-zinc-900 transition-colors hover:bg-zinc-100"
        >
          <X className="h-5 w-5" />
        </button>

        <button
          type="button"
          onClick={() => setIsFilterOpen((prev) => !prev)}
          className="inline-flex items-center gap-1 rounded-full px-3 py-1.5 text-[15px] font-bold text-zinc-950 transition-colors hover:bg-zinc-100"
        >
          <span>{filter}</span>
          <ChevronDown
            className={`h-4 w-4 transition-transform ${
              isFilterOpen ? 'rotate-180' : ''
            }`}
          />
        </button>

        <div className="w-10" />

        {isFilterOpen && (
          <div className="absolute left-1/2 top-12 z-30 w-44 -translate-x-1/2 overflow-hidden rounded-2xl border border-zinc-200 bg-white py-1 shadow-xl">
            {(['Recientes', 'Más vistos', 'Favoritos'] as const).map((option) => (
              <button
                key={option}
                type="button"
                onClick={() => {
                  setFilter(option);
                  setIsFilterOpen(false);
                }}
                className={`flex w-full items-center justify-between px-4 py-2.5 text-left text-xs font-semibold transition-colors hover:bg-zinc-50 ${
                  filter === option ? 'text-[#FF2D55]' : 'text-zinc-800'
                }`}
              >
                <span>{option}</span>
                {filter === option && <Check className="h-3.5 w-3.5" />}
              </button>
            ))}
          </div>
        )}
      </header>

      {/* GridView.builder 3 columnas (9:16, bordes redondeados sutiles, Play + vistas) */}
      <div className="flex-1 min-h-0 overflow-y-auto px-2 pt-2 pb-20 no-scrollbar">
        <div className="grid grid-cols-3 gap-1.5">
          {visibleItems.map((item) => {
            const isSelected = item.id === selectedId;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setSelectedId(item.id)}
                className={`group relative aspect-[9/16] w-full overflow-hidden rounded-lg bg-zinc-200 transition-all ${
                  isSelected
                    ? 'ring-2 ring-[#FF2D55] ring-offset-1'
                    : 'hover:opacity-95'
                }`}
              >
                <img
                  src={item.url}
                  alt={`Publicación ${item.id}`}
                  className="h-full w-full object-cover"
                />

                {/* Scrim inferior para vistas */}
                <div
                  aria-hidden="true"
                  className="pointer-events-none absolute inset-x-0 bottom-0 h-11 bg-gradient-to-t from-black/75 to-transparent"
                />

                {/* Play + número de vistas en esquina inferior izquierda */}
                <div className="absolute bottom-1.5 left-1.5 flex items-center gap-1 text-white">
                  <Play className="h-3 w-3 fill-white" />
                  <span className="text-[11px] font-semibold tabular-nums">
                    {item.views}
                  </span>
                </div>

                {/* Indicador de selección */}
                <span
                  className={`absolute right-1.5 top-1.5 flex h-5 w-5 items-center justify-center rounded-full transition-colors ${
                    isSelected
                      ? 'bg-[#FF2D55] text-white shadow'
                      : 'border border-white/80 bg-black/35 text-transparent'
                  }`}
                >
                  <Check className="h-3 w-3 stroke-[3]" />
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Botón flotante tipo píldora "Siguiente" (rosa/naranja) en esquina inferior derecha */}
      <button
        type="button"
        onClick={() => onSelectMedia(selectedItem.url)}
        className="absolute bottom-5 right-4 z-20 rounded-full px-6 py-2.5 text-sm font-bold text-white shadow-lg transition-transform active:scale-95"
        style={{
          background: 'linear-gradient(135deg, #FF2D55 0%, #FF6B35 100%)',
        }}
      >
        Siguiente
      </button>
    </div>
  );
};
