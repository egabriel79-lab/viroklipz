import React, { useState } from 'react';
import { ArrowLeft, ChevronRight } from 'lucide-react';

interface LanguageSettingsScreenProps {
  onBack: () => void;
  onNotify?: (message: string) => void;
}

export const LanguageSettingsScreen: React.FC<LanguageSettingsScreenProps> = ({
  onBack,
  onNotify,
}) => {
  const [appLanguage, setAppLanguage] = useState('Español');
  const [alwaysTranslate, setAlwaysTranslate] = useState(false);
  const [translateTo, setTranslateTo] = useState('Español');
  const [doNotTranslate, setDoNotTranslate] = useState('Español');

  const cycleLanguage = (current: string, setter: (v: string) => void, label: string) => {
    const langs = ['Español', 'Inglés', 'Portugués', 'Francés'];
    const next = langs[(langs.indexOf(current) + 1) % langs.length];
    setter(next);
    onNotify?.(`${label}: ${next}`);
  };

  return (
    <div className="flex h-full w-full flex-col bg-[#121212] text-white select-none overflow-hidden">
      <header className="relative flex h-12 shrink-0 items-center justify-center border-b border-white/10 bg-[#121212] px-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Atrás"
          className="absolute left-2 flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="text-[15px] font-bold text-white">Idiomas</h1>
      </header>

      <div className="flex-1 min-h-0 overflow-y-auto px-4 py-4 space-y-5 no-scrollbar">
        <div className="overflow-hidden rounded-xl bg-[#1E1E1E]">
          <button
            type="button"
            onClick={() =>
              cycleLanguage(appLanguage, setAppLanguage, 'Idioma de la aplicación')
            }
            className="flex w-full items-center justify-between px-4 py-3.5 text-left transition-colors hover:bg-white/5"
          >
            <span className="text-[14px] font-medium text-white">
              Idioma de la aplicación
            </span>
            <div className="flex items-center gap-1.5">
              <span className="text-xs text-zinc-400">{appLanguage}</span>
              <ChevronRight className="h-4 w-4 text-zinc-500" />
            </div>
          </button>
        </div>

        <section>
          <h2 className="mb-2 px-1 text-xs font-semibold tracking-wide text-zinc-400">
            Traducción
          </h2>
          <div className="divide-y divide-white/5 overflow-hidden rounded-xl bg-[#1E1E1E]">
            <div className="flex items-start justify-between gap-4 px-4 py-3.5">
              <div className="min-w-0 flex-1">
                <p className="text-[14px] font-medium text-white">
                  Traducir siempre las publicaciones
                </p>
                <p className="mt-1 text-xs leading-relaxed text-zinc-400">
                  Traduce automáticamente descripciones y comentarios a tu idioma preferido.
                </p>
              </div>
              <button
                type="button"
                role="switch"
                aria-checked={alwaysTranslate}
                onClick={() => {
                  const next = !alwaysTranslate;
                  setAlwaysTranslate(next);
                  onNotify?.(
                    `Traducir siempre las publicaciones ${next ? 'activado' : 'desactivado'}`
                  );
                }}
                className={`relative mt-0.5 inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors ${
                  alwaysTranslate ? 'bg-[#FF5722]' : 'bg-zinc-600'
                }`}
              >
                <span
                  className={`inline-block h-5 w-5 transform rounded-full bg-white shadow transition-transform ${
                    alwaysTranslate ? 'translate-x-5' : 'translate-x-0.5'
                  }`}
                />
              </button>
            </div>

            <button
              type="button"
              onClick={() => cycleLanguage(translateTo, setTranslateTo, 'Traducir a')}
              className="flex w-full items-center justify-between px-4 py-3.5 text-left transition-colors hover:bg-white/5"
            >
              <span className="text-[14px] font-medium text-white">Traducir a</span>
              <div className="flex items-center gap-1.5">
                <span className="text-xs text-zinc-400">{translateTo}</span>
                <ChevronRight className="h-4 w-4 text-zinc-500" />
              </div>
            </button>

            <button
              type="button"
              onClick={() =>
                cycleLanguage(doNotTranslate, setDoNotTranslate, 'No traducir')
              }
              className="flex w-full items-center justify-between px-4 py-3.5 text-left transition-colors hover:bg-white/5"
            >
              <span className="text-[14px] font-medium text-white">No traducir</span>
              <div className="flex items-center gap-1.5">
                <span className="text-xs text-zinc-400">{doNotTranslate}</span>
                <ChevronRight className="h-4 w-4 text-zinc-500" />
              </div>
            </button>
          </div>
        </section>
      </div>
    </div>
  );
};
