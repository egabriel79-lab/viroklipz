import React from 'react';
import { ArrowLeft, ShieldCheck } from 'lucide-react';

interface PrivacyPolicyScreenProps {
  onBack: () => void;
}

export const PrivacyPolicyScreen: React.FC<PrivacyPolicyScreenProps> = ({
  onBack,
}) => {
  return (
    <div className="flex h-full w-full flex-col bg-[#121212] text-zinc-100 select-none overflow-hidden">
      {/* AppBar */}
      <header className="flex h-12 shrink-0 items-center gap-2 border-b border-white/10 bg-[#121212] px-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Volver"
          className="flex h-9 w-9 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="text-[15px] font-bold text-white">
          Política de privacidad
        </h1>
      </header>

      {/* SingleChildScrollView equivalente */}
      <div className="flex-1 min-h-0 overflow-y-auto px-4 py-5 space-y-5 no-scrollbar">
        <div className="flex items-center gap-3 rounded-2xl border border-white/10 bg-[#1C1C1E] p-4">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-[#FF5722] via-[#E91E63] to-[#673AB7]">
            <ShieldCheck className="h-5 w-5 text-white" />
          </div>
          <div>
            <p className="text-sm font-bold text-white">
              Centro de Privacidad de Viroklipz
            </p>
            <p className="text-xs text-zinc-400">
              Última actualización: Noviembre 2026
            </p>
          </div>
        </div>

        <section className="space-y-2 rounded-2xl border border-white/10 bg-[#1C1C1E] p-4">
          <h2 className="text-sm font-bold text-white">
            1. Información que recopilamos en Viroklipz
          </h2>
          <p className="text-xs leading-relaxed text-zinc-300">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Viroklipz
            recopila los datos estrictamente necesarios para el funcionamiento de
            tu cuenta de creador, incluyendo nombre de usuario, correo
            electrónico, avatar, videos publicados y tokens de notificaciones
            push (FCM). Sed do eiusmod tempor incididunt ut labore et dolore
            magna aliqua.
          </p>
        </section>

        <section className="space-y-2 rounded-2xl border border-white/10 bg-[#1C1C1E] p-4">
          <h2 className="text-sm font-bold text-white">
            2. Uso de datos, cámara y almacenamiento
          </h2>
          <p className="text-xs leading-relaxed text-zinc-300">
            Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris
            nisi ut aliquip ex ea commodo consequat. Los permisos de cámara,
            micrófono y galería se utilizan exclusivamente cuando grabas clips,
            escaneas códigos QR o guardas videos en tu dispositivo. Duis aute
            irure dolor in reprehenderit in voluptate velit esse cillum dolore.
          </p>
        </section>

        <section className="space-y-2 rounded-2xl border border-white/10 bg-[#1C1C1E] p-4">
          <h2 className="text-sm font-bold text-white">
            3. Protección de menores y derechos ARCO
          </h2>
          <p className="text-xs leading-relaxed text-zinc-300">
            Excepteur sint occaecat cupidatat non proident, sunt in culpa qui
            officia deserunt mollit anim id est laborum. Puedes editar tu perfil,
            revocar permisos o eliminar permanentemente tu cuenta y todos tus
            datos personales desde el menú de Perfil en Viroklipz.
          </p>
        </section>

        <p className="pb-4 text-center text-[11px] text-zinc-500">
          © 2026 Viroklipz · Todos los derechos reservados
        </p>
      </div>
    </div>
  );
};
