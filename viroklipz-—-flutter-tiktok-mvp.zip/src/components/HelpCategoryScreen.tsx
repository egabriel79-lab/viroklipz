import React, { useState } from 'react';
import { ArrowLeft, ChevronRight, MessageSquare } from 'lucide-react';

type HelpTab = 'Cuenta' | 'Privacidad y seguridad' | 'Publicaciones';

interface HelpCategoryScreenProps {
  initialTab?: HelpTab;
  onBack: () => void;
  onNotify?: (message: string) => void;
}

const TABS: HelpTab[] = ['Cuenta', 'Privacidad y seguridad', 'Publicaciones'];

const FAQ_ITEMS = [
  'Informar de un problema técnico',
  'Estado de tu cuenta',
  'Edición, publicación y eliminación',
  'Seguridad de la cuenta',
];

export const HelpCategoryScreen: React.FC<HelpCategoryScreenProps> = ({
  initialTab = 'Cuenta',
  onBack,
  onNotify,
}) => {
  const [activeTab, setActiveTab] = useState<HelpTab>(initialTab);

  return (
    <div className="flex h-full w-full flex-col bg-[#121212] text-white select-none overflow-hidden">
      {/* AppBar */}
      <header className="relative flex h-12 shrink-0 items-center justify-center border-b border-white/10 bg-[#121212] px-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Atrás"
          className="absolute left-2 flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="text-[15px] font-bold text-white">Categorías de ayuda</h1>
      </header>

      {/* Tabs */}
      <div className="flex shrink-0 border-b border-white/10 bg-[#121212]">
        {TABS.map((tab) => {
          const selected = activeTab === tab;
          return (
            <button
              key={tab}
              type="button"
              onClick={() => setActiveTab(tab)}
              className={`relative flex-1 px-1 py-3 text-center text-[11px] font-semibold transition-colors ${
                selected ? 'text-white' : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <span className="truncate block">{tab}</span>
              {selected && (
                <span className="absolute bottom-0 left-2 right-2 h-0.5 rounded-full bg-[#E91E63]" />
              )}
            </button>
          );
        })}
      </div>

      {/* Lista de artículos por pestaña */}
      <div className="flex-1 min-h-0 overflow-y-auto px-4 py-4 no-scrollbar">
        <div className="divide-y divide-white/5 overflow-hidden rounded-xl bg-[#1E1E1E]">
          {FAQ_ITEMS.map((item) => (
            <button
              key={`${activeTab}-${item}`}
              type="button"
              onClick={() => onNotify?.(`${activeTab}: ${item}`)}
              className="flex w-full items-center justify-between px-4 py-3.5 text-left transition-colors hover:bg-white/5"
            >
              <span className="text-[14px] font-medium text-zinc-100">
                {item}
              </span>
              <ChevronRight className="h-4 w-4 shrink-0 text-zinc-500" />
            </button>
          ))}
        </div>

        <button
          type="button"
          onClick={() => onNotify?.(`Más artículos de ${activeTab}`)}
          className="mt-4 w-full rounded-xl bg-[#1E1E1E] py-3 text-center text-xs font-semibold text-zinc-200 transition-colors hover:bg-[#27272A]"
        >
          Ver más
        </button>
      </div>

      {/* Botón sticky inferior */}
      <div className="shrink-0 border-t border-white/10 bg-[#121212] px-4 py-3">
        <button
          type="button"
          onClick={() => onNotify?.('Iniciando chat de soporte...')}
          className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#E91E63] py-3 text-sm font-bold text-white transition-opacity hover:opacity-90 active:opacity-80"
        >
          <MessageSquare className="h-4 w-4" />
          <span>Chatea con nosotros</span>
        </button>
      </div>
    </div>
  );
};
