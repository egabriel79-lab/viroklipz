import React, { useState } from 'react';
import { ArrowLeft } from 'lucide-react';

interface ContactsLocationSettingsScreenProps {
  onBack: () => void;
  onNotify?: (message: string) => void;
}

export const ContactsLocationSettingsScreen: React.FC<
  ContactsLocationSettingsScreenProps
> = ({ onBack, onNotify }) => {
  const [contacts, setContacts] = useState(true);
  const [facebookFriends, setFacebookFriends] = useState(true);
  const [linkOpeners, setLinkOpeners] = useState(true);
  const [syncContacts, setSyncContacts] = useState(true);

  const renderSwitch = (
    title: string,
    checked: boolean,
    onToggle: () => void,
    subtitle?: string
  ) => (
    <div className="flex items-start justify-between gap-4 px-4 py-3.5">
      <div className="min-w-0 flex-1">
        <p className="text-[14px] font-medium text-white">{title}</p>
        {subtitle && (
          <p className="mt-1 text-xs leading-relaxed text-zinc-400">{subtitle}</p>
        )}
      </div>
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        onClick={onToggle}
        className={`relative mt-0.5 inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors ${
          checked ? 'bg-[#FF5722]' : 'bg-zinc-600'
        }`}
      >
        <span
          className={`inline-block h-5 w-5 transform rounded-full bg-white shadow transition-transform ${
            checked ? 'translate-x-5' : 'translate-x-0.5'
          }`}
        />
      </button>
    </div>
  );

  return (
    <div className="flex h-full w-full flex-col bg-[#121212] text-white select-none overflow-hidden">
      <header className="relative flex h-12 shrink-0 items-center justify-center border-b border-white/10 bg-[#121212] px-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Atrás"
          className="absolute left-2 flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="text-[15px] font-bold text-white">Contactos y ubicación</h1>
      </header>

      <div className="flex-1 min-h-0 overflow-y-auto px-4 py-4 space-y-5 no-scrollbar">
        <section>
          <h2 className="mb-2 px-1 text-xs font-semibold tracking-wide text-zinc-400">
            Recomienda tu cuenta a otros
          </h2>
          <div className="divide-y divide-white/5 overflow-hidden rounded-xl bg-[#1E1E1E]">
            {renderSwitch('Contactos', contacts, () => {
              const next = !contacts;
              setContacts(next);
              onNotify?.(`Contactos ${next ? 'activado' : 'desactivado'}`);
            })}
            {renderSwitch('Amigos de Facebook', facebookFriends, () => {
              const next = !facebookFriends;
              setFacebookFriends(next);
              onNotify?.(`Amigos de Facebook ${next ? 'activado' : 'desactivado'}`);
            })}
            {renderSwitch(
              'Usuarios que abrieron o te enviaron enlaces',
              linkOpeners,
              () => {
                const next = !linkOpeners;
                setLinkOpeners(next);
                onNotify?.(
                  `Usuarios de enlaces ${next ? 'activado' : 'desactivado'}`
                );
              }
            )}
          </div>
        </section>

        <section>
          <h2 className="mb-2 px-1 text-xs font-semibold tracking-wide text-zinc-400">
            Sincronizar contactos y amigos de Facebook
          </h2>
          <div className="overflow-hidden rounded-xl bg-[#1E1E1E]">
            {renderSwitch(
              'Sincronizar contactos',
              syncContacts,
              () => {
                const next = !syncContacts;
                setSyncContacts(next);
                onNotify?.(`Sincronizar contactos ${next ? 'activado' : 'desactivado'}`);
              },
              'Sincroniza periódicamente la libreta de contactos para sugerir conexiones.'
            )}
          </div>
        </section>
      </div>
    </div>
  );
};
