import React, { useState } from 'react';
import {
  AlertTriangle,
  ArrowLeft,
  Calendar,
  Mail,
  MapPin,
  ShieldCheck,
  User,
} from 'lucide-react';

export interface TutorInfo {
  nombre: string;
  apellido: string;
  email: string;
}

export interface RegisteredProfile {
  firstName: string;
  lastName: string;
  country: string;
  age: number;
  isMinor: boolean;
  tutor?: TutorInfo;
}

interface RegisterFormScreenProps {
  onBack: () => void;
  onGoToLogin: () => void;
  onRegistered: (profile: RegisteredProfile) => void;
}

interface FormErrors {
  firstName?: string;
  lastName?: string;
  country?: string;
  age?: string;
  tutorFirstName?: string;
  tutorLastName?: string;
  tutorEmail?: string;
  general?: string;
}

export const RegisterFormScreen: React.FC<RegisterFormScreenProps> = ({
  onBack,
  onGoToLogin,
  onRegistered,
}) => {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [country, setCountry] = useState('');
  const [age, setAge] = useState('');

  const [tutorFirstName, setTutorFirstName] = useState('');
  const [tutorLastName, setTutorLastName] = useState('');
  const [tutorEmail, setTutorEmail] = useState('');

  const [errors, setErrors] = useState<FormErrors>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const trimmedAge = age.trim();
  const parsedAge = Number(trimmedAge);
  const isValidPositiveAge =
    trimmedAge !== '' && Number.isInteger(parsedAge) && parsedAge > 0 && parsedAge <= 120;
  const isMinor = isValidPositiveAge && parsedAge < 18;

  const validate = (): boolean => {
    const nextErrors: FormErrors = {};

    if (!firstName.trim()) {
      nextErrors.firstName = 'Ingresa tus nombres';
    }
    if (!lastName.trim()) {
      nextErrors.lastName = 'Ingresa tus apellidos';
    }
    if (!country.trim()) {
      nextErrors.country = 'Ingresa tu país';
    }

    if (!trimmedAge) {
      nextErrors.age = 'Ingresa tu edad';
    } else if (!isValidPositiveAge) {
      nextErrors.age = 'Ingresa una edad numérica válida (1 a 120)';
    }

    if (isMinor) {
      if (!tutorFirstName.trim()) {
        nextErrors.tutorFirstName = 'Ingresa los nombres del representante legal';
      }
      if (!tutorLastName.trim()) {
        nextErrors.tutorLastName = 'Ingresa los apellidos del representante legal';
      }
      const cleanTutorEmail = tutorEmail.trim();
      if (!cleanTutorEmail) {
        nextErrors.tutorEmail = 'Ingresa el correo del representante legal';
      } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanTutorEmail)) {
        nextErrors.tutorEmail = 'Ingresa un correo electrónico válido';
      }

      if (
        nextErrors.tutorFirstName ||
        nextErrors.tutorLastName ||
        nextErrors.tutorEmail
      ) {
        nextErrors.general =
          'Debes completar todos los datos del representante legal para registrar una cuenta de menor de edad.';
      }
    }

    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);
    window.setTimeout(() => {
      setIsSubmitting(false);
      onRegistered({
        firstName: firstName.trim(),
        lastName: lastName.trim(),
        country: country.trim(),
        age: parsedAge,
        isMinor,
        tutor: isMinor
          ? {
              nombre: tutorFirstName.trim(),
              apellido: tutorLastName.trim(),
              email: tutorEmail.trim(),
            }
          : undefined,
      });
    }, 350);
  };

  return (
    <div className="relative h-full w-full overflow-y-auto bg-[#0F0F0F] text-white no-scrollbar">
      {/* Resplandores ambientales unificados con la Landing Page */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-24 left-1/2 h-72 w-72 -translate-x-1/2 rounded-full bg-orange-500/15 blur-[95px]"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute bottom-10 -right-16 h-64 w-64 rounded-full bg-purple-600/15 blur-[95px]"
      />

      {/* Cabecera */}
      <header className="sticky top-0 z-20 flex items-center justify-between border-b border-white/10 bg-[#0F0F0F]/85 px-4 py-3 backdrop-blur-md">
        <button
          type="button"
          onClick={onBack}
          aria-label="Volver a la landing"
          className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg px-2 text-xs font-medium text-zinc-300 transition-colors hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-orange-400"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Volver</span>
        </button>

        <span className="font-display text-base font-black tracking-tight text-white">
          Viroklipz
        </span>

        <div className="w-16" aria-hidden="true" />
      </header>

      {/* Formulario a pantalla completa directamente sobre el fondo #0F0F0F unificado */}
      <main className="relative z-10 flex min-h-[calc(100%-65px)] flex-col justify-between px-5 pb-8 pt-6">
        <form
          id="register-profile-form"
          onSubmit={handleSubmit}
          noValidate
          className="flex flex-1 flex-col justify-between space-y-8"
        >
          <div className="space-y-6">
            <div className="space-y-1.5">
              <h1 className="font-display text-[26px] font-black leading-tight tracking-tight text-white">
                Crea tu perfil de creador
              </h1>
              <p className="text-xs leading-relaxed text-zinc-400">
                Completa tus datos para personalizar tu cuenta en Viroklipz.
              </p>
            </div>

            <div className="space-y-4">
              {/* Nombres */}
              <div className="space-y-1.5">
                <label
                  htmlFor="reg-first-name"
                  className="block text-xs font-semibold text-zinc-200"
                >
                  Nombres
                </label>
                <div className="relative">
                  <User className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-400" />
                  <input
                    id="reg-first-name"
                    type="text"
                    value={firstName}
                    onChange={(e) => {
                      setFirstName(e.target.value);
                      if (errors.firstName) {
                        setErrors((prev) => ({ ...prev, firstName: undefined }));
                      }
                    }}
                    placeholder="Ej. Mateo Sebastián"
                    className={`h-12 w-full rounded-xl border bg-[#161616] pl-10 pr-3.5 text-sm text-white placeholder:text-zinc-500 focus:outline-none ${
                      errors.firstName
                        ? 'border-[#FF4D6D] focus:border-[#FF4D6D]'
                        : 'border-white/15 focus:border-[#FF6B00]'
                    }`}
                  />
                </div>
                {errors.firstName && (
                  <p className="text-[11.5px] font-medium text-[#FF4D6D]">
                    {errors.firstName}
                  </p>
                )}
              </div>

              {/* Apellidos */}
              <div className="space-y-1.5">
                <label
                  htmlFor="reg-last-name"
                  className="block text-xs font-semibold text-zinc-200"
                >
                  Apellidos
                </label>
                <div className="relative">
                  <User className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-400" />
                  <input
                    id="reg-last-name"
                    type="text"
                    value={lastName}
                    onChange={(e) => {
                      setLastName(e.target.value);
                      if (errors.lastName) {
                        setErrors((prev) => ({ ...prev, lastName: undefined }));
                      }
                    }}
                    placeholder="Ej. Rivera Gómez"
                    className={`h-12 w-full rounded-xl border bg-[#161616] pl-10 pr-3.5 text-sm text-white placeholder:text-zinc-500 focus:outline-none ${
                      errors.lastName
                        ? 'border-[#FF4D6D] focus:border-[#FF4D6D]'
                        : 'border-white/15 focus:border-[#FF6B00]'
                    }`}
                  />
                </div>
                {errors.lastName && (
                  <p className="text-[11.5px] font-medium text-[#FF4D6D]">
                    {errors.lastName}
                  </p>
                )}
              </div>

              {/* País (antes Ciudad) */}
              <div className="space-y-1.5">
                <label
                  htmlFor="reg-country"
                  className="block text-xs font-semibold text-zinc-200"
                >
                  País
                </label>
                <div className="relative">
                  <MapPin className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-400" />
                  <input
                    id="reg-country"
                    type="text"
                    value={country}
                    onChange={(e) => {
                      setCountry(e.target.value);
                      if (errors.country) {
                        setErrors((prev) => ({ ...prev, country: undefined }));
                      }
                    }}
                    placeholder="Escribe tu país (ej. Colombia, España, México...)"
                    className={`h-12 w-full rounded-xl border bg-[#161616] pl-10 pr-3.5 text-sm text-white placeholder:text-zinc-500 focus:outline-none ${
                      errors.country
                        ? 'border-[#FF4D6D] focus:border-[#FF4D6D]'
                        : 'border-white/15 focus:border-[#FF6B00]'
                    }`}
                  />
                </div>
                {errors.country && (
                  <p className="text-[11.5px] font-medium text-[#FF4D6D]">
                    {errors.country}
                  </p>
                )}
              </div>

              {/* Edad */}
              <div className="space-y-1.5">
                <label
                  htmlFor="reg-age"
                  className="block text-xs font-semibold text-zinc-200"
                >
                  Edad
                </label>
                <div className="relative">
                  <Calendar className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-400" />
                  <input
                    id="reg-age"
                    type="number"
                    inputMode="numeric"
                    min={1}
                    max={120}
                    value={age}
                    onChange={(e) => {
                      setAge(e.target.value);
                      if (errors.age || errors.general) {
                        setErrors((prev) => ({
                          ...prev,
                          age: undefined,
                          general: undefined,
                        }));
                      }
                    }}
                    placeholder="Ej. 22"
                    className={`h-12 w-full rounded-xl border bg-[#161616] pl-10 pr-3.5 text-sm text-white tabular-nums placeholder:text-zinc-500 focus:outline-none ${
                      errors.age
                        ? 'border-[#FF4D6D] focus:border-[#FF4D6D]'
                        : 'border-white/15 focus:border-[#FF6B00]'
                    }`}
                  />
                </div>
                {errors.age && (
                  <p className="text-[11.5px] font-medium text-[#FF4D6D]">
                    {errors.age}
                  </p>
                )}
              </div>

              {/* Formulario dinámico de Representante Legal cuando Edad < 18 */}
              {isMinor && (
                <div className="mt-2 space-y-4 rounded-2xl border border-amber-500/30 bg-[#161616]/90 p-4 transition-all duration-300">
                  <div className="flex items-start gap-2.5 rounded-xl border border-amber-500/25 bg-amber-500/10 px-3 py-2.5">
                    <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-400" />
                    <p className="text-[11.5px] font-medium leading-relaxed text-amber-200">
                      Debes tener al menos 18 años o contar con la autorización de un tutor legal
                    </p>
                  </div>

                  <div className="flex items-center gap-2 pt-0.5">
                    <ShieldCheck className="h-4 w-4 text-[#EC4899]" />
                    <h2 className="text-xs font-bold uppercase tracking-wider text-zinc-100">
                      Información del Representante Legal
                    </h2>
                  </div>

                  {/* Nombres del tutor */}
                  <div className="space-y-1.5">
                    <label
                      htmlFor="reg-tutor-first-name"
                      className="block text-xs font-semibold text-zinc-200"
                    >
                      Nombres (del tutor)
                    </label>
                    <div className="relative">
                      <User className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-400" />
                      <input
                        id="reg-tutor-first-name"
                        type="text"
                        value={tutorFirstName}
                        onChange={(e) => {
                          setTutorFirstName(e.target.value);
                          if (errors.tutorFirstName || errors.general) {
                            setErrors((prev) => ({
                              ...prev,
                              tutorFirstName: undefined,
                              general: undefined,
                            }));
                          }
                        }}
                        placeholder="Nombres del representante legal"
                        className={`h-11 w-full rounded-xl border bg-[#0F0F0F] pl-10 pr-3.5 text-sm text-white placeholder:text-zinc-500 focus:outline-none ${
                          errors.tutorFirstName
                            ? 'border-[#FF4D6D] focus:border-[#FF4D6D]'
                            : 'border-white/15 focus:border-[#EC4899]'
                        }`}
                      />
                    </div>
                    {errors.tutorFirstName && (
                      <p className="text-[11.5px] font-medium text-[#FF4D6D]">
                        {errors.tutorFirstName}
                      </p>
                    )}
                  </div>

                  {/* Apellidos del tutor */}
                  <div className="space-y-1.5">
                    <label
                      htmlFor="reg-tutor-last-name"
                      className="block text-xs font-semibold text-zinc-200"
                    >
                      Apellidos (del tutor)
                    </label>
                    <div className="relative">
                      <User className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-400" />
                      <input
                        id="reg-tutor-last-name"
                        type="text"
                        value={tutorLastName}
                        onChange={(e) => {
                          setTutorLastName(e.target.value);
                          if (errors.tutorLastName || errors.general) {
                            setErrors((prev) => ({
                              ...prev,
                              tutorLastName: undefined,
                              general: undefined,
                            }));
                          }
                        }}
                        placeholder="Apellidos del representante legal"
                        className={`h-11 w-full rounded-xl border bg-[#0F0F0F] pl-10 pr-3.5 text-sm text-white placeholder:text-zinc-500 focus:outline-none ${
                          errors.tutorLastName
                            ? 'border-[#FF4D6D] focus:border-[#FF4D6D]'
                            : 'border-white/15 focus:border-[#EC4899]'
                        }`}
                      />
                    </div>
                    {errors.tutorLastName && (
                      <p className="text-[11.5px] font-medium text-[#FF4D6D]">
                        {errors.tutorLastName}
                      </p>
                    )}
                  </div>

                  {/* Correo electrónico del tutor */}
                  <div className="space-y-1.5">
                    <label
                      htmlFor="reg-tutor-email"
                      className="block text-xs font-semibold text-zinc-200"
                    >
                      Correo electrónico (del tutor)
                    </label>
                    <div className="relative">
                      <Mail className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-400" />
                      <input
                        id="reg-tutor-email"
                        type="email"
                        value={tutorEmail}
                        onChange={(e) => {
                          setTutorEmail(e.target.value);
                          if (errors.tutorEmail || errors.general) {
                            setErrors((prev) => ({
                              ...prev,
                              tutorEmail: undefined,
                              general: undefined,
                            }));
                          }
                        }}
                        placeholder="tutor@ejemplo.com"
                        className={`h-11 w-full rounded-xl border bg-[#0F0F0F] pl-10 pr-3.5 text-sm text-white placeholder:text-zinc-500 focus:outline-none ${
                          errors.tutorEmail
                            ? 'border-[#FF4D6D] focus:border-[#FF4D6D]'
                            : 'border-white/15 focus:border-[#EC4899]'
                        }`}
                      />
                    </div>
                    {errors.tutorEmail && (
                      <p className="text-[11.5px] font-medium text-[#FF4D6D]">
                        {errors.tutorEmail}
                      </p>
                    )}
                  </div>

                  {errors.general && (
                    <p
                      role="alert"
                      className="rounded-lg border border-[#FF4D6D]/35 bg-[#FF4D6D]/10 px-3 py-2 text-[11.5px] font-medium text-[#FF4D6D]"
                    >
                      {errors.general}
                    </p>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Botón inferior dinámico + acceso a Login */}
          <div className="space-y-3 pt-2">
            {!isMinor ? (
              <button
                type="submit"
                disabled={isSubmitting}
                className="flex h-13 w-full items-center justify-center rounded-xl bg-gradient-to-r from-[#FF6B00] via-[#FF3D00] to-[#EC4899] text-sm font-bold text-white shadow-[0_0_28px_rgba(255,107,0,0.45)] transition-transform hover:brightness-105 active:scale-95 disabled:opacity-60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-orange-400"
              >
                {isSubmitting ? 'Creando cuenta...' : 'Crear mi cuenta'}
              </button>
            ) : (
              <button
                type="submit"
                disabled={isSubmitting}
                className="flex h-13 w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#673AB7] via-[#9333EA] to-[#E91E63] px-4 text-sm font-bold text-white shadow-[0_0_28px_rgba(147,51,234,0.45)] transition-transform hover:brightness-105 active:scale-95 disabled:opacity-60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-purple-400"
              >
                <ShieldCheck className="h-4 w-4 shrink-0" />
                <span>
                  {isSubmitting
                    ? 'Registrando autorización...'
                    : 'Soy representante legal de menor de edad'}
                </span>
              </button>
            )}

            <button
              type="button"
              onClick={onGoToLogin}
              className="flex min-h-[44px] w-full items-center justify-center text-xs font-medium text-zinc-400 transition-colors hover:text-white"
            >
              ¿Ya tienes cuenta? Inicia sesión
            </button>
          </div>
        </form>
      </main>
    </div>
  );
};
