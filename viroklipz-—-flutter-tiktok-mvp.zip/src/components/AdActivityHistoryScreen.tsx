import React, { useState } from 'react';
import { ArrowLeft, ClipboardList, FileText, Link2 } from 'lucide-react';

type AdTabId = 'ads' | 'links' | 'reviews';

interface AdActivityHistoryScreenProps {
  onBack: () => void;
}

const TABS: { id: AdTabId; label: string }[] = [
  { id: 'ads', label: 'Historial de anuncios' },
  { id: 'links', label: 'Historial de enlaces' },
  { id: 'reviews', label: 'Reseñas de anuncios' },
];

export const AdActivityHistoryScreen: React.FC<
  AdActivityHistoryScreenProps
> = ({ onBack }) => {
  const [activeTab, setActiveTab] = useState<AdTabId>('ads');

  const emptyStates: Record<
    AdTabId,
    {
      title: string;
      description: string;
      icon: React.ReactNode;
    }
  > = {
    ads: {
      title: 'No hay historial de anuncios',
      description:
        'Aquí aparecerán los anuncios que hayas visto o con los que hayas interactuado recientemente en Viroklipz.',
      icon: <FileText className="h-14 w-14 text-zinc-500" />,
    },
    links: {
      title: 'No hay historial de enlaces',
      description:
        'Cuando abras enlaces externos desde promociones o anuncios patrocinados, se guardarán en esta lista.',
      icon: <Link2 className="h-14 w-14 text-zinc-500" />,
    },
    reviews: {
      title: 'No hay reseñas de anuncios',
      description:
        'Tus comentarios y valoraciones sobre anuncios relevantes aparecerán aquí una vez los envíes.',
      icon: <ClipboardList className="h-14 w-14 text-zinc-500" />,
    },
  };

  const currentEmpty = emptyStates[activeTab];

  return (
    <div className="flex h-full w-full flex-col bg-[#121212] text-white select-none overflow-hidden">
      {/* AppBar */}
      <header className="flex h-12 shrink-0 items-center gap-1 border-b border-white/10 px-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Volver al centro de actividades"
          className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="truncate text-[15px] font-bold text-white">
          Historial de actividad de anuncios
        </h1>
      </header>

      {/* TabBar de 3 pestañas */}
      <div className="grid shrink-0 grid-cols-3 border-b border-white/10">
        {TABS.map((tab) => {
          const isSelected = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id)}
              className={`relative px-1.5 py-3 text-center text-[11px] font-semibold leading-tight transition-colors ${
                isSelected ? 'text-white' : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <span className="line-clamp-2">{tab.label}</span>
              {isSelected && (
                <span className="absolute bottom-0 left-3 right-3 h-[2px] rounded-full bg-white" />
              )}
            </button>
          );
        })}
      </div>

      {/* Empty State */}
      <div className="flex flex-1 flex-col items-center justify-center px-8 text-center">
        <div className="flex h-24 w-24 items-center justify-center rounded-full bg-white/[0.04]">
          {currentEmpty.icon}
        </div>
        <h2 className="mt-4 text-base font-bold text-white">
          {currentEmpty.title}
        </h2>
        <p className="mt-2 max-w-[260px] text-xs leading-relaxed text-zinc-400">
          {currentEmpty.description}
        </p>
      </div>
    </div>
  );
};
