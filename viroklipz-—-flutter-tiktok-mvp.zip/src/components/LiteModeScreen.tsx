import React, { useState } from 'react';
import { ArrowLeft } from 'lucide-react';

interface LiteModeScreenProps {
  initialEnabled?: boolean;
  onToggleEnabled?: (enabled: boolean) => void;
  onBack: () => void;
  onNotify?: (message: string) => void;
}

export const LiteModeScreen: React.FC<LiteModeScreenProps> = ({
  initialEnabled = true,
  onToggleEnabled,
  onBack,
  onNotify,
}) => {
  const [enabled, setEnabled] = useState(initialEnabled);

  const handleToggle = () => {
    const next = !enabled;
    setEnabled(next);
    onToggleEnabled?.(next);
    onNotify?.(`Modo lite: ${next ? 'Activado' : 'Desactivado'}`);
  };

  return (
    <div className="flex h-full w-full flex-col bg-[#121212] text-white select-none overflow-hidden">
      <header className="relative flex h-12 shrink-0 items-center justify-center border-b border-white/10 bg-[#121212] px-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Atrás"
          className="absolute left-2 flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="text-[15px] font-bold text-white">Modo lite</h1>
      </header>

      <div className="flex-1 min-h-0 overflow-y-auto px-4 py-4 no-scrollbar">
        <div className="overflow-hidden rounded-xl bg-[#1E1E1E]">
          <div className="flex items-start justify-between gap-4 px-4 py-4">
            <div className="min-w-0 flex-1">
              <p className="text-[14px] font-medium text-white">Modo lite</p>
              <p className="mt-1 text-xs leading-relaxed text-zinc-400">
                Optimiza el rendimiento de Viroklipz, reduce el uso de batería y
                disminuye el consumo de datos al reproducir videos en redes lentas.
              </p>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={enabled}
              onClick={handleToggle}
              className={`relative mt-0.5 inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors ${
                enabled ? 'bg-[#E91E63]' : 'bg-zinc-600'
              }`}
            >
              <span
                className={`inline-block h-5 w-5 transform rounded-full bg-white shadow transition-transform ${
                  enabled ? 'translate-x-5' : 'translate-x-0.5'
                }`}
              />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
