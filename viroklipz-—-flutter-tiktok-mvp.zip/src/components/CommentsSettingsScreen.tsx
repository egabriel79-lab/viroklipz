import React, { useState } from 'react';
import { ArrowLeft, ChevronRight, X } from 'lucide-react';

interface CommentsSettingsScreenProps {
  onBack: () => void;
  onNotify?: (message: string) => void;
}

type CommentAudience = 'everyone' | 'friends';

export const CommentsSettingsScreen: React.FC<CommentsSettingsScreenProps> = ({
  onBack,
  onNotify,
}) => {
  const [audience, setAudience] = useState<CommentAudience>('everyone');
  const [showAudienceSheet, setShowAudienceSheet] = useState(false);

  const [creatorControlMode, setCreatorControlMode] = useState(false);
  const [filterSpam, setFilterSpam] = useState(true);

  return (
    <div className="relative flex h-full w-full flex-col bg-[#121212] text-white select-none overflow-hidden">
      {/* AppBar */}
      <header className="relative flex h-12 shrink-0 items-center justify-center border-b border-white/10 bg-[#121212] px-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Atrás"
          className="absolute left-2 flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="text-[15px] font-bold text-white">Comentarios</h1>
      </header>

      {/* Cuerpo ListView */}
      <div className="flex-1 min-h-0 overflow-y-auto px-4 pt-5 pb-8 space-y-5 no-scrollbar">
        {/* Opción 1: Permite los comentarios desde */}
        <button
          type="button"
          onClick={() => setShowAudienceSheet(true)}
          className="flex w-full items-center justify-between gap-3 rounded-xl bg-[#1E1E1E] px-4 py-4 text-left transition-colors hover:bg-white/[0.04]"
        >
          <span className="text-[14px] font-semibold text-white">
            Permite los comentarios desde
          </span>
          <div className="flex shrink-0 items-center gap-1.5">
            <span className="text-xs text-zinc-400">
              {audience === 'everyone' ? 'Todo el m...' : 'Amigos'}
            </span>
            <ChevronRight className="h-4 w-4 text-zinc-500" />
          </div>
        </button>

        {/* Sección "Filtros de comentarios" */}
        <section>
          <h2 className="mb-2 px-1 text-xs font-semibold tracking-wide text-zinc-400">
            Filtros de comentarios
          </h2>

          <div className="divide-y divide-white/5 overflow-hidden rounded-xl bg-[#1E1E1E]">
            {/* Fila 1: Modo Control para creadores */}
            <div
              onClick={() => setCreatorControlMode((prev) => !prev)}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  setCreatorControlMode((prev) => !prev);
                }
              }}
              className="flex w-full cursor-pointer items-start justify-between gap-3 px-4 py-4 transition-colors hover:bg-white/5"
            >
              <div className="min-w-0 flex-1">
                <p className="text-[14px] font-medium text-zinc-100">
                  Modo Control para creadores
                </p>
                <p className="mt-1 text-xs leading-relaxed text-zinc-400">
                  Activa esta opción para ocultar automáticamente comentarios
                  ofensivos o poco relevantes hasta que decidas aprobarlos.
                </p>
              </div>
              <button
                type="button"
                role="switch"
                aria-checked={creatorControlMode}
                aria-label="Modo Control para creadores"
                onClick={(e) => {
                  e.stopPropagation();
                  setCreatorControlMode((prev) => !prev);
                }}
                className={`relative mt-0.5 inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors ${
                  creatorControlMode ? 'bg-[#25F4EE]' : 'bg-zinc-600'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white shadow transition-transform ${
                    creatorControlMode ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            {/* Fila 2: Filtra comentarios no deseados */}
            <div
              onClick={() => setFilterSpam((prev) => !prev)}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  setFilterSpam((prev) => !prev);
                }
              }}
              className="flex w-full cursor-pointer items-start justify-between gap-3 px-4 py-4 transition-colors hover:bg-white/5"
            >
              <div className="min-w-0 flex-1">
                <p className="text-[14px] font-medium text-zinc-100">
                  Filtra comentarios no deseados
                </p>
                <p className="mt-1 text-xs leading-relaxed text-zinc-400">
                  Oculta comentarios que el sistema detecte como spam o
                  contenido inapropiado antes de mostrarse en tus videos.
                </p>
              </div>
              <button
                type="button"
                role="switch"
                aria-checked={filterSpam}
                aria-label="Filtra comentarios no deseados"
                onClick={(e) => {
                  e.stopPropagation();
                  setFilterSpam((prev) => !prev);
                }}
                className={`relative mt-0.5 inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors ${
                  filterSpam ? 'bg-[#25F4EE]' : 'bg-zinc-600'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white shadow transition-transform ${
                    filterSpam ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            {/* Fila 3: Filtra palabras clave específicas */}
            <button
              type="button"
              onClick={() =>
                onNotify?.('Filtros: Filtra palabras clave específicas')
              }
              className="flex w-full items-center justify-between gap-3 px-4 py-4 text-left transition-colors hover:bg-white/5"
            >
              <div className="min-w-0 flex-1">
                <p className="text-[14px] font-medium text-zinc-100">
                  Filtra palabras clave específicas
                </p>
                <p className="mt-1 text-xs leading-relaxed text-zinc-400">
                  Agrega palabras o frases que quieras ocultar automáticamente
                  en los comentarios de todas tus publicaciones.
                </p>
              </div>
              <ChevronRight className="h-4 w-4 shrink-0 text-zinc-500" />
            </button>

            {/* Fila 4: Revisar comentarios filtrados */}
            <button
              type="button"
              onClick={() =>
                onNotify?.('Revisar comentarios filtrados')
              }
              className="flex w-full items-center justify-between gap-3 px-4 py-4 text-left transition-colors hover:bg-white/5"
            >
              <div className="min-w-0 flex-1">
                <p className="text-[14px] font-medium text-zinc-100">
                  Revisar comentarios filtrados
                </p>
                <p className="mt-1 text-xs leading-relaxed text-zinc-400">
                  Se mostrarán solo los comentarios aprobados
                </p>
              </div>
              <ChevronRight className="h-4 w-4 shrink-0 text-zinc-500" />
            </button>
          </div>
        </section>
      </div>

      {/* Bottom Sheet fondo blanco: Comentarios */}
      {showAudienceSheet && (
        <div
          className="absolute inset-0 z-50 flex items-end bg-black/55 backdrop-blur-[1px]"
          onClick={() => setShowAudienceSheet(false)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full rounded-t-[20px] bg-white px-5 pt-3 pb-7 text-zinc-950 shadow-2xl"
          >
            <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-zinc-300" />

            <div className="relative mb-4 flex items-center justify-center py-1">
              <h2 className="text-[16px] font-bold text-zinc-950">
                Comentarios
              </h2>
              <button
                type="button"
                onClick={() => setShowAudienceSheet(false)}
                aria-label="Cerrar"
                className="absolute right-0 flex h-8 w-8 items-center justify-center rounded-full text-zinc-700 transition-colors hover:bg-zinc-100"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="space-y-2">
              {/* Opción 1: Todo el mundo */}
              <button
                type="button"
                onClick={() => {
                  setAudience('everyone');
                  setShowAudienceSheet(false);
                  onNotify?.('Comentarios: Todo el mundo');
                }}
                className="flex w-full items-center justify-between rounded-xl px-2 py-3 text-left transition-colors hover:bg-zinc-100"
              >
                <span className="text-[15px] font-semibold text-zinc-900">
                  Todo el mundo
                </span>
                <span
                  className={`flex h-5 w-5 items-center justify-center rounded-full border-2 ${
                    audience === 'everyone'
                      ? 'border-[#FE2C55]'
                      : 'border-zinc-400'
                  }`}
                >
                  {audience === 'everyone' && (
                    <span className="h-2.5 w-2.5 rounded-full bg-[#FE2C55]" />
                  )}
                </span>
              </button>

              {/* Opción 2: Amigos 6 > */}
              <button
                type="button"
                onClick={() => {
                  setAudience('friends');
                  setShowAudienceSheet(false);
                  onNotify?.('Comentarios: Amigos');
                }}
                className="flex w-full items-center justify-between rounded-xl px-2 py-3 text-left transition-colors hover:bg-zinc-100"
              >
                <div className="min-w-0 flex-1 pr-3">
                  <div className="flex items-center gap-1 text-[15px] font-semibold text-zinc-900">
                    <span>Amigos 6</span>
                    <ChevronRight className="h-4 w-4 text-zinc-500" />
                  </div>
                  <p className="mt-0.5 text-xs text-zinc-500">
                    Seguidores a los que también sigues
                  </p>
                </div>

                <span
                  className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-full border-2 ${
                    audience === 'friends'
                      ? 'border-[#FE2C55]'
                      : 'border-zinc-400'
                  }`}
                >
                  {audience === 'friends' && (
                    <span className="h-2.5 w-2.5 rounded-full bg-[#FE2C55]" />
                  )}
                </span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
