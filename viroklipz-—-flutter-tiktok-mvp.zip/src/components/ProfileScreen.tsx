import React, { useState } from 'react';
import {
  ArrowLeft,
  Bookmark,
  ChevronRight,
  Clock,
  CloudDownload,
  Coins,
  FileText,
  Grid3X3,
  Heart,
  Loader2,
  Lock,
  LogOut,
  Menu,
  Pencil,
  Play,
  Plus,
  QrCode,
  Repeat2,
  Settings,
  Shield,
  Star,
  Trash2,
  UserPlus,
  Wallet,
  X,
} from 'lucide-react';
import { EditDescriptionScreen } from './EditDescriptionScreen';
import { ViroklipzStudioScreen } from './ViroklipzStudioScreen';
import { SelectHighlightMediaScreen } from './SelectHighlightMediaScreen';
import { StoryHighlightSlide, StoryViewerScreen } from './StoryViewerScreen';
import { QrProfileScreen } from './QrProfileScreen';
import { EditProfileScreen } from './EditProfileScreen';
import { ActivityCenterScreen } from './ActivityCenterScreen';
import { OfflineVideosScreen } from './OfflineVideosScreen';
import { SettingsPrivacyScreen } from './SettingsPrivacyScreen';
import { BalanceScreen } from './BalanceScreen';
import { GetCoinsScreen } from './GetCoinsScreen';
import { LEGAL_TEXTS, LegalScreen } from './LegalScreen';
import { UserAccount } from '../hooks/useAuthProvider';
import { VideoItem } from '../data/mockVideos';

interface ProfileHighlightItem {
  id: string;
  title: string;
  coverUrl: string;
  timeAgo: string;
  slides: StoryHighlightSlide[];
}

const INITIAL_HIGHLIGHTS: ProfileHighlightItem[] = [
  {
    id: 'hl-moment',
    title: 'Moment...',
    coverUrl: '/src/assets/images/story_hinduismo_temple_1794607243976.jpg',
    timeAgo: 'hace 23 h',
    slides: [
      {
        id: 'sl-1',
        url: '/src/assets/images/story_hinduismo_temple_1794607243976.jpg',
        caption: 'HINDUISMO',
      },
      {
        id: 'sl-2',
        url: '/src/assets/images/avatar_creator_mateo_1794604321715.jpg',
      },
    ],
  },
];

interface ProfileScreenProps {
  currentUsername: string;
  currentEmail: string;
  savedAccounts?: UserAccount[];
  currentUser?: UserAccount | null;
  userVideos?: VideoItem[];
  likedVideos?: VideoItem[];
  onSelectVideo?: (videoId: string) => void;
  onSwitchAccount?: (account: UserAccount) => void;
  onAddAccount?: () => void;
  onDeleteAccount?: (account: UserAccount) => void;
  onUpdateUserProfile?: (updates: {
    avatarUrl?: string;
    displayName?: string;
    username?: string;
  }) => void;
  onBackToFeed: () => void;
  onSignOut: () => void;
  onOpenCamera?: () => void;
  onNotify?: (message: string) => void;
}

type ProfileTabId = 'videos' | 'private' | 'reposts' | 'saved' | 'liked';

interface ProfileVideoThumb {
  id: string;
  thumbUrl: string;
  views: string;
  tab: ProfileTabId;
}

const PROFILE_THUMBNAILS: ProfileVideoThumb[] = [
  {
    id: 'pv-1',
    thumbUrl: '/src/assets/images/avatar_creator_mateo_1794604321715.jpg',
    views: '157',
    tab: 'videos',
  },
  {
    id: 'pv-2',
    thumbUrl: '/src/assets/images/story_hinduismo_temple_1794607243976.jpg',
    views: '412',
    tab: 'videos',
  },
  {
    id: 'pv-3',
    thumbUrl: '/src/assets/images/avatar_creator_valeria_1794604321625.jpg',
    views: '1.2K',
    tab: 'videos',
  },
  {
    id: 'pv-4',
    thumbUrl: '/src/assets/images/avatar_creator_lucas_1794604322245.jpg',
    views: '893',
    tab: 'videos',
  },
  {
    id: 'pv-5',
    thumbUrl: '/src/assets/images/avatar_creator_sofia_1794604322145.jpg',
    views: '2.4K',
    tab: 'videos',
  },
  {
    id: 'pv-6',
    thumbUrl: '/src/assets/images/avatar_creator_diego_1794604323122.jpg',
    views: '645',
    tab: 'videos',
  },
  {
    id: 'pv-7',
    thumbUrl: '/src/assets/images/avatar_creator_valeria_1794604321625.jpg',
    views: '32.4K',
    tab: 'liked',
  },
  {
    id: 'pv-8',
    thumbUrl: '/src/assets/images/avatar_creator_sofia_1794604322145.jpg',
    views: '21.5K',
    tab: 'liked',
  },
];

const PROFILE_TABS: { id: ProfileTabId; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { id: 'videos', label: 'Videos', icon: Grid3X3 },
  { id: 'private', label: 'Privados', icon: Lock },
  { id: 'reposts', label: 'Compartidos', icon: Repeat2 },
  { id: 'saved', label: 'Guardados', icon: Bookmark },
  { id: 'liked', label: 'Me gusta', icon: Heart },
];

export const ProfileScreen: React.FC<ProfileScreenProps> = ({
  currentUsername,
  currentEmail,
  savedAccounts,
  currentUser,
  userVideos = [],
  likedVideos = [],
  onSelectVideo,
  onSwitchAccount,
  onAddAccount,
  onDeleteAccount,
  onUpdateUserProfile,
  onBackToFeed,
  onSignOut,
  onOpenCamera,
  onNotify,
}) => {
  const [nombreUsuario, setNombreUsuario] = useState(
    currentUser?.displayName || 'Eloy'
  );
  const [arroba, setArroba] = useState(
    currentUser ? `@${currentUser.username}` : '@gabriel_12343'
  );
  const [bio, setBio] = useState('');
  const [pronoun, setPronoun] = useState('');
  const [avatarUrl, setAvatarUrl] = useState(
    currentUser?.avatarUrl ||
      '/src/assets/images/avatar_creator_mateo_1794604321715.jpg'
  );
  const [backgroundUrl, setBackgroundUrl] = useState('');

  React.useEffect(() => {
    if (currentUser) {
      setNombreUsuario(currentUser.displayName);
      setArroba(`@${currentUser.username}`);
      setAvatarUrl(currentUser.avatarUrl);
    }
  }, [currentUser]);
  const [highlights, setHighlights] = useState<ProfileHighlightItem[]>(INITIAL_HIGHLIGHTS);
  const [activeHighlight, setActiveHighlight] = useState<ProfileHighlightItem | null>(null);
  const [activeSubScreen, setActiveSubScreen] = useState<
    | 'none'
    | 'edit_bio'
    | 'edit_profile'
    | 'studio'
    | 'select_highlight'
    | 'story_viewer'
    | 'qr_profile'
    | 'activity_center'
    | 'offline_videos'
    | 'settings_privacy'
    | 'terms_conditions'
    | 'privacy_policy'
    | 'balance'
    | 'get_coins'
  >('none');
  const [activeTab, setActiveTab] = useState<ProfileTabId>('videos');
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isDeletingAccount, setIsDeletingAccount] = useState(false);
  const [scannedProfileHandle, setScannedProfileHandle] = useState<string | null>(null);
  const [isFollowingScanned, setIsFollowingScanned] = useState(false);

  const visibleVideoItems: VideoItem[] =
    activeTab === 'videos'
      ? userVideos
      : activeTab === 'liked'
        ? likedVideos
        : [];

  if (activeSubScreen === 'edit_bio') {
    return (
      <EditDescriptionScreen
        initialDescription={bio}
        onCancel={() => setActiveSubScreen('none')}
        onSave={(newDescription) => {
          setBio(newDescription);
          setActiveSubScreen('none');
          onNotify?.('Descripción actualizada');
        }}
      />
    );
  }

  if (activeSubScreen === 'studio') {
    return (
      <ViroklipzStudioScreen
        onBack={() => setActiveSubScreen('none')}
        onCreateVideo={() => {
          setActiveSubScreen('none');
          onOpenCamera?.();
        }}
        onNotify={onNotify}
      />
    );
  }

  if (activeSubScreen === 'select_highlight') {
    return (
      <SelectHighlightMediaScreen
        onClose={() => setActiveSubScreen('none')}
        onCreateHighlight={(payload) => {
          const created: ProfileHighlightItem = {
            id: `hl-${Date.now()}`,
            title: payload.title,
            coverUrl: payload.coverUrl,
            timeAgo: 'ahora',
            slides: payload.slides,
          };
          setHighlights((prev) => [created, ...prev]);
          setActiveSubScreen('none');
          onNotify?.(`Destacado "${payload.title}" guardado`);
        }}
      />
    );
  }

  if (activeSubScreen === 'story_viewer' && activeHighlight) {
    return (
      <StoryViewerScreen
        title={activeHighlight.title}
        timeAgo={activeHighlight.timeAgo}
        avatarUrl={avatarUrl}
        slides={activeHighlight.slides}
        onClose={() => {
          setActiveHighlight(null);
          setActiveSubScreen('none');
        }}
        onNotify={onNotify}
      />
    );
  }

  if (activeSubScreen === 'qr_profile') {
    return (
      <QrProfileScreen
        nombreUsuario={nombreUsuario}
        arroba={arroba}
        avatarUrl={avatarUrl}
        onBack={() => setActiveSubScreen('none')}
        onOpenScannedProfile={(username) => {
          setIsFollowingScanned(false);
          setScannedProfileHandle(username);
          setActiveSubScreen('none');
        }}
        onNotify={onNotify}
      />
    );
  }

  if (activeSubScreen === 'edit_profile') {
    return (
      <EditProfileScreen
        profile={{
          nombreUsuario,
          arroba,
          bio,
          pronoun,
          avatarUrl,
          backgroundUrl,
        }}
        onAvatarUpdated={(newAvatarUrl) => {
          setAvatarUrl(newAvatarUrl);
          onUpdateUserProfile?.({ avatarUrl: newAvatarUrl });
        }}
        onBack={(updated) => {
          setNombreUsuario(updated.nombreUsuario);
          setArroba(updated.arroba);
          setBio(updated.bio);
          setPronoun(updated.pronoun);
          setAvatarUrl(updated.avatarUrl);
          setBackgroundUrl(updated.backgroundUrl);
          onUpdateUserProfile?.({
            avatarUrl: updated.avatarUrl,
            displayName: updated.nombreUsuario,
            username: updated.arroba.replace(/^@/, ''),
          });
          setActiveSubScreen('none');
        }}
        onOpenCamera={() => {
          setActiveSubScreen('none');
          onOpenCamera?.();
        }}
        onNotify={onNotify}
      />
    );
  }

  if (activeSubScreen === 'activity_center') {
    return (
      <ActivityCenterScreen
        onBack={() => setActiveSubScreen('none')}
        onNotify={onNotify}
      />
    );
  }

  if (activeSubScreen === 'offline_videos') {
    return (
      <OfflineVideosScreen
        onBack={() => setActiveSubScreen('none')}
        onNotify={onNotify}
      />
    );
  }

  if (activeSubScreen === 'balance') {
    return (
      <BalanceScreen
        onBack={() => setActiveSubScreen('none')}
        onOpenGetCoins={() => setActiveSubScreen('get_coins')}
        onNotify={onNotify}
      />
    );
  }

  if (activeSubScreen === 'get_coins') {
    return (
      <GetCoinsScreen
        onBack={() => setActiveSubScreen('none')}
        onNotify={onNotify}
      />
    );
  }

  if (activeSubScreen === 'settings_privacy') {
    return (
      <SettingsPrivacyScreen
        activeHandle={arroba}
        avatarUrl={avatarUrl}
        savedAccounts={savedAccounts}
        currentUser={currentUser}
        onSwitchAccount={onSwitchAccount}
        onAddAccount={onAddAccount}
        onDeleteAccount={onDeleteAccount}
        onBack={() => setActiveSubScreen('none')}
        onSignOut={onSignOut}
        onOpenActivityCenter={() => setActiveSubScreen('activity_center')}
        onOpenOfflineVideos={() => setActiveSubScreen('offline_videos')}
        onOpenQrProfile={() => setActiveSubScreen('qr_profile')}
        onNotify={onNotify}
      />
    );
  }

  if (activeSubScreen === 'terms_conditions') {
    return (
      <LegalScreen
        title="Términos y Condiciones"
        content={LEGAL_TEXTS.termsAndConditions}
        onBack={() => setActiveSubScreen('none')}
      />
    );
  }

  if (activeSubScreen === 'privacy_policy') {
    return (
      <LegalScreen
        title="Política de Privacidad"
        content={LEGAL_TEXTS.privacyPolicy}
        onBack={() => setActiveSubScreen('none')}
      />
    );
  }

  if (scannedProfileHandle) {
    const cleanName = scannedProfileHandle.replace(/^@/, '');
    const displayName =
      cleanName.charAt(0).toUpperCase() + cleanName.slice(1);

    return (
      <div className="relative flex h-full w-full flex-col bg-white text-zinc-950 select-none overflow-hidden">
        <header className="flex h-12 shrink-0 items-center justify-between border-b border-zinc-100 bg-white px-2">
          <button
            type="button"
            onClick={() => setScannedProfileHandle(null)}
            aria-label="Volver a mi perfil"
            className="flex h-10 w-10 items-center justify-center rounded-full text-zinc-900 transition-colors hover:bg-zinc-100"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>

          <span className="text-sm font-bold text-zinc-950">
            {scannedProfileHandle}
          </span>

          <div className="w-10" aria-hidden="true" />
        </header>

        <div className="flex-1 min-h-0 overflow-y-auto no-scrollbar">
          <section className="flex items-start justify-between gap-4 px-4 pt-3 pb-2">
            <div className="min-w-0 flex-1">
              <h1 className="text-2xl font-bold tracking-tight text-zinc-950">
                {displayName}
              </h1>
              <p className="text-sm text-zinc-500">{scannedProfileHandle}</p>

              <div className="mt-3 flex items-center gap-4">
                <div className="flex flex-col items-center">
                  <span className="text-base font-bold text-zinc-950 tabular-nums">142</span>
                  <span className="text-xs text-zinc-500">Siguiendo</span>
                </div>
                <div className="flex flex-col items-center">
                  <span className="text-base font-bold text-zinc-950 tabular-nums">12.4K</span>
                  <span className="text-xs text-zinc-500">Seguidores</span>
                </div>
                <div className="flex flex-col items-center">
                  <span className="text-base font-bold text-zinc-950 tabular-nums">84.2K</span>
                  <span className="text-xs text-zinc-500">Me gusta</span>
                </div>
              </div>
            </div>

            <div className="h-[88px] w-[88px] shrink-0 overflow-hidden rounded-full border border-zinc-200 bg-zinc-100">
              <img
                src="/src/assets/images/avatar_creator_mateo_1794604321715.jpg"
                alt={`Avatar de ${displayName}`}
                className="h-full w-full object-cover"
              />
            </div>
          </section>

          <section className="px-4 py-3">
            <button
              type="button"
              onClick={() => setIsFollowingScanned((prev) => !prev)}
              className={`w-full rounded-xl py-2.5 text-sm font-bold transition-colors ${
                isFollowingScanned
                  ? 'bg-zinc-100 text-zinc-900 hover:bg-zinc-200'
                  : 'bg-[#FE2C55] text-white hover:opacity-95'
              }`}
            >
              {isFollowingScanned ? 'Siguiendo' : 'Seguir'}
            </button>
          </section>

          <section className="grid grid-cols-3 gap-0.5 pt-2">
            {PROFILE_THUMBNAILS.filter((item) => item.tab === 'videos').map((item) => (
              <div
                key={item.id}
                className="relative aspect-[9/16] overflow-hidden bg-zinc-900"
              >
                <img
                  src={item.thumbUrl}
                  alt="Video del usuario"
                  className="h-full w-full object-cover"
                />
                <div className="absolute inset-x-0 bottom-0 flex items-center gap-1 bg-gradient-to-t from-black/70 to-transparent px-1.5 py-1 text-[11px] font-semibold text-white">
                  <Play className="h-3 w-3 fill-white" />
                  <span>{item.views}</span>
                </div>
              </div>
            ))}
          </section>
        </div>
      </div>
    );
  }

  return (
    <div className="relative flex h-full w-full flex-col bg-white text-zinc-950 select-none overflow-hidden">
      {/* 1. APP BAR PERSONALIZADO */}
      <header className="flex h-12 shrink-0 items-center justify-between bg-white px-2">
        <button
          type="button"
          onClick={() => setActiveSubScreen('edit_profile')}
          aria-label="Editar perfil"
          className="flex h-10 w-10 items-center justify-center rounded-full text-zinc-900 transition-colors hover:bg-zinc-100"
        >
          <Pencil className="h-5 w-5" />
        </button>

        <div className="flex items-center gap-0.5">
          <button
            type="button"
            onClick={() => setActiveSubScreen('qr_profile')}
            aria-label="Código QR"
            className="flex h-10 w-10 items-center justify-center rounded-full text-zinc-900 transition-colors hover:bg-zinc-100"
          >
            <QrCode className="h-5 w-5" />
          </button>
          <button
            type="button"
            onClick={() => onNotify?.('Sugerencias de amigos')}
            aria-label="Añadir amigos"
            className="flex h-10 w-10 items-center justify-center rounded-full text-zinc-900 transition-colors hover:bg-zinc-100"
          >
            <UserPlus className="h-5 w-5" />
          </button>
          <button
            type="button"
            onClick={() => setIsDrawerOpen(true)}
            aria-label="Abrir menú lateral"
            className="flex h-10 w-10 items-center justify-center rounded-full text-zinc-900 transition-colors hover:bg-zinc-100"
          >
            <Menu className="h-5 w-5" />
          </button>
        </div>
      </header>

      {/* Contenido scrolleable */}
      <div className="flex-1 min-h-0 overflow-y-auto no-scrollbar">
        {/* Fondo de perfil si fue seleccionado */}
        {backgroundUrl && (
          <div className="relative mx-4 mt-1 h-24 overflow-hidden rounded-2xl border border-zinc-200 bg-zinc-100">
            <img
              src={backgroundUrl}
              alt="Fondo de perfil"
              className="h-full w-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/35 to-transparent" />
          </div>
        )}

        {/* 2. INFORMACIÓN DEL PERFIL */}
        <section className="flex items-start justify-between gap-4 px-4 pt-2 pb-2">
          <div className="min-w-0 flex-1">
            <h1 className="text-2xl font-bold tracking-tight text-zinc-950">
              {nombreUsuario}
            </h1>
            <p className="text-sm text-zinc-500">
              {arroba}
              {pronoun ? ` · ${pronoun}` : ''}
            </p>

            <div className="mt-3 flex items-center gap-4">
              <div className="flex flex-col items-center">
                <span className="text-base font-bold text-zinc-950 tabular-nums">17</span>
                <span className="text-xs text-zinc-500">Siguiendo</span>
              </div>
              <div className="flex flex-col items-center">
                <span className="text-base font-bold text-zinc-950 tabular-nums">269</span>
                <span className="text-xs text-zinc-500">Seguidores</span>
              </div>
              <div className="flex flex-col items-center">
                <span className="text-base font-bold text-zinc-950 tabular-nums">577</span>
                <span className="text-xs text-zinc-500">Me gusta</span>
              </div>
            </div>
          </div>

          {/* Foto de perfil circular (tocar abre EditProfileScreen) */}
          <div className="relative shrink-0">
            <button
              type="button"
              onClick={() => setActiveSubScreen('edit_profile')}
              aria-label="Editar foto de perfil"
              className="h-[88px] w-[88px] overflow-hidden rounded-full border border-zinc-200 bg-zinc-100 transition-transform active:scale-95 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#E91E63]"
            >
              <img
                src={avatarUrl}
                alt={`Foto de ${nombreUsuario}`}
                className="h-full w-full object-cover"
              />
            </button>
          </div>
        </section>

        {/* 3. BOTONES DE DESCRIPCIÓN & STUDIO */}
        <section className="space-y-3 px-4 py-3">
          <button
            type="button"
            onClick={() => setActiveSubScreen('edit_bio')}
            className="w-full rounded-lg bg-zinc-100 px-3 py-3 text-center text-[13px] text-zinc-500 transition-colors hover:bg-zinc-200/70"
          >
            <span className={bio ? 'text-zinc-900 font-medium' : 'text-zinc-500'}>
              {bio || '+ Agregar descripción'}
            </span>
          </button>

          <div className="flex items-center">
            <button
              type="button"
              onClick={() => setActiveSubScreen('studio')}
              className="inline-flex items-center gap-1.5 rounded-full border border-zinc-300 px-3 py-1.5 text-xs font-semibold text-zinc-900 transition-colors hover:bg-zinc-50"
            >
              <Star className="h-4 w-4 fill-pink-500 text-pink-500" />
              Viroklipz Studio
            </button>
          </div>
        </section>

        {/* 4. HISTORIAS / DESTACADOS */}
        <section className="flex items-center gap-4 overflow-x-auto px-4 pb-3 pt-1 no-scrollbar">
          <button
            type="button"
            onClick={() => setActiveSubScreen('select_highlight')}
            className="flex shrink-0 flex-col items-center gap-1"
          >
            <div className="flex h-[60px] w-[60px] items-center justify-center rounded-full border border-zinc-300 bg-white text-zinc-900 transition-colors hover:bg-zinc-50">
              <Plus className="h-6 w-6" />
            </div>
            <span className="text-xs text-zinc-800">Nuevo</span>
          </button>

          {highlights.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => {
                setActiveHighlight(item);
                setActiveSubScreen('story_viewer');
              }}
              className="flex shrink-0 flex-col items-center gap-1"
            >
              <div className="h-[60px] w-[60px] overflow-hidden rounded-full border border-zinc-300 bg-zinc-100">
                <img
                  src={item.coverUrl}
                  alt={item.title}
                  className="h-full w-full object-cover"
                />
              </div>
              <span className="max-w-[64px] truncate text-xs text-zinc-800">
                {item.title}
              </span>
            </button>
          ))}
        </section>

        {/* 5. PESTAÑAS (TABS) */}
        <div className="sticky top-0 z-10 grid grid-cols-5 border-b border-zinc-200 bg-white">
          {PROFILE_TABS.map((tab) => {
            const Icon = tab.icon;
            const isSelected = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id)}
                aria-label={tab.label}
                className={`relative flex h-11 items-center justify-center transition-colors ${
                  isSelected ? 'text-zinc-950' : 'text-zinc-400 hover:text-zinc-600'
                }`}
              >
                <Icon className="h-5 w-5" />
                {isSelected && (
                  <span className="absolute bottom-0 h-[2px] w-10 bg-zinc-950" />
                )}
              </button>
            );
          })}
        </div>

        {/* 6. GRID DE VIDEOS SUBIDOS (9:16) */}
        {visibleVideoItems.length === 0 ? (
          <div className="flex flex-col items-center justify-center px-6 py-14 text-center">
            <p className="text-sm font-semibold text-zinc-800">
              {activeTab === 'videos'
                ? 'Aún no has publicado videos'
                : 'Aún no hay videos en esta pestaña'}
            </p>
            <p className="mt-1 text-xs text-zinc-500">
              {activeTab === 'videos'
                ? 'Toca el botón central para grabar o subir tu primer Viroklipz.'
                : 'Sube o reacciona a clips para verlos organizados aquí.'}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-3 gap-0.5 p-0.5">
            {visibleVideoItems.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() =>
                  onSelectVideo ? onSelectVideo(item.id) : onBackToFeed()
                }
                className="group relative aspect-[9/16] w-full overflow-hidden bg-[#1F1F23]"
              >
                <video
                  src={item.videoUrl}
                  muted
                  playsInline
                  preload="metadata"
                  className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                />
                <div
                  aria-hidden="true"
                  className="pointer-events-none absolute inset-x-0 bottom-0 h-12 bg-gradient-to-t from-black/75 to-transparent"
                />
                <div className="absolute bottom-1.5 left-1.5 flex items-center gap-1 text-white">
                  <Play className="h-3.5 w-3.5 fill-white" />
                  <span className="text-[11px] font-semibold tabular-nums">
                    {item.likes}
                  </span>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Menú Lateral Derecho (endDrawer) */}
      {isDrawerOpen && (
        <div
          className="absolute inset-0 z-40 flex justify-end bg-black/45 backdrop-blur-[1px]"
          onClick={() => setIsDrawerOpen(false)}
        >
          <aside
            aria-label="Menú lateral de perfil"
            onClick={(e) => e.stopPropagation()}
            className="flex h-full w-[82%] max-w-[310px] flex-col bg-white text-zinc-950 shadow-2xl"
          >
            <div className="flex items-center justify-between border-b border-zinc-100 px-4 py-3">
              <div className="min-w-0">
                <p className="truncate text-sm font-bold text-zinc-950">@{currentUsername}</p>
                <p className="truncate text-[11px] text-zinc-500">{currentEmail}</p>
              </div>
              <button
                type="button"
                onClick={() => setIsDrawerOpen(false)}
                aria-label="Cerrar menú lateral"
                className="flex h-8 w-8 items-center justify-center rounded-full text-zinc-500 hover:bg-zinc-100"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto px-2 py-2 no-scrollbar">
              <p className="px-3 pb-1.5 pt-2 text-xs font-semibold text-zinc-500">
                Recursos
              </p>
              <button
                type="button"
                onClick={() => {
                  setIsDrawerOpen(false);
                  setActiveSubScreen('balance');
                }}
                className="flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-left transition-colors hover:bg-zinc-100"
              >
                <span className="flex items-center gap-3 text-[15px] font-medium text-zinc-950">
                  <Wallet className="h-5 w-5 text-zinc-900" />
                  Saldo
                </span>
                <ChevronRight className="h-4 w-4 text-zinc-400" />
              </button>
              <button
                type="button"
                onClick={() => {
                  setIsDrawerOpen(false);
                  setActiveSubScreen('get_coins');
                }}
                className="flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-left transition-colors hover:bg-zinc-100"
              >
                <span className="flex items-center gap-3 text-[15px] font-medium text-zinc-950">
                  <Coins className="h-5 w-5 text-zinc-900" />
                  Obtener Monedas
                </span>
                <ChevronRight className="h-4 w-4 text-zinc-400" />
              </button>

              <hr className="my-2 border-zinc-200" />

              <p className="px-3 pb-1.5 pt-2 text-xs font-semibold text-zinc-500">
                Herramientas personales
              </p>
              <button
                type="button"
                onClick={() => {
                  setIsDrawerOpen(false);
                  setActiveSubScreen('activity_center');
                }}
                className="flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-left transition-colors hover:bg-zinc-100"
              >
                <span className="flex items-center gap-3 text-[15px] font-medium text-zinc-950">
                  <Clock className="h-5 w-5 text-zinc-900" />
                  Centro de actividades
                </span>
                <ChevronRight className="h-4 w-4 text-zinc-400" />
              </button>
              <button
                type="button"
                onClick={() => {
                  setIsDrawerOpen(false);
                  setActiveSubScreen('offline_videos');
                }}
                className="flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-left transition-colors hover:bg-zinc-100"
              >
                <span className="flex items-center gap-3 text-[15px] font-medium text-zinc-950">
                  <CloudDownload className="h-5 w-5 text-zinc-900" />
                  Vídeos sin conexión
                </span>
                <ChevronRight className="h-4 w-4 text-zinc-400" />
              </button>
              <button
                type="button"
                onClick={() => {
                  setIsDrawerOpen(false);
                  setActiveSubScreen('qr_profile');
                }}
                className="flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-left transition-colors hover:bg-zinc-100"
              >
                <span className="flex items-center gap-3 text-[15px] font-medium text-zinc-950">
                  <QrCode className="h-5 w-5 text-zinc-900" />
                  Tu código QR
                </span>
                <ChevronRight className="h-4 w-4 text-zinc-400" />
              </button>

              <hr className="my-2 border-zinc-200" />

              <p className="px-3 pb-1.5 pt-2 text-xs font-semibold text-zinc-500">
                Herramientas de creación y negocios
              </p>
              <button
                type="button"
                onClick={() => {
                  setIsDrawerOpen(false);
                  setActiveSubScreen('studio');
                }}
                className="flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-left transition-colors hover:bg-zinc-100"
              >
                <span className="flex items-center gap-3 text-[15px] font-medium text-zinc-950">
                  <Star className="h-5 w-5 text-zinc-900" />
                  Viroklipz Studio
                </span>
                <ChevronRight className="h-4 w-4 text-zinc-400" />
              </button>

              <hr className="my-2 border-zinc-200" />

              <button
                type="button"
                onClick={() => {
                  setIsDrawerOpen(false);
                  setActiveSubScreen('settings_privacy');
                }}
                className="flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-left transition-colors hover:bg-zinc-100"
              >
                <span className="flex items-center gap-3 text-[15px] font-medium text-zinc-950">
                  <Settings className="h-5 w-5 text-zinc-900" />
                  Ajustes y privacidad
                </span>
                <ChevronRight className="h-4 w-4 text-zinc-400" />
              </button>
              <button
                type="button"
                onClick={() => {
                  setIsDrawerOpen(false);
                  setActiveSubScreen('terms_conditions');
                }}
                className="flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-left transition-colors hover:bg-zinc-100"
              >
                <span className="flex items-center gap-3 text-[15px] font-medium text-zinc-950">
                  <FileText className="h-5 w-5 text-zinc-900" />
                  Términos y Condiciones
                </span>
                <ChevronRight className="h-4 w-4 text-zinc-400" />
              </button>
              <button
                type="button"
                onClick={() => {
                  setIsDrawerOpen(false);
                  setActiveSubScreen('privacy_policy');
                }}
                className="flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-left transition-colors hover:bg-zinc-100"
              >
                <span className="flex items-center gap-3 text-[15px] font-medium text-zinc-950">
                  <Shield className="h-5 w-5 text-zinc-900" />
                  Política de Privacidad
                </span>
                <ChevronRight className="h-4 w-4 text-zinc-400" />
              </button>
            </div>

            <div className="space-y-1.5 border-t border-zinc-100 p-3">
              <button
                type="button"
                onClick={() => {
                  setIsDrawerOpen(false);
                  onSignOut();
                }}
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-rose-50 px-3 py-2.5 text-sm font-semibold text-rose-600 transition-colors hover:bg-rose-100"
              >
                <LogOut className="h-4 w-4" />
                Cerrar sesión
              </button>

              <button
                type="button"
                onClick={() => {
                  setIsDrawerOpen(false);
                  setIsDeleteDialogOpen(true);
                }}
                className="flex w-full items-center justify-center gap-2 rounded-xl px-3 py-2 text-sm font-semibold text-[#881337] transition-colors hover:bg-red-50"
              >
                <Trash2 className="h-4 w-4" />
                Eliminar cuenta
              </button>
            </div>
          </aside>
        </div>
      )}

      {/* Diálogo de Confirmación para Eliminar Cuenta (#1E1E1E) */}
      {isDeleteDialogOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="delete-account-title"
          className="absolute inset-0 z-50 flex items-center justify-center bg-black/75 px-5 backdrop-blur-[1px]"
        >
          <div className="w-full max-w-[320px] rounded-2xl border border-white/10 bg-[#1E1E1E] p-5 text-white shadow-2xl">
            <h3
              id="delete-account-title"
              className="text-base font-bold leading-snug text-white"
            >
              ¿Estás seguro de que deseas eliminar tu cuenta?
            </h3>
            <p className="mt-2.5 text-xs leading-relaxed text-zinc-300">
              Esta acción es permanente e irreversible. Se eliminarán todos tus videos, seguidores y datos personales en Viroklipz.
            </p>
            <div className="mt-5 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setIsDeleteDialogOpen(false)}
                className="rounded-lg px-3.5 py-2 text-xs font-semibold text-zinc-300 transition-colors hover:bg-white/10 hover:text-white"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => {
                  setIsDeleteDialogOpen(false);
                  setIsDeletingAccount(true);
                  const targetAccount: UserAccount = currentUser ?? {
                    id: 'acc-current',
                    username: currentUsername,
                    displayName: currentUsername,
                    email: currentEmail,
                    avatarUrl: '/src/assets/images/avatar_creator_mateo_1794604321715.jpg',
                    unreadCount: 0,
                  };
                  window.setTimeout(() => {
                    setIsDeletingAccount(false);
                    if (onDeleteAccount) {
                      onDeleteAccount(targetAccount);
                    } else {
                      onSignOut();
                    }
                  }, 700);
                }}
                className="rounded-lg px-3.5 py-2 text-xs font-bold text-[#EF4444] transition-colors hover:bg-red-500/15"
              >
                Eliminar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Overlay de carga al eliminar cuenta */}
      {isDeletingAccount && (
        <div className="absolute inset-0 z-50 flex flex-col items-center justify-center gap-3 bg-black/80 text-white backdrop-blur-sm">
          <Loader2 className="h-9 w-9 animate-spin text-[#EF4444]" />
          <p className="text-xs font-semibold text-zinc-200">
            Eliminando cuenta...
          </p>
        </div>
      )}
    </div>
  );
};
