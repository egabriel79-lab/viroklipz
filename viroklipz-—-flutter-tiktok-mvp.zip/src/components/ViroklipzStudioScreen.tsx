import React, { useState } from 'react';
import {
  ArrowLeft,
  DollarSign,
  Eye,
  Heart,
  Play,
  Plus,
  Star,
  TrendingUp,
  Users,
} from 'lucide-react';

interface ViroklipzStudioScreenProps {
  onBack: () => void;
  onCreateVideo?: () => void;
  onNotify?: (message: string) => void;
}

type StudioRange = '7d' | '28d';

const STUDIO_METRICS: Record<
  StudioRange,
  { views: string; profileVisits: string; likes: string; followers: string; delta: string }
> = {
  '7d': {
    views: '14.8K',
    profileVisits: '1.9K',
    likes: '577',
    followers: '+48',
    delta: '+24% vs semana anterior',
  },
  '28d': {
    views: '62.4K',
    profileVisits: '7.3K',
    likes: '2.4K',
    followers: '+194',
    delta: '+39% vs mes anterior',
  },
};

const TOP_CLIPS = [
  {
    id: 'clip-1',
    title: 'Tomas nocturnas 35mm en la azotea',
    views: '6.4K',
    retention: '68%',
    thumbUrl: '/src/assets/images/avatar_creator_mateo_1794604321715.jpg',
  },
  {
    id: 'clip-2',
    title: 'Atardecer en ruta y timelapses',
    views: '4.1K',
    retention: '61%',
    thumbUrl: '/src/assets/images/story_hinduismo_temple_1794607243976.jpg',
  },
  {
    id: 'clip-3',
    title: 'Detrás de cámaras · edición rápida',
    views: '2.9K',
    retention: '54%',
    thumbUrl: '/src/assets/images/avatar_creator_valeria_1794604321625.jpg',
  },
];

export const ViroklipzStudioScreen: React.FC<ViroklipzStudioScreenProps> = ({
  onBack,
  onCreateVideo,
  onNotify,
}) => {
  const [range, setRange] = useState<StudioRange>('7d');
  const metrics = STUDIO_METRICS[range];

  return (
    <div className="flex h-full w-full flex-col bg-[#0F0F0F] text-white select-none">
      {/* AppBar Studio */}
      <header className="flex h-13 shrink-0 items-center justify-between border-b border-white/10 px-3">
        <button
          type="button"
          onClick={onBack}
          aria-label="Volver al perfil"
          className="flex h-9 w-9 items-center justify-center rounded-full text-white hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>

        <div className="flex items-center gap-1.5">
          <Star className="h-4 w-4 fill-pink-500 text-pink-500" />
          <h1 className="text-[15.5px] font-bold tracking-tight">Viroklipz Studio</h1>
        </div>

        <button
          type="button"
          onClick={() => (onCreateVideo ? onCreateVideo() : onNotify?.('Crear nuevo clip'))}
          aria-label="Crear video"
          className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-r from-cyan-400 to-pink-500 text-white"
        >
          <Plus className="h-4 w-4 stroke-[2.8]" />
        </button>
      </header>

      <div className="flex-1 min-h-0 overflow-y-auto p-4 space-y-5 no-scrollbar">
        {/* Selector de rango */}
        <div className="flex items-center justify-between gap-2">
          <div>
            <p className="text-xs text-zinc-400">Resumen de creador</p>
            <p className="text-[11px] font-semibold text-emerald-400 flex items-center gap-1 mt-0.5">
              <TrendingUp className="h-3.5 w-3.5" />
              {metrics.delta}
            </p>
          </div>
          <div className="flex rounded-lg border border-white/10 bg-[#1B1B1E] p-0.5">
            {(['7d', '28d'] as StudioRange[]).map((item) => (
              <button
                key={item}
                type="button"
                onClick={() => setRange(item)}
                className={`rounded-md px-2.5 py-1 text-xs font-semibold transition-colors ${
                  range === item ? 'bg-white text-zinc-950' : 'text-zinc-400 hover:text-white'
                }`}
              >
                {item === '7d' ? '7 días' : '28 días'}
              </button>
            ))}
          </div>
        </div>

        {/* Grid 2x2 de métricas */}
        <div className="grid grid-cols-2 gap-2.5">
          <div className="rounded-2xl border border-white/[0.07] bg-[#1E1E1E] p-3.5">
            <div className="flex items-center gap-2 text-xs text-zinc-400">
              <Eye className="h-3.5 w-3.5 text-cyan-400" />
              Visualizaciones
            </div>
            <p className="mt-1.5 text-xl font-bold text-white tabular-nums">{metrics.views}</p>
          </div>

          <div className="rounded-2xl border border-white/[0.07] bg-[#1E1E1E] p-3.5">
            <div className="flex items-center gap-2 text-xs text-zinc-400">
              <Users className="h-3.5 w-3.5 text-pink-400" />
              Visitas al perfil
            </div>
            <p className="mt-1.5 text-xl font-bold text-white tabular-nums">
              {metrics.profileVisits}
            </p>
          </div>

          <div className="rounded-2xl border border-white/[0.07] bg-[#1E1E1E] p-3.5">
            <div className="flex items-center gap-2 text-xs text-zinc-400">
              <Heart className="h-3.5 w-3.5 text-rose-500" />
              Me gusta
            </div>
            <p className="mt-1.5 text-xl font-bold text-white tabular-nums">{metrics.likes}</p>
          </div>

          <div className="rounded-2xl border border-white/[0.07] bg-[#1E1E1E] p-3.5">
            <div className="flex items-center gap-2 text-xs text-zinc-400">
              <TrendingUp className="h-3.5 w-3.5 text-emerald-400" />
              Nuevos seguidores
            </div>
            <p className="mt-1.5 text-xl font-bold text-white tabular-nums">
              {metrics.followers}
            </p>
          </div>
        </div>

        {/* Tarjeta de Monetización */}
        <section className="rounded-2xl border border-pink-500/25 bg-gradient-to-br from-[#1E1E24] to-[#17171B] p-4 space-y-2.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="flex h-7 w-7 items-center justify-center rounded-full bg-blue-600 text-white">
                <DollarSign className="h-4 w-4" />
              </span>
              <div>
                <h2 className="text-sm font-bold text-white">Programa de Creadores</h2>
                <p className="text-[11px] text-zinc-400">Monetización por vistas</p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => onNotify?.('Meta al 74% para activar pagos')}
              className="rounded-full bg-white/10 px-2.5 py-1 text-[11px] font-semibold text-white hover:bg-white/15"
            >
              Ver requisitos
            </button>
          </div>
          <div className="h-2 w-full overflow-hidden rounded-full bg-white/10">
            <div className="h-full w-[74%] rounded-full bg-gradient-to-r from-orange-400 to-pink-500" />
          </div>
          <p className="text-[11px] text-zinc-400 tabular-nums">
            7,400 / 10,000 reproducciones elegibles este mes
          </p>
        </section>

        {/* Clips con mejor rendimiento */}
        <section className="space-y-2.5">
          <h2 className="text-xs font-bold uppercase tracking-wider text-zinc-400">
            Tus videos destacados
          </h2>
          <div className="space-y-2">
            {TOP_CLIPS.map((clip) => (
              <div
                key={clip.id}
                className="flex items-center gap-3 rounded-xl border border-white/[0.06] bg-[#1E1E1E] p-2.5"
              >
                <div className="relative h-14 w-10 shrink-0 overflow-hidden rounded-lg bg-zinc-800">
                  <img
                    src={clip.thumbUrl}
                    alt={clip.title}
                    className="h-full w-full object-cover"
                  />
                  <Play className="absolute bottom-1 left-1 h-3 w-3 fill-white text-white drop-shadow" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-xs font-semibold text-white">{clip.title}</p>
                  <p className="mt-1 text-[11px] text-zinc-400 tabular-nums">
                    {clip.views} vistas · Retención {clip.retention}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};
