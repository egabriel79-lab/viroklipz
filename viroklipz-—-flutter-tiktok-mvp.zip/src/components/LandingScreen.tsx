import React, { useState } from 'react';
import { Home, Sparkles, Star } from 'lucide-react';

interface LandingScreenProps {
  onGetStarted: () => void;
  onCreateAccount: () => void;
  onGoHome: () => void;
}

const CREATOR_AVATARS = [
  {
    name: 'Mateo Rivera',
    src: '/src/assets/images/avatar_creator_mateo_1794604321715.jpg',
  },
  {
    name: 'Valeria Mendoza',
    src: '/src/assets/images/avatar_creator_valeria_1794604321625.jpg',
  },
  {
    name: 'Lucas Serrano',
    src: '/src/assets/images/avatar_creator_lucas_1794604322245.jpg',
  },
  {
    name: 'Sofía Navarro',
    src: '/src/assets/images/avatar_creator_sofia_1794604322145.jpg',
  },
  {
    name: 'Diego Paredes',
    src: '/src/assets/images/avatar_creator_diego_1794604323122.jpg',
  },
];

export const LandingScreen: React.FC<LandingScreenProps> = ({
  onGetStarted,
  onCreateAccount,
  onGoHome,
}) => {
  const [heroImageError, setHeroImageError] = useState(false);

  return (
    <div className="relative h-full w-full overflow-y-auto bg-[#0F0F0F] text-white no-scrollbar">
      {/* Resplandores ambientales de fondo */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-24 left-1/2 h-72 w-72 -translate-x-1/2 rounded-full bg-orange-500/20 blur-[90px]"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute top-44 -right-16 h-64 w-64 rounded-full bg-purple-600/20 blur-[95px]"
      />

      {/* 1. Barra de Navegación Superior (Solo Logo a la izquierda + Únete gratis a la derecha) */}
      <header className="sticky top-0 z-30 border-b border-white/10 bg-[#0F0F0F]/80 px-4 py-3 backdrop-blur-md">
        <div className="flex items-center justify-between gap-4">
          <a
            href="#top"
            onClick={(e) => {
              e.preventDefault();
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="font-display text-lg font-black tracking-tight text-white whitespace-nowrap shrink-0"
          >
            Viroklipz
          </a>

          <button
            type="button"
            onClick={onGetStarted}
            className="inline-flex min-h-[38px] items-center justify-center rounded-xl bg-gradient-to-r from-[#FF6B00] to-[#EC4899] px-4 py-1.5 text-xs font-bold text-white shadow-[0_0_22px_rgba(255,107,0,0.45)] transition-transform active:scale-95 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-orange-400"
          >
            Únete gratis
          </button>
        </div>
      </header>

      <main className="relative z-10 px-4 pb-10 pt-6 space-y-10">
        {/* 2. Sección Hero */}
        <section id="top" className="text-center space-y-4">
          <div className="space-y-2.5">
            <p className="font-display text-[46px] font-black leading-none tracking-tight text-white">
              Viroklipz
            </p>
            <h1 className="font-display text-[32px] font-black leading-[1.08] tracking-tight text-white text-balance">
              Comparte tus{' '}
              <span className="bg-gradient-to-r from-[#FF8A00] via-[#FF3D5A] to-[#EC4899] bg-clip-text text-transparent">
                Videos
              </span>
            </h1>
          </div>

          <p className="mx-auto max-w-[310px] text-sm leading-relaxed text-zinc-400">
            La red social de videos verticales. Sube tus clips, descubre creadores increíbles y hazte viral en segundos.
          </p>

          {/* Botones de Acción Hero */}
          <div className="flex items-center justify-center gap-3 pt-1">
            <button
              type="button"
              onClick={onCreateAccount}
              className="inline-flex min-h-[44px] items-center justify-center rounded-xl bg-gradient-to-r from-[#FF6B00] via-[#FF3D00] to-[#EC4899] px-5 py-2.5 text-sm font-bold text-white shadow-[0_0_28px_rgba(255,107,0,0.5)] transition-transform hover:brightness-105 active:scale-95 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-orange-400"
            >
              Crear cuenta
            </button>

            <button
              type="button"
              onClick={onGoHome}
              className="inline-flex min-h-[44px] items-center justify-center gap-1.5 rounded-xl border border-white/20 bg-white/[0.04] px-5 py-2.5 text-sm font-semibold text-white backdrop-blur-md transition-colors hover:bg-white/10 active:scale-95 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"
            >
              <Home className="h-3.5 w-3.5" />
              Inicio
            </button>
          </div>

          {/* Visual Central 3D Cyberpunk / Astronauta */}
          <div className="relative mt-4 overflow-hidden rounded-2xl border border-white/15 bg-white/[0.03] p-1.5 backdrop-blur-md shadow-[0_18px_45px_rgba(147,51,234,0.22)]">
            <div className="relative aspect-[4/3] w-full overflow-hidden rounded-xl bg-zinc-900">
              {!heroImageError ? (
                <img
                  src="/src/assets/images/hero_cyber_astronaut_1794614449948.jpg"
                  alt="Render 3D futurista de cámara y casco cyberpunk para creadores"
                  referrerPolicy="no-referrer"
                  onError={() => setHeroImageError(true)}
                  className="h-full w-full object-cover"
                />
              ) : (
                <div className="flex h-full w-full flex-col items-center justify-center bg-gradient-to-br from-orange-600/30 via-zinc-900 to-purple-700/35">
                  <Sparkles className="h-10 w-10 text-orange-400" />
                  <span className="mt-2 text-xs font-semibold text-zinc-200">
                    Viroklipz Social
                  </span>
                </div>
              )}

              <div
                aria-hidden="true"
                className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#0F0F0F]/80 via-transparent to-transparent"
              />
            </div>
          </div>
        </section>

        {/* Cómo funciona */}
        <section
          id="how-it-works"
          className="rounded-2xl border border-white/10 bg-white/[0.03] p-4 backdrop-blur-md space-y-3"
        >
          <h2 className="font-display text-base font-bold text-white">
            Cómo funciona
          </h2>
          <ol className="space-y-2.5 text-xs text-zinc-300">
            <li className="flex items-start gap-2.5">
              <span className="font-mono font-bold text-orange-400">01.</span>
              <span>Graba o sube tus videos verticales directamente desde tu teléfono.</span>
            </li>
            <li className="flex items-start gap-2.5">
              <span className="font-mono font-bold text-purple-400">02.</span>
              <span>Edita, ponle tu música favorita y dale tu estilo único.</span>
            </li>
            <li className="flex items-start gap-2.5">
              <span className="font-mono font-bold text-blue-400">03.</span>
              <span>Publica en el feed, compártelo con tus amigos y consigue seguidores.</span>
            </li>
          </ol>
        </section>

        {/* Social Proof */}
        <section className="flex flex-col items-center gap-2.5 border-t border-white/10 pt-5 text-center">
          <div className="flex items-center justify-center">
            <div className="flex -space-x-2.5">
              {CREATOR_AVATARS.map((avatar) => (
                <img
                  key={avatar.name}
                  src={avatar.src}
                  alt={avatar.name}
                  referrerPolicy="no-referrer"
                  className="h-9 w-9 rounded-full border-2 border-[#0F0F0F] object-cover bg-zinc-800"
                />
              ))}
            </div>
          </div>

          <div className="flex items-center gap-1" aria-label="Calificación de 5 estrellas">
            {Array.from({ length: 5 }).map((_, idx) => (
              <Star
                key={idx}
                className="h-4 w-4 fill-amber-400 text-amber-400"
              />
            ))}
          </div>

          <p className="text-xs font-semibold text-zinc-200 tabular-nums">
            Amado por más de 100,000 creadores
          </p>
        </section>
      </main>
    </div>
  );
};
