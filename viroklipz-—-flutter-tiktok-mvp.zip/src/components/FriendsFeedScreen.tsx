import React, { useEffect, useMemo, useRef, useState } from 'react';
import { ChevronDown, ChevronUp, Search, Users, Video, X } from 'lucide-react';
import { VideoItem } from '../data/mockVideos';
import { APP_COLORS } from '../theme/appColors';
import { VideoCard } from './VideoCard';

interface FriendsFeedScreenProps {
  videos: VideoItem[];
  hasAnyVideos?: boolean;
  currentUserAvatarUrl?: string;
  isFeedVisible: boolean;
  isMuted: boolean;
  onToggleMute: () => void;
  likedIds: Record<string, boolean>;
  onToggleLike: (id: string) => void;
  isFollowing: (authorId: string) => boolean;
  onToggleFollow: (video: VideoItem) => void;
  onOpenComments: (video: VideoItem) => void;
  onShare: (video: VideoItem) => void;
  onExploreForYou: () => void;
  onOpenCamera?: () => void;
  onNotify: (
    message: string,
    options?: {
      variant?: 'default' | 'downloading' | 'success' | 'error';
      persistent?: boolean;
    }
  ) => void;
}

export const FriendsFeedScreen: React.FC<FriendsFeedScreenProps> = ({
  videos,
  hasAnyVideos = false,
  currentUserAvatarUrl,
  isFeedVisible,
  isMuted,
  onToggleMute,
  likedIds,
  onToggleLike,
  isFollowing,
  onToggleFollow,
  onOpenComments,
  onShare,
  onExploreForYou,
  onOpenCamera,
  onNotify,
}) => {
  const scrollRef = useRef<HTMLDivElement | null>(null);
  const [activeIndex, setActiveIndex] = useState(0);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredVideos = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return videos;
    return videos.filter(
      (v) =>
        v.username.toLowerCase().includes(q) ||
        v.displayName.toLowerCase().includes(q) ||
        v.caption.toLowerCase().includes(q)
    );
  }, [videos, searchQuery]);

  // Ajusta el índice si el usuario deja de seguir a alguien y se reduce la lista
  useEffect(() => {
    if (filteredVideos.length === 0) {
      setActiveIndex(0);
      return;
    }
    if (activeIndex >= filteredVideos.length) {
      const nextIdx = filteredVideos.length - 1;
      setActiveIndex(nextIdx);
      if (scrollRef.current) {
        scrollRef.current.scrollTo({
          top: nextIdx * scrollRef.current.clientHeight,
          behavior: 'auto',
        });
      }
    }
  }, [filteredVideos.length, activeIndex]);

  useEffect(() => {
    const container = scrollRef.current;
    if (!container) return;

    const handleScroll = () => {
      const height = container.clientHeight;
      if (height === 0) return;
      const nextIndex = Math.round(container.scrollTop / height);
      if (
        nextIndex !== activeIndex &&
        nextIndex >= 0 &&
        nextIndex < filteredVideos.length
      ) {
        setActiveIndex(nextIndex);
      }
    };

    container.addEventListener('scroll', handleScroll, { passive: true });
    return () => container.removeEventListener('scroll', handleScroll);
  }, [activeIndex, filteredVideos.length]);

  const scrollToIndex = (targetIndex: number) => {
    const container = scrollRef.current;
    if (!container || filteredVideos.length === 0) return;
    const clamped = Math.max(0, Math.min(filteredVideos.length - 1, targetIndex));
    container.scrollTo({
      top: clamped * container.clientHeight,
      behavior: 'smooth',
    });
    setActiveIndex(clamped);
  };

  return (
    <div className="relative h-full w-full overflow-hidden bg-black text-white select-none">
      {/* Barra Superior de Comunidad (Título centrado + buscador) */}
      <header className="pointer-events-none absolute inset-x-0 top-0 z-30 flex flex-col gap-2 px-4 pt-3.5">
        <div className="pointer-events-auto flex items-center justify-between">
          <div className="h-10 w-10" aria-hidden="true" />

          <div className="flex flex-col items-center">
            <span className="text-[18px] font-bold tracking-tight text-white drop-shadow">
              Comunidad
            </span>
            <span
              className="mt-1 h-[2.5px] w-8 rounded-full"
              style={{ background: APP_COLORS.brandGradient }}
            />
          </div>

          <button
            type="button"
            onClick={() => {
              setSearchOpen((prev) => !prev);
              if (searchOpen) setSearchQuery('');
            }}
            aria-label={searchOpen ? 'Cerrar búsqueda' : 'Buscar en comunidad'}
            className="flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-black/45"
          >
            {searchOpen ? <X className="h-5 w-5" /> : <Search className="h-6 w-6 drop-shadow" />}
          </button>
        </div>

        {searchOpen && (
          <div className="pointer-events-auto flex items-center gap-2 rounded-xl border border-white/20 bg-black/75 px-3 py-2 backdrop-blur-md">
            <Search className="h-4 w-4 text-white/60" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Filtrar videos de la comunidad..."
              className="w-full bg-transparent text-xs text-white placeholder:text-white/55 focus:outline-none"
            />
          </div>
        )}
      </header>

      {filteredVideos.length === 0 ? (
        <div className="flex h-full flex-col items-center justify-center px-8 text-center">
          <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-zinc-900 text-[#FF5722]">
            {!searchQuery.trim() && !hasAnyVideos ? (
              <Video className="h-7 w-7" />
            ) : (
              <Users className="h-7 w-7" />
            )}
          </div>
          <h2 className="text-base font-bold text-white">
            {searchQuery.trim()
              ? 'Sin resultados en Comunidad'
              : !hasAnyVideos
                ? 'Aún no hay videos. ¡Sé el primero en subir uno!'
                : 'Aún no hay videos en Comunidad'}
          </h2>
          <p className="mt-1.5 text-xs leading-relaxed text-zinc-400">
            {searchQuery.trim()
              ? 'Prueba con otro @usuario o limpia la búsqueda.'
              : !hasAnyVideos
                ? 'Graba o selecciona un clip desde tu cámara para iniciar el feed.'
                : 'Sigue a creadores en "Radar" o sube tu propio video para ver sus clips aquí.'}
          </p>
          <button
            type="button"
            onClick={
              searchQuery.trim()
                ? () => setSearchQuery('')
                : !hasAnyVideos && onOpenCamera
                  ? onOpenCamera
                  : onExploreForYou
            }
            style={{ background: APP_COLORS.brandGradient }}
            className="mt-5 inline-flex items-center gap-2 rounded-full px-5 py-2.5 text-xs font-bold text-white transition-transform active:scale-95 shadow-lg"
          >
            {searchQuery.trim() ? (
              'Limpiar filtro'
            ) : !hasAnyVideos && onOpenCamera ? (
              <>
                <Video className="h-4 w-4" />
                <span>Subir primer video</span>
              </>
            ) : (
              'Explorar Radar'
            )}
          </button>
        </div>
      ) : (
        <>
          {/* Controles discretos en escritorio */}
          <div className="hidden lg:flex flex-col gap-1.5 absolute left-3 top-1/2 -translate-y-1/2 z-30">
            <button
              type="button"
              onClick={() => scrollToIndex(activeIndex - 1)}
              disabled={activeIndex === 0}
              aria-label="Video anterior de amigos"
              className="flex h-9 w-9 items-center justify-center rounded-full bg-black/45 text-white backdrop-blur-sm transition-opacity hover:bg-black/70 disabled:opacity-25"
            >
              <ChevronUp className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={() => scrollToIndex(activeIndex + 1)}
              disabled={activeIndex >= filteredVideos.length - 1}
              aria-label="Siguiente video de amigos"
              className="flex h-9 w-9 items-center justify-center rounded-full bg-black/45 text-white backdrop-blur-sm transition-opacity hover:bg-black/70 disabled:opacity-25"
            >
              <ChevronDown className="h-4 w-4" />
            </button>
          </div>

          {/* PageView Vertical inmersivo a pantalla completa (borde a borde como Radar) */}
          <div
            ref={scrollRef}
            className="h-full w-full snap-y snap-mandatory overflow-y-scroll no-scrollbar"
          >
            {filteredVideos.map((video, index) => (
              <VideoCard
                key={video.id}
                video={video}
                currentUserAvatarUrl={currentUserAvatarUrl}
                isActive={index === activeIndex}
                isFeedVisible={isFeedVisible}
                isMuted={isMuted}
                onToggleMute={onToggleMute}
                isLiked={Boolean(likedIds[video.id])}
                onToggleLike={() => onToggleLike(video.id)}
                isFollowing={isFollowing(video.authorId)}
                onToggleFollow={() => onToggleFollow(video)}
                onOpenComments={() => onOpenComments(video)}
                onShare={() => onShare(video)}
                onNotify={onNotify}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
};
