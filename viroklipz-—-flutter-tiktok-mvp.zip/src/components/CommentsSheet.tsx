import React, { useState } from 'react';
import { Send, X } from 'lucide-react';
import { VideoComment, VideoItem } from '../data/mockVideos';

interface CommentsSheetProps {
  video: VideoItem | null;
  extraComments: VideoComment[];
  onClose: () => void;
  onAddComment: (videoId: string, text: string) => void;
}

export const CommentsSheet: React.FC<CommentsSheetProps> = ({
  video,
  extraComments,
  onClose,
  onAddComment,
}) => {
  const [draft, setDraft] = useState('');

  if (!video) return null;

  const allComments = [...extraComments, ...video.comments];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = draft.trim();
    if (!trimmed) return;
    onAddComment(video.id, trimmed);
    setDraft('');
  };

  return (
    <div className="absolute inset-0 z-40 flex flex-col justify-end bg-black/55 backdrop-blur-[2px]">
      <button
        type="button"
        aria-label="Cerrar comentarios"
        onClick={onClose}
        className="flex-1 w-full cursor-default"
      />
      <div className="flex max-h-[68%] flex-col rounded-t-3xl bg-zinc-900 border-t border-zinc-800 text-zinc-100 shadow-2xl">
        <div className="mx-auto mt-2.5 h-1 w-10 rounded-full bg-zinc-700" />
        <div className="flex items-center justify-between border-b border-zinc-800 px-4 py-3">
          <span className="text-sm font-semibold tabular-nums">
            {video.commentsCount + extraComments.length} comentarios
          </span>
          <button
            type="button"
            onClick={onClose}
            aria-label="Cerrar panel de comentarios"
            className="flex h-10 w-10 items-center justify-center rounded-full text-zinc-400 hover:bg-zinc-800 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-4 py-3 space-y-4">
          {allComments.map((comment) => (
            <div key={comment.id} className="flex items-start gap-3">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-zinc-800 text-xs font-semibold text-zinc-300">
                {comment.username.slice(0, 2).toUpperCase()}
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 text-xs text-zinc-400">
                  <span className="font-semibold text-zinc-200">@{comment.username}</span>
                  <span aria-hidden="true">·</span>
                  <span>{comment.timeAgo}</span>
                </div>
                <p className="mt-0.5 text-[13.5px] leading-snug text-zinc-100">{comment.text}</p>
              </div>
            </div>
          ))}
        </div>

        <form onSubmit={handleSubmit} className="flex items-center gap-2 border-t border-zinc-800 bg-zinc-950/60 px-3 py-2.5">
          <input
            type="text"
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            placeholder="Añade un comentario..."
            className="h-10 flex-1 rounded-full bg-zinc-800 px-4 text-sm text-white placeholder:text-zinc-400 focus:outline-none focus:ring-2 focus:ring-[#FF2D55]"
          />
          <button
            type="submit"
            disabled={!draft.trim()}
            aria-label="Enviar comentario"
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[#FF2D55] text-white transition-opacity disabled:opacity-40"
          >
            <Send className="h-4 w-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
