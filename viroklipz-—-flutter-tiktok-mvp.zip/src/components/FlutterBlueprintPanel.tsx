import React, { useState } from 'react';
import { Check, Copy, Download, FileCode2, FolderTree, Layers, Terminal } from 'lucide-react';
import { FLUTTER_FILES, FLUTTER_FOLDER_TREE } from '../data/flutterFiles';
import { downloadFlutterProjectZip } from '../utils/flutterZipExport';

type BlueprintViewMode = 'architecture' | 'code';

export const FlutterBlueprintPanel: React.FC = () => {
  const [viewMode, setViewMode] = useState<BlueprintViewMode>('code');
  const [selectedFileId, setSelectedFileId] = useState<string>('profile_screen');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const activeFile = FLUTTER_FILES.find((f) => f.id === selectedFileId) ?? FLUTTER_FILES[0];

  const handleCopy = async (key: string, content: string) => {
    try {
      await navigator.clipboard.writeText(content);
      setCopiedKey(key);
      window.setTimeout(() => setCopiedKey(null), 1800);
    } catch {
      // Fallback ignored in restricted clipboard environments
    }
  };

  return (
    <div className="flex h-full flex-col rounded-2xl border border-zinc-800 bg-zinc-900/70 text-zinc-100 overflow-hidden">
      {/* Cabecera del panel técnico */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-zinc-800 px-5 py-4">
        <div>
          <h1 className="text-lg font-bold tracking-tight text-white">
            Viroklipz — Flutter + Supabase + Cloudflare R2
          </h1>
          <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-zinc-400">
            <span>Flutter 3.x / Dart 3</span>
            <span aria-hidden="true">·</span>
            <span>Supabase Auth &amp; DB</span>
            <span aria-hidden="true">·</span>
            <span>Cloudflare R2 (S3)</span>
          </div>
        </div>

        {/* Control segmentado interactivo + Descarga ZIP */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={downloadFlutterProjectZip}
            className="inline-flex items-center gap-1.5 rounded-lg bg-[#FE2C55] px-3 py-1.5 text-xs font-semibold text-white whitespace-nowrap shrink-0 transition hover:bg-[#FE2C55]/90 active:scale-95"
          >
            <Download className="h-3.5 w-3.5" />
            Descargar Flutter (.zip)
          </button>
          <div className="flex items-center gap-1 rounded-lg bg-zinc-950 p-1 border border-zinc-800">
            <button
              type="button"
              onClick={() => setViewMode('code')}
              className={`inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium whitespace-nowrap shrink-0 transition-colors ${
                viewMode === 'code'
                  ? 'bg-zinc-800 text-white'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <FileCode2 className="h-3.5 w-3.5" />
              Código &amp; SQL ({FLUTTER_FILES.length} archivos)
            </button>
            <button
              type="button"
              onClick={() => setViewMode('architecture')}
              className={`inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium whitespace-nowrap shrink-0 transition-colors ${
                viewMode === 'architecture'
                  ? 'bg-zinc-800 text-white'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <Layers className="h-3.5 w-3.5" />
              Setup Supabase &amp; R2
            </button>
          </div>
        </div>
      </div>

      {viewMode === 'architecture' ? (
        <div className="flex-1 overflow-y-auto p-5 space-y-6">
          {/* Paso 1: Paquetes y Variables de Entorno */}
          <section className="space-y-2.5">
            <div className="flex items-center justify-between gap-2">
              <h2 className="flex items-center gap-2 text-sm font-semibold text-white">
                <Terminal className="h-4 w-4 text-[#25F4EE]" />
                01. Instalar paquetes y ejecutar con --dart-define
              </h2>
              <button
                type="button"
                onClick={() =>
                  handleCopy(
                    'cli-init',
                    'flutter pub add provider supabase_flutter image_picker file_picker dio gal permission_handler path_provider device_info_plus minio path\n\nflutter run \\\n  --dart-define=SUPABASE_URL=https://tu-proyecto.supabase.co \\\n  --dart-define=SUPABASE_ANON_KEY=tu_anon_key \\\n  --dart-define=R2_ENDPOINT=tu_account_id.r2.cloudflarestorage.com \\\n  --dart-define=R2_ACCESS_KEY=tu_access_key \\\n  --dart-define=R2_SECRET_KEY=tu_secret_key \\\n  --dart-define=R2_BUCKET_NAME=viroklipz-videos \\\n  --dart-define=R2_PUBLIC_BASE_URL=https://pub-xxxx.r2.dev'
                  )
                }
                className="inline-flex items-center gap-1.5 rounded-lg border border-zinc-700 bg-zinc-950 px-2.5 py-1 text-xs font-medium text-zinc-300 hover:bg-zinc-800 hover:text-white"
              >
                {copiedKey === 'cli-init' ? (
                  <>
                    <Check className="h-3.5 w-3.5 text-emerald-400" />
                    Copiado
                  </>
                ) : (
                  <>
                    <Copy className="h-3.5 w-3.5" />
                    Copiar CLI
                  </>
                )}
              </button>
            </div>
            <pre className="overflow-x-auto rounded-xl border border-zinc-800 bg-zinc-950 p-4 text-xs leading-relaxed text-zinc-200 font-mono">
              {`flutter pub add provider supabase_flutter image_picker file_picker dio gal permission_handler path_provider device_info_plus minio path

flutter run \\
  --dart-define=SUPABASE_URL=https://tu-proyecto.supabase.co \\
  --dart-define=SUPABASE_ANON_KEY=tu_anon_key \\
  --dart-define=R2_ENDPOINT=tu_account_id.r2.cloudflarestorage.com \\
  --dart-define=R2_ACCESS_KEY=tu_access_key \\
  --dart-define=R2_SECRET_KEY=tu_secret_key \\
  --dart-define=R2_BUCKET_NAME=viroklipz-videos \\
  --dart-define=R2_PUBLIC_BASE_URL=https://pub-xxxx.r2.dev`}
            </pre>
            <p className="text-xs leading-relaxed text-zinc-400">
              Para producción, mueve la firma de subida a una Supabase Edge Function que genere URLs prefirmadas de R2 para no incluir el <code className="text-zinc-200">R2_SECRET_KEY</code> en la app móvil.
            </p>
          </section>

          <hr className="border-zinc-800" />

          {/* Paso 2: Configuración de Cloudflare R2 */}
          <section className="space-y-3">
            <h2 className="text-sm font-semibold text-white">
              02. Configuración de Cloudflare R2 (API compatible con S3)
            </h2>
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="rounded-xl border border-zinc-800 bg-zinc-950/60 p-4 space-y-1.5">
                <p className="text-xs font-semibold text-[#25F4EE]">Endpoint y Región</p>
                <ul className="space-y-1.5 text-xs text-zinc-300 leading-relaxed">
                  <li>· Endpoint: <code className="text-zinc-100">&lt;ACCOUNT_ID&gt;.r2.cloudflarestorage.com</code> (sin <code className="text-zinc-100">https://</code>).</li>
                  <li>· Región en <code className="text-zinc-100">Minio</code>: <code className="text-zinc-100">'auto'</code> con <code className="text-zinc-100">useSSL: true</code>.</li>
                  <li>· Token R2 con permisos de lectura/escritura en el bucket.</li>
                </ul>
              </div>
              <div className="rounded-xl border border-zinc-800 bg-zinc-950/60 p-4 space-y-1.5">
                <p className="text-xs font-semibold text-rose-400">Lectura pública del Feed</p>
                <ul className="space-y-1.5 text-xs text-zinc-300 leading-relaxed">
                  <li>· Habilita acceso público (<code className="text-zinc-100">r2.dev</code> o dominio propio) en el bucket.</li>
                  <li>· La app guarda esa URL pública en la columna <code className="text-zinc-100">video_url</code> de Supabase.</li>
                  <li>· Configura CORS en R2 si pruebas desde Flutter Web.</li>
                </ul>
              </div>
            </div>
          </section>

          <hr className="border-zinc-800" />

          {/* Paso 3: Estructura de carpetas */}
          <section className="space-y-2.5">
            <h2 className="flex items-center gap-2 text-sm font-semibold text-white">
              <FolderTree className="h-4 w-4 text-[#FF2D55]" />
              03. Estructura actualizada del proyecto
            </h2>
            <pre className="overflow-x-auto rounded-xl border border-zinc-800 bg-zinc-950 p-4 text-xs leading-relaxed text-zinc-200 font-mono">
              {FLUTTER_FOLDER_TREE}
            </pre>
          </section>
        </div>
      ) : (
        <div className="flex flex-1 min-h-0 flex-col">
          {/* Selector de archivos Dart */}
          <div className="flex items-center gap-1.5 overflow-x-auto border-b border-zinc-800 bg-zinc-950/60 px-4 py-2.5 no-scrollbar">
            {FLUTTER_FILES.map((file) => {
              const isSelected = file.id === activeFile.id;
              return (
                <button
                  key={file.id}
                  type="button"
                  onClick={() => setSelectedFileId(file.id)}
                  className={`rounded-lg px-3 py-1.5 text-xs font-mono whitespace-nowrap shrink-0 transition-colors ${
                    isSelected
                      ? 'bg-[#FF2D55] text-white font-medium'
                      : 'bg-zinc-900 text-zinc-400 hover:bg-zinc-800 hover:text-zinc-200'
                  }`}
                >
                  {file.path.replace('lib/', '')}
                </button>
              );
            })}
          </div>

          {/* Meta del archivo activo + Copiar */}
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-zinc-800/80 bg-zinc-900/40 px-5 py-3">
            <div className="min-w-0">
              <div className="flex items-center gap-2 text-xs text-zinc-400">
                <span className="font-mono font-semibold text-zinc-100">{activeFile.path}</span>
                <span aria-hidden="true">·</span>
                <span>{activeFile.phase}</span>
              </div>
              <p className="mt-1 text-xs text-zinc-400">{activeFile.summary}</p>
            </div>
            <button
              type="button"
              onClick={() => handleCopy(activeFile.id, activeFile.code)}
              className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border border-zinc-700 bg-zinc-950 px-3 py-1.5 text-xs font-medium text-zinc-200 hover:bg-zinc-800 shrink-0"
            >
              {copiedKey === activeFile.id ? (
                <>
                  <Check className="h-3.5 w-3.5 text-emerald-400" />
                  Copiado
                </>
              ) : (
                <>
                  <Copy className="h-3.5 w-3.5" />
                  Copiar archivo
                </>
              )}
            </button>
          </div>

          {/* Código fuente */}
          <div className="flex-1 overflow-auto bg-zinc-950 p-5">
            <pre className="text-[12.5px] leading-relaxed text-zinc-200 font-mono">
              <code>{activeFile.code}</code>
            </pre>
          </div>
        </div>
      )}
    </div>
  );
};
