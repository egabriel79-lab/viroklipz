import React, { useState } from 'react';
import { Check, Film, X } from 'lucide-react';

export interface HighlightMediaCandidate {
  id: string;
  url: string;
  duration: string;
}

export interface CreatedHighlightPayload {
  title: string;
  coverUrl: string;
  slides: { id: string; url: string; caption?: string }[];
}

interface SelectHighlightMediaScreenProps {
  onClose: () => void;
  onCreateHighlight: (payload: CreatedHighlightPayload) => void;
}

const GALLERY_MEDIA: HighlightMediaCandidate[] = [
  {
    id: 'hm-1',
    url: '/src/assets/images/story_hinduismo_temple_1794607243976.jpg',
    duration: '0:15',
  },
  {
    id: 'hm-2',
    url: '/src/assets/images/avatar_creator_mateo_1794604321715.jpg',
    duration: '0:22',
  },
  {
    id: 'hm-3',
    url: '/src/assets/images/avatar_creator_valeria_1794604321625.jpg',
    duration: '0:18',
  },
  {
    id: 'hm-4',
    url: '/src/assets/images/avatar_creator_lucas_1794604322245.jpg',
    duration: '0:31',
  },
  {
    id: 'hm-5',
    url: '/src/assets/images/avatar_creator_sofia_1794604322145.jpg',
    duration: '0:12',
  },
  {
    id: 'hm-6',
    url: '/src/assets/images/avatar_creator_diego_1794604323122.jpg',
    duration: '0:27',
  },
];

export const SelectHighlightMediaScreen: React.FC<
  SelectHighlightMediaScreenProps
> = ({ onClose, onCreateHighlight }) => {
  const [selectedIds, setSelectedIds] = useState<string[]>(['hm-1']);
  const [title, setTitle] = useState('Destacado');

  const toggleMedia = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleConfirm = () => {
    const picked = selectedIds
      .map((id) => GALLERY_MEDIA.find((item) => item.id === id))
      .filter((item): item is HighlightMediaCandidate => Boolean(item));

    if (picked.length === 0) return;

    onCreateHighlight({
      title: title.trim() || 'Destacado',
      coverUrl: picked[0].url,
      slides: picked.map((item) => ({
        id: `${item.id}-${Date.now()}`,
        url: item.url,
      })),
    });
  };

  return (
    <div className="flex h-full w-full flex-col bg-[#0F0F0F] text-white select-none">
      {/* Header */}
      <header className="flex h-12 shrink-0 items-center justify-between border-b border-white/10 px-3">
        <button
          type="button"
          onClick={onClose}
          aria-label="Cerrar galería de destacados"
          className="flex h-9 w-9 items-center justify-center rounded-full text-white hover:bg-white/10"
        >
          <X className="h-5 w-5" />
        </button>

        <h1 className="text-[15px] font-bold">Nuevo destacado</h1>

        <button
          type="button"
          onClick={handleConfirm}
          disabled={selectedIds.length === 0}
          className="rounded-full bg-[#FF2D55] px-3.5 py-1.5 text-xs font-bold text-white transition-opacity disabled:opacity-40"
        >
          Listo ({selectedIds.length})
        </button>
      </header>

      {/* Input para título del destacado */}
      <div className="border-b border-white/10 px-4 py-3">
        <label
          htmlFor="highlight-title"
          className="mb-1.5 block text-[11px] font-semibold uppercase tracking-wide text-zinc-400"
        >
          Nombre del destacado
        </label>
        <input
          id="highlight-title"
          type="text"
          maxLength={18}
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Ej. Viajes, Studio, Rodajes..."
          className="w-full rounded-xl border border-white/15 bg-[#1B1B1E] px-3 py-2 text-sm text-white placeholder:text-zinc-500 focus:border-white/40 focus:outline-none"
        />
      </div>

      {/* Subtítulo */}
      <div className="flex items-center justify-between px-4 py-2.5 text-xs text-zinc-400">
        <span className="flex items-center gap-1.5 font-medium text-zinc-200">
          <Film className="h-3.5 w-3.5 text-[#25F4EE]" />
          Selecciona tus clips o stories
        </span>
        <span className="tabular-nums">{GALLERY_MEDIA.length} elementos</span>
      </div>

      {/* Grid de selección 3 columnas */}
      <div className="flex-1 min-h-0 overflow-y-auto px-0.5 pb-4 no-scrollbar">
        <div className="grid grid-cols-3 gap-0.5">
          {GALLERY_MEDIA.map((media) => {
            const selectionIndex = selectedIds.indexOf(media.id);
            const isSelected = selectionIndex !== -1;
            return (
              <button
                key={media.id}
                type="button"
                onClick={() => toggleMedia(media.id)}
                className="relative aspect-[9/16] w-full overflow-hidden bg-zinc-900"
              >
                <img
                  src={media.url}
                  alt={`Clip ${media.id}`}
                  className={`h-full w-full object-cover transition-all ${
                    isSelected ? 'scale-[0.98] opacity-80' : 'opacity-100'
                  }`}
                />
                {isSelected && (
                  <span
                    aria-hidden="true"
                    className="pointer-events-none absolute inset-0 border-2 border-[#FF2D55]"
                  />
                )}
                <span
                  className={`absolute right-1.5 top-1.5 flex h-6 w-6 items-center justify-center rounded-full text-[11px] font-bold transition-colors ${
                    isSelected
                      ? 'bg-[#FF2D55] text-white'
                      : 'border border-white/80 bg-black/45 text-transparent'
                  }`}
                >
                  {isSelected ? selectionIndex + 1 : <Check className="h-3 w-3" />}
                </span>
                <span className="absolute bottom-1.5 right-1.5 rounded bg-black/65 px-1.5 py-0.5 text-[10px] font-semibold text-white tabular-nums">
                  {media.duration}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
