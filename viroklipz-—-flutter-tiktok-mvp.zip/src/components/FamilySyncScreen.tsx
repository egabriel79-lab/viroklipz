import React, { useState } from 'react';
import { ArrowLeft, Home } from 'lucide-react';
import { InviteFamilyScreen } from './InviteFamilyScreen';

interface FamilySyncScreenProps {
  onBack: () => void;
  onNotify?: (message: string) => void;
}

export const FamilySyncScreen: React.FC<FamilySyncScreenProps> = ({
  onBack,
  onNotify,
}) => {
  const [selectedRole, setSelectedRole] = useState<'guardian' | 'teen' | null>(
    null
  );

  if (selectedRole) {
    return (
      <InviteFamilyScreen
        isGuardian={selectedRole === 'guardian'}
        onBack={() => setSelectedRole(null)}
        onNotify={onNotify}
      />
    );
  }

  return (
    <div className="flex h-full w-full flex-col bg-[#121212] text-white select-none overflow-hidden">
      {/* AppBar */}
      <header className="relative flex h-12 shrink-0 items-center justify-center border-b border-white/10 bg-[#121212] px-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Atrás"
          className="absolute left-2 flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="text-[15px] font-bold text-white">
          Sincronización familiar
        </h1>
      </header>

      {/* Cuerpo principal centrado y scrolleable */}
      <div className="flex-1 min-h-0 overflow-y-auto px-6 no-scrollbar">
        <div className="flex min-h-full flex-col items-center justify-center py-6 text-center">
          {/* Ilustración casita amarilla con sonrisa (100x100, ícono 50px, fondo amarillo oscuro/oliva) */}
          <div className="flex h-[100px] w-[100px] items-center justify-center rounded-[20px] bg-[#332D10] shadow-inner">
            <svg
              viewBox="0 0 80 80"
              className="h-[50px] w-[50px]"
              aria-hidden="true"
            >
              <path
                d="M12 37L40 13L68 37V64C68 67.3 65.3 70 62 70H18C14.7 70 12 67.3 12 64V37Z"
                fill="#FACC15"
              />
              <circle cx="31" cy="45" r="2.8" fill="#18181B" />
              <circle cx="49" cy="45" r="2.8" fill="#18181B" />
              <path
                d="M30 53C33 58 47 58 50 53"
                stroke="#18181B"
                strokeWidth="3.2"
                strokeLinecap="round"
                fill="none"
              />
            </svg>
          </div>

          <div className="h-5" />

          {/* Título más compacto */}
          <h2 className="text-[22px] font-bold leading-[1.25] text-white">
            Acompaña a tu adolescente en Viroklipz
          </h2>

          <div className="h-4" />

          {/* Cuadro de texto descriptivo con padding 16px, texto 14px e ícono pequeño */}
          <div className="flex w-full items-start gap-3 rounded-2xl bg-[#1E1E1E] p-4 text-left">
            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[#332D10] text-amber-400">
              <Home className="h-4 w-4" />
            </span>
            <p className="text-[13.5px] leading-relaxed text-zinc-300">
              Vincula tu cuenta con la de tu adolescente para configurar juntos
              límites de tiempo en pantalla, restricciones de contenido y
              ajustes de privacidad.
            </p>
          </div>

          <div className="h-6" />

          {/* Dos botones con altura fija de 50px */}
          <div className="w-full space-y-3">
            <button
              type="button"
              onClick={() => setSelectedRole('guardian')}
              className="flex h-[50px] w-full items-center justify-center rounded-xl border border-zinc-700 bg-black text-sm font-bold text-white transition-colors hover:bg-zinc-900 active:scale-[0.99]"
            >
              Continuar como tutor legal
            </button>

            <button
              type="button"
              onClick={() => setSelectedRole('teen')}
              className="flex h-[50px] w-full items-center justify-center rounded-xl bg-white text-sm font-bold text-black transition-colors hover:bg-zinc-200 active:scale-[0.99]"
            >
              Continuar como adolescente
            </button>
          </div>

          {/* Espacio inferior de 30px */}
          <div className="h-[30px] shrink-0" />
        </div>
      </div>
    </div>
  );
};
