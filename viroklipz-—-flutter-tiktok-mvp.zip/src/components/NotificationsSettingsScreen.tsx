import React, { useState } from 'react';
import { ArrowLeft, ChevronRight } from 'lucide-react';

interface NotificationsSettingsScreenProps {
  onBack: () => void;
  onNotify?: (message: string) => void;
}

const INITIAL_SWITCH_STATES: Record<string, boolean> = {
  // Interacciones
  likes: true,
  saved_posts: true,
  comments: true,
  new_followers: true,
  profile_views: true,
  reposts: true,
  interacted_posts: true,
  streaks: true,
  // Mensajes
  direct_messages: true,
  dm_previews: true,
  message_requests: true,
  activity_status: true,
  // Boletín de noticias
  new_bulletins: true,
  bulletin_invites: true,
  bulletin_interactions: true,
  bulletin_new_members: true,
  // Sugerencias de publicaciones personalizadas
  posts_people_you_may_know: true,
  shared_by_others: true,
  posts_you_might_like: true,
  // LIVE
  live_creator_rankings: true,
  // Tiempo en pantalla (único en false por defecto)
  weekly_screen_time: false,
  // Otro
  people_you_may_know: true,
  personalized_updates: true,
  other_accounts_notifications: true,
};

interface SwitchTileProps {
  id: string;
  title: string;
  subtitle?: string;
  checked: boolean;
  onToggle: (id: string) => void;
}

const SwitchTile: React.FC<SwitchTileProps> = ({
  id,
  title,
  subtitle,
  checked,
  onToggle,
}) => (
  <div
    onClick={() => onToggle(id)}
    role="button"
    tabIndex={0}
    onKeyDown={(e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        onToggle(id);
      }
    }}
    className="flex w-full cursor-pointer items-center justify-between gap-3 px-4 py-3.5 transition-colors hover:bg-white/5"
  >
    <div className="min-w-0 flex-1">
      <p className="text-[14px] font-medium leading-snug text-zinc-100">
        {title}
      </p>
      {subtitle && (
        <p className="mt-1 text-xs leading-relaxed text-zinc-400">
          {subtitle}
        </p>
      )}
    </div>

    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={title}
      onClick={(e) => {
        e.stopPropagation();
        onToggle(id);
      }}
      className={`relative inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors ${
        checked ? 'bg-[#25F4EE]' : 'bg-zinc-600'
      }`}
    >
      <span
        className={`inline-block h-4 w-4 transform rounded-full bg-white shadow transition-transform ${
          checked ? 'translate-x-6' : 'translate-x-1'
        }`}
      />
    </button>
  </div>
);

interface NavigationTileProps {
  title: string;
  subtitle?: string;
  onTap: () => void;
}

const NavigationTile: React.FC<NavigationTileProps> = ({
  title,
  subtitle,
  onTap,
}) => (
  <button
    type="button"
    onClick={onTap}
    className="flex w-full items-center justify-between gap-3 px-4 py-3.5 text-left transition-colors hover:bg-white/5 active:bg-white/10"
  >
    <div className="min-w-0 flex-1">
      <p className="text-[14px] font-medium leading-snug text-zinc-100">
        {title}
      </p>
      {subtitle && (
        <p className="mt-1 text-xs leading-relaxed text-zinc-400">
          {subtitle}
        </p>
      )}
    </div>
    <ChevronRight className="h-4 w-4 shrink-0 text-zinc-500" />
  </button>
);

interface SectionBlockProps {
  title?: string;
  children: React.ReactNode;
}

const SectionBlock: React.FC<SectionBlockProps> = ({ title, children }) => (
  <section className="px-4 pt-5">
    {title && (
      <h2 className="mb-2 px-1 text-xs font-semibold tracking-wide text-zinc-400">
        {title}
      </h2>
    )}
    <div className="divide-y divide-white/5 overflow-hidden rounded-xl bg-[#1E1E1E]">
      {children}
    </div>
  </section>
);

export const NotificationsSettingsScreen: React.FC<
  NotificationsSettingsScreenProps
> = ({ onBack, onNotify }) => {
  const [switchStates, setSwitchStates] = useState<Record<string, boolean>>(
    INITIAL_SWITCH_STATES
  );

  const handleToggle = (id: string) => {
    setSwitchStates((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const notifyNav = (title: string) => {
    onNotify?.(`Notificaciones: ${title}`);
  };

  return (
    <div className="flex h-full w-full flex-col bg-[#121212] text-white select-none overflow-hidden">
      {/* AppBar: Flecha de atrás a la izquierda y título centrado */}
      <header className="relative flex h-12 shrink-0 items-center justify-center border-b border-white/10 bg-[#121212] px-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Atrás"
          className="absolute left-2 flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="text-[15px] font-bold text-white">Notificaciones</h1>
      </header>

      {/* ListView de secciones */}
      <div className="flex-1 min-h-0 overflow-y-auto pb-8 no-scrollbar">
        {/* Sección Superior (Sin título) */}
        <SectionBlock>
          <NavigationTile
            title="Notificaciones en la aplicación"
            onTap={() => notifyNav('Notificaciones en la aplicación')}
          />
          <NavigationTile
            title="Horario de notificaciones push"
            subtitle="Establece un horario para desactivar las notificaciones push."
            onTap={() => notifyNav('Horario de notificaciones push')}
          />
        </SectionBlock>

        {/* Sección "Interacciones" */}
        <SectionBlock title="Interacciones">
          <SwitchTile
            id="likes"
            title="Me gusta"
            checked={switchStates.likes}
            onToggle={handleToggle}
          />
          <SwitchTile
            id="saved_posts"
            title="Publicaciones guardadas"
            checked={switchStates.saved_posts}
            onToggle={handleToggle}
          />
          <SwitchTile
            id="comments"
            title="Comentarios"
            checked={switchStates.comments}
            onToggle={handleToggle}
          />
          <SwitchTile
            id="new_followers"
            title="Nuevos seguidores"
            checked={switchStates.new_followers}
            onToggle={handleToggle}
          />
          <SwitchTile
            id="profile_views"
            title="Visualizaciones del perfil"
            checked={switchStates.profile_views}
            onToggle={handleToggle}
          />
          <SwitchTile
            id="reposts"
            title="Publicaciones compartidas"
            checked={switchStates.reposts}
            onToggle={handleToggle}
          />
          <SwitchTile
            id="interacted_posts"
            title="Publicaciones con las que interactuaste"
            subtitle="Recibe notificaciones sobre publicaciones que te gustaron, comentaste o compartiste recientemente."
            checked={switchStates.interacted_posts}
            onToggle={handleToggle}
          />
          <SwitchTile
            id="streaks"
            title="Rachas"
            subtitle="Recibe notificaciones cuando estés a punto de perder una racha de chat con tus amigos."
            checked={switchStates.streaks}
            onToggle={handleToggle}
          />
        </SectionBlock>

        {/* Sección "Mensajes" */}
        <SectionBlock title="Mensajes">
          <SwitchTile
            id="direct_messages"
            title="Mensajes directos"
            checked={switchStates.direct_messages}
            onToggle={handleToggle}
          />
          <NavigationTile
            title="Llamadas de voz"
            subtitle="Personas a las que sigues"
            onTap={() => notifyNav('Llamadas de voz')}
          />
          <SwitchTile
            id="dm_previews"
            title="Vista previa de mensajes directos"
            checked={switchStates.dm_previews}
            onToggle={handleToggle}
          />
          <SwitchTile
            id="message_requests"
            title="Solicitudes de mensajes"
            subtitle="Recibe una notificación cuando alguien te envíe una solicitud de mensaje."
            checked={switchStates.message_requests}
            onToggle={handleToggle}
          />
          <SwitchTile
            id="activity_status"
            title="Estado de actividad"
            checked={switchStates.activity_status}
            onToggle={handleToggle}
          />
          <NavigationTile
            title="Tonos de alerta"
            subtitle="Establece tonos de alerta únicos para tus notificaciones de mensajes."
            onTap={() => notifyNav('Tonos de alerta')}
          />
        </SectionBlock>

        {/* Sección "Boletín de noticias" */}
        <SectionBlock title="Boletín de noticias">
          <SwitchTile
            id="new_bulletins"
            title="Boletines nuevos"
            checked={switchStates.new_bulletins}
            onToggle={handleToggle}
          />
          <SwitchTile
            id="bulletin_invites"
            title="Invitaciones"
            checked={switchStates.bulletin_invites}
            onToggle={handleToggle}
          />
          <SwitchTile
            id="bulletin_interactions"
            title="Interacciones"
            checked={switchStates.bulletin_interactions}
            onToggle={handleToggle}
          />
          <SwitchTile
            id="bulletin_new_members"
            title="Nuevos miembros"
            checked={switchStates.bulletin_new_members}
            onToggle={handleToggle}
          />
        </SectionBlock>

        {/* Sección "Sugerencias de publicaciones" */}
        <SectionBlock title="Sugerencias de publicaciones">
          <NavigationTile
            title="Publicaciones de cuentas que sigues"
            onTap={() => notifyNav('Publicaciones de cuentas que sigues')}
          />
        </SectionBlock>

        {/* Sección "Sugerencias de publicaciones personalizadas" */}
        <SectionBlock title="Sugerencias de publicaciones personalizadas">
          <SwitchTile
            id="posts_people_you_may_know"
            title="Publicaciones de gente que quizás conozcas"
            checked={switchStates.posts_people_you_may_know}
            onToggle={handleToggle}
          />
          <SwitchTile
            id="shared_by_others"
            title="Compartidas por otros"
            checked={switchStates.shared_by_others}
            onToggle={handleToggle}
          />
          <SwitchTile
            id="posts_you_might_like"
            title="Publicaciones que podrían gustarte"
            checked={switchStates.posts_you_might_like}
            onToggle={handleToggle}
          />
        </SectionBlock>

        {/* Sección "LIVE" */}
        <SectionBlock title="LIVE">
          <NavigationTile
            title="Ajustes de notificaciones de LIVE"
            onTap={() => notifyNav('Ajustes de notificaciones de LIVE')}
          />
          <SwitchTile
            id="live_creator_rankings"
            title="Notificaciones de los rankings de creadores"
            subtitle="Activa esta opción para recibir notificaciones sobre actualizaciones y logros de los rankings de creadores."
            checked={switchStates.live_creator_rankings}
            onToggle={handleToggle}
          />
        </SectionBlock>

        {/* Sección "Tiempo en pantalla" */}
        <SectionBlock title="Tiempo en pantalla">
          <SwitchTile
            id="weekly_screen_time"
            title="Novedades sobre el tiempo en pantalla semanal"
            checked={switchStates.weekly_screen_time}
            onToggle={handleToggle}
          />
        </SectionBlock>

        {/* Sección "Otro" */}
        <SectionBlock title="Otro">
          <SwitchTile
            id="people_you_may_know"
            title="Personas que quizás conozcas"
            subtitle="Estas son las notificaciones sobre cuentas sugeridas de personas que podrías conocer."
            checked={switchStates.people_you_may_know}
            onToggle={handleToggle}
          />
          <SwitchTile
            id="personalized_updates"
            title="Actualizaciones personalizadas y más"
            checked={switchStates.personalized_updates}
            onToggle={handleToggle}
          />
          <NavigationTile
            title="Notificaciones por correo electrónico"
            onTap={() => notifyNav('Notificaciones por correo electrónico')}
          />
          <NavigationTile
            title="Notificaciones por SMS"
            onTap={() => notifyNav('Notificaciones por SMS')}
          />
          <SwitchTile
            id="other_accounts_notifications"
            title="Notificaciones de tus otras cuentas de TikTok"
            checked={switchStates.other_accounts_notifications}
            onToggle={handleToggle}
          />
        </SectionBlock>
      </div>
    </div>
  );
};
