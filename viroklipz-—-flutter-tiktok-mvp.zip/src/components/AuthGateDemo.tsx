import React, { useState } from 'react';
import { ArrowLeft, Lock, Mail, User } from 'lucide-react';

interface AuthGateDemoProps {
  onAuthenticated: (username: string, email: string) => void;
  onBack?: () => void;
}

export const AuthGateDemo: React.FC<AuthGateDemoProps> = ({
  onAuthenticated,
  onBack,
}) => {
  const [isLogin, setIsLogin] = useState(true);
  const [username, setUsername] = useState('mateo.cine');
  const [email, setEmail] = useState('mateo@viroklipz.app');
  const [password, setPassword] = useState('123456');
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.includes('@')) {
      setError('Ingresa un correo válido');
      return;
    }
    if (password.length < 6) {
      setError('Mínimo 6 caracteres');
      return;
    }
    if (!isLogin && username.trim().length < 3) {
      setError('Ingresa un nombre de usuario de al menos 3 caracteres');
      return;
    }

    setError(null);
    setIsLoading(true);
    window.setTimeout(() => {
      setIsLoading(false);
      const resolvedName = isLogin
        ? email.split('@')[0] || 'creador'
        : username.trim().replace(/^@/, '');
      onAuthenticated(resolvedName, email.trim());
    }, 450);
  };

  return (
    <div className="relative flex h-full w-full flex-col overflow-y-auto bg-[#0F0F0F] text-white no-scrollbar">
      {/* Resplandores ambientales unificados con la Landing Page */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-24 left-1/2 h-72 w-72 -translate-x-1/2 rounded-full bg-orange-500/15 blur-[95px]"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute bottom-10 -right-16 h-64 w-64 rounded-full bg-purple-600/15 blur-[95px]"
      />

      {onBack && (
        <header className="sticky top-0 z-20 flex items-center justify-between border-b border-white/10 bg-[#0F0F0F]/85 px-4 py-3 backdrop-blur-md">
          <button
            type="button"
            onClick={onBack}
            aria-label="Volver al inicio"
            className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg px-2 text-xs font-medium text-zinc-300 transition-colors hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-orange-400"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Volver</span>
          </button>

          <span className="font-display text-base font-black tracking-tight text-white">
            Viroklipz
          </span>

          <div className="w-16" aria-hidden="true" />
        </header>
      )}

      <div className="relative z-10 flex flex-1 flex-col justify-center px-6 py-8">
        <div className="mb-8 text-center">
          <h2 className="font-display text-3xl font-black tracking-tight text-white">
            Viroklipz
          </h2>
          <p className="mt-2 text-xs text-zinc-400">
            {isLogin ? 'Inicia sesión para ver y publicar clips' : 'Crea tu cuenta de creador'}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {!isLogin && (
            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-zinc-200" htmlFor="auth-username">
                Nombre de usuario
              </label>
              <div className="relative">
                <User className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-400" />
                <input
                  id="auth-username"
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Nombre de usuario (ej. mateo.cine)"
                  className="h-12 w-full rounded-xl border border-white/15 bg-[#161616] pl-10 pr-3.5 text-sm text-white placeholder:text-zinc-500 focus:border-[#FF6B00] focus:outline-none"
                />
              </div>
            </div>
          )}

          <div className="space-y-1.5">
            <label className="block text-xs font-semibold text-zinc-200" htmlFor="auth-email">
              Correo electrónico
            </label>
            <div className="relative">
              <Mail className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-400" />
              <input
                id="auth-email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Correo electrónico"
                className="h-12 w-full rounded-xl border border-white/15 bg-[#161616] pl-10 pr-3.5 text-sm text-white placeholder:text-zinc-500 focus:border-[#FF6B00] focus:outline-none"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="block text-xs font-semibold text-zinc-200" htmlFor="auth-password">
              Contraseña
            </label>
            <div className="relative">
              <Lock className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-400" />
              <input
                id="auth-password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Contraseña"
                className="h-12 w-full rounded-xl border border-white/15 bg-[#161616] pl-10 pr-3.5 text-sm text-white placeholder:text-zinc-500 focus:border-[#FF6B00] focus:outline-none"
              />
            </div>
          </div>

          {error && (
            <p className="text-center text-xs font-medium text-[#FF4D6D]">{error}</p>
          )}

          <button
            type="submit"
            disabled={isLoading}
            className="mt-2 flex h-13 w-full items-center justify-center rounded-xl bg-gradient-to-r from-[#FF6B00] via-[#FF3D00] to-[#EC4899] text-sm font-bold text-white shadow-[0_0_28px_rgba(255,107,0,0.45)] transition-transform hover:brightness-105 active:scale-95 disabled:opacity-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-orange-400"
          >
            {isLoading ? 'Conectando...' : isLogin ? 'Entrar' : 'Crear cuenta'}
          </button>
        </form>

        <button
          type="button"
          onClick={() => {
            setIsLogin((prev) => !prev);
            setError(null);
          }}
          className="mt-5 min-h-[44px] text-center text-xs font-medium text-zinc-400 transition-colors hover:text-white"
        >
          {isLogin ? '¿No tienes cuenta? Regístrate' : '¿Ya tienes cuenta? Inicia sesión'}
        </button>
      </div>
    </div>
  );
};
