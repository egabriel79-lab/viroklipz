import React, { useEffect, useRef, useState } from 'react';
import {
  AlertCircle,
  ArrowDownToLine,
  BookmarkPlus,
  Check,
  Film,
  Flame,
  Loader2,
  MessageCircle,
  Music2,
  Play,
  Plus,
  RefreshCw,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { CURRENT_USER_ID, VideoItem } from '../data/mockVideos';
import { APP_COLORS } from '../theme/appColors';

interface ToastOptions {
  variant?: 'default' | 'downloading' | 'success' | 'error';
  persistent?: boolean;
}

interface VideoCardProps {
  video: VideoItem;
  currentUserAvatarUrl?: string;
  isActive: boolean;
  isFeedVisible: boolean;
  isMuted: boolean;
  onToggleMute: () => void;
  isLiked: boolean;
  onToggleLike: () => void;
  isFollowing: boolean;
  onToggleFollow: () => void;
  onOpenComments: () => void;
  onShare?: () => void;
  onNotify: (message: string, options?: ToastOptions) => void;
}

function formatCompactCount(count: number): string {
  if (count >= 1_000_000) return `${(count / 1_000_000).toFixed(1)}M`;
  if (count >= 1_000) return `${(count / 1_000).toFixed(1)}K`;
  return String(count);
}

export const VideoCard: React.FC<VideoCardProps> = ({
  video,
  currentUserAvatarUrl,
  isActive,
  isFeedVisible,
  isMuted,
  onToggleMute,
  isLiked,
  onToggleLike,
  isFollowing,
  onToggleFollow,
  onOpenComments,
  onNotify,
}) => {
  const cardRef = useRef<HTMLDivElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [isInViewport, setIsInViewport] = useState(isActive);
  const [isPausedByUser, setIsPausedByUser] = useState(false);
  const [isBuffering, setIsBuffering] = useState(true);
  const [hasVideoError, setHasVideoError] = useState(false);
  const [retryCount, setRetryCount] = useState(0);
  const [isDownloading, setIsDownloading] = useState(false);
  const [showHeartBurst, setShowHeartBurst] = useState(false);
  const [isFireAnimating, setIsFireAnimating] = useState(false);
  const [avatarError, setAvatarError] = useState(false);
  const lastTapRef = useRef<number>(0);
  const singleTapTimerRef = useRef<number | null>(null);
  const fireTimerRef = useRef<number | null>(null);
  const hasLoadedDataRef = useRef<boolean>(false);

  useEffect(() => {
    const node = cardRef.current;
    if (!node || typeof IntersectionObserver === 'undefined') {
      setIsInViewport(true);
      return;
    }

    const observer = new IntersectionObserver(
      ([entry]) => {
        setIsInViewport(entry.isIntersecting && entry.intersectionRatio >= 0.5);
      },
      { threshold: 0.5 }
    );

    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const el = videoRef.current;
    if (!el || hasVideoError) return;

    el.muted = isMuted;

    if (isActive && isFeedVisible) {
      setIsPausedByUser(false);
      if (el.error) {
        setHasVideoError(true);
        setIsBuffering(false);
        return;
      }
      const playPromise = el.play();
      if (playPromise !== undefined) {
        playPromise.catch((err: unknown) => {
          if (err instanceof DOMException && err.name === 'NotSupportedError') {
            setHasVideoError(true);
            setIsBuffering(false);
          } else if (err instanceof DOMException && err.name === 'NotAllowedError') {
            el.muted = true;
            el.play().catch(() => {});
          }
        });
      }
    } else {
      el.pause();
    }
  }, [isActive, isFeedVisible, hasVideoError, retryCount, isMuted]);

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.muted = isMuted;
    }
  }, [isMuted]);

  useEffect(() => {
    const hasUrl = Boolean(video.videoUrl && video.videoUrl.trim());
    hasLoadedDataRef.current = false;
    setHasVideoError(!hasUrl);
    setIsBuffering(hasUrl);
  }, [video.videoUrl, retryCount]);

  useEffect(() => {
    if (!isActive || !isBuffering || hasVideoError || !video.videoUrl) return;
    const timeoutId = window.setTimeout(() => {
      const el = videoRef.current;
      const ready = el ? el.readyState >= 1 : false;
      if (!hasLoadedDataRef.current && !ready) {
        setIsBuffering(false);
        setHasVideoError(true);
      } else {
        setIsBuffering(false);
      }
    }, 12000);
    return () => window.clearTimeout(timeoutId);
  }, [isActive, isBuffering, hasVideoError, video.videoUrl, retryCount]);

  useEffect(() => {
    return () => {
      if (singleTapTimerRef.current) {
        window.clearTimeout(singleTapTimerRef.current);
      }
      if (fireTimerRef.current) {
        window.clearTimeout(fireTimerRef.current);
      }
    };
  }, []);

  const triggerFireScale = () => {
    if (fireTimerRef.current) {
      window.clearTimeout(fireTimerRef.current);
    }
    setIsFireAnimating(true);
    fireTimerRef.current = window.setTimeout(() => {
      setIsFireAnimating(false);
    }, 200);
  };

  const handleFireLikeClick = () => {
    triggerFireScale();
    onToggleLike();
  };

  const handleRetryVideo = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.stopPropagation();
    if (!video.videoUrl || !video.videoUrl.trim()) {
      setHasVideoError(true);
      setIsBuffering(false);
      return;
    }
    hasLoadedDataRef.current = false;
    setHasVideoError(false);
    setIsBuffering(true);
    setRetryCount((prev) => prev + 1);
  };

  const handleVideoSurfaceClick = () => {
    const now = Date.now();
    const delta = now - lastTapRef.current;
    lastTapRef.current = now;

    if (delta < 260) {
      if (singleTapTimerRef.current) {
        window.clearTimeout(singleTapTimerRef.current);
        singleTapTimerRef.current = null;
      }
      if (!isLiked) onToggleLike();
      triggerFireScale();
      setShowHeartBurst(true);
      window.setTimeout(() => setShowHeartBurst(false), 650);
      return;
    }

    singleTapTimerRef.current = window.setTimeout(() => {
      const el = videoRef.current;
      if (!el) return;
      if (el.paused) {
        el.play().catch(() => {});
        setIsPausedByUser(false);
      } else {
        el.pause();
        setIsPausedByUser(true);
      }
    }, 240);
  };

  const handleDownloadVideo = async () => {
    if (isDownloading) return;
    setIsDownloading(true);
    onNotify('Descargando video...', { variant: 'downloading', persistent: true });

    try {
      const response = await fetch(video.videoUrl);
      if (!response.ok) throw new Error('Error al descargar');
      const blob = await response.blob();
      const blobUrl = URL.createObjectURL(blob);

      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = `viroklipz_${video.username}_${video.id}.mp4`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(blobUrl);

      onNotify('Video descargado con éxito', { variant: 'success' });
    } catch {
      onNotify('No se pudo descargar el video', { variant: 'error' });
    } finally {
      setIsDownloading(false);
    }
  };

  const effectiveLikes = video.likes + (isLiked ? 1 : 0);
  const isVisibleInViewport = isActive || isInViewport;
  const resolvedAvatarUrl =
    video.authorId === CURRENT_USER_ID && currentUserAvatarUrl
      ? currentUserAvatarUrl
      : video.avatarUrl;

  return (
    <div
      ref={cardRef}
      className="video-card-container relative h-full w-full snap-start snap-always overflow-hidden bg-zinc-950 select-none"
    >
      <div
        className={`relative h-full w-full transform-gpu transition-all duration-500 ease-out motion-reduce:transition-none motion-reduce:opacity-100 motion-reduce:scale-100 ${
          isVisibleInViewport ? 'opacity-100 scale-100' : 'opacity-0 scale-[0.96]'
        }`}
      >
        {/* Dark muted placeholder surface while loading */}
        <div
          aria-hidden="true"
          className="absolute inset-0 flex items-center justify-center bg-[#141417]"
        >
          {isBuffering && !hasVideoError && (
            <Film className="h-12 w-12 text-zinc-700/80" />
          )}
        </div>

        {/* Video player */}
        {!hasVideoError && (
          <video
            key={`${video.id}-${retryCount}`}
            ref={videoRef}
            src={video.videoUrl}
            style={video.cssFilter ? { filter: video.cssFilter } : undefined}
            className="relative h-full w-full cursor-pointer object-cover"
            loop
            playsInline
            muted={isMuted}
            preload={isActive ? 'auto' : 'metadata'}
            onLoadedMetadata={() => {
              hasLoadedDataRef.current = true;
              setHasVideoError(false);
            }}
            onLoadedData={() => {
              hasLoadedDataRef.current = true;
              setIsBuffering(false);
              setHasVideoError(false);
            }}
            onCanPlay={() => {
              hasLoadedDataRef.current = true;
              setIsBuffering(false);
              setHasVideoError(false);
              const el = videoRef.current;
              if (el && isActive && isFeedVisible && !isPausedByUser && el.paused) {
                el.muted = isMuted;
                el.play().catch(() => {});
              }
            }}
            onWaiting={() => {
              if (!hasVideoError) setIsBuffering(true);
            }}
            onPlaying={() => {
              hasLoadedDataRef.current = true;
              setIsBuffering(false);
              setHasVideoError(false);
            }}
            onStalled={() => {
              const el = videoRef.current;
              if (el && el.networkState === HTMLMediaElement.NETWORK_NO_SOURCE) {
                setHasVideoError(true);
                setIsBuffering(false);
              }
            }}
            onError={() => {
              setHasVideoError(true);
              setIsBuffering(false);
            }}
            onClick={handleVideoSurfaceClick}
          />
        )}

        {/* Dark, muted error placeholder replacing infinite spinner with Retry button */}
        {hasVideoError && (
          <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-[#121215] pl-5 pr-20 text-center">
            <div className="flex max-w-[230px] flex-col items-center gap-3">
              <div className="flex h-14 w-14 items-center justify-center rounded-full border border-zinc-800 bg-zinc-900/90 text-zinc-500">
                <AlertCircle className="h-6 w-6" />
              </div>
              <div className="space-y-1">
                <p className="text-sm font-semibold text-zinc-200">
                  Failed to load video
                </p>
                <p className="text-xs leading-relaxed text-zinc-400">
                  Check your connection or try reloading the stream.
                </p>
              </div>
              <button
                type="button"
                onClick={handleRetryVideo}
                className="relative z-30 inline-flex items-center gap-1.5 rounded-full border border-zinc-700/80 bg-zinc-800/90 px-4 py-2 text-xs font-semibold text-zinc-100 transition hover:bg-zinc-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white active:scale-95"
              >
                <RefreshCw className="h-3.5 w-3.5" />
                <span>Retry</span>
              </button>
            </div>
          </div>
        )}

        {/* Overlay visual opcional superpuesto en Stack */}
        {video.effectUsed && video.effectUsed !== 'Ninguno' && (
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-0 opacity-40 mix-blend-screen"
            style={{
              background:
                video.effectUsed === 'neon_particles' || video.effectUsed === 'Partículas Neón'
                  ? 'linear-gradient(135deg, rgba(37,244,238,0.6) 0%, rgba(233,30,99,0.5) 100%)'
                  : video.effectUsed === 'bokeh_nights' || video.effectUsed === 'Bokeh Nocturno'
                    ? 'linear-gradient(135deg, rgba(103,58,183,0.65) 0%, rgba(233,30,99,0.5) 100%)'
                    : video.effectUsed === 'vhs_retro' || video.effectUsed === 'Estática Retro'
                      ? 'linear-gradient(180deg, rgba(255,255,255,0.3) 0%, rgba(255,87,34,0.35) 100%)'
                      : 'linear-gradient(135deg, rgba(255,87,34,0.65) 0%, rgba(233,30,99,0.45) 100%)',
            }}
          />
        )}
        {video.effectVideoUrl && (
          <video
            src={video.effectVideoUrl}
            autoPlay
            loop
            playsInline
            muted
            aria-hidden="true"
            className="pointer-events-none absolute inset-0 h-full w-full object-cover opacity-45 mix-blend-screen"
          />
        )}

      {/* Stack overlay: scrim superior sutil + gradiente semi-transparente inferior para legibilidad sobre fondos claros */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-x-0 top-0 z-10 h-28 bg-gradient-to-b from-black/45 to-transparent"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-x-0 bottom-0 z-10 h-64 bg-gradient-to-t from-black/90 via-black/55 to-transparent"
      />

      {/* Indicador de carga sutil (solo mientras carga sin errores) */}
      {isBuffering && !hasVideoError && isActive && (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
          <div className="h-8 w-8 rounded-full border-2 border-white/25 border-t-white animate-spin" />
        </div>
      )}

      {/* Botón de silencio/sonido en esquina superior derecha */}
      <button
        type="button"
        onClick={onToggleMute}
        aria-label={isMuted ? 'Activar sonido' : 'Silenciar video'}
        className="absolute right-3 top-14 z-20 flex h-11 w-11 items-center justify-center rounded-full bg-black/35 text-white backdrop-blur-sm transition-colors hover:bg-black/55 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"
      >
        {isMuted ? <VolumeX className="h-4.5 w-4.5" /> : <Volume2 className="h-4.5 w-4.5" />}
      </button>

      {/* Indicador de Pausa manual */}
      {isPausedByUser && (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
          <div className="flex h-16 w-16 items-center justify-center rounded-full bg-black/50 backdrop-blur-sm">
            <Play className="ml-1 h-8 w-8 fill-white text-white" />
          </div>
        </div>
      )}

      {/* Animación de llama al hacer doble toque */}
      {showHeartBurst && (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
          <Flame className="h-24 w-24 fill-[#FF5722] text-[#FF5722] drop-shadow-2xl animate-ping" />
        </div>
      )}

      {/* Lateral Derecho: Contenedor flotante Glassmorphism con acciones Viroklipz */}
      <div
        className={`absolute bottom-5 right-2.5 z-20 flex flex-col items-center gap-3 transition-all duration-500 delay-75 ease-out motion-reduce:transition-none ${
          isVisibleInViewport ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-2'
        }`}
      >
        <div className="flex flex-col items-center gap-3.5 rounded-[22px] border border-white/15 bg-white/10 px-1.5 py-3 shadow-2xl backdrop-blur-md">
          {/* Avatar + Botón Seguir */}
          <div className="relative mb-1 flex flex-col items-center">
            <div className="h-11 w-11 overflow-hidden rounded-full border-2 border-white bg-zinc-800 shadow-md">
              {!avatarError ? (
                <img
                  src={resolvedAvatarUrl}
                  alt={`Avatar de ${video.username}`}
                  referrerPolicy="no-referrer"
                  onError={() => setAvatarError(true)}
                  className="h-full w-full object-cover"
                />
              ) : (
                <div className="flex h-full w-full items-center justify-center text-sm font-bold text-white">
                  {video.username.slice(0, 2).toUpperCase()}
                </div>
              )}
            </div>
            <button
              type="button"
              onClick={onToggleFollow}
              aria-label={isFollowing ? `Dejar de seguir a ${video.username}` : `Seguir a ${video.username}`}
              style={
                !isFollowing
                  ? { background: APP_COLORS.brandGradient }
                  : undefined
              }
              className={`-mt-2.5 flex h-6 w-6 items-center justify-center rounded-full border border-zinc-950 transition-transform active:scale-90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white ${
                isFollowing ? 'bg-white text-zinc-950' : 'text-white'
              }`}
            >
              {isFollowing ? <Check className="h-3.5 w-3.5 stroke-[3]" /> : <Plus className="h-3.5 w-3.5 stroke-[3]" />}
            </button>
          </div>

          {/* Reacción Llama (Reemplaza Corazón) con animación de escala al tocar */}
          <button
            type="button"
            onClick={handleFireLikeClick}
            aria-label={`Impulsar (${effectiveLikes})`}
            className="group flex min-h-[42px] min-w-[42px] flex-col items-center justify-center gap-0.5 rounded-lg text-white transition-transform active:scale-90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"
          >
            <Flame
              className={`h-7 w-7 transform-gpu drop-shadow-md transition-all duration-200 ease-out motion-reduce:transition-none ${
                isFireAnimating ? 'scale-125' : 'scale-100 group-active:scale-90'
              } ${
                isLiked ? 'fill-[#FF5722] text-[#FF5722]' : 'fill-white/20 text-white'
              }`}
            />
            <span className="text-[11px] font-semibold tabular-nums drop-shadow">
              {formatCompactCount(effectiveLikes)}
            </span>
          </button>

          {/* Comentarios */}
          <button
            type="button"
            onClick={onOpenComments}
            aria-label={`Abrir comentarios (${video.commentsCount})`}
            className="flex min-h-[42px] min-w-[42px] flex-col items-center justify-center gap-0.5 text-white transition-transform active:scale-90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white rounded-lg"
          >
            <MessageCircle className="h-7 w-7 fill-white/15 text-white drop-shadow-md" />
            <span className="text-[11px] font-semibold tabular-nums drop-shadow">
              {formatCompactCount(video.commentsCount)}
            </span>
          </button>

          {/* Descargar video a la galería */}
          <button
            type="button"
            onClick={handleDownloadVideo}
            disabled={isDownloading}
            aria-label={isDownloading ? 'Descargando video' : 'Descargar video'}
            className="flex min-h-[42px] min-w-[42px] flex-col items-center justify-center gap-0.5 text-white transition-transform active:scale-90 disabled:opacity-85 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white rounded-lg"
          >
            {isDownloading ? (
              <Loader2 className="h-6 w-6 animate-spin text-[#FF5722] drop-shadow-md" />
            ) : (
              <ArrowDownToLine className="h-6 w-6 text-white drop-shadow-md" />
            )}
            <span className="text-[10.5px] font-semibold tabular-nums drop-shadow">
              {isDownloading ? 'Descargando' : formatCompactCount(video.shares)}
            </span>
          </button>

          {/* Guardar (Marcador) */}
          <button
            type="button"
            onClick={handleDownloadVideo}
            disabled={isDownloading}
            aria-label={isDownloading ? 'Descargando video' : 'Guardar video'}
            className="flex min-h-[42px] min-w-[42px] flex-col items-center justify-center gap-0.5 text-white transition-transform active:scale-90 disabled:opacity-80 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white rounded-lg"
          >
            {isDownloading ? (
              <Loader2 className="h-6 w-6 animate-spin text-[#FF5722] drop-shadow-md" />
            ) : (
              <BookmarkPlus className="h-6 w-6 text-white drop-shadow-md" />
            )}
            <span className="text-[10px] font-semibold drop-shadow">
              {isDownloading ? 'Descargando' : 'Guardar'}
            </span>
          </button>
        </div>

        {/* Disco giratorio de audio */}
        <div
          aria-hidden="true"
          className={`flex h-10 w-10 items-center justify-center rounded-full border-[5px] border-zinc-800 bg-zinc-950 shadow-lg ${
            isActive && !isPausedByUser ? 'animate-disc' : ''
          }`}
        >
          <div className="h-4 w-4 overflow-hidden rounded-full bg-zinc-700">
            {!avatarError && (
              <img
                src={resolvedAvatarUrl}
                alt=""
                referrerPolicy="no-referrer"
                className="h-full w-full object-cover"
              />
            )}
          </div>
        </div>
      </div>

      {/* Inferior Izquierdo: @usuario, descripción y marquesina de audio */}
      <div
        className={`pointer-events-none absolute bottom-4 left-3.5 right-20 z-20 flex flex-col gap-1.5 text-white transition-all duration-500 delay-75 ease-out motion-reduce:transition-none ${
          isVisibleInViewport ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-2'
        }`}
      >
        <p className="text-[15px] font-bold tracking-tight drop-shadow">@{video.username}</p>
        <p className="line-clamp-2 text-[13.5px] leading-snug text-white/95 drop-shadow">
          {video.caption}
        </p>
        <div className="mt-1 flex items-center gap-2 overflow-hidden">
          <Music2 className="h-3.5 w-3.5 shrink-0 text-white" />
          <div className="relative w-full overflow-hidden">
            <div className="animate-marquee text-[13px] font-medium text-white/95">
              <span className="pr-10">{video.audioName}</span>
              <span className="pr-10">{video.audioName}</span>
            </div>
          </div>
        </div>
      </div>
      </div>
    </div>
  );
};
