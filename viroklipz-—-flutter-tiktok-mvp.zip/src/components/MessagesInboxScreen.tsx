import React, { useEffect, useRef, useState } from 'react';
import {
  ArrowLeft,
  Camera,
  ChevronRight,
  Inbox,
  Send,
  Zap,
} from 'lucide-react';
import { ActivityScreen } from './ActivityScreen';
import { SystemNotificationsScreen } from './SystemNotificationsScreen';

const CURRENT_CHAT_UID = 'user_me_viroklipz';

interface ChatThread {
  id: string;
  otherUserId: string;
  name: string;
  avatarUrl: string;
  initials: string;
  lastMessage: string;
  time: string;
  showCameraIcon: boolean;
  messages: { id: string; fromMe: boolean; text: string; time: string }[];
}

interface MessagesInboxScreenProps {
  onOpenCamera?: () => void;
  onNotify?: (message: string) => void;
}

const INITIAL_CHATS: ChatThread[] = [
  {
    id: 'bicorne',
    otherUserId: 'uid_bicorne',
    name: 'El Bicorne',
    avatarUrl: '/src/assets/images/avatar_creator_diego_1794604323122.jpg',
    initials: 'EB',
    lastMessage: 'As Salam aleykum...',
    time: '5 nov',
    showCameraIcon: true,
    messages: [
      {
        id: 'm1',
        fromMe: false,
        text: 'As Salam aleykum... ¿ya viste el último clip que subí?',
        time: '5 nov',
      },
    ],
  },
  {
    id: 'toxica',
    otherUserId: 'uid_toxica',
    name: 'la toxica #1🦋',
    avatarUrl: '/src/assets/images/avatar_creator_valeria_1794604321625.jpg',
    initials: 'LT',
    lastMessage: 'Enviado',
    time: '10:30 AM',
    showCameraIcon: true,
    messages: [
      {
        id: 'm2',
        fromMe: true,
        text: 'Te mandé el audio nuevo por DM',
        time: '10:30 AM',
      },
    ],
  },
  {
    id: 'jovana',
    otherUserId: 'uid_jovana',
    name: '1382jovana🇻🇪',
    avatarUrl: '/src/assets/images/avatar_creator_sofia_1794604322145.jpg',
    initials: '13',
    lastMessage: 'Hola, ¿cómo estás?',
    time: 'Ayer',
    showCameraIcon: false,
    messages: [
      {
        id: 'm3',
        fromMe: false,
        text: 'Hola, ¿cómo estás?',
        time: 'Ayer',
      },
    ],
  },
];

export const MessagesInboxScreen: React.FC<MessagesInboxScreenProps> = ({
  onOpenCamera,
  onNotify,
}) => {
  const [chats, setChats] = useState<ChatThread[]>(INITIAL_CHATS);
  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const [showActivityScreen, setShowActivityScreen] = useState(false);
  const [showSystemNotifications, setShowSystemNotifications] = useState(false);
  const [draftReply, setDraftReply] = useState('');
  const [brokenAvatars, setBrokenAvatars] = useState<Record<string, boolean>>({});
  const [typingStatusByChat, setTypingStatusByChat] = useState<
    Record<string, Record<string, boolean>>
  >({});

  const typingDebounceRef = useRef<number | null>(null);
  const replyStartTimerRef = useRef<number | null>(null);
  const replyDeliverTimerRef = useRef<number | null>(null);

  const activeChat = chats.find((c) => c.id === activeChatId) ?? null;

  const setTypingStatus = (chatId: string, uid: string, isTyping: boolean) => {
    setTypingStatusByChat((prev) => {
      const currentMap = prev[chatId] ?? {};
      if (Boolean(currentMap[uid]) === isTyping) return prev;
      return {
        ...prev,
        [chatId]: {
          ...currentMap,
          [uid]: isTyping,
        },
      };
    });
  };

  const clearDebounceTimer = () => {
    if (typingDebounceRef.current !== null) {
      window.clearTimeout(typingDebounceRef.current);
      typingDebounceRef.current = null;
    }
  };

  useEffect(() => {
    return () => {
      clearDebounceTimer();
      if (replyStartTimerRef.current !== null) {
        window.clearTimeout(replyStartTimerRef.current);
      }
      if (replyDeliverTimerRef.current !== null) {
        window.clearTimeout(replyDeliverTimerRef.current);
      }
    };
  }, []);

  if (showActivityScreen) {
    return (
      <ActivityScreen
        onBack={() => setShowActivityScreen(false)}
        onNotify={onNotify}
      />
    );
  }

  if (showSystemNotifications) {
    return (
      <SystemNotificationsScreen
        onBack={() => setShowSystemNotifications(false)}
        onNotify={onNotify}
      />
    );
  }

  const handleDraftChanged = (value: string) => {
    setDraftReply(value);
    if (!activeChat) return;

    clearDebounceTimer();

    if (!value.trim()) {
      setTypingStatus(activeChat.id, CURRENT_CHAT_UID, false);
      return;
    }

    setTypingStatus(activeChat.id, CURRENT_CHAT_UID, true);
    typingDebounceRef.current = window.setTimeout(() => {
      setTypingStatus(activeChat.id, CURRENT_CHAT_UID, false);
    }, 2500);
  };

  const handleSendReply = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = draftReply.trim();
    if (!trimmed || !activeChat) return;

    const targetChatId = activeChat.id;
    const targetOtherUid = activeChat.otherUserId;

    clearDebounceTimer();
    setTypingStatus(targetChatId, CURRENT_CHAT_UID, false);

    setChats((prev) =>
      prev.map((chat) =>
        chat.id === targetChatId
          ? {
              ...chat,
              lastMessage: trimmed,
              time: 'Ahora',
              messages: [
                ...chat.messages,
                {
                  id: `local-${Date.now()}`,
                  fromMe: true,
                  text: trimmed,
                  time: 'Ahora',
                },
              ],
            }
          : chat
      )
    );
    setDraftReply('');

    if (replyStartTimerRef.current !== null) {
      window.clearTimeout(replyStartTimerRef.current);
    }
    if (replyDeliverTimerRef.current !== null) {
      window.clearTimeout(replyDeliverTimerRef.current);
    }

    replyStartTimerRef.current = window.setTimeout(() => {
      setTypingStatus(targetChatId, targetOtherUid, true);

      replyDeliverTimerRef.current = window.setTimeout(() => {
        setTypingStatus(targetChatId, targetOtherUid, false);
        const autoReply = '¡Recibido! Me encantó ese video 🔥';
        setChats((prev) =>
          prev.map((chat) =>
            chat.id === targetChatId
              ? {
                  ...chat,
                  lastMessage: autoReply,
                  time: 'Ahora',
                  messages: [
                    ...chat.messages,
                    {
                      id: `reply-${Date.now()}`,
                      fromMe: false,
                      text: autoReply,
                      time: 'Ahora',
                    },
                  ],
                }
              : chat
          )
        );
      }, 2200);
    }, 450);
  };

  const handleCloseActiveChat = () => {
    if (activeChat) {
      clearDebounceTimer();
      setTypingStatus(activeChat.id, CURRENT_CHAT_UID, false);
    }
    setDraftReply('');
    setActiveChatId(null);
  };

  if (activeChat) {
    const activeTypingMap = typingStatusByChat[activeChat.id] ?? {};
    const isOtherUserTyping = Boolean(activeTypingMap[activeChat.otherUserId]);

    return (
      <div className="flex h-full w-full flex-col bg-[#0F0F0F] text-white">
        <header className="flex items-center gap-3 border-b border-white/10 px-4 py-3">
          <button
            type="button"
            onClick={handleCloseActiveChat}
            aria-label="Volver a mensajes"
            className="flex h-9 w-9 items-center justify-center rounded-full text-zinc-300 transition-colors hover:bg-white/10 hover:text-white"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>

          <div className="flex items-center gap-2.5 min-w-0 flex-1">
            {!brokenAvatars[activeChat.id] ? (
              <img
                src={activeChat.avatarUrl}
                alt={activeChat.name}
                referrerPolicy="no-referrer"
                onError={() =>
                  setBrokenAvatars((prev) => ({ ...prev, [activeChat.id]: true }))
                }
                className="h-9 w-9 rounded-full object-cover bg-zinc-800 shrink-0"
              />
            ) : (
              <div className="flex h-9 w-9 items-center justify-center rounded-full bg-zinc-800 text-xs font-bold text-white shrink-0">
                {activeChat.initials}
              </div>
            )}
            <span className="truncate text-sm font-bold text-white">
              {activeChat.name}
            </span>
          </div>

          {onOpenCamera && (
            <button
              type="button"
              onClick={onOpenCamera}
              aria-label="Enviar video o foto"
              className="flex h-9 w-9 items-center justify-center rounded-full text-zinc-400 transition-colors hover:bg-white/10 hover:text-white"
            >
              <Camera className="h-4.5 w-4.5" />
            </button>
          )}
        </header>

        {/* Indicador de "Escribiendo..." en la parte superior del chat */}
        <div
          aria-live="polite"
          className={`overflow-hidden transition-all duration-200 ease-out ${
            isOtherUserTyping ? 'max-h-8 opacity-100' : 'max-h-0 opacity-0'
          }`}
        >
          {isOtherUserTyping && (
            <div className="px-4 pt-2 pb-0.5 text-left">
              <span className="text-xs italic text-zinc-400">
                Escribiendo...
              </span>
            </div>
          )}
        </div>

        <div className="flex-1 space-y-3 overflow-y-auto px-4 py-4 no-scrollbar">
          {activeChat.messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex ${msg.fromMe ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[78%] rounded-2xl px-3.5 py-2.5 text-sm leading-relaxed ${
                  msg.fromMe
                    ? 'bg-[#FF2D55] text-white'
                    : 'bg-[#1B1B1F] text-zinc-100 border border-white/10'
                }`}
              >
                <p>{msg.text}</p>
                <p
                  className={`mt-1 text-[10px] tabular-nums ${
                    msg.fromMe ? 'text-white/75' : 'text-zinc-500'
                  }`}
                >
                  {msg.time}
                </p>
              </div>
            </div>
          ))}
        </div>

        <form
          onSubmit={handleSendReply}
          className="flex items-center gap-2 border-t border-white/10 bg-[#0F0F0F] px-3 py-2.5"
        >
          <input
            type="text"
            value={draftReply}
            onChange={(e) => handleDraftChanged(e.target.value)}
            placeholder="Enviar mensaje..."
            className="h-10 flex-1 rounded-full border border-white/10 bg-[#18181B] px-4 text-sm text-white placeholder:text-zinc-500 focus:border-[#FF2D55] focus:outline-none"
          />
          <button
            type="submit"
            disabled={!draftReply.trim()}
            aria-label="Enviar mensaje"
            className="flex h-10 w-10 items-center justify-center rounded-full bg-[#FF2D55] text-white transition-opacity disabled:opacity-40"
          >
            <Send className="h-4 w-4" />
          </button>
        </form>
      </div>
    );
  }

  return (
    <div className="flex h-full w-full flex-col bg-[#0F0F0F] text-white">
      {/* Header centrado "Mensajes" */}
      <header className="sticky top-0 z-10 flex h-13 shrink-0 items-center justify-center border-b border-white/10 bg-[#0F0F0F]/95 px-4 backdrop-blur-md">
        <h1 className="text-[17px] font-bold tracking-tight text-white">
          Mensajes
        </h1>
      </header>

      {/* Lista scrolleable (Sección Sistema + Sección Mensajes entre usuarios) */}
      <div className="flex-1 min-h-0 overflow-y-auto divide-y divide-white/[0.04] no-scrollbar">
        {/* A. SECCIÓN DE SISTEMA */}
        <div className="py-1">
          <button
            type="button"
            onClick={() => setShowActivityScreen(true)}
            className="flex w-full items-center gap-3.5 px-4 py-3 text-left transition-colors hover:bg-white/[0.04] active:bg-white/[0.06]"
          >
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-[#FF2D55]/20 text-[#FF2D55]">
              <Zap className="h-5.5 w-5.5 fill-[#FF2D55]" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="truncate text-[14.5px] font-bold text-white">
                Actividad y nuevos seguidores
              </p>
              <p className="mt-0.5 truncate text-[13px] text-zinc-400">
                Tienes nuevas visitas en tu perfil
              </p>
            </div>
            <ChevronRight className="h-4 w-4 shrink-0 text-zinc-600" />
          </button>

          <button
            type="button"
            onClick={() => setShowSystemNotifications(true)}
            className="flex w-full items-center gap-3.5 px-4 py-3 text-left transition-colors hover:bg-white/[0.04] active:bg-white/[0.06]"
          >
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-cyan-500/15 text-[#25F4EE]">
              <Inbox className="h-5.5 w-5.5" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="truncate text-[14.5px] font-bold text-white">
                Notificación del sistema
              </p>
              <p className="mt-0.5 truncate text-[13px] text-zinc-400">
                Bienvenido a Viroklipz. ¡Sube tu primer video!
              </p>
            </div>
            <ChevronRight className="h-4 w-4 shrink-0 text-zinc-600" />
          </button>
        </div>

        {/* B. SECCIÓN DE MENSAJES ENTRE USUARIOS */}
        <div className="py-1">
          {chats.map((chat) => (
            <div
              key={chat.id}
              className="flex items-center gap-3.5 px-4 py-3 transition-colors hover:bg-white/[0.04]"
            >
              <button
                type="button"
                onClick={() => setActiveChatId(chat.id)}
                className="flex min-w-0 flex-1 items-center gap-3.5 text-left"
              >
                {!brokenAvatars[chat.id] ? (
                  <img
                    src={chat.avatarUrl}
                    alt={chat.name}
                    referrerPolicy="no-referrer"
                    onError={() =>
                      setBrokenAvatars((prev) => ({ ...prev, [chat.id]: true }))
                    }
                    className="h-12 w-12 shrink-0 rounded-full object-cover bg-zinc-800 border border-white/10"
                  />
                ) : (
                  <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-zinc-800 text-xs font-bold text-white border border-white/10">
                    {chat.initials}
                  </div>
                )}

                <div className="min-w-0 flex-1">
                  <p className="truncate text-[14.5px] font-bold text-white">
                    {chat.name}
                  </p>
                  <p className="mt-0.5 truncate text-[13px] text-zinc-400">
                    {chat.lastMessage}
                  </p>
                </div>
              </button>

              <div className="flex shrink-0 items-center gap-2.5">
                <span className="text-[11.5px] text-zinc-500 tabular-nums whitespace-nowrap">
                  {chat.time}
                </span>

                {chat.showCameraIcon && (
                  <button
                    type="button"
                    onClick={() =>
                      onOpenCamera
                        ? onOpenCamera()
                        : onNotify?.(`Responder con video a ${chat.name}`)
                    }
                    aria-label={`Enviar foto o video a ${chat.name}`}
                    className="flex h-8 w-8 items-center justify-center rounded-full text-zinc-400 transition-colors hover:bg-white/10 hover:text-white"
                  >
                    <Camera className="h-4.5 w-4.5" />
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
