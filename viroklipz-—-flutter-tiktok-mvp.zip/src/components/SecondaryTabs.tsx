import React from 'react';
import { MessagesInboxScreen } from './MessagesInboxScreen';
import { ProfileScreen } from './ProfileScreen';
import { UserAccount } from '../hooks/useAuthProvider';
import { VideoItem } from '../data/mockVideos';

export type BottomNavTab = 'inicio' | 'amigos' | 'mensajes' | 'perfil';

interface SecondaryTabProps {
  tab: Exclude<BottomNavTab, 'inicio' | 'amigos'>;
  currentUsername: string;
  currentEmail: string;
  savedAccounts?: UserAccount[];
  currentUser?: UserAccount | null;
  userVideos?: VideoItem[];
  likedVideos?: VideoItem[];
  onSelectVideo?: (videoId: string) => void;
  onSwitchAccount?: (account: UserAccount) => void;
  onAddAccount?: () => void;
  onDeleteAccount?: (account: UserAccount) => void;
  onUpdateUserProfile?: (updates: {
    avatarUrl?: string;
    displayName?: string;
    username?: string;
  }) => void;
  onBackToFeed: () => void;
  onSignOut: () => void;
  onOpenCamera?: () => void;
  onNotify?: (message: string) => void;
}

export const SecondaryTabView: React.FC<SecondaryTabProps> = ({
  tab,
  currentUsername,
  currentEmail,
  savedAccounts,
  currentUser,
  userVideos,
  likedVideos,
  onSelectVideo,
  onSwitchAccount,
  onAddAccount,
  onDeleteAccount,
  onUpdateUserProfile,
  onBackToFeed,
  onSignOut,
  onOpenCamera,
  onNotify,
}) => {
  if (tab === 'mensajes') {
    return (
      <MessagesInboxScreen
        onOpenCamera={onOpenCamera}
        onNotify={onNotify}
      />
    );
  }

  return (
    <ProfileScreen
      currentUsername={currentUsername}
      currentEmail={currentEmail}
      savedAccounts={savedAccounts}
      currentUser={currentUser}
      userVideos={userVideos}
      likedVideos={likedVideos}
      onSelectVideo={onSelectVideo}
      onSwitchAccount={onSwitchAccount}
      onAddAccount={onAddAccount}
      onDeleteAccount={onDeleteAccount}
      onUpdateUserProfile={onUpdateUserProfile}
      onBackToFeed={onBackToFeed}
      onSignOut={onSignOut}
      onOpenCamera={onOpenCamera}
      onNotify={onNotify}
    />
  );
};
