import React, { useState } from 'react';
import {
  ArrowLeft,
  Atom,
  ChevronRight,
  Filter,
  RefreshCw,
  ShieldAlert,
  SlidersHorizontal,
  VolumeX,
  X,
} from 'lucide-react';

interface ContentPreferencesScreenProps {
  onBack: () => void;
  onNotify?: (message: string) => void;
}

type PreferenceSheetType = 'restricted' | 'stem' | null;

interface PreferenceOptionRowProps {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  subtitle?: string;
  trailingText?: string;
  isActive?: boolean;
  onTap: () => void;
}

const PreferenceOptionRow: React.FC<PreferenceOptionRowProps> = ({
  icon: Icon,
  title,
  subtitle,
  trailingText,
  isActive = false,
  onTap,
}) => (
  <button
    type="button"
    onClick={onTap}
    className="flex w-full items-center justify-between px-4 py-3.5 text-left transition-colors hover:bg-white/5 active:bg-white/10"
  >
    <div className="flex min-w-0 items-center gap-3.5 pr-3">
      <Icon className="h-[19px] w-[19px] shrink-0 text-zinc-200" />
      <div className="min-w-0">
        <p className="truncate text-[14px] font-medium text-zinc-100">
          {title}
        </p>
        {subtitle && (
          <p className="mt-0.5 truncate text-[11px] text-zinc-400">
            {subtitle}
          </p>
        )}
      </div>
    </div>

    <div className="flex shrink-0 items-center gap-2">
      {trailingText !== undefined && (
        <span
          className={`text-xs font-medium transition-colors ${
            isActive ? 'text-[#FE2C55]' : 'text-zinc-400'
          }`}
        >
          {trailingText}
        </span>
      )}
      <ChevronRight className="h-4 w-4 text-zinc-500" />
    </div>
  </button>
);

export const ContentPreferencesScreen: React.FC<ContentPreferencesScreenProps> = ({
  onBack,
  onNotify,
}) => {
  const [restrictedMode, setRestrictedMode] = useState(false);
  const [stemFeed, setStemFeed] = useState(false);

  const [activeSheet, setActiveSheet] = useState<PreferenceSheetType>(null);
  const [draftToggle, setDraftToggle] = useState(false);

  const openModeSheet = (type: Exclude<PreferenceSheetType, null>) => {
    setDraftToggle(type === 'restricted' ? restrictedMode : stemFeed);
    setActiveSheet(type);
  };

  const handleSaveSheet = () => {
    if (activeSheet === 'restricted') {
      setRestrictedMode(draftToggle);
      onNotify?.(
        draftToggle ? 'Modo Restringido activado' : 'Modo Restringido desactivado'
      );
    } else if (activeSheet === 'stem') {
      setStemFeed(draftToggle);
      onNotify?.(draftToggle ? 'Feed STEM activado' : 'Feed STEM desactivado');
    }
    setActiveSheet(null);
  };

  return (
    <div className="relative flex h-full w-full flex-col bg-[#121212] text-white select-none overflow-hidden">
      {/* AppBar: Flecha Atrás y Título centrado */}
      <header className="relative flex h-12 shrink-0 items-center justify-center border-b border-white/10 bg-[#121212] px-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Atrás"
          className="absolute left-2 flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="text-[15px] font-bold text-white">
          Preferencias de contenido
        </h1>
      </header>

      {/* ListView con contenedores redondeados */}
      <div className="flex-1 min-h-0 overflow-y-auto px-4 py-5 space-y-4 no-scrollbar">
        {/* Grupo 1: Filtros y modos */}
        <div className="divide-y divide-white/5 overflow-hidden rounded-xl bg-[#1E1E1E]">
          <PreferenceOptionRow
            icon={Filter}
            title="Filtrar por palabras clave"
            trailingText="0"
            onTap={() => onNotify?.('Filtrar por palabras clave (0)')}
          />
          <PreferenceOptionRow
            icon={ShieldAlert}
            title="Modo Restringido"
            trailingText={restrictedMode ? 'Activada' : 'Desactivada'}
            isActive={restrictedMode}
            onTap={() => openModeSheet('restricted')}
          />
          <PreferenceOptionRow
            icon={Atom}
            title="Feed STEM"
            trailingText={stemFeed ? 'Activada' : 'Desactivada'}
            isActive={stemFeed}
            onTap={() => openModeSheet('stem')}
          />
        </div>

        {/* Grupo 2: Personalización del feed */}
        <div className="divide-y divide-white/5 overflow-hidden rounded-xl bg-[#1E1E1E]">
          <PreferenceOptionRow
            icon={SlidersHorizontal}
            title="Gestionar temas"
            subtitle="Ajusta cuánto contenido ves de cada categoría"
            onTap={() => onNotify?.('Gestionar temas')}
          />
          <PreferenceOptionRow
            icon={RefreshCw}
            title="Actualiza tu feed Para ti"
            subtitle="Restablece tus recomendaciones iniciales"
            onTap={() => onNotify?.('Actualiza tu feed Para ti')}
          />
        </div>

        {/* Grupo 3: Cuentas silenciadas */}
        <div className="divide-y divide-white/5 overflow-hidden rounded-xl bg-[#1E1E1E]">
          <PreferenceOptionRow
            icon={VolumeX}
            title="Cuentas silenciadas"
            onTap={() => onNotify?.('Cuentas silenciadas')}
          />
        </div>
      </div>

      {/* Bottom Sheet con Switch y Guardar para Modo Restringido / Feed STEM */}
      {activeSheet && (
        <div
          className="absolute inset-0 z-50 flex items-end bg-black/60 backdrop-blur-[1px]"
          onClick={() => setActiveSheet(null)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full rounded-t-[20px] bg-[#1E1E1E] px-5 pt-3 pb-7 text-white shadow-2xl"
          >
            <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-zinc-600" />

            <div className="relative mb-3 flex items-center justify-center py-1">
              <h2 className="text-[16px] font-bold text-white">
                {activeSheet === 'restricted'
                  ? 'Modo Restringido'
                  : 'Feed STEM'}
              </h2>
              <button
                type="button"
                onClick={() => setActiveSheet(null)}
                aria-label="Cerrar"
                className="absolute right-0 flex h-8 w-8 items-center justify-center rounded-full text-zinc-300 transition-colors hover:bg-white/10"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <p className="mb-5 text-center text-xs leading-relaxed text-zinc-400">
              {activeSheet === 'restricted'
                ? 'Limita la aparición de videos que pueden no ser apropiados para todos los públicos.'
                : 'Agrega una pestaña dedicada a contenido educativo de Ciencia, Tecnología, Ingeniería y Matemáticas.'}
            </p>

            {/* Fila con Switch */}
            <div className="mb-5 flex items-center justify-between rounded-xl bg-[#27272A] px-4 py-3.5">
              <div>
                <p className="text-sm font-semibold text-white">
                  {activeSheet === 'restricted'
                    ? 'Activar Modo Restringido'
                    : 'Mostrar Feed STEM'}
                </p>
                <p
                  className={`text-xs ${
                    draftToggle ? 'text-[#FE2C55]' : 'text-zinc-400'
                  }`}
                >
                  {draftToggle ? 'Activada' : 'Desactivada'}
                </p>
              </div>

              <button
                type="button"
                role="switch"
                aria-checked={draftToggle}
                onClick={() => setDraftToggle((prev) => !prev)}
                className={`relative inline-flex h-7 w-12 shrink-0 items-center rounded-full transition-colors ${
                  draftToggle ? 'bg-[#FE2C55]' : 'bg-zinc-600'
                }`}
              >
                <span
                  className={`inline-block h-5 w-5 transform rounded-full bg-white shadow transition-transform ${
                    draftToggle ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            <button
              type="button"
              onClick={handleSaveSheet}
              className="w-full rounded-xl bg-[#FE2C55] py-3 text-sm font-bold text-white transition-opacity hover:opacity-95 active:opacity-85"
            >
              Guardar
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
