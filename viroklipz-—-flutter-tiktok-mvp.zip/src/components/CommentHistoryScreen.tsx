import React, { useState } from 'react';
import { ArrowLeft, ChevronDown, X } from 'lucide-react';

type SortOrderOption =
  | 'De más recientes a más antiguos'
  | 'De más antiguos a más recientes';

interface CommentHistoryItem {
  id: string;
  authorName: string;
  avatarUrl: string;
  commentText: string;
  dateLabel: string;
  videoThumbUrl: string;
}

const INITIAL_COMMENTS: CommentHistoryItem[] = [
  {
    id: 'ch-1',
    authorName: 'Eloy',
    avatarUrl: '/src/assets/images/avatar_creator_mateo_1794604321715.jpg',
    commentText: '[Sticker]',
    dateLabel: '13 nov',
    videoThumbUrl: '/src/assets/images/story_hinduismo_temple_1794607243976.jpg',
  },
  {
    id: 'ch-2',
    authorName: 'Eloy',
    avatarUrl: '/src/assets/images/avatar_creator_mateo_1794604321715.jpg',
    commentText: '¡Qué transición tan brutal! 🔥',
    dateLabel: '11 nov',
    videoThumbUrl: '/src/assets/images/avatar_creator_valeria_1794604321625.jpg',
  },
  {
    id: 'ch-3',
    authorName: 'Eloy',
    avatarUrl: '/src/assets/images/avatar_creator_mateo_1794604321715.jpg',
    commentText: '¿Cómo se llama este audio?',
    dateLabel: '8 nov',
    videoThumbUrl: '/src/assets/images/avatar_creator_lucas_1794604322245.jpg',
  },
  {
    id: 'ch-4',
    authorName: 'Eloy',
    avatarUrl: '/src/assets/images/avatar_creator_mateo_1794604321715.jpg',
    commentText: 'Guardado para grabarlo el finde 🙌',
    dateLabel: '4 nov',
    videoThumbUrl: '/src/assets/images/avatar_creator_sofia_1794604322145.jpg',
  },
  {
    id: 'ch-5',
    authorName: 'Eloy',
    avatarUrl: '/src/assets/images/avatar_creator_mateo_1794604321715.jpg',
    commentText: 'Me encantó la iluminación 35mm 📸',
    dateLabel: '29 oct',
    videoThumbUrl: '/src/assets/images/avatar_creator_diego_1794604323122.jpg',
  },
];

const SORT_OPTIONS: SortOrderOption[] = [
  'De más recientes a más antiguos',
  'De más antiguos a más recientes',
];

interface CommentHistoryScreenProps {
  onBack: () => void;
  onNotify?: (message: string) => void;
}

export const CommentHistoryScreen: React.FC<CommentHistoryScreenProps> = ({
  onBack,
  onNotify,
}) => {
  const [sortOrder, setSortOrder] = useState<SortOrderOption>(
    'De más recientes a más antiguos'
  );
  const [isSortSheetOpen, setIsSortSheetOpen] = useState(false);

  const displayedComments =
    sortOrder === 'De más recientes a más antiguos'
      ? INITIAL_COMMENTS
      : [...INITIAL_COMMENTS].reverse();

  return (
    <div className="relative flex h-full w-full flex-col bg-[#121212] text-white select-none overflow-hidden">
      {/* AppBar: Atrás a la izquierda, Título centrado */}
      <header className="flex h-12 shrink-0 items-center justify-between border-b border-white/10 px-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Volver al centro de actividades"
          className="flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>

        <h1 className="text-[15px] font-bold text-white">
          Historial de comentarios
        </h1>

        <div className="w-10" />
      </header>

      {/* Chip / píldora de ordenamiento */}
      <div className="shrink-0 px-4 pt-3 pb-2">
        <button
          type="button"
          onClick={() => setIsSortSheetOpen(true)}
          className="inline-flex items-center gap-1.5 rounded-full border border-white/15 bg-[#1E1E22] px-3.5 py-1.5 text-xs font-medium text-zinc-100 transition-colors hover:bg-[#27272C]"
        >
          <span>{sortOrder}</span>
          <ChevronDown className="h-3.5 w-3.5 text-zinc-400" />
        </button>
      </div>

      {/* Lista de comentarios (ListView.builder) */}
      <div className="flex-1 min-h-0 overflow-y-auto px-4 pb-6 no-scrollbar">
        <div className="divide-y divide-white/5">
          {displayedComments.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() =>
                onNotify?.(`Abriendo video comentado (${item.dateLabel})`)
              }
              className="flex w-full items-center gap-3 py-3 text-left transition-colors hover:bg-white/[0.03]"
            >
              {/* Avatar circular a la izquierda */}
              <img
                src={item.avatarUrl}
                alt={item.authorName}
                className="h-10 w-10 shrink-0 rounded-full object-cover ring-1 ring-white/15"
              />

              {/* Column central: nombre en gris, comentario en blanco + fecha en gris claro */}
              <div className="min-w-0 flex-1">
                <p className="text-xs font-medium text-zinc-400">
                  {item.authorName}
                </p>
                <div className="mt-0.5 flex items-baseline gap-2">
                  <span className="truncate text-sm font-normal text-white">
                    {item.commentText}
                  </span>
                  <span className="shrink-0 text-xs text-zinc-400">
                    {item.dateLabel}
                  </span>
                </div>
              </div>

              {/* Miniatura cuadrada redondeada del video a la derecha */}
              <img
                src={item.videoThumbUrl}
                alt={`Video comentado ${item.id}`}
                className="h-12 w-12 shrink-0 rounded-lg bg-zinc-800 object-cover"
              />
            </button>
          ))}
        </div>
      </div>

      {/* Bottom Sheet de ordenamiento */}
      {isSortSheetOpen && (
        <div
          className="absolute inset-0 z-30 flex items-end bg-black/60 backdrop-blur-[1px]"
          onClick={() => setIsSortSheetOpen(false)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full rounded-t-2xl bg-[#1C1C1E] pb-6 pt-3 text-white shadow-2xl"
          >
            {/* Fila superior: Título "Ordenar por" centrado + "X" a la derecha */}
            <div className="relative flex items-center justify-center border-b border-white/10 px-4 pb-3">
              <span className="text-sm font-bold text-white">Ordenar por</span>
              <button
                type="button"
                onClick={() => setIsSortSheetOpen(false)}
                aria-label="Cerrar ordenamiento"
                className="absolute right-3 top-0 flex h-8 w-8 items-center justify-center rounded-full text-zinc-300 hover:bg-white/10"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Opciones RadioListTile */}
            <div className="divide-y divide-white/5 px-2 pt-1">
              {SORT_OPTIONS.map((option) => {
                const isSelected = sortOrder === option;
                return (
                  <button
                    key={option}
                    type="button"
                    onClick={() => {
                      setSortOrder(option);
                      setIsSortSheetOpen(false);
                      onNotify?.(`Orden: ${option}`);
                    }}
                    className="flex w-full items-center gap-3 px-3 py-3.5 text-left transition-colors hover:bg-white/5"
                  >
                    <span
                      className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-full border-2 transition-colors ${
                        isSelected ? 'border-[#FF2D55]' : 'border-zinc-500'
                      }`}
                    >
                      {isSelected && (
                        <span className="h-2.5 w-2.5 rounded-full bg-[#FF2D55]" />
                      )}
                    </span>
                    <span className="text-sm font-medium text-white">
                      {option}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
