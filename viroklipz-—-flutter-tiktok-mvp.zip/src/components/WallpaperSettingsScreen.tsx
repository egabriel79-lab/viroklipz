import React, { useState } from 'react';
import { ArrowLeft, Settings } from 'lucide-react';
import { HowToWallpaperBottomSheet } from './HowToWallpaperBottomSheet';
import { SearchWallpaperScreen } from './SearchWallpaperScreen';

interface WallpaperSettingsScreenProps {
  onBack: () => void;
  onNotify?: (message: string) => void;
}

export const WallpaperSettingsScreen: React.FC<
  WallpaperSettingsScreenProps
> = ({ onBack, onNotify }) => {
  const [showSearch, setShowSearch] = useState(false);
  const [showHowToSheet, setShowHowToSheet] = useState(false);

  if (showSearch) {
    return (
      <SearchWallpaperScreen
        onBack={() => setShowSearch(false)}
        onNotify={onNotify}
      />
    );
  }

  return (
    <div className="relative flex h-full w-full flex-col bg-[#121212] text-white select-none overflow-hidden">
      {/* AppBar: Fondo de pantalla + ícono de ajustes a la derecha */}
      <header className="relative flex h-12 shrink-0 items-center justify-center border-b border-white/10 bg-[#121212] px-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Atrás"
          className="absolute left-2 flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="text-[15px] font-bold text-white">Fondo de pantalla</h1>
        <button
          type="button"
          onClick={() => onNotify?.('Ajustes de fondo de pantalla')}
          aria-label="Ajustes de fondo de pantalla"
          className="absolute right-2 flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <Settings className="h-5 w-5" />
        </button>
      </header>

      {/* Estado vacío centrado */}
      <div className="flex flex-1 flex-col items-center justify-center px-8 text-center">
        <div className="flex h-20 w-20 items-center justify-center rounded-full border-2 border-dashed border-zinc-600 bg-[#1E1E1E]">
          <Settings className="h-9 w-9 text-zinc-400" strokeDasharray="3 2" />
        </div>
        <h2 className="mt-5 text-base font-bold text-white">
          Aún no hay fondos de pantalla
        </h2>
        <p className="mt-2 text-xs leading-relaxed text-zinc-400">
          Tus fondos de pantalla descargados se mostrarán aquí
        </p>
      </div>

      {/* Botones al final */}
      <div className="shrink-0 space-y-2.5 px-4 pb-6 pt-2">
        <button
          type="button"
          onClick={() => setShowSearch(true)}
          className="w-full rounded-xl bg-[#E91E63] py-3 text-sm font-bold text-white transition-opacity hover:opacity-90 active:opacity-80"
        >
          Buscar fondos de pantalla
        </button>
        <button
          type="button"
          onClick={() => setShowHowToSheet(true)}
          className="w-full rounded-xl bg-[#27272A] py-3 text-xs font-semibold text-zinc-200 transition-colors hover:bg-[#323236]"
        >
          Descubre cómo establecer un fondo de pantalla
        </button>
      </div>

      <HowToWallpaperBottomSheet
        open={showHowToSheet}
        onClose={() => setShowHowToSheet(false)}
      />
    </div>
  );
};
