import React, { useState } from 'react';
import { ArrowLeft } from 'lucide-react';

interface DownloadsSettingsScreenProps {
  initialEnabled?: boolean;
  onBack: () => void;
  onToggleEnabled?: (enabled: boolean) => void;
  onNotify?: (message: string) => void;
}

export const DownloadsSettingsScreen: React.FC<DownloadsSettingsScreenProps> = ({
  initialEnabled = true,
  onBack,
  onToggleEnabled,
  onNotify,
}) => {
  const [downloadsEnabled, setDownloadsEnabled] = useState(initialEnabled);

  const handleToggle = () => {
    const next = !downloadsEnabled;
    setDownloadsEnabled(next);
    onToggleEnabled?.(next);
    onNotify?.(`Descargas de videos ${next ? 'activadas' : 'desactivadas'}`);
  };

  return (
    <div className="flex h-full w-full flex-col bg-[#121212] text-white select-none overflow-hidden">
      <header className="relative flex h-12 shrink-0 items-center justify-center border-b border-white/10 bg-[#121212] px-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Atrás"
          className="absolute left-2 flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="text-[15px] font-bold text-white">Descargas</h1>
      </header>

      <div className="flex-1 min-h-0 overflow-y-auto px-4 py-4 no-scrollbar">
        <div className="overflow-hidden rounded-xl bg-[#1E1E1E]">
          <div className="flex items-start justify-between gap-4 px-4 py-4">
            <div className="min-w-0 flex-1">
              <p className="text-[14px] font-medium text-white">Descargas de videos</p>
              <p className="mt-1.5 text-xs leading-relaxed text-zinc-400">
                Permite que otras personas descarguen tus videos y los compartan en otras plataformas. Si desactivas esta opción, nadie podrá descargar tus publicaciones futuras, aunque se mantendrán los enlaces ya compartidos.
              </p>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={downloadsEnabled}
              onClick={handleToggle}
              className={`relative mt-0.5 inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors ${
                downloadsEnabled ? 'bg-[#FF5722]' : 'bg-zinc-600'
              }`}
            >
              <span
                className={`inline-block h-5 w-5 transform rounded-full bg-white shadow transition-transform ${
                  downloadsEnabled ? 'translate-x-5' : 'translate-x-0.5'
                }`}
              />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
