import React, { useRef, useState } from 'react';
import {
  ArrowLeft,
  Camera,
  Check,
  ChevronRight,
  Copy,
  Image as ImageIcon,
  ImagePlus,
  Loader2,
  Sparkles,
  Trash2,
} from 'lucide-react';
import { EditDescriptionScreen } from './EditDescriptionScreen';
import { MediaPickerScreen } from './MediaPickerScreen';

export interface EditProfileData {
  nombreUsuario: string;
  arroba: string;
  bio: string;
  pronoun: string;
  avatarUrl: string;
  backgroundUrl: string;
}

interface EditProfileScreenProps {
  profile: EditProfileData;
  onAvatarUpdated?: (newAvatarUrl: string) => void;
  onBack: (updated: EditProfileData) => void;
  onOpenCamera?: () => void;
  onNotify?: (message: string) => void;
}

const PRONOUN_OPTIONS = [
  'Él / Lo',
  'Ella / La',
  'Elle / Le',
  'Prefiero no especificar',
];

export const EditProfileScreen: React.FC<EditProfileScreenProps> = ({
  profile,
  onAvatarUpdated,
  onBack,
  onOpenCamera,
  onNotify,
}) => {
  const [draft, setDraft] = useState<EditProfileData>(profile);
  const [isUploadingAvatar, setIsUploadingAvatar] = useState(false);
  const [mediaSheetTarget, setMediaSheetTarget] = useState<
    null | 'avatar' | 'background'
  >(null);
  const [mediaPickerTarget, setMediaPickerTarget] = useState<
    null | 'avatar' | 'background'
  >(null);
  const [isEditingBio, setIsEditingBio] = useState(false);
  const [editingField, setEditingField] = useState<
    null | 'nombre' | 'username' | 'pronoun'
  >(null);
  const [fieldValue, setFieldValue] = useState('');
  const [copiedUrl, setCopiedUrl] = useState(false);

  const avatarInputRef = useRef<HTMLInputElement>(null);
  const avatarCameraInputRef = useRef<HTMLInputElement>(null);
  const bgInputRef = useRef<HTMLInputElement>(null);

  const applyAvatarUpload = (nextUrl: string) => {
    setMediaSheetTarget(null);
    setIsUploadingAvatar(true);
    window.setTimeout(() => {
      setDraft((prev) => ({ ...prev, avatarUrl: nextUrl }));
      setIsUploadingAvatar(false);
      onAvatarUpdated?.(nextUrl);
      onNotify?.('Foto de perfil actualizada');
    }, 650);
  };

  const cleanUsername = draft.arroba.replace(/^@/, '');
  const profileUrl = `viroklipz.app/@${cleanUsername}`;

  if (mediaPickerTarget) {
    return (
      <MediaPickerScreen
        onClose={() => setMediaPickerTarget(null)}
        onSelectMedia={(url) => {
          if (mediaPickerTarget === 'avatar') {
            setMediaPickerTarget(null);
            applyAvatarUpload(url);
          } else {
            setDraft((prev) => ({ ...prev, backgroundUrl: url }));
            setMediaPickerTarget(null);
            onNotify?.('Fondo seleccionado de tus publicaciones');
          }
        }}
      />
    );
  }

  if (isEditingBio) {
    return (
      <EditDescriptionScreen
        initialDescription={draft.bio}
        onCancel={() => setIsEditingBio(false)}
        onSave={(newBio) => {
          setDraft((prev) => ({ ...prev, bio: newBio }));
          setIsEditingBio(false);
          onNotify?.('Descripción actualizada');
        }}
      />
    );
  }

  const handleCopyProfileUrl = async () => {
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(`https://${profileUrl}`);
      }
    } catch {
      // Fallback silencioso
    }
    setCopiedUrl(true);
    onNotify?.('URL del perfil copiada');
    window.setTimeout(() => setCopiedUrl(false), 1800);
  };

  const handlePickAvatarFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const objectUrl = URL.createObjectURL(file);
    applyAvatarUpload(objectUrl);
    e.target.value = '';
  };

  const handlePickBackgroundFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const objectUrl = URL.createObjectURL(file);
    setDraft((prev) => ({ ...prev, backgroundUrl: objectUrl }));
    setMediaSheetTarget(null);
    onNotify?.('Foto de fondo cargada');
    e.target.value = '';
  };

  const handleRemoveBackground = () => {
    setDraft((prev) => ({ ...prev, backgroundUrl: '' }));
    onNotify?.('Fondo de perfil eliminado');
  };

  const openFieldModal = (field: 'nombre' | 'username' | 'pronoun') => {
    if (field === 'nombre') setFieldValue(draft.nombreUsuario);
    if (field === 'username') setFieldValue(cleanUsername);
    if (field === 'pronoun') setFieldValue(draft.pronoun);
    setEditingField(field);
  };

  const saveFieldModal = () => {
    const trimmed = fieldValue.trim();
    if (editingField === 'nombre' && trimmed) {
      setDraft((prev) => ({ ...prev, nombreUsuario: trimmed }));
      onNotify?.('Nombre actualizado');
    } else if (editingField === 'username' && trimmed) {
      const sanitized = trimmed.replace(/^@/, '').replace(/\s+/g, '_');
      setDraft((prev) => ({ ...prev, arroba: `@${sanitized}` }));
      onNotify?.('Nombre de usuario actualizado');
    }
    setEditingField(null);
  };

  return (
    <div className="relative flex h-full w-full flex-col bg-[#121212] text-white select-none overflow-hidden">
      {/* Inputs reales ocultos para galería y cámara (simulan image_picker) */}
      <input
        ref={avatarInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handlePickAvatarFile}
      />
      <input
        ref={avatarCameraInputRef}
        type="file"
        accept="image/*"
        capture="user"
        className="hidden"
        onChange={handlePickAvatarFile}
      />
      <input
        ref={bgInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handlePickBackgroundFile}
      />

      {/* AppBar: Atrás a la izquierda + título "Editar perfil" + "Agregar fondo" a la derecha */}
      <header className="flex h-12 shrink-0 items-center justify-between border-b border-white/10 bg-[#121212] px-2">
        <button
          type="button"
          onClick={() => onBack(draft)}
          aria-label="Volver al perfil"
          className="flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>

        <h1 className="text-[15px] font-bold text-white">Editar perfil</h1>

        <button
          type="button"
          onClick={() => setMediaSheetTarget('background')}
          className="rounded-lg px-2.5 py-1.5 text-xs font-semibold text-zinc-200 transition-colors hover:bg-white/10"
        >
          Agregar fondo
        </button>
      </header>

      {/* Cuerpo scrollable */}
      <div className="flex-1 min-h-0 overflow-y-auto pb-8 no-scrollbar">
        {/* Banner superior del fondo de perfil con botones Cambiar y Eliminar fondo */}
        {draft.backgroundUrl && (
          <div className="relative mx-4 mt-3 h-24 overflow-hidden rounded-2xl border border-white/15 bg-[#1E1E1E]">
            <img
              src={draft.backgroundUrl}
              alt="Fondo de perfil seleccionado"
              className="h-full w-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/25 to-transparent" />
            <span className="absolute bottom-2.5 left-3 text-[11px] font-semibold text-white">
              Fondo seleccionado
            </span>
            <div className="absolute bottom-2 right-2 flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => setMediaSheetTarget('background')}
                className="rounded-full bg-black/65 px-2.5 py-1 text-[10px] font-semibold text-white backdrop-blur-sm transition-colors hover:bg-black/80"
              >
                Cambiar
              </button>
              <button
                type="button"
                onClick={handleRemoveBackground}
                className="inline-flex items-center gap-1 rounded-full bg-black/65 px-2.5 py-1 text-[10px] font-semibold text-rose-400 backdrop-blur-sm transition-colors hover:bg-rose-950/90"
              >
                <Trash2 className="h-3 w-3" />
                Eliminar fondo
              </button>
            </div>
          </div>
        )}

        {/* Avatar circular grande + cámara superpuesta + "Cambiar foto" */}
        <div className="flex flex-col items-center py-6">
          <button
            type="button"
            disabled={isUploadingAvatar}
            onClick={() => setMediaSheetTarget('avatar')}
            aria-label="Cambiar foto de perfil"
            className="group relative h-24 w-24 overflow-hidden rounded-full border border-white/15 bg-[#1E1E1E] shadow-md disabled:cursor-wait"
          >
            <img
              src={draft.avatarUrl}
              alt={draft.nombreUsuario}
              className="h-full w-full object-cover"
            />
            <span className="absolute inset-0 flex items-center justify-center bg-black/45 transition-colors group-hover:bg-black/55">
              {isUploadingAvatar ? (
                <Loader2 className="h-7 w-7 animate-spin text-[#E91E63]" />
              ) : (
                <Camera className="h-6 w-6 text-white" />
              )}
            </span>
          </button>

          <button
            type="button"
            disabled={isUploadingAvatar}
            onClick={() => setMediaSheetTarget('avatar')}
            className="mt-2.5 text-xs font-semibold text-[#E91E63] transition-colors hover:text-pink-400 disabled:opacity-50"
          >
            {isUploadingAvatar ? 'Subiendo foto...' : 'Cambiar foto'}
          </button>
        </div>

        {/* Lista de opciones principales (ListTile) */}
        <div className="divide-y divide-white/5 border-t border-white/10 bg-[#121212]">
          <button
            type="button"
            onClick={() => openFieldModal('nombre')}
            className="flex w-full items-center justify-between px-4 py-3.5 text-left transition-colors hover:bg-white/5"
          >
            <span className="text-sm font-medium text-white">Nombre</span>
            <span className="flex items-center gap-1.5 text-sm text-zinc-400">
              <span className="max-w-[150px] truncate">{draft.nombreUsuario}</span>
              <ChevronRight className="h-4 w-4 text-zinc-500" />
            </span>
          </button>

          <button
            type="button"
            onClick={() => openFieldModal('username')}
            className="flex w-full items-center justify-between px-4 py-3.5 text-left transition-colors hover:bg-white/5"
          >
            <span className="text-sm font-medium text-white">
              Nombre de usuario
            </span>
            <span className="flex items-center gap-1.5 text-sm text-zinc-400">
              <span className="max-w-[140px] truncate">{cleanUsername}</span>
              <ChevronRight className="h-4 w-4 text-zinc-500" />
            </span>
          </button>

          <button
            type="button"
            onClick={handleCopyProfileUrl}
            className="flex w-full items-center justify-between px-4 py-3.5 text-left transition-colors hover:bg-white/5"
          >
            <span className="text-sm font-medium text-white">
              URL del perfil
            </span>
            <span className="flex items-center gap-2 text-xs text-zinc-400">
              <span className="max-w-[155px] truncate">{profileUrl}</span>
              {copiedUrl ? (
                <Check className="h-4 w-4 shrink-0 text-emerald-400" />
              ) : (
                <Copy className="h-4 w-4 shrink-0 text-zinc-500" />
              )}
            </span>
          </button>
        </div>

        {/* Sección: Información básica */}
        <div className="mt-2 border-t border-white/10 pt-3">
          <p className="px-4 pb-1 text-xs font-semibold text-zinc-400">
            Información básica
          </p>

          <button
            type="button"
            onClick={() => setIsEditingBio(true)}
            className="flex w-full items-center justify-between px-4 py-3.5 text-left transition-colors hover:bg-white/5"
          >
            <span className="text-sm font-medium text-white">Descripción</span>
            <span className="flex items-center gap-1.5 text-sm text-zinc-400">
              <span className="max-w-[150px] truncate">
                {draft.bio || 'Agregar una descripción'}
              </span>
              <ChevronRight className="h-4 w-4 text-zinc-500" />
            </span>
          </button>

          <button
            type="button"
            onClick={() => openFieldModal('pronoun')}
            className="flex w-full items-center justify-between px-4 py-3.5 text-left transition-colors hover:bg-white/5"
          >
            <span className="text-sm font-medium text-white">Pronombre</span>
            <span className="flex items-center gap-1.5 text-sm text-zinc-400">
              <span className="max-w-[150px] truncate">
                {draft.pronoun || 'Agregar pronombres'}
              </span>
              <ChevronRight className="h-4 w-4 text-zinc-500" />
            </span>
          </button>
        </div>

        {/* Sección: Otros */}
        <div className="mt-2 border-t border-white/10 pt-3">
          <p className="px-4 pb-1 text-xs font-semibold text-zinc-400">Otros</p>

          <button
            type="button"
            onClick={() => onNotify?.('AI Self disponible próximamente')}
            className="flex w-full items-center justify-between px-4 py-3.5 text-left transition-colors hover:bg-white/5"
          >
            <span className="flex items-center gap-2 text-sm font-medium text-white">
              <Sparkles className="h-4 w-4 text-pink-500" />
              AI Self
            </span>
            <span className="flex items-center gap-1.5 text-sm text-zinc-400">
              <span>Configurar</span>
              <ChevronRight className="h-4 w-4 text-zinc-500" />
            </span>
          </button>
        </div>
      </div>

      {/* Bottom Sheet oscuro para foto de perfil / fondo */}
      {mediaSheetTarget && (
        <div
          className="absolute inset-0 z-30 flex items-end bg-black/65 backdrop-blur-[1px]"
          onClick={() => setMediaSheetTarget(null)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full rounded-t-2xl border-t border-white/10 bg-[#1E1E1E] pb-5 pt-2 text-white shadow-2xl"
          >
            <div className="mx-auto mb-2 h-1 w-9 rounded-full bg-zinc-600" />

            {/* Nueva opción arriba de todo: Tomar foto o video */}
            <button
              type="button"
              onClick={() => {
                if (mediaSheetTarget === 'avatar') {
                  avatarCameraInputRef.current?.click();
                } else {
                  setMediaSheetTarget(null);
                  if (onOpenCamera) {
                    onOpenCamera();
                  } else {
                    onNotify?.('Abriendo cámara de Viroklipz...');
                  }
                }
              }}
              className="flex w-full items-center justify-center gap-2 border-b border-white/10 py-3.5 text-center text-[15px] font-semibold text-white transition-colors hover:bg-white/5"
            >
              <Camera className="h-4 w-4 text-[#E91E63]" />
              <span>Tomar foto o video</span>
            </button>

            <button
              type="button"
              onClick={() => {
                if (mediaSheetTarget === 'avatar') {
                  avatarInputRef.current?.click();
                } else {
                  bgInputRef.current?.click();
                }
              }}
              className="flex w-full items-center justify-center gap-2 border-b border-white/10 py-3.5 text-center text-[15px] font-semibold text-white transition-colors hover:bg-white/5"
            >
              <ImagePlus className="h-4 w-4 text-zinc-300" />
              <span>Cargar foto</span>
            </button>

            <button
              type="button"
              onClick={() => {
                const target = mediaSheetTarget;
                setMediaSheetTarget(null);
                setMediaPickerTarget(target);
              }}
              className="flex w-full items-center justify-center gap-2 border-b border-white/10 py-3.5 text-center text-[15px] font-semibold text-white transition-colors hover:bg-white/5"
            >
              <ImageIcon className="h-4 w-4 text-zinc-300" />
              <span>Elegir de tus publicaciones</span>
            </button>

            <div className="h-2 bg-[#121212]" />

            <button
              type="button"
              onClick={() => setMediaSheetTarget(null)}
              className="w-full py-3.5 text-center text-[15px] font-medium text-zinc-400 transition-colors hover:bg-white/5"
            >
              Cancelar
            </button>
          </div>
        </div>
      )}

      {/* Modal rápido oscuro para editar Nombre, Nombre de usuario o Pronombre */}
      {editingField && (
        <div
          className="absolute inset-0 z-30 flex items-center justify-center bg-black/70 p-4"
          onClick={() => setEditingField(null)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-[290px] rounded-2xl border border-white/10 bg-[#1E1E1E] p-4 text-white shadow-2xl"
          >
            <h2 className="text-sm font-bold text-white">
              {editingField === 'nombre'
                ? 'Editar nombre'
                : editingField === 'username'
                ? 'Editar nombre de usuario'
                : 'Seleccionar pronombre'}
            </h2>

            {editingField === 'pronoun' ? (
              <div className="mt-3 space-y-1.5">
                {PRONOUN_OPTIONS.map((opt) => (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => {
                      setDraft((prev) => ({ ...prev, pronoun: opt }));
                      setEditingField(null);
                      onNotify?.('Pronombre actualizado');
                    }}
                    className={`flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-left text-xs font-semibold transition-colors ${
                      draft.pronoun === opt
                        ? 'bg-[#E91E63]/20 text-pink-400'
                        : 'bg-[#27272A] text-zinc-200 hover:bg-zinc-700'
                    }`}
                  >
                    <span>{opt}</span>
                    {draft.pronoun === opt && <Check className="h-4 w-4" />}
                  </button>
                ))}
              </div>
            ) : (
              <>
                <input
                  type="text"
                  value={fieldValue}
                  onChange={(e) => setFieldValue(e.target.value)}
                  maxLength={30}
                  autoFocus
                  className="mt-3 w-full rounded-xl border border-white/10 bg-[#121212] px-3 py-2 text-sm text-white focus:border-[#E91E63] focus:outline-none"
                />
                <div className="mt-4 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setEditingField(null)}
                    className="rounded-xl px-3 py-1.5 text-xs font-semibold text-zinc-400 hover:bg-white/10"
                  >
                    Cancelar
                  </button>
                  <button
                    type="button"
                    onClick={saveFieldModal}
                    className="rounded-xl bg-[#E91E63] px-4 py-1.5 text-xs font-bold text-white"
                  >
                    Guardar
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
