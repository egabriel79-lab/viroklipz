import React, { useState } from 'react';
import { ArrowLeft } from 'lucide-react';

interface AudienceControlScreenProps {
  onBack: () => void;
  onNotify?: (message: string) => void;
}

export const AudienceControlScreen: React.FC<AudienceControlScreenProps> = ({
  onBack,
  onNotify,
}) => {
  const [adultsOnly, setAdultsOnly] = useState(false);

  const handleToggle = () => {
    const next = !adultsOnly;
    setAdultsOnly(next);
    onNotify?.(`Restricción mayores de 18 años ${next ? 'activada' : 'desactivada'}`);
  };

  return (
    <div className="flex h-full w-full flex-col bg-[#121212] text-white select-none overflow-hidden">
      <header className="relative flex h-12 shrink-0 items-center justify-center border-b border-white/10 bg-[#121212] px-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Atrás"
          className="absolute left-2 flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="text-[15px] font-bold text-white">Control del público</h1>
      </header>

      <div className="flex-1 min-h-0 overflow-y-auto px-4 py-4 no-scrollbar">
        <div className="overflow-hidden rounded-xl bg-[#1E1E1E]">
          <div className="flex items-start justify-between gap-4 px-4 py-4">
            <div className="min-w-0 flex-1">
              <p className="text-[14px] font-medium text-white">Mayores de 18 años</p>
              <p className="mt-1.5 text-xs leading-relaxed text-zinc-400">
                Activa este ajuste si tu contenido está pensado únicamente para público adulto. Al activarlo, los videos que publiques o las transmisiones vinculadas quedarán limitadas a usuarios mayores de 18 años.
              </p>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={adultsOnly}
              onClick={handleToggle}
              className={`relative mt-0.5 inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors ${
                adultsOnly ? 'bg-[#FF5722]' : 'bg-zinc-600'
              }`}
            >
              <span
                className={`inline-block h-5 w-5 transform rounded-full bg-white shadow transition-transform ${
                  adultsOnly ? 'translate-x-5' : 'translate-x-0.5'
                }`}
              />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
