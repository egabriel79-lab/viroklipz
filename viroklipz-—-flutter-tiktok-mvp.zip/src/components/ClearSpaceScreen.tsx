import React, { useState } from 'react';
import { ArrowLeft } from 'lucide-react';

interface ClearSpaceScreenProps {
  onBack: () => void;
  onNotify?: (message: string) => void;
}

export const ClearSpaceScreen: React.FC<ClearSpaceScreenProps> = ({
  onBack,
  onNotify,
}) => {
  const [cacheCleared, setCacheCleared] = useState(false);

  const handleClearCache = () => {
    setCacheCleared(true);
    onNotify?.('Memoria caché de Viroklipz liberada');
  };

  return (
    <div className="flex h-full w-full flex-col bg-[#121212] text-white select-none overflow-hidden">
      <header className="relative flex h-12 shrink-0 items-center justify-center border-b border-white/10 bg-[#121212] px-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Atrás"
          className="absolute left-2 flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="text-[15px] font-bold text-white">Liberar espacio</h1>
      </header>

      <div className="flex-1 min-h-0 overflow-y-auto px-4 py-6 no-scrollbar">
        <div className="mb-6">
          <p className="text-sm font-medium text-zinc-400">
            Datos de Viroklipz
          </p>
          <p className="mt-1 text-3xl font-extrabold tracking-tight text-white">
            {cacheCleared ? '0.0 MB' : 'Calculando...'}
          </p>

          {/* Barra de progreso simulada (gris) */}
          <div className="mt-4 h-3 w-full overflow-hidden rounded-full bg-[#27272A]">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                cacheCleared ? 'w-[8%] bg-zinc-500' : 'w-[62%] bg-zinc-400'
              }`}
            />
          </div>
        </div>

        {/* Contenedor de Caché */}
        <div className="rounded-xl bg-[#1E1E1E] p-4">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0 flex-1">
              <h2 className="text-[15px] font-bold text-white">Caché:</h2>
              <p className="mt-1 text-xs leading-relaxed text-zinc-400">
                {cacheCleared
                  ? 'La memoria caché temporal se ha limpiado correctamente.'
                  : 'Borrar la memoria caché para liberar espacio. Esto no afectará a tu experiencia en Viroklipz.'}
              </p>
            </div>
            <button
              type="button"
              onClick={handleClearCache}
              disabled={cacheCleared}
              className={`shrink-0 rounded-lg px-4 py-2 text-xs font-bold transition-opacity ${
                cacheCleared
                  ? 'bg-zinc-700 text-zinc-400 cursor-default'
                  : 'bg-[#E91E63] text-white hover:opacity-90 active:opacity-80'
              }`}
            >
              {cacheCleared ? 'Listo' : 'Borrar'}
            </button>
          </div>
        </div>

        <p className="mt-4 px-1 text-xs leading-relaxed text-zinc-500">
          La memoria caché incluye archivos temporales descargados mientras
          navegas para acelerar la carga de videos e imágenes. Al borrarla no se
          eliminarán tus borradores, publicaciones ni cuenta.
        </p>
      </div>
    </div>
  );
};
