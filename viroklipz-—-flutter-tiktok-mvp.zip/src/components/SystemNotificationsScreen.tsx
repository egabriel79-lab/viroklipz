import React, { useState } from 'react';
import {
  ArrowLeft,
  DollarSign,
  Lightbulb,
  MoreHorizontal,
  Music,
  Radio,
  Settings,
} from 'lucide-react';

type SystemFilter = 'todo' | 'viroklipz' | 'creadores' | 'transacciones';

interface SystemNotificationsScreenProps {
  onBack: () => void;
  onNotify?: (message: string) => void;
}

interface SystemNotificationCardData {
  id: string;
  category: Exclude<SystemFilter, 'todo'>;
  sender: string;
  time: string;
  icon: 'music' | 'lightbulb' | 'live' | 'dollar';
  title: string;
  subtitle: string;
  expandedDetail: string;
}

const SYSTEM_CARDS: SystemNotificationCardData[] = [
  {
    id: 'sys-1',
    category: 'viroklipz',
    sender: 'Viroklipz · Actividades',
    time: '1 d',
    icon: 'music',
    title: 'Tus fans están buscando contenido. Asegúrate de que te encuentren.',
    subtitle:
      'Mira lo que es popular en tu nicho, respaldado por millones de búsquedas reales...',
    expandedDetail:
      'Usa palabras clave claras en la descripción de tus videos verticales y aprovecha sonidos en tendencia para multiplicar el alcance orgánico en "Para ti".',
  },
  {
    id: 'sys-2',
    category: 'creadores',
    sender: 'Actualizaciones de creadores',
    time: '2 d',
    icon: 'lightbulb',
    title: 'Hola, @mateo.cine, ¡la semana pasada te fue muy bien!',
    subtitle:
      '¿Estás ofreciendo lo que la gente busca? Descubre cómo te fue y obtén inspiración...',
    expandedDetail:
      'Tus clips obtuvieron un 28% más de retención en los primeros 3 segundos. Publicar entre 7:00 PM y 9:00 PM mantiene el mejor ritmo de interacción.',
  },
  {
    id: 'sys-3',
    category: 'creadores',
    sender: 'Actualizaciones de creadores',
    time: '10 mar',
    icon: 'lightbulb',
    title: 'Perfecto para tu estilo creativo',
    subtitle:
      'activar monetización por vistas es un tema popular ahora. Explora tendencias relacionadas en Estadísticas de...',
    expandedDetail:
      'Los creadores en tu categoría están generando un 35% más de ingresos activando la monetización en videos originales de más de 30 segundos.',
  },
  {
    id: 'sys-4',
    category: 'viroklipz',
    sender: 'LIVE · Actividades',
    time: '3 d',
    icon: 'live',
    title: 'Tus espectadores quieren ver más de ti',
    subtitle:
      'Tu contenido LIVE genera comentarios. ¡Mantén el ritmo! LIVE Studio te permite iniciar...',
    expandedDetail:
      'Conecta directamente con tus seguidores en tiempo real, responde preguntas de la comunidad y convierte los mejores momentos en clips para tu feed.',
  },
  {
    id: 'sys-5',
    category: 'transacciones',
    sender: 'Asistente para transacciones',
    time: '2 ene',
    icon: 'dollar',
    title: 'Límite de retirada actualizado',
    subtitle: 'Puedes retirar hasta $100 al día en 01/2026.',
    expandedDetail:
      'Tu cuenta cumple con los requisitos de verificación activa. Los retiros diarios se procesan de forma automática hacia tu método de pago vinculado.',
  },
  {
    id: 'sys-6',
    category: 'transacciones',
    sender: 'Asistente para transacciones',
    time: '19 dic 2025',
    icon: 'dollar',
    title: 'Identidad verificada',
    subtitle: 'Tu identidad se verificó.',
    expandedDetail:
      'Ya tienes acceso completo a retiros, propinas LIVE y herramientas de monetización para creadores dentro de Viroklipz.',
  },
];

const FILTERS: { id: SystemFilter; label: string }[] = [
  { id: 'todo', label: 'Todo' },
  { id: 'viroklipz', label: 'Viroklipz' },
  { id: 'creadores', label: 'Actualizaciones de creadores' },
  { id: 'transacciones', label: 'Asistente para transacciones' },
];

export const SystemNotificationsScreen: React.FC<SystemNotificationsScreenProps> = ({
  onBack,
  onNotify,
}) => {
  const [selectedFilter, setSelectedFilter] = useState<SystemFilter>('todo');
  const [expandedCards, setExpandedCards] = useState<Record<string, boolean>>({});

  const visibleCards =
    selectedFilter === 'todo'
      ? SYSTEM_CARDS
      : SYSTEM_CARDS.filter((card) => card.category === selectedFilter);

  const toggleExpand = (id: string) => {
    setExpandedCards((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const renderCardIcon = (icon: SystemNotificationCardData['icon']) => {
    if (icon === 'music') {
      return (
        <span className="flex h-6 w-6 items-center justify-center rounded-full bg-[#FF2D55]/20 text-[#FF2D55]">
          <Music className="h-3.5 w-3.5" />
        </span>
      );
    }
    if (icon === 'lightbulb') {
      return (
        <span className="flex h-6 w-6 items-center justify-center rounded-full bg-amber-400/20 text-amber-400">
          <Lightbulb className="h-3.5 w-3.5" />
        </span>
      );
    }
    if (icon === 'dollar') {
      return (
        <span className="flex h-6 w-6 items-center justify-center rounded-full bg-[#2563EB] text-white">
          <DollarSign className="h-3.5 w-3.5 stroke-[2.5]" />
        </span>
      );
    }
    return (
      <span className="flex h-6 w-6 items-center justify-center rounded-full bg-cyan-400/20 text-[#25F4EE]">
        <Radio className="h-3.5 w-3.5" />
      </span>
    );
  };

  return (
    <div className="flex h-full w-full flex-col bg-[#0F0F0F] text-white">
      {/* AppBar superior: Atrás izquierda, Título centrado, Engranaje derecha */}
      <header className="shrink-0 border-b border-white/10 bg-[#0F0F0F]">
        <div className="flex h-13 items-center justify-between px-2">
          <button
            type="button"
            onClick={onBack}
            aria-label="Volver a mensajes"
            className="flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>

          <h1 className="truncate px-2 text-[15.5px] font-bold tracking-tight text-white">
            Notificaciones del sistema
          </h1>

          <button
            type="button"
            onClick={() =>
              onNotify?.('Alertas del sistema activadas para esta cuenta')
            }
            aria-label="Configuración de notificaciones"
            className="flex h-10 w-10 items-center justify-center rounded-full text-zinc-300 transition-colors hover:bg-white/10 hover:text-white"
          >
            <Settings className="h-5 w-5" />
          </button>
        </div>

        {/* Fila horizontal deslizable de filtros */}
        <div className="flex items-center gap-2 overflow-x-auto px-4 pb-3 pt-1 no-scrollbar">
          {FILTERS.map((filter) => {
            const isActive = selectedFilter === filter.id;
            return (
              <button
                key={filter.id}
                type="button"
                onClick={() => setSelectedFilter(filter.id)}
                className={`min-h-[34px] shrink-0 rounded-full px-3.5 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap ${
                  isActive
                    ? 'border border-white/35 bg-[#2D2D34] text-white'
                    : 'border border-white/15 bg-transparent text-zinc-400 hover:bg-white/5 hover:text-zinc-200'
                }`}
              >
                {filter.label}
              </button>
            );
          })}
        </div>
      </header>

      {/* Lista de tarjetas de notificación */}
      <div className="flex-1 min-h-0 overflow-y-auto space-y-3 p-4 no-scrollbar">
        {visibleCards.map((card) => {
          const isExpanded = Boolean(expandedCards[card.id]);
          return (
            <article
              key={card.id}
              className="rounded-2xl border border-white/[0.06] bg-[#1E1E1E] p-4 space-y-2.5"
            >
              {/* Encabezado de tarjeta */}
              <div className="flex items-center justify-between gap-2">
                <div className="flex min-w-0 items-center gap-2">
                  {renderCardIcon(card.icon)}
                  <span className="truncate text-xs font-semibold text-zinc-300">
                    {card.sender}
                  </span>
                </div>

                <div className="flex shrink-0 items-center gap-2">
                  <span className="text-[11px] text-zinc-500 tabular-nums">
                    {card.time}
                  </span>
                  <button
                    type="button"
                    onClick={() =>
                      onNotify?.(`Opciones de "${card.sender}"`)
                    }
                    aria-label={`Más opciones para ${card.sender}`}
                    className="flex h-7 w-7 items-center justify-center rounded-full text-zinc-400 transition-colors hover:bg-white/10 hover:text-white"
                  >
                    <MoreHorizontal className="h-4 w-4" />
                  </button>
                </div>
              </div>

              {/* Título principal en negrita y blanco */}
              <h2 className="text-[14.5px] font-bold leading-snug text-white">
                {card.title}
              </h2>

              {/* Subtítulo en gris */}
              <p className="text-xs leading-relaxed text-zinc-400">
                {card.subtitle}
              </p>

              {isExpanded && (
                <p className="border-t border-white/10 pt-2.5 text-xs leading-relaxed text-zinc-300">
                  {card.expandedDetail}
                </p>
              )}

              {/* Botón de texto Ver más en blanco */}
              <div className="pt-0.5">
                <button
                  type="button"
                  onClick={() => toggleExpand(card.id)}
                  className="text-xs font-bold text-white transition-opacity hover:opacity-80"
                >
                  {isExpanded ? 'Ver menos' : 'Ver más'}
                </button>
              </div>
            </article>
          );
        })}
      </div>
    </div>
  );
};
