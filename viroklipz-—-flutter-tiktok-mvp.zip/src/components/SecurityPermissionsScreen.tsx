import React, { useState } from 'react';
import { ArrowLeft, ChevronRight } from 'lucide-react';

interface SecurityPermissionsScreenProps {
  activeHandle?: string;
  onBack: () => void;
  onNotify?: (message: string) => void;
}

interface SecurityNavRowProps {
  title: string;
  trailingText?: string;
  onTap: () => void;
}

const SecurityNavRow: React.FC<SecurityNavRowProps> = ({
  title,
  trailingText,
  onTap,
}) => (
  <button
    type="button"
    onClick={onTap}
    className="flex w-full items-center justify-between gap-3 px-4 py-3.5 text-left transition-colors hover:bg-white/5 active:bg-white/10"
  >
    <span className="min-w-0 flex-1 text-[14px] font-medium text-zinc-100">
      {title}
    </span>
    <div className="flex shrink-0 items-center gap-2">
      {trailingText && (
        <span className="text-xs text-zinc-400">{trailingText}</span>
      )}
      <ChevronRight className="h-4 w-4 text-zinc-500" />
    </div>
  </button>
);

export const SecurityPermissionsScreen: React.FC<
  SecurityPermissionsScreenProps
> = ({ activeHandle = 'gabriel_12343', onBack, onNotify }) => {
  const [saveLoginInfo, setSaveLoginInfo] = useState(true);
  const cleanHandle = activeHandle.replace(/^@/, '');

  const notifyOption = (title: string) => {
    onNotify?.(`Seguridad: ${title}`);
  };

  return (
    <div className="flex h-full w-full flex-col bg-[#121212] text-white select-none overflow-hidden">
      {/* AppBar oscura */}
      <header className="relative flex h-12 shrink-0 items-center justify-center border-b border-white/10 bg-[#121212] px-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Atrás"
          className="absolute left-2 flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="text-[15px] font-bold text-white">
          Seguridad y permisos
        </h1>
      </header>

      {/* Cuerpo scrolleable */}
      <div className="flex-1 min-h-0 overflow-y-auto px-4 pt-5 pb-8 space-y-5 no-scrollbar">
        {/* Sección "Seguridad" */}
        <section>
          <h2 className="mb-2 px-1 text-xs font-semibold tracking-wide text-zinc-400">
            Seguridad
          </h2>
          <div className="divide-y divide-white/5 overflow-hidden rounded-xl bg-[#1E1E1E]">
            <SecurityNavRow
              title="Alertas de seguridad"
              onTap={() => notifyOption('Alertas de seguridad')}
            />
            <SecurityNavRow
              title="Verificación de seguridad"
              onTap={() => notifyOption('Verificación de seguridad')}
            />
            <SecurityNavRow
              title="Tus dispositivos"
              onTap={() => notifyOption('Tus dispositivos')}
            />
            <SecurityNavRow
              title="Verificación en dos pasos"
              trailingText="Desactivado"
              onTap={() => notifyOption('Verificación en dos pasos')}
            />

            {/* Switch funcional: Guardar los datos de inicio de sesión */}
            <div
              onClick={() => {
                const next = !saveLoginInfo;
                setSaveLoginInfo(next);
                onNotify?.(
                  next
                    ? 'Datos de inicio de sesión guardados'
                    : 'Guardado de inicio de sesión desactivado'
                );
              }}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  setSaveLoginInfo((prev) => !prev);
                }
              }}
              className="flex w-full cursor-pointer items-center justify-between gap-3 px-4 py-3.5 transition-colors hover:bg-white/5"
            >
              <div className="min-w-0 flex-1">
                <p className="text-[14px] font-medium leading-snug text-zinc-100">
                  Guardar los datos de inicio de sesión
                </p>
                <p className="mt-1 text-xs leading-relaxed text-zinc-400">
                  Inicia sesión en {cleanHandle} en este dispositivo sin tener
                  que introducir tus credenciales cada vez.
                </p>
              </div>

              <button
                type="button"
                role="switch"
                aria-checked={saveLoginInfo}
                aria-label="Guardar los datos de inicio de sesión"
                onClick={(e) => {
                  e.stopPropagation();
                  const next = !saveLoginInfo;
                  setSaveLoginInfo(next);
                  onNotify?.(
                    next
                      ? 'Datos de inicio de sesión guardados'
                      : 'Guardado de inicio de sesión desactivado'
                  );
                }}
                className={`relative inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors ${
                  saveLoginInfo ? 'bg-[#25F4EE]' : 'bg-zinc-600'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white shadow transition-transform ${
                    saveLoginInfo ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            <SecurityNavRow
              title="Ayuda a tus amigos a recuperar sus cuentas"
              onTap={() =>
                notifyOption('Ayuda a tus amigos a recuperar sus cuentas')
              }
            />
          </div>
        </section>

        {/* Sección "Permisos" */}
        <section>
          <h2 className="mb-2 px-1 text-xs font-semibold tracking-wide text-zinc-400">
            Permisos
          </h2>
          <div className="divide-y divide-white/5 overflow-hidden rounded-xl bg-[#1E1E1E]">
            <SecurityNavRow
              title="Permisos de aplicaciones y servicios"
              onTap={() =>
                notifyOption('Permisos de aplicaciones y servicios')
              }
            />
            <SecurityNavRow
              title="Ajustes del navegador"
              onTap={() => notifyOption('Ajustes del navegador')}
            />
          </div>
        </section>
      </div>
    </div>
  );
};
