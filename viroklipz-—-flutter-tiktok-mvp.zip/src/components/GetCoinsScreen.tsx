import React, { useState } from 'react';
import { ArrowLeft, History } from 'lucide-react';
import { COIN_PACKAGES } from '../data/coinPackages';

interface GetCoinsScreenProps {
  onBack: () => void;
  onNotify?: (message: string) => void;
}

const COIN_RATE_USD = 0.0079;

export const CoinBadge: React.FC<{ size?: 'sm' | 'md' | 'lg' }> = ({
  size = 'md',
}) => {
  const sizeClass =
    size === 'lg'
      ? 'h-8 w-8 text-sm'
      : size === 'sm'
      ? 'h-4 w-4 text-[9px]'
      : 'h-5 w-5 text-[10px]';

  return (
    <span
      aria-hidden="true"
      className={`inline-flex shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-amber-300 via-amber-400 to-orange-500 font-black text-amber-950 shadow-sm ring-1 ring-amber-200/80 ${sizeClass}`}
    >
      V
    </span>
  );
};

export const GetCoinsScreen: React.FC<GetCoinsScreenProps> = ({
  onBack,
  onNotify,
}) => {
  const [selectedIndex, setSelectedIndex] = useState<number | null>(0);
  const [customInput, setCustomInput] = useState('');

  const customCoins = customInput ? parseInt(customInput, 10) || 0 : 0;
  const hasDiscount = customCoins > 1000;
  const rawTotal = customCoins * COIN_RATE_USD;
  const customTotalUsd = hasDiscount ? rawTotal * 0.9 : rawTotal;
  const formattedCustomTotal = customTotalUsd.toFixed(2);

  const selectedPackage =
    selectedIndex !== null ? COIN_PACKAGES[selectedIndex] ?? null : null;

  const isActionEnabled = selectedPackage !== null || customCoins > 0;

  const buttonLabel = selectedPackage
    ? `Consigue ${selectedPackage.coins + selectedPackage.bonus} Monedas (${selectedPackage.priceText})`
    : customCoins > 0
    ? `Consigue ${customCoins} Monedas (USD ${formattedCustomTotal})`
    : 'Ingresa una cantidad o elige un paquete';

  const handleSelectPackage = (index: number) => {
    setSelectedIndex(index);
    setCustomInput('');
  };

  const handleCustomChange = (value: string) => {
    const digitsOnly = value.replace(/[^0-9]/g, '');
    setCustomInput(digitsOnly);
    setSelectedIndex(null);
  };

  return (
    <div className="flex h-full w-full flex-col bg-[#121212] text-white select-none">
      {/* AppBar: Botón atrás, Título "Obtener Monedas", ícono de historial */}
      <header className="flex h-12 shrink-0 items-center justify-between border-b border-white/10 bg-[#121212] px-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Atrás"
          className="flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>

        <h1 className="text-[15.5px] font-bold tracking-tight text-white">
          Obtener Monedas
        </h1>

        <button
          type="button"
          onClick={() =>
            onNotify?.('Historial de transacciones: Sin recargas recientes')
          }
          aria-label="Historial de recargas"
          className="flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <History className="h-5 w-5" />
        </button>
      </header>

      {/* Cuerpo principal */}
      <div className="flex-1 min-h-0 overflow-y-auto px-4 py-4 space-y-4 no-scrollbar">
        {/* Sección Saldo */}
        <section className="rounded-2xl border border-white/10 bg-[#1E1E1E] p-4">
          <p className="text-xs font-medium text-zinc-400">Saldo de Monedas</p>
          <div className="mt-2 flex items-center gap-2.5">
            <CoinBadge size="lg" />
            <span className="text-3xl font-extrabold tracking-tight text-white tabular-nums">
              0
            </span>
          </div>
        </section>

        {/* Banner de Regalo */}
        <section className="flex items-center justify-between gap-3 rounded-2xl border border-pink-400/30 bg-gradient-to-r from-[#FCE7F3] to-[#FFE4EC] px-4 py-3 text-zinc-900 shadow-sm">
          <div className="min-w-0 flex-1">
            <p className="text-[13px] font-bold leading-snug text-rose-950">
              Rosas de bonus y Monedas en la primera recarga...
            </p>
            <p className="mt-0.5 text-[11px] font-medium text-rose-700">
              Precios más económicos que nunca en Viroklipz
            </p>
          </div>
          <div
            aria-hidden="true"
            className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-white/85 text-2xl shadow-sm"
          >
            🌹
          </div>
        </section>

        {/* Sección Recarga (Grid 3 columnas) */}
        <section className="space-y-2.5">
          <div className="flex items-center justify-between">
            <h2 className="text-xs font-bold uppercase tracking-wider text-zinc-400">
              Recargar
            </h2>
            <span className="text-[11px] font-medium text-[#E91E63]">
              Incluye bono extra
            </span>
          </div>

          <div className="grid grid-cols-3 gap-2.5">
            {COIN_PACKAGES.map((pkg, index) => {
              const isSelected = selectedIndex === index;
              return (
                <button
                  key={pkg.id}
                  type="button"
                  onClick={() => handleSelectPackage(index)}
                  className={`flex flex-col items-center justify-center rounded-xl border px-2 py-3 text-center transition-all active:scale-95 ${
                    isSelected
                      ? 'border-2 border-[#E91E63] bg-[#E91E63]/15 shadow-[0_0_16px_rgba(233,30,99,0.22)]'
                      : 'border-white/10 bg-[#1E1E1E] hover:border-white/25'
                  }`}
                >
                  <div className="flex items-center gap-1">
                    <CoinBadge size="sm" />
                    <span className="text-base font-extrabold text-white tabular-nums">
                      {pkg.coins}
                    </span>
                  </div>
                  <span className="mt-0.5 text-[11px] font-bold text-[#FE2C55] tabular-nums">
                    +{pkg.bonus} Bono
                  </span>
                  <span className="mt-1.5 text-[11px] font-medium text-zinc-300 tabular-nums">
                    {pkg.priceText}
                  </span>
                </button>
              );
            })}
          </div>
        </section>

        {/* Calculadora de monedas personalizada */}
        <section className="rounded-2xl border border-white/10 bg-[#17171A] p-4 space-y-2.5">
          <div>
            <h2 className="text-sm font-bold text-white">
              Calculadora personalizada
            </h2>
            <p className="mt-0.5 text-xs text-zinc-400">
              Ingresa la cantidad de monedas que deseas comprar:
            </p>
          </div>

          <div className="flex items-center gap-2.5">
            <div className="relative flex-1">
              <input
                type="text"
                inputMode="numeric"
                value={customInput}
                onChange={(e) => handleCustomChange(e.target.value)}
                placeholder="Ej. 250"
                aria-label="Cantidad personalizada de monedas"
                className="w-full rounded-xl border border-white/10 bg-[#1E1E1E] px-3.5 py-2.5 text-sm font-semibold text-white placeholder:text-zinc-500 focus:border-[#E91E63] focus:outline-none tabular-nums"
              />
            </div>
            <div className="shrink-0 text-right">
              <p className="text-xs font-bold text-[#E91E63] tabular-nums">
                Total a pagar: USD {formattedCustomTotal}
              </p>
              {hasDiscount ? (
                <p className="text-[10px] font-semibold text-emerald-400">
                  10% de descuento aplicado
                </p>
              ) : (
                <p className="text-[10px] text-zinc-500">
                  +1000 monedas = 10% dto.
                </p>
              )}
            </div>
          </div>
        </section>

        {/* Texto Legal */}
        <p className="pt-1 text-[11px] leading-relaxed text-zinc-500">
          Al recargar, confirmas que eres mayor de 18 años y aceptas los Términos
          de Artículos Virtuales de Viroklipz. Las monedas no son reembolsables ni
          canjeables por dinero en efectivo.
        </p>
      </div>

      {/* Botón Inferior */}
      <footer className="shrink-0 border-t border-white/10 bg-[#121212] p-4">
        <button
          type="button"
          disabled={!isActionEnabled}
          onClick={() =>
            onNotify?.('Redirigiendo a pasarela de pago... (Simulación)')
          }
          className={`flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#FF5722] to-[#E91E63] py-3.5 text-sm font-bold text-white shadow-lg shadow-[#E91E63]/25 transition-all ${
            isActionEnabled
              ? 'hover:opacity-95 active:scale-[0.99]'
              : 'cursor-not-allowed opacity-50'
          }`}
        >
          <span>{buttonLabel}</span>
        </button>
      </footer>
    </div>
  );
};
