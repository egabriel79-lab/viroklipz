import React, { useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  AudioLines,
  Award,
  Medal,
  Play,
  Trophy,
  Volume2,
  VolumeX,
} from 'lucide-react';

interface WellbeingScreenProps {
  nombreUsuario?: string;
  avatarUrl?: string;
  onBack: () => void;
  onNotify?: (message: string) => void;
}

const WEEKLY_BARS = [
  { day: 'Dom', hours: 1.9, heightPct: 52 },
  { day: 'Lun', hours: 2.4, heightPct: 68 },
  { day: 'Mar', hours: 3.1, heightPct: 88 },
  { day: 'Mié', hours: 2.1, heightPct: 60 },
  { day: 'Jue', hours: 2.8, heightPct: 78 },
  { day: 'Vie', hours: 3.3, heightPct: 94 },
  { day: 'Hoy', hours: 2.3, heightPct: 65, isToday: true },
];

const RESOURCE_VIDEOS = [
  {
    id: 'res-1',
    title: 'Cómo crear pausas digitales conscientes',
    duration: '01:45',
    thumb: '/src/assets/images/story_hinduismo_temple_1794607243976.jpg',
  },
  {
    id: 'res-2',
    title: 'Técnica 4-7-8 para reducir el estrés',
    duration: '02:15',
    thumb: '/src/assets/images/avatar_creator_valeria_1794604321625.jpg',
  },
  {
    id: 'res-3',
    title: 'Higiene del sueño antes de dormir',
    duration: '03:05',
    thumb: '/src/assets/images/avatar_creator_sofia_1794604322145.jpg',
  },
  {
    id: 'res-4',
    title: 'Equilibrio entre estudio y redes sociales',
    duration: '02:40',
    thumb: '/src/assets/images/avatar_creator_lucas_1794604322245.jpg',
  },
];

export const WellbeingScreen: React.FC<WellbeingScreenProps> = ({
  nombreUsuario = 'Eloy',
  avatarUrl = '/src/assets/images/avatar_creator_mateo_1794604321715.jpg',
  onBack,
  onNotify,
}) => {
  const [isMuted, setIsMuted] = useState(false);
  const [selectedDay, setSelectedDay] = useState<string>('Hoy');

  return (
    <div className="flex h-full w-full flex-col bg-[#121212] text-white select-none overflow-hidden">
      {/* AppBar */}
      <header className="relative flex h-12 shrink-0 items-center justify-center border-b border-white/10 bg-[#121212] px-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Atrás"
          className="absolute left-2 flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="text-[15px] font-bold text-white">
          Tiempo y bienestar
        </h1>
      </header>

      {/* Cuerpo scrolleable */}
      <div className="flex-1 min-h-0 overflow-y-auto px-4 pt-5 pb-8 space-y-6 no-scrollbar">
        {/* 1. Encabezado */}
        <section className="flex items-start justify-between gap-3">
          <div className="min-w-0 flex-1">
            <h2 className="text-2xl font-extrabold tracking-tight text-white">
              Hola, {nombreUsuario}
            </h2>
            <p className="mt-1 text-xs leading-relaxed text-zinc-400">
              Revisa tu tiempo en pantalla, explora herramientas de calma y
              mantén hábitos digitales saludables.
            </p>
          </div>
          <img
            src={avatarUrl}
            alt={nombreUsuario}
            className="h-12 w-12 shrink-0 rounded-full border border-white/15 object-cover"
          />
        </section>

        {/* 2. Sección "Tiempo en pantalla" */}
        <section className="rounded-2xl bg-[#1E1E1E] p-4">
          <div className="flex items-baseline justify-between">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-zinc-400">
                Tiempo en pantalla
              </p>
              <p className="mt-1 text-3xl font-extrabold text-white tabular-nums">
                2 h 34 min
              </p>
              <p className="text-xs text-zinc-400">Promedio diario</p>
            </div>
            <span className="rounded-full bg-sky-500/15 px-2.5 py-1 text-[11px] font-semibold text-sky-300">
              {selectedDay}:{' '}
              {WEEKLY_BARS.find((b) => b.day === selectedDay)?.hours} h
            </span>
          </div>

          {/* Gráfico de barras simulado */}
          <div className="mt-5 flex h-32 items-end justify-between gap-2.5 px-1">
            {WEEKLY_BARS.map((bar) => {
              const isSelected = selectedDay === bar.day;
              return (
                <button
                  key={bar.day}
                  type="button"
                  onClick={() => setSelectedDay(bar.day)}
                  className="group flex flex-1 flex-col items-center gap-2 focus:outline-none"
                >
                  <div className="flex h-24 w-full items-end justify-center">
                    <div
                      style={{ height: `${bar.heightPct}%` }}
                      className={`w-full max-w-[26px] rounded-t-lg transition-all duration-300 ${
                        isSelected
                          ? 'bg-gradient-to-t from-sky-500 to-cyan-300 shadow-[0_0_12px_rgba(56,189,248,0.45)]'
                          : 'bg-gradient-to-t from-blue-600/70 to-sky-400/75 group-hover:from-blue-500 group-hover:to-sky-300'
                      }`}
                    />
                  </div>
                  <span
                    className={`text-[11px] font-medium ${
                      isSelected ? 'text-cyan-300 font-bold' : 'text-zinc-400'
                    }`}
                  >
                    {bar.day}
                  </span>
                </button>
              );
            })}
          </div>
        </section>

        {/* 3. Sección "Insignias" */}
        <section>
          <h3 className="mb-2.5 px-1 text-sm font-bold text-white">
            Insignias
          </h3>
          <div className="flex items-center justify-between rounded-2xl bg-[#1E1E1E] px-4 py-4">
            <div>
              <p className="text-2xl font-extrabold text-white tabular-nums">
                0/9
              </p>
              <p className="text-[11px] text-zinc-400">
                Desbloquea logros de bienestar
              </p>
            </div>
            <div className="flex items-center gap-2">
              <span className="flex h-9 w-9 items-center justify-center rounded-full bg-amber-500/20 text-amber-400">
                <Trophy className="h-4 w-4" />
              </span>
              <span className="flex h-9 w-9 items-center justify-center rounded-full bg-emerald-500/20 text-emerald-400">
                <Medal className="h-4 w-4" />
              </span>
              <span className="flex h-9 w-9 items-center justify-center rounded-full bg-sky-500/20 text-sky-400">
                <Award className="h-4 w-4" />
              </span>
              <span className="flex h-9 w-9 items-center justify-center rounded-full bg-pink-500/20 text-pink-400">
                <Medal className="h-4 w-4" />
              </span>
            </div>
          </div>
        </section>

        {/* 4. Sección "Pausar y restablecer" */}
        <section className="space-y-3">
          <h3 className="px-1 text-sm font-bold text-white">
            Pausar y restablecer
          </h3>

          {/* Tarjeta 1 (Morada) */}
          <div
            onClick={() => onNotify?.('Registro emocional: Hoy estoy...')}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                onNotify?.('Registro emocional: Hoy estoy...');
              }
            }}
            className="flex cursor-pointer items-center justify-between gap-3 rounded-2xl p-4 shadow-lg transition-transform active:scale-[0.99]"
            style={{
              background:
                'linear-gradient(135deg, #6D28D9 0%, #9333EA 55%, #C084FC 100%)',
            }}
          >
            <div className="min-w-0 flex-1">
              <h4 className="text-base font-bold text-white">Hoy estoy...</h4>
              <p className="mt-1 text-xs leading-relaxed text-purple-100">
                Elige 2 palabras para expresar cómo te sientes en este momento.
              </p>
            </div>
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-white text-purple-700 shadow">
              <ArrowRight className="h-5 w-5" />
            </span>
          </div>

          {/* Tarjeta 2 (Celeste) */}
          <div
            onClick={() => onNotify?.('Iniciando ejercicio de respiración (2 min)')}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                onNotify?.('Iniciando ejercicio de respiración (2 min)');
              }
            }}
            className="flex cursor-pointer items-center justify-between gap-3 rounded-2xl p-4 shadow-lg transition-transform active:scale-[0.99]"
            style={{
              background:
                'linear-gradient(135deg, #0284C7 0%, #06B6D4 60%, #38BDF8 100%)',
            }}
          >
            <div className="min-w-0 flex-1">
              <h4 className="text-base font-bold text-white">
                Respira de manera uniforme
              </h4>
              <p className="mt-1 text-xs leading-relaxed text-cyan-50">
                Inhala y exhala siguiendo el ritmo guiado para despejar tu mente.
              </p>
              <div className="mt-2.5 flex items-center gap-2">
                <span className="rounded-full bg-white/20 px-2.5 py-0.5 text-[11px] font-semibold text-white">
                  Concentrate
                </span>
                <span className="rounded-full bg-white/20 px-2.5 py-0.5 text-[11px] font-semibold text-white">
                  2 min
                </span>
              </div>
            </div>
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-white text-sky-600 shadow">
              <ArrowRight className="h-5 w-5" />
            </span>
          </div>

          {/* Tarjeta 3 (Azul claro) */}
          <div
            className="flex items-center justify-between gap-3 rounded-2xl p-4 shadow-lg"
            style={{
              background:
                'linear-gradient(135deg, #1D4ED8 0%, #3B82F6 60%, #60A5FA 100%)',
            }}
          >
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <AudioLines className="h-4 w-4 text-blue-100" />
                <h4 className="text-base font-bold text-white">
                  Sonidos relajantes
                </h4>
              </div>
              <p className="mt-1 text-xs leading-relaxed text-blue-50">
                Lluvia suave y ruido blanco para descansar mejor.
              </p>
            </div>
            <button
              type="button"
              onClick={() => {
                const next = !isMuted;
                setIsMuted(next);
                onNotify?.(
                  next
                    ? 'Sonidos relajantes silenciados'
                    : 'Sonidos relajantes activados'
                );
              }}
              aria-label={isMuted ? 'Activar sonido' : 'Silenciar'}
              className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-white/20 text-white backdrop-blur-sm transition-colors hover:bg-white/30"
            >
              {isMuted ? (
                <VolumeX className="h-5 w-5" />
              ) : (
                <Volume2 className="h-5 w-5" />
              )}
            </button>
          </div>
        </section>

        {/* 5. Sección "Más recursos" (Carrusel horizontal) */}
        <section>
          <h3 className="mb-2.5 px-1 text-sm font-bold text-white">
            Más recursos
          </h3>
          <div className="flex gap-3 overflow-x-auto pb-2 no-scrollbar">
            {RESOURCE_VIDEOS.map((video) => (
              <button
                key={video.id}
                type="button"
                onClick={() => onNotify?.(`Reproduciendo: ${video.title}`)}
                className="group relative w-40 shrink-0 overflow-hidden rounded-xl bg-[#1E1E1E] text-left transition-transform active:scale-95"
              >
                <div className="relative h-48 w-full overflow-hidden">
                  <img
                    src={video.thumb}
                    alt={video.title}
                    className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent" />
                  <span className="absolute top-2 right-2 flex h-7 w-7 items-center justify-center rounded-full bg-black/55 text-white backdrop-blur-sm">
                    <Play className="h-3.5 w-3.5 fill-white" />
                  </span>
                  <span className="absolute bottom-2 right-2 rounded bg-black/70 px-1.5 py-0.5 text-[10px] font-semibold text-white">
                    {video.duration}
                  </span>
                </div>
                <p className="line-clamp-2 p-2.5 text-xs font-medium leading-snug text-zinc-100">
                  {video.title}
                </p>
              </button>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};
