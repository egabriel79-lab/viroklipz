import React, { useState } from 'react';
import {
  Check,
  Facebook,
  Link2,
  MessageCircle,
  MessageSquare,
  Search,
  Send,
  X,
} from 'lucide-react';

interface ShareProfileBottomSheetProps {
  profileHandle?: string;
  onClose: () => void;
  onNotify?: (message: string) => void;
}

const SUGGESTED_CONTACTS = [
  {
    id: 'c-1',
    name: 'la toxica #1🦋',
    avatar: '/src/assets/images/avatar_creator_valeria_1794604321625.jpg',
  },
  {
    id: 'c-2',
    name: '1382jovana',
    avatar: '/src/assets/images/avatar_creator_sofia_1794604322145.jpg',
  },
  {
    id: 'c-3',
    name: 'Tarot Masónico',
    avatar: '/src/assets/images/story_hinduismo_temple_1794607243976.jpg',
  },
  {
    id: 'c-4',
    name: 'ELOY',
    avatar: '/src/assets/images/avatar_creator_mateo_1794604321715.jpg',
  },
  {
    id: 'c-5',
    name: 'diego_vlogs',
    avatar: '/src/assets/images/avatar_creator_diego_1794604323122.jpg',
  },
];

export const ShareProfileBottomSheet: React.FC<
  ShareProfileBottomSheetProps
> = ({ profileHandle = 'gabriel_12343', onClose, onNotify }) => {
  const [showSearch, setShowSearch] = useState(false);
  const [query, setQuery] = useState('');
  const [sentIds, setSentIds] = useState<string[]>([]);

  const cleanHandle = profileHandle.replace(/^@/, '');
  const profileUrl = `https://viroklipz.app/@${cleanHandle}`;

  const filteredContacts = SUGGESTED_CONTACTS.filter((c) =>
    c.name.toLowerCase().includes(query.trim().toLowerCase())
  );

  const handleCopyLink = async () => {
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(profileUrl);
      }
    } catch {
      // Fallback silencioso si el iframe restringe el portapapeles
    }
    onNotify?.('Enlace del perfil copiado al portapapeles');
    onClose();
  };

  const handleNativeOrSocialShare = async (channelName: string) => {
    if (typeof navigator !== 'undefined' && navigator.share) {
      try {
        await navigator.share({
          title: `Perfil de @${cleanHandle} en Viroklipz`,
          text: `¡Mira mi perfil en Viroklipz! ${profileUrl}`,
          url: profileUrl,
        });
        onClose();
        return;
      } catch {
        // Fallback a notificación del simulador
      }
    }
    onNotify?.(`Compartiendo perfil por ${channelName}`);
    onClose();
  };

  return (
    <div
      className="absolute inset-0 z-50 flex items-end bg-black/55 backdrop-blur-[1px]"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full rounded-t-[20px] bg-white px-4 pt-3 pb-7 text-zinc-950 shadow-2xl"
      >
        {/* Barra indicadora superior */}
        <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-zinc-300" />

        {/* Encabezado: Lupa (izq), Título "Enviar a" (centro), X (der) */}
        <div className="flex items-center justify-between pb-3">
          <button
            type="button"
            onClick={() => setShowSearch((prev) => !prev)}
            aria-label="Buscar contacto"
            className="flex h-9 w-9 items-center justify-center rounded-full text-zinc-800 transition-colors hover:bg-zinc-100"
          >
            <Search className="h-5 w-5" />
          </button>

          <h2 className="text-[16px] font-bold text-zinc-950">Enviar a</h2>

          <button
            type="button"
            onClick={onClose}
            aria-label="Cerrar"
            className="flex h-9 w-9 items-center justify-center rounded-full text-zinc-800 transition-colors hover:bg-zinc-100"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Buscador desplegable opcional */}
        {showSearch && (
          <div className="mb-3 flex items-center gap-2 rounded-xl bg-zinc-100 px-3 py-2">
            <Search className="h-4 w-4 text-zinc-500" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Buscar contacto..."
              className="w-full bg-transparent text-xs text-zinc-900 placeholder-zinc-500 focus:outline-none"
            />
          </div>
        )}

        {/* Fila 1: Scroll horizontal de avatares circulares con nombres debajo */}
        <div className="flex gap-4 overflow-x-auto py-2 no-scrollbar">
          {filteredContacts.map((contact) => {
            const isSent = sentIds.includes(contact.id);
            return (
              <button
                key={contact.id}
                type="button"
                onClick={() => {
                  setSentIds((prev) =>
                    prev.includes(contact.id) ? prev : [...prev, contact.id]
                  );
                  onNotify?.(`Perfil enviado a ${contact.name}`);
                }}
                className="flex w-[64px] shrink-0 flex-col items-center gap-1.5"
              >
                <div className="relative h-14 w-14 overflow-hidden rounded-full border border-zinc-200 bg-zinc-100">
                  <img
                    src={contact.avatar}
                    alt={contact.name}
                    className="h-full w-full object-cover"
                  />
                  {isSent && (
                    <span className="absolute inset-0 flex items-center justify-center bg-black/45 text-white">
                      <Check className="h-5 w-5" />
                    </span>
                  )}
                </div>
                <span className="w-full truncate text-center text-[11px] font-medium text-zinc-700">
                  {contact.name}
                </span>
              </button>
            );
          })}
        </div>

        <hr className="my-3 border-zinc-200" />

        {/* Fila 2: Botones de compartir */}
        <div className="grid grid-cols-5 gap-2 pt-1">
          <button
            type="button"
            onClick={handleCopyLink}
            className="flex flex-col items-center gap-1.5"
          >
            <span className="flex h-12 w-12 items-center justify-center rounded-full bg-zinc-100 text-zinc-900 transition-transform active:scale-90">
              <Link2 className="h-5 w-5" />
            </span>
            <span className="text-center text-[11px] leading-tight text-zinc-700">
              Copiar enlace
            </span>
          </button>

          <button
            type="button"
            onClick={() => handleNativeOrSocialShare('WhatsApp')}
            className="flex flex-col items-center gap-1.5"
          >
            <span className="flex h-12 w-12 items-center justify-center rounded-full bg-[#25D366] text-white transition-transform active:scale-90">
              <MessageCircle className="h-5 w-5" />
            </span>
            <span className="text-center text-[11px] leading-tight text-zinc-700">
              WhatsApp
            </span>
          </button>

          <button
            type="button"
            onClick={() => handleNativeOrSocialShare('Facebook')}
            className="flex flex-col items-center gap-1.5"
          >
            <span className="flex h-12 w-12 items-center justify-center rounded-full bg-[#1877F2] text-white transition-transform active:scale-90">
              <Facebook className="h-5 w-5" />
            </span>
            <span className="text-center text-[11px] leading-tight text-zinc-700">
              Facebook
            </span>
          </button>

          <button
            type="button"
            onClick={() => handleNativeOrSocialShare('Telegram')}
            className="flex flex-col items-center gap-1.5"
          >
            <span className="flex h-12 w-12 items-center justify-center rounded-full bg-[#229ED9] text-white transition-transform active:scale-90">
              <Send className="h-5 w-5" />
            </span>
            <span className="text-center text-[11px] leading-tight text-zinc-700">
              Telegram
            </span>
          </button>

          <button
            type="button"
            onClick={() => handleNativeOrSocialShare('SMS')}
            className="flex flex-col items-center gap-1.5"
          >
            <span className="flex h-12 w-12 items-center justify-center rounded-full bg-[#1E3A8A] text-white transition-transform active:scale-90">
              <MessageSquare className="h-5 w-5" />
            </span>
            <span className="text-center text-[11px] leading-tight text-zinc-700">
              SMS
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
