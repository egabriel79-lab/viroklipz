import React, { useState } from 'react';
import { ArrowLeft, Sparkles } from 'lucide-react';

interface EditDescriptionScreenProps {
  initialDescription: string;
  onCancel: () => void;
  onSave: (newDescription: string) => void;
}

const MAX_CHARS = 80;

const QUICK_TAGS = [
  '🎬 Creador de clips',
  '🎵 Música & beats',
  '✈️ Viajes y rutas',
  '📸 Fotografía 35mm',
  '🎮 Gaming',
];

export const EditDescriptionScreen: React.FC<EditDescriptionScreenProps> = ({
  initialDescription,
  onCancel,
  onSave,
}) => {
  const [text, setText] = useState(initialDescription);

  const trimmed = text.trim();
  const hasChanged = trimmed !== initialDescription.trim();

  const handleAppendTag = (tag: string) => {
    const base = text.trim();
    const candidate = base ? `${base} · ${tag}` : tag;
    if (candidate.length <= MAX_CHARS) {
      setText(candidate);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(trimmed);
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="flex h-full w-full flex-col bg-white text-zinc-950 select-none"
    >
      {/* Header estilo TikTok */}
      <header className="flex h-12 shrink-0 items-center justify-between border-b border-zinc-200 px-3">
        <button
          type="button"
          onClick={onCancel}
          className="flex items-center gap-1 text-sm font-medium text-zinc-700 hover:text-zinc-950"
        >
          <ArrowLeft className="h-4.5 w-4.5" />
          <span>Cancelar</span>
        </button>

        <h1 className="text-[15px] font-bold text-zinc-950">Descripción</h1>

        <button
          type="submit"
          className={`text-sm font-bold transition-colors ${
            hasChanged || trimmed.length > 0
              ? 'text-[#FF2D55] hover:opacity-80'
              : 'text-zinc-400'
          }`}
        >
          Guardar
        </button>
      </header>

      <div className="flex-1 overflow-y-auto p-4 space-y-5 no-scrollbar">
        <div className="space-y-2">
          <label
            htmlFor="bio-textarea"
            className="block text-xs font-semibold uppercase tracking-wide text-zinc-500"
          >
            Tu presentación
          </label>
          <textarea
            id="bio-textarea"
            rows={4}
            maxLength={MAX_CHARS}
            autoFocus
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Agrega una descripción sobre ti o tus aficiones..."
            className="w-full resize-none rounded-xl border border-zinc-200 bg-zinc-50 p-3.5 text-sm leading-relaxed text-zinc-950 placeholder:text-zinc-400 focus:border-zinc-900 focus:bg-white focus:outline-none"
          />
          <div className="flex items-center justify-between text-xs text-zinc-400">
            <span>Visible para todos en tu perfil</span>
            <span className="font-medium tabular-nums">
              {text.length}/{MAX_CHARS}
            </span>
          </div>
        </div>

        {/* Sugerencias rápidas */}
        <div className="space-y-2.5">
          <p className="flex items-center gap-1.5 text-xs font-semibold text-zinc-600">
            <Sparkles className="h-3.5 w-3.5 text-pink-500" />
            Ideas rápidas
          </p>
          <div className="flex flex-wrap gap-2">
            {QUICK_TAGS.map((tag) => (
              <button
                key={tag}
                type="button"
                onClick={() => handleAppendTag(tag)}
                className="rounded-full border border-zinc-200 bg-zinc-50 px-3 py-1.5 text-xs font-medium text-zinc-700 transition-colors hover:border-zinc-300 hover:bg-zinc-100"
              >
                {tag}
              </button>
            ))}
          </div>
        </div>
      </div>
    </form>
  );
};
