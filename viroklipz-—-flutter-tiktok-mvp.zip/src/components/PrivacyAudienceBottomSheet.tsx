import React from 'react';
import { X } from 'lucide-react';

export type AudiencePrivacyValue = 'Todo el mundo' | 'Solo tú';

interface PrivacyAudienceBottomSheetProps {
  title: string;
  question: string;
  footerNote: string;
  selectedValue: AudiencePrivacyValue;
  onSelect: (value: AudiencePrivacyValue) => void;
  onClose: () => void;
}

export const PrivacyAudienceBottomSheet: React.FC<PrivacyAudienceBottomSheetProps> = ({
  title,
  question,
  footerNote,
  selectedValue,
  onSelect,
  onClose,
}) => {
  const options: AudiencePrivacyValue[] = ['Todo el mundo', 'Solo tú'];

  return (
    <div
      className="absolute inset-0 z-50 flex items-end bg-black/60 backdrop-blur-[1px]"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full rounded-t-[20px] bg-white px-5 pt-4 pb-7 text-zinc-900 shadow-2xl"
      >
        <div className="relative mb-3 flex items-center justify-center py-1">
          <h2 className="text-[16px] font-bold text-zinc-900">{title}</h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Cerrar"
            className="absolute right-0 flex h-8 w-8 items-center justify-center rounded-full text-zinc-600 transition-colors hover:bg-zinc-100"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <p className="mb-3 text-[13px] font-medium text-zinc-700">{question}</p>

        <div className="divide-y divide-zinc-100">
          {options.map((option) => {
            const isSelected = selectedValue === option;
            return (
              <button
                key={option}
                type="button"
                onClick={() => {
                  onSelect(option);
                  onClose();
                }}
                className="flex w-full items-center justify-between py-3.5 text-left transition-colors hover:bg-zinc-50"
              >
                <span className="text-[14px] font-semibold text-zinc-900">
                  {option}
                </span>
                <span
                  className={`flex h-5 w-5 items-center justify-center rounded-full border-2 ${
                    isSelected ? 'border-[#FF5722]' : 'border-zinc-300'
                  }`}
                >
                  {isSelected && (
                    <span className="h-2.5 w-2.5 rounded-full bg-[#FF5722]" />
                  )}
                </span>
              </button>
            );
          })}
        </div>

        <p className="mt-3 text-xs leading-relaxed text-zinc-500">{footerNote}</p>
      </div>
    </div>
  );
};
