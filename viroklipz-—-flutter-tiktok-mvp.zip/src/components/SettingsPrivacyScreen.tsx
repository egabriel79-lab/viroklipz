import React, { useState } from 'react';
import {
  Accessibility,
  ArrowLeft,
  AtSign,
  Ban,
  Bell,
  Bookmark,
  ChevronRight,
  Clock,
  CloudDownload,
  Coins,
  Compass,
  Contact,
  Download,
  Eye,
  FileText,
  FolderKanban,
  Gauge,
  Globe,
  Heart,
  HelpCircle,
  History,
  Image,
  Lock,
  LogOut,
  Megaphone,
  MessageCircle,
  MessageSquare,
  Music,
  PlaySquare,
  Radio,
  Repeat2,
  Send,
  Share2,
  Shield,
  ShieldCheck,
  Smartphone,
  Sparkles,
  Trash2,
  User,
  UserCheck,
  Users,
  Wallet,
  Wifi,
} from 'lucide-react';
import { ContentPreferencesScreen } from './ContentPreferencesScreen';
import { NotificationsSettingsScreen } from './NotificationsSettingsScreen';
import { WellbeingScreen } from './WellbeingScreen';
import { FamilySyncScreen } from './FamilySyncScreen';
import { AccountSettingsScreen } from './AccountSettingsScreen';
import { SecurityPermissionsScreen } from './SecurityPermissionsScreen';
import { ShareProfileBottomSheet } from './ShareProfileBottomSheet';
import { PrivateAccountScreen } from './PrivateAccountScreen';
import { BlockedAccountsScreen } from './BlockedAccountsScreen';
import { MentionsSettingsScreen } from './MentionsSettingsScreen';
import { CommentsSettingsScreen } from './CommentsSettingsScreen';
import { DirectMessagesSettingsScreen } from './DirectMessagesSettingsScreen';
import { ReuseContentScreen } from './ReuseContentScreen';
import { DownloadsSettingsScreen } from './DownloadsSettingsScreen';
import { ViewersSettingsScreen } from './ViewersSettingsScreen';
import { MusicSettingsScreen } from './MusicSettingsScreen';
import { InboxSettingsScreen } from './InboxSettingsScreen';
import { AudienceControlScreen } from './AudienceControlScreen';
import { AdsSettingsScreen } from './AdsSettingsScreen';
import { PlaybackSettingsScreen } from './PlaybackSettingsScreen';
import { DisplaySettingsScreen } from './DisplaySettingsScreen';
import { LanguageSettingsScreen } from './LanguageSettingsScreen';
import { AccessibilitySettingsScreen } from './AccessibilitySettingsScreen';
import { ContactsLocationSettingsScreen } from './ContactsLocationSettingsScreen';
import { LiteModeScreen } from './LiteModeScreen';
import { DataSaverScreen } from './DataSaverScreen';
import { ClearSpaceScreen } from './ClearSpaceScreen';
import { WallpaperSettingsScreen } from './WallpaperSettingsScreen';
import { HelpCenterScreen } from './HelpCenterScreen';
import { PrivacyPolicyScreen } from './PrivacyPolicyScreen';
import { TermsOfServiceScreen } from './TermsOfServiceScreen';
import { SwitchAccountBottomSheet } from './SwitchAccountBottomSheet';
import { BalanceScreen } from './BalanceScreen';
import { GetCoinsScreen } from './GetCoinsScreen';
import { UserAccount } from '../hooks/useAuthProvider';
import {
  AudiencePrivacyValue,
  PrivacyAudienceBottomSheet,
} from './PrivacyAudienceBottomSheet';

interface SettingsPrivacyScreenProps {
  activeHandle?: string;
  avatarUrl?: string;
  savedAccounts?: UserAccount[];
  currentUser?: UserAccount | null;
  onSwitchAccount?: (account: UserAccount) => void;
  onAddAccount?: () => void;
  onDeleteAccount?: (account: UserAccount) => void;
  onBack: () => void;
  onSignOut: () => void;
  onOpenActivityCenter?: () => void;
  onOpenOfflineVideos?: () => void;
  onOpenQrProfile?: () => void;
  onNotify?: (message: string) => void;
}

interface SettingsItemProps {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  trailingText?: string;
  trailingAvatarUrl?: string;
  isDestructive?: boolean;
  onTap: () => void;
}

const SettingsItem: React.FC<SettingsItemProps> = ({
  icon: Icon,
  title,
  trailingText,
  trailingAvatarUrl,
  isDestructive = false,
  onTap,
}) => {
  return (
    <button
      type="button"
      onClick={onTap}
      className="flex w-full items-center justify-between px-4 py-3.5 text-left transition-colors hover:bg-white/5 active:bg-white/10"
    >
      <div className="flex min-w-0 items-center gap-3.5 pr-3">
        <Icon
          className={`h-[19px] w-[19px] shrink-0 ${
            isDestructive ? 'text-rose-400' : 'text-zinc-200'
          }`}
        />
        <span
          className={`truncate text-[14px] font-medium ${
            isDestructive ? 'text-rose-400' : 'text-zinc-100'
          }`}
        >
          {title}
        </span>
      </div>

      <div className="flex shrink-0 items-center gap-2">
        {trailingText && (
          <span className="text-xs font-normal text-zinc-400">
            {trailingText}
          </span>
        )}
        {trailingAvatarUrl && (
          <img
            src={trailingAvatarUrl}
            alt="Avatar de cuenta"
            className="h-6 w-6 rounded-full border border-white/15 object-cover"
          />
        )}
        <ChevronRight className="h-4 w-4 text-zinc-500" />
      </div>
    </button>
  );
};

interface SettingsSectionProps {
  title: string;
  children: React.ReactNode;
}

const SettingsSection: React.FC<SettingsSectionProps> = ({
  title,
  children,
}) => (
  <section className="px-4 pt-5">
    <h2 className="mb-2 px-1 text-xs font-semibold tracking-wide text-zinc-400">
      {title}
    </h2>
    <div className="divide-y divide-white/5 overflow-hidden rounded-xl bg-[#1C1C1E]">
      {children}
    </div>
  </section>
);

export const SettingsPrivacyScreen: React.FC<SettingsPrivacyScreenProps> = ({
  activeHandle = 'gabriel_12343',
  avatarUrl = '/src/assets/images/avatar_creator_mateo_1794604321715.jpg',
  savedAccounts,
  currentUser,
  onSwitchAccount,
  onAddAccount,
  onDeleteAccount,
  onBack,
  onSignOut,
  onOpenActivityCenter,
  onOpenOfflineVideos,
  onNotify,
}) => {
  const [showContentPreferences, setShowContentPreferences] = useState(false);
  const [showNotificationsSettings, setShowNotificationsSettings] = useState(false);
  const [showWellbeing, setShowWellbeing] = useState(false);
  const [showFamilySync, setShowFamilySync] = useState(false);
  const [showAccountSettings, setShowAccountSettings] = useState(false);
  const [showSecurityPermissions, setShowSecurityPermissions] = useState(false);
  const [showPrivateAccount, setShowPrivateAccount] = useState(false);
  const [showBlockedAccounts, setShowBlockedAccounts] = useState(false);
  const [showMentionsSettings, setShowMentionsSettings] = useState(false);
  const [showCommentsSettings, setShowCommentsSettings] = useState(false);
  const [showDirectMessagesSettings, setShowDirectMessagesSettings] = useState(false);
  const [showReuseContent, setShowReuseContent] = useState(false);
  const [showDownloadsSettings, setShowDownloadsSettings] = useState(false);
  const [downloadsEnabled, setDownloadsEnabled] = useState(true);
  const [showViewersSettings, setShowViewersSettings] = useState(false);
  const [viewersEnabled, setViewersEnabled] = useState(true);
  const [showMusicSettings, setShowMusicSettings] = useState(false);
  const [showInboxSettings, setShowInboxSettings] = useState(false);
  const [showAudienceControl, setShowAudienceControl] = useState(false);
  const [showAdsSettings, setShowAdsSettings] = useState(false);
  const [showPlaybackSettings, setShowPlaybackSettings] = useState(false);
  const [showDisplaySettings, setShowDisplaySettings] = useState(false);
  const [showLanguageSettings, setShowLanguageSettings] = useState(false);
  const [showAccessibilitySettings, setShowAccessibilitySettings] = useState(false);
  const [showContactsLocationSettings, setShowContactsLocationSettings] = useState(false);
  const [showLiteMode, setShowLiteMode] = useState(false);
  const [liteModeEnabled, setLiteModeEnabled] = useState(true);
  const [showDataSaver, setShowDataSaver] = useState(false);
  const [showClearSpace, setShowClearSpace] = useState(false);
  const [showWallpaperSettings, setShowWallpaperSettings] = useState(false);
  const [showHelpCenter, setShowHelpCenter] = useState(false);
  const [showPrivacyPolicy, setShowPrivacyPolicy] = useState(false);
  const [showTermsOfService, setShowTermsOfService] = useState(false);
  const [followingListPrivacy, setFollowingListPrivacy] =
    useState<AudiencePrivacyValue>('Solo tú');
  const [likedVideosPrivacy, setLikedVideosPrivacy] =
    useState<AudiencePrivacyValue>('Solo tú');
  const [activeAudienceSheet, setActiveAudienceSheet] = useState<
    'following' | 'liked' | null
  >(null);
  const [showShareProfileSheet, setShowShareProfileSheet] = useState(false);
  const [showSwitchAccountSheet, setShowSwitchAccountSheet] = useState(false);
  const [showDeleteAccountDialog, setShowDeleteAccountDialog] = useState(false);
  const [showBalance, setShowBalance] = useState(false);
  const [showGetCoins, setShowGetCoins] = useState(false);

  const fallbackAccounts: UserAccount[] = [
    {
      id: 'acc-gabriel',
      username: 'gabriel_12343',
      displayName: 'Eloy',
      email: 'gabriel_12343@viroklipz.app',
      avatarUrl,
      unreadCount: 0,
    },
    {
      id: 'acc-eloy',
      username: 'eloy_p79',
      displayName: 'Eloy Palma',
      email: 'eloy_p79@viroklipz.app',
      avatarUrl: '/src/assets/images/avatar_creator_lucas_1794604322245.jpg',
      unreadCount: 1,
    },
  ];

  const accountsList = savedAccounts && savedAccounts.length > 0 ? savedAccounts : fallbackAccounts;
  const resolvedCurrentUser =
    currentUser ??
    accountsList.find(
      (acc) => acc.username === activeHandle.replace(/^@/, '')
    ) ??
    accountsList[0];

  const notifyItem = (title: string) => {
    onNotify?.(`Ajustes: ${title}`);
  };

  if (showContentPreferences) {
    return (
      <ContentPreferencesScreen
        onBack={() => setShowContentPreferences(false)}
        onNotify={onNotify}
      />
    );
  }

  if (showNotificationsSettings) {
    return (
      <NotificationsSettingsScreen
        onBack={() => setShowNotificationsSettings(false)}
        onNotify={onNotify}
      />
    );
  }

  if (showWellbeing) {
    return (
      <WellbeingScreen
        avatarUrl={avatarUrl}
        onBack={() => setShowWellbeing(false)}
        onNotify={onNotify}
      />
    );
  }

  if (showFamilySync) {
    return (
      <FamilySyncScreen
        onBack={() => setShowFamilySync(false)}
        onNotify={onNotify}
      />
    );
  }

  if (showAccountSettings) {
    return (
      <AccountSettingsScreen
        onBack={() => setShowAccountSettings(false)}
        onNotify={onNotify}
      />
    );
  }

  if (showSecurityPermissions) {
    return (
      <SecurityPermissionsScreen
        activeHandle={activeHandle}
        onBack={() => setShowSecurityPermissions(false)}
        onNotify={onNotify}
      />
    );
  }

  if (showPrivateAccount) {
    return (
      <PrivateAccountScreen
        onBack={() => setShowPrivateAccount(false)}
        onNotify={onNotify}
      />
    );
  }

  if (showBlockedAccounts) {
    return (
      <BlockedAccountsScreen onBack={() => setShowBlockedAccounts(false)} />
    );
  }

  if (showMentionsSettings) {
    return (
      <MentionsSettingsScreen
        onBack={() => setShowMentionsSettings(false)}
        onNotify={onNotify}
      />
    );
  }

  if (showCommentsSettings) {
    return (
      <CommentsSettingsScreen
        onBack={() => setShowCommentsSettings(false)}
        onNotify={onNotify}
      />
    );
  }

  if (showDirectMessagesSettings) {
    return (
      <DirectMessagesSettingsScreen
        onBack={() => setShowDirectMessagesSettings(false)}
        onNotify={onNotify}
      />
    );
  }

  if (showReuseContent) {
    return (
      <ReuseContentScreen
        onBack={() => setShowReuseContent(false)}
        onNotify={onNotify}
      />
    );
  }

  if (showDownloadsSettings) {
    return (
      <DownloadsSettingsScreen
        initialEnabled={downloadsEnabled}
        onBack={() => setShowDownloadsSettings(false)}
        onToggleEnabled={setDownloadsEnabled}
        onNotify={onNotify}
      />
    );
  }

  if (showViewersSettings) {
    return (
      <ViewersSettingsScreen
        initialEnabled={viewersEnabled}
        onBack={() => setShowViewersSettings(false)}
        onToggleEnabled={setViewersEnabled}
        onNotify={onNotify}
      />
    );
  }

  if (showMusicSettings) {
    return (
      <MusicSettingsScreen
        onBack={() => setShowMusicSettings(false)}
        onNotify={onNotify}
      />
    );
  }

  if (showInboxSettings) {
    return (
      <InboxSettingsScreen
        onBack={() => setShowInboxSettings(false)}
        onNotify={onNotify}
      />
    );
  }

  if (showAudienceControl) {
    return (
      <AudienceControlScreen
        onBack={() => setShowAudienceControl(false)}
        onNotify={onNotify}
      />
    );
  }

  if (showAdsSettings) {
    return (
      <AdsSettingsScreen
        onBack={() => setShowAdsSettings(false)}
        onNotify={onNotify}
      />
    );
  }

  if (showPlaybackSettings) {
    return (
      <PlaybackSettingsScreen
        onBack={() => setShowPlaybackSettings(false)}
        onNotify={onNotify}
      />
    );
  }

  if (showDisplaySettings) {
    return (
      <DisplaySettingsScreen
        onBack={() => setShowDisplaySettings(false)}
        onNotify={onNotify}
      />
    );
  }

  if (showLanguageSettings) {
    return (
      <LanguageSettingsScreen
        onBack={() => setShowLanguageSettings(false)}
        onNotify={onNotify}
      />
    );
  }

  if (showAccessibilitySettings) {
    return (
      <AccessibilitySettingsScreen
        onBack={() => setShowAccessibilitySettings(false)}
        onNotify={onNotify}
      />
    );
  }

  if (showContactsLocationSettings) {
    return (
      <ContactsLocationSettingsScreen
        onBack={() => setShowContactsLocationSettings(false)}
        onNotify={onNotify}
      />
    );
  }

  if (showLiteMode) {
    return (
      <LiteModeScreen
        initialEnabled={liteModeEnabled}
        onToggleEnabled={setLiteModeEnabled}
        onBack={() => setShowLiteMode(false)}
        onNotify={onNotify}
      />
    );
  }

  if (showDataSaver) {
    return (
      <DataSaverScreen
        onBack={() => setShowDataSaver(false)}
        onNotify={onNotify}
      />
    );
  }

  if (showClearSpace) {
    return (
      <ClearSpaceScreen
        onBack={() => setShowClearSpace(false)}
        onNotify={onNotify}
      />
    );
  }

  if (showWallpaperSettings) {
    return (
      <WallpaperSettingsScreen
        onBack={() => setShowWallpaperSettings(false)}
        onNotify={onNotify}
      />
    );
  }

  if (showHelpCenter) {
    return (
      <HelpCenterScreen
        onBack={() => setShowHelpCenter(false)}
        onNotify={onNotify}
      />
    );
  }

  if (showPrivacyPolicy) {
    return (
      <PrivacyPolicyScreen
        onBack={() => setShowPrivacyPolicy(false)}
      />
    );
  }

  if (showTermsOfService) {
    return (
      <TermsOfServiceScreen
        onBack={() => setShowTermsOfService(false)}
      />
    );
  }

  if (showGetCoins) {
    return (
      <GetCoinsScreen
        onBack={() => setShowGetCoins(false)}
        onNotify={onNotify}
      />
    );
  }

  if (showBalance) {
    return (
      <BalanceScreen
        onBack={() => setShowBalance(false)}
        onOpenGetCoins={() => {
          setShowBalance(false);
          setShowGetCoins(true);
        }}
        onNotify={onNotify}
      />
    );
  }

  return (
    <div className="relative flex h-full w-full flex-col bg-[#121212] text-white select-none overflow-hidden">
      {/* AppBar: Flecha de atrás a la izquierda y título centrado */}
      <header className="relative flex h-12 shrink-0 items-center justify-center border-b border-white/10 bg-[#121212] px-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Atrás"
          className="absolute left-2 flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="text-[15px] font-bold text-white">
          Ajustes y privacidad
        </h1>
      </header>

      {/* Cuerpo scrolleable */}
      <div className="flex-1 min-h-0 overflow-y-auto pb-8 no-scrollbar">
        {/* 1. Actividad */}
        <SettingsSection title="Actividad">
          <SettingsItem
            icon={FolderKanban}
            title="Administrar publicaciones"
            onTap={() => notifyItem('Administrar publicaciones')}
          />
          <SettingsItem
            icon={Sparkles}
            title="Preferencias de contenido"
            onTap={() => setShowContentPreferences(true)}
          />
          <SettingsItem
            icon={Radio}
            title="LIVE"
            onTap={() => notifyItem('LIVE')}
          />
          <SettingsItem
            icon={Bell}
            title="Notificaciones"
            onTap={() => setShowNotificationsSettings(true)}
          />
          <SettingsItem
            icon={Clock}
            title="Tiempo y bienestar"
            onTap={() => setShowWellbeing(true)}
          />
          <SettingsItem
            icon={Users}
            title="Sincronización familiar"
            onTap={() => setShowFamilySync(true)}
          />
        </SettingsSection>

        {/* 2. Cuenta */}
        <SettingsSection title="Cuenta">
          <SettingsItem
            icon={User}
            title="Cuenta"
            onTap={() => setShowAccountSettings(true)}
          />
          <SettingsItem
            icon={Wallet}
            title="Saldo"
            trailingText="0.00 VES"
            onTap={() => setShowBalance(true)}
          />
          <SettingsItem
            icon={Coins}
            title="Obtener Monedas"
            onTap={() => setShowGetCoins(true)}
          />
          <SettingsItem
            icon={Shield}
            title="Seguridad y permisos"
            onTap={() => setShowSecurityPermissions(true)}
          />
          <SettingsItem
            icon={Share2}
            title="Compartir el perfil"
            onTap={() => setShowShareProfileSheet(true)}
          />
        </SettingsSection>

        {/* 3. Visibilidad */}
        <SettingsSection title="Visibilidad">
          <SettingsItem
            icon={Lock}
            title="Cuenta privada"
            onTap={() => setShowPrivateAccount(true)}
          />
          <SettingsItem
            icon={Ban}
            title="Cuentas bloqueadas"
            onTap={() => setShowBlockedAccounts(true)}
          />
        </SettingsSection>

        {/* 4. Interacciones */}
        <SettingsSection title="Interacciones">
          <SettingsItem
            icon={MessageCircle}
            title="Comentarios"
            onTap={() => setShowCommentsSettings(true)}
          />
          <SettingsItem
            icon={AtSign}
            title="Menciones"
            onTap={() => setShowMentionsSettings(true)}
          />
          <SettingsItem
            icon={Send}
            title="Mensajes directos"
            onTap={() => setShowDirectMessagesSettings(true)}
          />
          <SettingsItem
            icon={Repeat2}
            title="Reutilizar contenido"
            onTap={() => setShowReuseContent(true)}
          />
          <SettingsItem
            icon={Download}
            title="Descargas"
            trailingText={downloadsEnabled ? 'Activado' : 'Desactivado'}
            onTap={() => setShowDownloadsSettings(true)}
          />
          <SettingsItem
            icon={UserCheck}
            title="Lista Siguiendo"
            trailingText={followingListPrivacy}
            onTap={() => setActiveAudienceSheet('following')}
          />
          <SettingsItem
            icon={Heart}
            title="Videos que te gustaron"
            trailingText={likedVideosPrivacy}
            onTap={() => setActiveAudienceSheet('liked')}
          />
          <SettingsItem
            icon={Eye}
            title="Espectadores"
            trailingText={viewersEnabled ? 'Activado' : 'Desactivado'}
            onTap={() => setShowViewersSettings(true)}
          />
        </SettingsSection>

        {/* 5. Contenido y pantalla */}
        <SettingsSection title="Contenido y pantalla">
          <SettingsItem
            icon={Music}
            title="Música"
            onTap={() => setShowMusicSettings(true)}
          />
          <SettingsItem
            icon={MessageSquare}
            title="Bandeja de entrada y mensajes"
            onTap={() => setShowInboxSettings(true)}
          />
          <SettingsItem
            icon={History}
            title="Centro de actividades"
            onTap={() =>
              onOpenActivityCenter
                ? onOpenActivityCenter()
                : notifyItem('Centro de actividades')
            }
          />
          <SettingsItem
            icon={Compass}
            title="Control del público"
            onTap={() => setShowAudienceControl(true)}
          />
          <SettingsItem
            icon={Megaphone}
            title="Anuncios"
            onTap={() => setShowAdsSettings(true)}
          />
          <SettingsItem
            icon={PlaySquare}
            title="Reproducción"
            onTap={() => setShowPlaybackSettings(true)}
          />
          <SettingsItem
            icon={Smartphone}
            title="Mostrar"
            onTap={() => setShowDisplaySettings(true)}
          />
          <SettingsItem
            icon={Globe}
            title="Idiomas"
            onTap={() => setShowLanguageSettings(true)}
          />
          <SettingsItem
            icon={Accessibility}
            title="Accesibilidad"
            onTap={() => setShowAccessibilitySettings(true)}
          />
          <SettingsItem
            icon={Contact}
            title="Contactos y ubicación"
            onTap={() => setShowContactsLocationSettings(true)}
          />
        </SettingsSection>

        {/* 6. Caché y datos móviles */}
        <SettingsSection title="Caché y datos móviles">
          <SettingsItem
            icon={CloudDownload}
            title="Videos sin conexión"
            onTap={() =>
              onOpenOfflineVideos
                ? onOpenOfflineVideos()
                : notifyItem('Videos sin conexión')
            }
          />
          <SettingsItem
            icon={Trash2}
            title="Liberar espacio"
            onTap={() => setShowClearSpace(true)}
          />
          <SettingsItem
            icon={Wifi}
            title="Ahorro de datos"
            onTap={() => setShowDataSaver(true)}
          />
          <SettingsItem
            icon={Image}
            title="Fondo de pantalla"
            onTap={() => setShowWallpaperSettings(true)}
          />
          <SettingsItem
            icon={Gauge}
            title="Modo lite"
            trailingText={liteModeEnabled ? 'Activado' : 'Desactivado'}
            onTap={() => setShowLiteMode(true)}
          />
        </SettingsSection>

        {/* 7. Ayuda e información */}
        <SettingsSection title="Ayuda e información">
          <SettingsItem
            icon={HelpCircle}
            title="Centro de ayuda"
            onTap={() => setShowHelpCenter(true)}
          />
          <SettingsItem
            icon={ShieldCheck}
            title="Centro de privacidad"
            onTap={() => setShowPrivacyPolicy(true)}
          />
          <SettingsItem
            icon={FileText}
            title="Términos y políticas"
            onTap={() => setShowTermsOfService(true)}
          />
        </SettingsSection>

        {/* 8. Inicio de sesión */}
        <SettingsSection title="Inicio de sesión">
          <SettingsItem
            icon={Bookmark}
            title="Cambiar de cuenta"
            trailingAvatarUrl={resolvedCurrentUser?.avatarUrl ?? avatarUrl}
            onTap={() => setShowSwitchAccountSheet(true)}
          />
          <SettingsItem
            icon={LogOut}
            title="Cerrar sesión"
            isDestructive
            onTap={onSignOut}
          />
          <SettingsItem
            icon={Trash2}
            title="Eliminar cuenta"
            isDestructive
            onTap={() => setShowDeleteAccountDialog(true)}
          />
        </SettingsSection>

        {/* Versión al final */}
        <div className="pt-7 pb-4 text-center">
          <p className="text-[11px] font-medium tracking-wide text-zinc-500">
            v47.7.3(202407030)
          </p>
        </div>
      </div>

      {/* Bottom Sheet "Cambiar de cuenta" */}
      <SwitchAccountBottomSheet
        open={showSwitchAccountSheet}
        accounts={accountsList}
        currentUser={resolvedCurrentUser}
        onSelectAccount={(account) => {
          onSwitchAccount?.(account);
          setShowSwitchAccountSheet(false);
          onNotify?.(`Cuenta activa: @${account.username}`);
        }}
        onAddAccount={() => {
          setShowSwitchAccountSheet(false);
          if (onAddAccount) {
            onAddAccount();
          } else {
            onNotify?.('Función para añadir cuenta');
          }
        }}
        onClose={() => setShowSwitchAccountSheet(false)}
      />

      {/* Diálogo oscuro de confirmación "¿Eliminar cuenta?" */}
      {showDeleteAccountDialog && (
        <div
          className="absolute inset-0 z-50 flex items-center justify-center bg-black/75 px-6 backdrop-blur-[2px]"
          onClick={() => setShowDeleteAccountDialog(false)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-[320px] rounded-2xl border border-white/10 bg-[#1E1E1E] p-5 text-white shadow-2xl"
          >
            <h3 className="text-base font-bold text-white">
              ¿Eliminar cuenta?
            </h3>
            <p className="mt-2.5 text-xs leading-relaxed text-zinc-300">
              Esta acción es permanente y no se puede deshacer. Perderás todos
              tus videos, seguidores y mensajes.
            </p>
            <div className="mt-5 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setShowDeleteAccountDialog(false)}
                className="rounded-lg bg-zinc-700 px-4 py-2 text-xs font-semibold text-zinc-200 transition-colors hover:bg-zinc-600"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowDeleteAccountDialog(false);
                  if (onDeleteAccount && resolvedCurrentUser) {
                    onDeleteAccount(resolvedCurrentUser);
                  } else {
                    onSignOut();
                  }
                }}
                className="rounded-lg bg-[#FE2C55] px-4 py-2 text-xs font-bold text-white transition-opacity hover:opacity-90"
              >
                Eliminar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Bottom Sheet "Compartir el perfil" (fondo claro) */}
      {showShareProfileSheet && (
        <ShareProfileBottomSheet
          profileHandle={activeHandle}
          onClose={() => setShowShareProfileSheet(false)}
          onNotify={onNotify}
        />
      )}

      {/* Bottom Sheet blanco para "Lista Siguiendo" */}
      {activeAudienceSheet === 'following' && (
        <PrivacyAudienceBottomSheet
          title="Lista Siguiendo"
          question="¿Quién puede ver la lista de cuentas que sigues?"
          footerNote="Solo las personas autorizadas podrán consultar los perfiles que sigues desde tu perfil."
          selectedValue={followingListPrivacy}
          onSelect={(val) => {
            setFollowingListPrivacy(val);
            onNotify?.(`Lista Siguiendo: ${val}`);
          }}
          onClose={() => setActiveAudienceSheet(null)}
        />
      )}

      {/* Bottom Sheet blanco para "Videos que te gustaron" */}
      {activeAudienceSheet === 'liked' && (
        <PrivacyAudienceBottomSheet
          title="Videos que te gustaron"
          question="Permitir que los videos a los que diste me gusta sean visibles para"
          footerNote="Incluso si esta lista es privada, los creadores pueden ver quién reaccionó a sus publicaciones."
          selectedValue={likedVideosPrivacy}
          onSelect={(val) => {
            setLikedVideosPrivacy(val);
            onNotify?.(`Videos que te gustaron: ${val}`);
          }}
          onClose={() => setActiveAudienceSheet(null)}
        />
      )}
    </div>
  );
};
