import React from 'react';
import { ArrowLeft, Info, LogIn } from 'lucide-react';

interface AccountEventItem {
  id: string;
  device: string;
  location: string;
  time: string;
  group: string;
}

const ACCOUNT_EVENTS: AccountEventItem[] = [
  {
    id: 'ac-1',
    device: 'iPhone 15 Pro',
    location: 'Madrid, España',
    time: '10:15 a. m.',
    group: 'Hoy',
  },
  {
    id: 'ac-2',
    device: 'Samsung Galaxy S24',
    location: 'Barcelona, España',
    time: '8:47 p. m.',
    group: '12 de noviembre',
  },
  {
    id: 'ac-3',
    device: 'Navegador Web (macOS)',
    location: 'Madrid, España',
    time: '6:12 p. m.',
    group: '5 de noviembre',
  },
];

interface AccountHistoryScreenProps {
  onBack: () => void;
}

export const AccountHistoryScreen: React.FC<AccountHistoryScreenProps> = ({
  onBack,
}) => {
  const groups = Array.from(new Set(ACCOUNT_EVENTS.map((item) => item.group)));

  return (
    <div className="flex h-full w-full flex-col bg-[#121212] text-white select-none overflow-hidden">
      {/* AppBar */}
      <header className="flex h-12 shrink-0 items-center justify-between border-b border-white/10 px-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Volver al centro de actividades"
          className="flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>

        <h1 className="text-[15px] font-bold text-white">
          Historial de la cuenta
        </h1>

        <div className="w-10" />
      </header>

      <div className="flex-1 min-h-0 overflow-y-auto px-4 pb-6 pt-3 no-scrollbar">
        {/* Contenedor de advertencia gris oscuro */}
        <div className="flex items-start gap-2.5 rounded-xl border border-white/10 bg-[#1E1E22] p-3.5 text-xs leading-relaxed text-zinc-300">
          <Info className="mt-0.5 h-4 w-4 shrink-0 text-zinc-400" />
          <p>
            Se mostrará el historial de la cuenta correspondiente al último año.
            Revisa tus inicios de sesión recientes para mantener tu cuenta
            protegida.
          </p>
        </div>

        {/* Lista agrupada por fechas con tarjetas oscuras */}
        {groups.map((group) => {
          const entries = ACCOUNT_EVENTS.filter((item) => item.group === group);
          return (
            <section key={group} className="mt-4">
              <h2 className="pb-2 text-xs font-semibold uppercase tracking-wide text-zinc-400">
                {group}
              </h2>
              <div className="space-y-2.5">
                {entries.map((entry) => (
                  <div
                    key={entry.id}
                    className="rounded-xl border border-white/10 bg-[#1C1C1E] p-3.5 shadow-sm"
                  >
                    <div className="flex items-start gap-3">
                      <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-white/10 text-zinc-200">
                        <LogIn className="h-4 w-4" />
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-bold text-white">
                          Inicio de sesión
                        </p>
                        <p className="mt-1 text-xs leading-relaxed text-zinc-300">
                          Iniciaste sesión en tu cuenta desde un{' '}
                          <span className="font-semibold text-white">
                            {entry.device}
                          </span>{' '}
                          ubicado en{' '}
                          <span className="font-semibold text-white">
                            {entry.location}
                          </span>
                          .
                        </p>
                        <p className="mt-1.5 text-[11px] text-zinc-400">
                          {entry.time}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          );
        })}
      </div>
    </div>
  );
};
