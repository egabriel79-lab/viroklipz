import React, { useMemo, useState } from 'react';
import { ArrowLeft, Heart, Search, Volume2, X } from 'lucide-react';

interface SearchWallpaperScreenProps {
  onBack: () => void;
  onNotify?: (message: string) => void;
}

type WallpaperTab = 'Tendencias' | 'Videos' | 'Fotos' | 'Usuarios';

interface WallpaperItem {
  id: string;
  title: string;
  author: string;
  likes: string;
  isVideo: boolean;
  category: WallpaperTab;
  imageUrl: string;
}

const WALLPAPER_ITEMS: WallpaperItem[] = [
  {
    id: 'wp1',
    title: 'Cyber Astronaut',
    author: '@neon_pulse',
    likes: '18.4K',
    isVideo: true,
    category: 'Tendencias',
    imageUrl: '/src/assets/images/hero_cyber_astronaut_1794614449948.jpg',
  },
  {
    id: 'wp2',
    title: 'Templo Dorado',
    author: '@zen_visuals',
    likes: '9.2K',
    isVideo: true,
    category: 'Videos',
    imageUrl: '/src/assets/images/story_hinduismo_temple_1794607243976.jpg',
  },
  {
    id: 'wp3',
    title: 'Ciudad Nocturna 4K',
    author: '@mateo_fx',
    likes: '24.1K',
    isVideo: true,
    category: 'Tendencias',
    imageUrl: '/src/assets/images/avatar_creator_mateo_1794604321715.jpg',
  },
  {
    id: 'wp4',
    title: 'Aesthetic Sunset',
    author: '@valeria_art',
    likes: '12.7K',
    isVideo: false,
    category: 'Fotos',
    imageUrl: '/src/assets/images/avatar_creator_valeria_1794604321625.jpg',
  },
  {
    id: 'wp5',
    title: 'Neon Motion Loop',
    author: '@diego_clips',
    likes: '31.5K',
    isVideo: true,
    category: 'Videos',
    imageUrl: '/src/assets/images/avatar_creator_diego_1794604323122.jpg',
  },
  {
    id: 'wp6',
    title: 'Minimal Aura',
    author: '@sofia_studio',
    likes: '7.8K',
    isVideo: false,
    category: 'Fotos',
    imageUrl: '/src/assets/images/avatar_creator_sofia_1794604322145.jpg',
  },
];

const TABS: WallpaperTab[] = ['Tendencias', 'Videos', 'Fotos', 'Usuarios'];

export const SearchWallpaperScreen: React.FC<SearchWallpaperScreenProps> = ({
  onBack,
  onNotify,
}) => {
  const [query, setQuery] = useState('Live Wallpaper');
  const [activeTab, setActiveTab] = useState<WallpaperTab>('Tendencias');

  const filteredItems = useMemo(() => {
    const base =
      activeTab === 'Tendencias' || activeTab === 'Usuarios'
        ? WALLPAPER_ITEMS
        : WALLPAPER_ITEMS.filter((item) => item.category === activeTab);

    const normalized = query.trim().toLowerCase();
    if (!normalized || normalized === 'live wallpaper') {
      return base;
    }

    return base.filter(
      (item) =>
        item.title.toLowerCase().includes(normalized) ||
        item.author.toLowerCase().includes(normalized)
    );
  }, [activeTab, query]);

  return (
    <div className="flex h-full w-full flex-col bg-[#121212] text-white select-none overflow-hidden">
      {/* AppBar con barra de búsqueda */}
      <header className="flex shrink-0 items-center gap-2 border-b border-white/10 bg-[#121212] px-2 py-2.5">
        <button
          type="button"
          onClick={onBack}
          aria-label="Atrás"
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>

        <div className="relative flex flex-1 items-center rounded-xl bg-[#1E1E1E] px-3 py-1.5">
          <Search className="mr-2 h-4 w-4 shrink-0 text-zinc-400" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Live Wallpaper"
            className="w-full bg-transparent text-xs text-white placeholder-zinc-500 focus:outline-none"
          />
          {query.length > 0 && (
            <button
              type="button"
              onClick={() => setQuery('')}
              aria-label="Limpiar búsqueda"
              className="ml-1 text-zinc-400 hover:text-white"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          )}
        </div>
      </header>

      {/* TabBar */}
      <div className="flex shrink-0 border-b border-white/10 bg-[#121212]">
        {TABS.map((tab) => {
          const isActive = activeTab === tab;
          return (
            <button
              key={tab}
              type="button"
              onClick={() => setActiveTab(tab)}
              className={`relative flex-1 py-2.5 text-center text-xs font-semibold transition-colors ${
                isActive ? 'text-white' : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              {tab}
              {isActive && (
                <span className="absolute bottom-0 left-3 right-3 h-0.5 rounded-full bg-[#E91E63]" />
              )}
            </button>
          );
        })}
      </div>

      {/* GridView 2 columnas */}
      <div className="flex-1 min-h-0 overflow-y-auto p-3 no-scrollbar">
        <div className="grid grid-cols-2 gap-3">
          {filteredItems.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() =>
                onNotify?.(`Fondo seleccionado: ${item.title} (${item.author})`)
              }
              className="group overflow-hidden rounded-xl bg-[#1E1E1E] text-left transition-transform active:scale-[0.98]"
            >
              <div className="relative aspect-[3/4] w-full overflow-hidden bg-zinc-800">
                <img
                  src={item.imageUrl}
                  alt={item.title}
                  className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-transparent to-transparent" />
                {item.isVideo && (
                  <div className="absolute right-2 top-2 flex h-6 w-6 items-center justify-center rounded-full bg-black/55 text-white backdrop-blur-sm">
                    <Volume2 className="h-3.5 w-3.5" />
                  </div>
                )}
              </div>

              <div className="p-2.5">
                <p className="truncate text-xs font-semibold text-white">
                  {item.title}
                </p>
                <div className="mt-1.5 flex items-center justify-between gap-1 text-[11px] text-zinc-400">
                  <span className="truncate">{item.author}</span>
                  <span className="flex shrink-0 items-center gap-1">
                    <Heart className="h-3 w-3 text-[#E91E63]" />
                    {item.likes}
                  </span>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
