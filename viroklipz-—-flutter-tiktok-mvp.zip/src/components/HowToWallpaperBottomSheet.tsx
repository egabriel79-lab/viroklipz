import React from 'react';
import {
  Play,
  Share2,
  X,
  Heart,
  MessageCircle,
  Bookmark,
  Wallpaper,
} from 'lucide-react';

interface HowToWallpaperBottomSheetProps {
  open: boolean;
  onClose: () => void;
}

export const HowToWallpaperBottomSheet: React.FC<
  HowToWallpaperBottomSheetProps
> = ({ open, onClose }) => {
  if (!open) return null;

  return (
    <div className="absolute inset-0 z-50 flex items-end bg-black/70 backdrop-blur-[2px]">
      <div className="w-full max-h-[88%] flex flex-col rounded-t-2xl bg-[#1E1E1E] text-white shadow-2xl border-t border-white/10">
        {/* Handle bar */}
        <div className="flex justify-center pt-2.5 pb-1">
          <div className="h-1 w-10 rounded-full bg-zinc-600" />
        </div>

        {/* Header */}
        <div className="relative flex items-center justify-center border-b border-white/10 px-4 py-3">
          <h2 className="pr-7 text-center text-[15px] font-bold text-white">
            Cómo establecer un fondo de pantalla
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Cerrar"
            className="absolute right-3 flex h-8 w-8 items-center justify-center rounded-full text-zinc-300 transition-colors hover:bg-white/10"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Pasos */}
        <div className="flex-1 overflow-y-auto px-4 py-4 space-y-5 no-scrollbar">
          {/* Paso 1 */}
          <div>
            <div className="flex items-center gap-1.5 text-[13px] font-medium text-zinc-100">
              <span>1. Pulsa</span>
              <span className="inline-flex h-6 w-6 items-center justify-center rounded-full bg-[#27272A] text-[#E91E63]">
                <Share2 className="h-3.5 w-3.5" />
              </span>
              <span>en un video</span>
            </div>

            {/* Placeholder simulando el feed */}
            <div className="relative mt-2.5 h-36 w-full overflow-hidden rounded-xl border border-white/10 bg-gradient-to-br from-zinc-800 via-zinc-900 to-black p-3">
              <div className="absolute bottom-3 left-3 space-y-1.5">
                <div className="h-2.5 w-24 rounded bg-white/25" />
                <div className="h-2 w-36 rounded bg-white/15" />
              </div>
              <div className="absolute bottom-3 right-3 flex flex-col items-center gap-2">
                <Heart className="h-4 w-4 text-white/60" />
                <MessageCircle className="h-4 w-4 text-white/60" />
                <Bookmark className="h-4 w-4 text-white/60" />
                <div className="flex h-7 w-7 items-center justify-center rounded-full bg-[#E91E63] text-white shadow-lg ring-2 ring-[#E91E63]/40">
                  <Share2 className="h-3.5 w-3.5" />
                </div>
              </div>
            </div>
          </div>

          {/* Paso 2 */}
          <div>
            <div className="flex flex-wrap items-center gap-1.5 text-[13px] font-medium text-zinc-100">
              <span>2. Pulsa</span>
              <span className="inline-flex h-6 w-6 items-center justify-center rounded-full bg-[#27272A] text-[#FF5722]">
                <Play className="h-3.5 w-3.5 fill-current" />
              </span>
              <span>para establecer este video como fondo</span>
            </div>

            {/* Placeholder de menú */}
            <div className="mt-2.5 rounded-xl border border-white/10 bg-[#141416] p-3">
              <div className="grid grid-cols-4 gap-2 text-center">
                {[
                  { label: 'Dúo', active: false },
                  { label: 'Guardar', active: false },
                  { label: 'Fondo', active: true },
                  { label: 'Más', active: false },
                ].map((item) => (
                  <div
                    key={item.label}
                    className={`flex flex-col items-center gap-1.5 rounded-lg py-2 ${
                      item.active
                        ? 'bg-[#E91E63]/15 ring-1 ring-[#E91E63]'
                        : 'bg-[#1E1E1E]'
                    }`}
                  >
                    <div
                      className={`flex h-8 w-8 items-center justify-center rounded-full ${
                        item.active
                          ? 'bg-[#E91E63] text-white'
                          : 'bg-zinc-700 text-zinc-300'
                      }`}
                    >
                      {item.active ? (
                        <Play className="h-3.5 w-3.5 fill-current" />
                      ) : (
                        <Wallpaper className="h-3.5 w-3.5" />
                      )}
                    </div>
                    <span className="text-[11px] font-medium text-zinc-200">
                      {item.label}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
