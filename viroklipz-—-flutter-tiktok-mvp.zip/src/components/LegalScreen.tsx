import React from 'react';
import { ArrowLeft } from 'lucide-react';

export const LEGAL_TEXTS = {
  termsAndConditions: `**TÉRMINOS Y CONDICIONES DE USO DE VIROKLIPZ**
Última actualización: Noviembre 2026

**1. Aceptación de los términos**
Al descargar, registrarte o utilizar la aplicación móvil Viroklipz, aceptas quedar vinculado por estos Términos y Condiciones de Uso y por nuestra Política de Privacidad. Si no estás de acuerdo con alguno de estos términos, por favor no utilices la plataforma.

**2. Elegibilidad y edad mínima**
Para crear una cuenta y publicar contenido en Viroklipz debes tener al menos 13 años de edad (o la edad mínima legal aplicable en tu país). Los usuarios menores de 18 años declaran contar con la autorización expresa de su padre, madre o tutor legal.

**3. Cuenta de usuario y seguridad**
Eres responsable de mantener la confidencialidad de tus credenciales de acceso y de toda actividad realizada desde tu cuenta. Debes notificarnos de inmediato si detectas un uso no autorizado de tu perfil.

**4. Contenido generado por los usuarios**
Conservas la titularidad de los videos, audios, descripciones y comentarios que publiques en Viroklipz. No obstante, al publicar contenido en la plataforma nos concedes una licencia mundial, no exclusiva y gratuita para alojarlo, reproducirlo y mostrarlo dentro de la aplicación.

Queda estrictamente prohibido publicar contenido que:
• Sea ilegal, difamatorio, violento, sexualmente explícito o promueva el odio.
• Infrinja derechos de autor, marcas comerciales o derechos de terceros.
• Suplante la identidad de otra persona o distribuya spam o software malicioso.

**5. Moderación y eliminación de cuenta**
Viroklipz se reserva el derecho de retirar contenido que infrinja las normas de la comunidad y de suspender o cancelar cuentas reincidentes. Puedes eliminar tu cuenta en cualquier momento desde el menú lateral en la opción "Eliminar cuenta".

**6. Funciones virtuales y modificaciones**
Los saldos, monedas o herramientas de estudio mostrados en la aplicación están sujetos a disponibilidad y pueden actualizarse o modificarse para mejorar el servicio.

**7. Contacto**
Si tienes dudas sobre estos Términos y Condiciones, puedes contactarnos a través del Centro de Ayuda dentro de la aplicación.`,

  privacyPolicy: `**POLÍTICA DE PRIVACIDAD DE VIROKLIPZ**
Última actualización: Noviembre 2026

**1. Información que recopilamos**
En Viroklipz respetamos tu privacidad y recopilamos únicamente los datos necesarios para brindarte el servicio:
• Datos de cuenta: correo electrónico, nombre de usuario, nombre visible, biografía y foto de perfil.
• Contenido publicado: videos, descripciones, hashtags, comentarios, "Me gusta" y relaciones de seguimiento.
• Datos técnicos: token de notificaciones push (FCM) para enviarte alertas de actividad cuando lo autorices.

**2. Uso de cámara, micrófono, galería y almacenamiento**
Viroklipz solicita acceso a la cámara, micrófono y galería del dispositivo únicamente cuando decides grabar un clip, seleccionar un video existente, escanear un código QR de perfil o guardar un video en tu galería. No grabamos ni accedemos a estos sensores en segundo plano sin tu acción directa.

**3. Finalidad del tratamiento de datos**
Utilizamos tu información para:
• Autenticar tu sesión de forma segura mediante Firebase Authentication.
• Almacenar y reproducir tus videos mediante Firebase Storage y Cloud Firestore.
• Mostrar tu perfil, seguidores y notificaciones en tiempo real.
• Prevenir abusos, spam y mantener la seguridad de la comunidad.

**4. Compartición de información**
No vendemos ni alquilamos tus datos personales a terceros. Tu nombre de usuario, avatar y videos públicos son visibles para otros usuarios de Viroklipz. Los proveedores de infraestructura (como Google Firebase) procesan los datos bajo estrictas medidas de seguridad y cifrado.

**5. Retención y eliminación de datos**
Conservamos tus datos mientras tu cuenta permanezca activa. Puedes actualizar tu perfil, revocar permisos del sistema operativo o eliminar permanentemente tu cuenta y datos asociados desde el menú lateral ("Eliminar cuenta").

**6. Privacidad de menores**
No recopilamos de manera consciente información personal de niños menores de la edad mínima legal sin el consentimiento de sus padres o tutores.

**7. Cambios en esta política**
Podemos actualizar esta Política de Privacidad periódicamente. Cualquier cambio relevante será notificado dentro de la aplicación.`,
};

interface LegalScreenProps {
  title: string;
  content: string;
  onBack: () => void;
}

function renderFormattedLine(line: string, lineIndex: number) {
  const parts = line.split(/(\*\*[^*]+\*\*)/g);
  return (
    <React.Fragment key={lineIndex}>
      {parts.map((part, idx) => {
        if (part.startsWith('**') && part.endsWith('**')) {
          return (
            <strong key={idx} className="font-bold text-white">
              {part.slice(2, -2)}
            </strong>
          );
        }
        return <span key={idx}>{part}</span>;
      })}
      {'\n'}
    </React.Fragment>
  );
}

export const LegalScreen: React.FC<LegalScreenProps> = ({
  title,
  content,
  onBack,
}) => {
  const lines = content.split('\n');

  return (
    <div className="flex h-full w-full flex-col overflow-hidden bg-[#121212] text-zinc-100 select-none">
      {/* AppBar oscura con flecha atrás */}
      <header className="flex h-12 shrink-0 items-center gap-2 border-b border-white/10 bg-[#121212] px-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Volver"
          className="flex h-9 w-9 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="truncate text-[15px] font-bold text-white">{title}</h1>
      </header>

      {/* SingleChildScrollView + Padding + Text */}
      <div className="no-scrollbar flex-1 min-h-0 overflow-y-auto px-5 py-5">
        <div className="whitespace-pre-line text-[13.5px] leading-[1.65] text-zinc-300 select-text">
          {lines.map((line, index) => renderFormattedLine(line, index))}
        </div>
      </div>
    </div>
  );
};
