import React, { useState } from 'react';
import { ArrowLeft, Check, Search, Trash2 } from 'lucide-react';

interface SearchEntry {
  id: string;
  query: string;
  time: string;
  group: string;
}

const INITIAL_SEARCHES: SearchEntry[] = [
  { id: 'sh-1', query: 'mi próximo auto', time: '10:31 p. m.', group: 'Ayer' },
  {
    id: 'sh-2',
    query: 'transiciones rápidas video vertical',
    time: '7:14 p. m.',
    group: 'Ayer',
  },
  {
    id: 'sh-3',
    query: 'beats lo-fi sin copyright',
    time: '4:05 p. m.',
    group: '12 de noviembre',
  },
  {
    id: 'sh-4',
    query: 'mejores cámaras 4k para vlogs',
    time: '11:20 a. m.',
    group: '12 de noviembre',
  },
  {
    id: 'sh-5',
    query: 'recetas fáciles en 5 minutos',
    time: '9:02 a. m.',
    group: '12 de noviembre',
  },
];

interface SearchHistoryScreenProps {
  onBack: () => void;
  onNotify?: (message: string) => void;
}

export const SearchHistoryScreen: React.FC<SearchHistoryScreenProps> = ({
  onBack,
  onNotify,
}) => {
  const [items, setItems] = useState<SearchEntry[]>(INITIAL_SEARCHES);
  const [selecting, setSelecting] = useState(false);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  const groups = Array.from(new Set(items.map((item) => item.group)));

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleDeleteSelected = () => {
    if (selectedIds.length === 0) return;
    setItems((prev) => prev.filter((item) => !selectedIds.includes(item.id)));
    onNotify?.(`${selectedIds.length} búsqueda(s) eliminada(s)`);
    setSelectedIds([]);
    setSelecting(false);
  };

  return (
    <div className="flex h-full w-full flex-col bg-[#121212] text-white select-none overflow-hidden">
      {/* AppBar: Flecha atrás, Título "Historial de búsqueda", botón "Seleccionar" */}
      <header className="flex h-12 shrink-0 items-center justify-between border-b border-white/10 px-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Volver al centro de actividades"
          className="flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>

        <h1 className="text-[15px] font-bold text-white">
          Historial de búsqueda
        </h1>

        <button
          type="button"
          onClick={() => {
            if (selecting) {
              setSelectedIds([]);
              setSelecting(false);
            } else {
              setSelecting(true);
            }
          }}
          className="rounded-lg px-2.5 py-1.5 text-xs font-semibold text-zinc-200 transition-colors hover:bg-white/10"
        >
          {selecting ? 'Cancelar' : 'Seleccionar'}
        </button>
      </header>

      {/* Lista agrupada por fechas */}
      <div className="flex-1 min-h-0 overflow-y-auto pb-6 no-scrollbar">
        {items.length === 0 ? (
          <div className="flex h-full flex-col items-center justify-center px-6 text-center">
            <Search className="h-10 w-10 text-zinc-600" />
            <p className="mt-3 text-sm font-bold text-white">
              Sin historial de búsqueda
            </p>
            <p className="mt-1 text-xs text-zinc-400">
              Tus búsquedas recientes aparecerán aquí.
            </p>
          </div>
        ) : (
          groups.map((group) => {
            const groupItems = items.filter((item) => item.group === group);
            return (
              <section key={group} className="pt-3">
                <h2 className="px-4 pb-1.5 text-xs font-semibold uppercase tracking-wide text-zinc-400">
                  {group}
                </h2>
                <div className="divide-y divide-white/5">
                  {groupItems.map((entry) => {
                    const isChecked = selectedIds.includes(entry.id);
                    return (
                      <button
                        key={entry.id}
                        type="button"
                        onClick={() => {
                          if (selecting) {
                            toggleSelect(entry.id);
                          } else {
                            onNotify?.(`Buscando "${entry.query}"`);
                          }
                        }}
                        className="flex w-full items-center justify-between gap-3 px-4 py-3 text-left transition-colors hover:bg-white/5"
                      >
                        <div className="flex min-w-0 items-center gap-3.5">
                          <Search className="h-4 w-4 shrink-0 text-zinc-400" />
                          <div className="min-w-0">
                            <p className="truncate text-sm font-medium text-white">
                              {entry.query}
                            </p>
                            <p className="mt-0.5 text-xs text-zinc-400">
                              {entry.time}
                            </p>
                          </div>
                        </div>

                        {selecting && (
                          <span
                            className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-full border transition-colors ${
                              isChecked
                                ? 'border-[#FF2D55] bg-[#FF2D55] text-white'
                                : 'border-zinc-500 bg-transparent text-transparent'
                            }`}
                          >
                            <Check className="h-3 w-3 stroke-[3]" />
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </section>
            );
          })
        )}
      </div>

      {selecting && selectedIds.length > 0 && (
        <div className="shrink-0 border-t border-white/10 bg-[#18181B] px-4 py-3">
          <button
            type="button"
            onClick={handleDeleteSelected}
            className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#FF2D55] py-2.5 text-xs font-bold text-white shadow-lg"
          >
            <Trash2 className="h-4 w-4" />
            <span>Eliminar ({selectedIds.length})</span>
          </button>
        </div>
      )}
    </div>
  );
};
