import React, { useState } from 'react';
import { ArrowLeft, ChevronRight, Music } from 'lucide-react';

interface MusicSettingsScreenProps {
  onBack: () => void;
  onNotify?: (message: string) => void;
}

export const MusicSettingsScreen: React.FC<MusicSettingsScreenProps> = ({
  onBack,
  onNotify,
}) => {
  const [linkedApp, setLinkedApp] = useState(false);

  const handleToggleLink = () => {
    const next = !linkedApp;
    setLinkedApp(next);
    onNotify?.(
      next ? 'Aplicación de música vinculada' : 'Aplicación de música desvinculada'
    );
  };

  return (
    <div className="flex h-full w-full flex-col bg-[#121212] text-white select-none overflow-hidden">
      <header className="relative flex h-12 shrink-0 items-center justify-center border-b border-white/10 bg-[#121212] px-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Atrás"
          className="absolute left-2 flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="text-[15px] font-bold text-white">Música</h1>
      </header>

      <div className="flex-1 min-h-0 overflow-y-auto px-4 py-4 no-scrollbar">
        <h2 className="mb-2 px-1 text-xs font-semibold tracking-wide text-zinc-400">
          Aplicación de música
        </h2>
        <div className="overflow-hidden rounded-xl bg-[#1E1E1E]">
          <button
            type="button"
            onClick={handleToggleLink}
            className="flex w-full items-center justify-between gap-3 px-4 py-4 text-left transition-colors hover:bg-white/5"
          >
            <div className="flex min-w-0 items-center gap-3">
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-[#FF5722]/15 text-[#FF5722]">
                <Music className="h-4.5 w-4.5" />
              </div>
              <p className="text-[14px] font-medium text-white">
                Agregar a la aplicación de música
              </p>
            </div>

            <div className="flex shrink-0 items-center gap-1">
              <span
                className={`text-xs font-semibold ${
                  linkedApp ? 'text-[#FF5722]' : 'text-zinc-300'
                }`}
              >
                {linkedApp ? 'Vinculada' : 'Vincular'}
              </span>
              <ChevronRight className="h-4 w-4 text-zinc-500" />
            </div>
          </button>
        </div>
      </div>
    </div>
  );
};
