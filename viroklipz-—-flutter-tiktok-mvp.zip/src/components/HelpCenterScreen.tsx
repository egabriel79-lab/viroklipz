import React, { useState } from 'react';
import { ArrowLeft, ChevronRight, MessageSquare } from 'lucide-react';
import { HelpCategoryScreen } from './HelpCategoryScreen';

interface HelpCenterScreenProps {
  onBack: () => void;
  onNotify?: (message: string) => void;
}

type HelpCenterTab = 'Guía de uso' | 'Monetización' | 'Otros';

const TABS: HelpCenterTab[] = ['Guía de uso', 'Monetización', 'Otros'];

const TAB_FAQS: Record<HelpCenterTab, string[]> = {
  'Guía de uso': [
    'Cómo crear y publicar videos en Viroklipz',
    'Edición, filtros, música y efectos',
    'Configurar tu perfil y privacidad',
    'Administrar notificaciones y feed Radar',
    'Seguridad y verificación de la cuenta',
  ],
  Monetización: [
    'Viroklipz Plus',
    'Artículos no recibidos',
    'Commercial Content Library',
    'About AI-generated content',
    'Propiedad intelectual',
  ],
  Otros: [
    '¿Qué tipos de suscripciones existen?',
    '¿Por qué no puedo renovar mi suscripción?',
    '¿Cómo me suscribo a la comunidad de un creador...?',
    '¿Dónde puedo ver mis suscripciones?',
    '¿Cómo puedo cancelar una suscripción...?',
  ],
};

export const HelpCenterScreen: React.FC<HelpCenterScreenProps> = ({
  onBack,
  onNotify,
}) => {
  const [activeTab, setActiveTab] = useState<HelpCenterTab>('Guía de uso');
  const [selectedCategoryTab, setSelectedCategoryTab] = useState<
    'Cuenta' | 'Privacidad y seguridad' | 'Publicaciones' | null
  >(null);

  if (selectedCategoryTab) {
    return (
      <HelpCategoryScreen
        initialTab={selectedCategoryTab}
        onBack={() => setSelectedCategoryTab(null)}
        onNotify={onNotify}
      />
    );
  }

  const openMoreForTab = (tab: HelpCenterTab) => {
    if (tab === 'Guía de uso') {
      setSelectedCategoryTab('Publicaciones');
    } else if (tab === 'Monetización') {
      setSelectedCategoryTab('Cuenta');
    } else {
      setSelectedCategoryTab('Privacidad y seguridad');
    }
  };

  return (
    <div className="flex h-full w-full flex-col bg-[#121212] text-white select-none overflow-hidden">
      {/* AppBar */}
      <header className="relative flex h-12 shrink-0 items-center justify-center bg-[#121212] px-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Atrás"
          className="absolute left-2 flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="text-[15px] font-bold text-white">Centro de ayuda</h1>
      </header>

      {/* DefaultTabController Tabs: Guía de uso | Monetización | Otros */}
      <div className="flex shrink-0 border-b border-white/10 bg-[#121212]">
        {TABS.map((tab) => {
          const isSelected = activeTab === tab;
          return (
            <button
              key={tab}
              type="button"
              onClick={() => setActiveTab(tab)}
              className={`relative flex-1 py-3 text-center text-xs font-semibold transition-colors ${
                isSelected ? 'text-white' : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              {tab}
              {isSelected && (
                <span className="absolute bottom-0 left-3 right-3 h-0.5 rounded-full bg-[#E91E63]" />
              )}
            </button>
          );
        })}
      </div>

      {/* Contenido de la pestaña activa */}
      <div className="flex-1 min-h-0 overflow-y-auto px-4 py-4 no-scrollbar">
        <div className="divide-y divide-white/5 overflow-hidden rounded-xl bg-[#1E1E1E]">
          {TAB_FAQS[activeTab].map((question) => (
            <button
              key={`${activeTab}-${question}`}
              type="button"
              onClick={() => onNotify?.(`${activeTab}: ${question}`)}
              className="flex w-full items-center justify-between gap-3 px-4 py-3.5 text-left transition-colors hover:bg-white/5"
            >
              <span className="text-[14px] font-medium leading-snug text-zinc-100">
                {question}
              </span>
              <ChevronRight className="h-4 w-4 shrink-0 text-zinc-500" />
            </button>
          ))}
        </div>

        <button
          type="button"
          onClick={() => openMoreForTab(activeTab)}
          className="mt-4 w-full rounded-xl bg-[#1E1E1E] py-3 text-center text-xs font-semibold text-zinc-200 transition-colors hover:bg-[#27272A]"
        >
          Ver más
        </button>
      </div>

      {/* Botón Sticky inferior rosa */}
      <div className="shrink-0 border-t border-white/10 bg-[#121212] px-4 py-3">
        <button
          type="button"
          onClick={() => onNotify?.('Iniciando chat de soporte...')}
          className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#E91E63] py-3 text-sm font-bold text-white transition-opacity hover:opacity-90 active:opacity-80"
        >
          <MessageSquare className="h-4 w-4" />
          <span>Chatea con nosotros</span>
        </button>
      </div>
    </div>
  );
};
