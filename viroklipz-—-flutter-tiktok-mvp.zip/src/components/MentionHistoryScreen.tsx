import React from 'react';
import { ArrowLeft } from 'lucide-react';

interface MentionEntry {
  id: string;
  authorName: string;
  avatarUrl: string;
  time: string;
  group: string;
  photoThumbUrl: string;
}

const MENTION_ITEMS: MentionEntry[] = [
  {
    id: 'mn-1',
    authorName: 'Mateo Cine',
    avatarUrl: '/src/assets/images/avatar_creator_mateo_1794604321715.jpg',
    time: '9:18 p. m.',
    group: 'Ayer',
    photoThumbUrl: '/src/assets/images/story_hinduismo_temple_1794607243976.jpg',
  },
  {
    id: 'mn-2',
    authorName: 'Valeria Beats',
    avatarUrl: '/src/assets/images/avatar_creator_valeria_1794604321625.jpg',
    time: '3:42 p. m.',
    group: 'Ayer',
    photoThumbUrl: '/src/assets/images/avatar_creator_valeria_1794604321625.jpg',
  },
  {
    id: 'mn-3',
    authorName: 'Sofía Fit',
    avatarUrl: '/src/assets/images/avatar_creator_sofia_1794604322145.jpg',
    time: '12:05 p. m.',
    group: '10 de noviembre',
    photoThumbUrl: '/src/assets/images/avatar_creator_diego_1794604323122.jpg',
  },
];

interface MentionHistoryScreenProps {
  onBack: () => void;
  onNotify?: (message: string) => void;
}

export const MentionHistoryScreen: React.FC<MentionHistoryScreenProps> = ({
  onBack,
  onNotify,
}) => {
  const groups = Array.from(new Set(MENTION_ITEMS.map((item) => item.group)));

  return (
    <div className="flex h-full w-full flex-col bg-[#121212] text-white select-none overflow-hidden">
      {/* AppBar */}
      <header className="flex h-12 shrink-0 items-center justify-between border-b border-white/10 px-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Volver al centro de actividades"
          className="flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>

        <h1 className="text-[15px] font-bold text-white">
          Historial de menciones
        </h1>

        <div className="w-10" />
      </header>

      {/* Lista agrupada por fechas */}
      <div className="flex-1 min-h-0 overflow-y-auto pb-6 no-scrollbar">
        {groups.map((group) => {
          const entries = MENTION_ITEMS.filter((item) => item.group === group);
          return (
            <section key={group} className="pt-3">
              <h2 className="px-4 pb-1.5 text-xs font-semibold uppercase tracking-wide text-zinc-400">
                {group}
              </h2>
              <div className="divide-y divide-white/5">
                {entries.map((entry) => (
                  <button
                    key={entry.id}
                    type="button"
                    onClick={() =>
                      onNotify?.(`Viendo foto de ${entry.authorName}`)
                    }
                    className="flex w-full items-center gap-3 px-4 py-3 text-left transition-colors hover:bg-white/5"
                  >
                    <img
                      src={entry.avatarUrl}
                      alt={entry.authorName}
                      className="h-10 w-10 shrink-0 rounded-full object-cover ring-1 ring-white/15"
                    />
                    <div className="min-w-0 flex-1">
                      <p className="text-sm leading-snug text-white">
                        <span className="font-semibold">{entry.authorName}</span>{' '}
                        te mencionó en una foto
                      </p>
                      <p className="mt-0.5 text-xs text-zinc-400">
                        {entry.time}
                      </p>
                    </div>
                    <img
                      src={entry.photoThumbUrl}
                      alt="Miniatura de foto"
                      className="h-12 w-12 shrink-0 rounded-lg bg-zinc-800 object-cover"
                    />
                  </button>
                ))}
              </div>
            </section>
          );
        })}
      </div>
    </div>
  );
};
