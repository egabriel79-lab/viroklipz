import React, { useMemo, useRef, useState } from 'react';
import {
  ArrowLeft,
  Bookmark,
  Check,
  ChevronRight,
  Heart,
  MessageCircle,
  Play,
  Plus,
  Search,
  Settings,
  Share2,
  WifiOff,
  X,
} from 'lucide-react';

export interface OfflineVideoPost {
  id: string;
  username: string;
  avatarUrl: string;
  posterUrl: string;
  videoUrl: string;
  dateLabel: string;
  caption: string;
  likes: number;
  commentsCount: number;
  bookmarksCount: number;
  sharesCount: number;
  searchHint: string;
}

const SAMPLE_MEDIA = [
  {
    poster: '/src/assets/images/story_hinduismo_temple_1794607243976.jpg',
    video:
      'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    avatar: '/src/assets/images/avatar_creator_mateo_1794604321715.jpg',
  },
  {
    poster: '/src/assets/images/avatar_creator_valeria_1794604321625.jpg',
    video:
      'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
    avatar: '/src/assets/images/avatar_creator_valeria_1794604321625.jpg',
  },
  {
    poster: '/src/assets/images/avatar_creator_lucas_1794604322245.jpg',
    video:
      'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4',
    avatar: '/src/assets/images/avatar_creator_lucas_1794604322245.jpg',
  },
  {
    poster: '/src/assets/images/avatar_creator_sofia_1794604322145.jpg',
    video:
      'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoy.mp4',
    avatar: '/src/assets/images/avatar_creator_sofia_1794604322145.jpg',
  },
  {
    poster: '/src/assets/images/avatar_creator_diego_1794604323122.jpg',
    video:
      'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4',
    avatar: '/src/assets/images/avatar_creator_diego_1794604323122.jpg',
  },
];

const SAMPLE_USERS = [
  'fugr356',
  'mateo.cine',
  'valeria.flow',
  'lucas.ruta',
  'sofia.beats',
  'diego.35mm',
  'tallermadera',
  'craft.diy',
];

const SAMPLE_CAPTIONS = [
  '#StressRelief#PopularScience#Tips Construyendo miniaturas paso a paso',
  '#Woodworking#Satisfying#Viral Técnica tradicional sin clavos',
  '#35mm#Filmmaking#ColorGrading Luz natural al amanecer',
  '#Beatmaking#LoFi#StudioSession Creando ritmos sin conexión',
  '#Outdoor#Adventure#Viroklipz Vista panorámica en la cumbre',
];

const SAMPLE_SEARCHES = [
  'barcos pequeños de madera',
  'carpintería miniatura relajante',
  'transiciones cinematográficas 2025',
  'beats lofi para editar',
  'rutas de montaña en solitario',
];

interface OfflineVideosScreenProps {
  onBack: () => void;
  onNotify?: (message: string) => void;
}

export const OfflineVideosScreen: React.FC<OfflineVideosScreenProps> = ({
  onBack,
  onNotify,
}) => {
  const offlineVideos = useMemo<OfflineVideoPost[]>(() => {
    const generated: OfflineVideoPost[] = [];
    for (let i = 0; i < 300; i++) {
      const media = SAMPLE_MEDIA[i % SAMPLE_MEDIA.length];
      const day = String(((i + 4) % 28) + 1).padStart(2, '0');
      generated.push({
        id: `offline-${i + 1}`,
        username: i === 0 ? 'fugr356' : SAMPLE_USERS[i % SAMPLE_USERS.length],
        avatarUrl: media.avatar,
        posterUrl: media.poster,
        videoUrl: media.video,
        dateLabel: i === 0 ? '11-05' : `11-${day}`,
        caption: SAMPLE_CAPTIONS[i % SAMPLE_CAPTIONS.length],
        likes: i === 0 ? 3667 : 820 + ((i * 137) % 9400),
        commentsCount: i === 0 ? 22 : 12 + ((i * 19) % 240),
        bookmarksCount: i === 0 ? 487 : 65 + ((i * 43) % 1200),
        sharesCount: i === 0 ? 243 : 28 + ((i * 29) % 680),
        searchHint: SAMPLE_SEARCHES[i % SAMPLE_SEARCHES.length],
      });
    }
    return generated;
  }, []);

  const feedRef = useRef<HTMLDivElement>(null);
  const [activeIndex, setActiveIndex] = useState(0);
  const [likedIds, setLikedIds] = useState<Record<string, boolean>>({});
  const [bookmarkedIds, setBookmarkedIds] = useState<Record<string, boolean>>(
    {}
  );
  const [followedUsers, setFollowedUsers] = useState<Record<string, boolean>>(
    {}
  );
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  const handleScroll = () => {
    const el = feedRef.current;
    if (!el || el.clientHeight === 0) return;
    const nextIdx = Math.round(el.scrollTop / el.clientHeight);
    if (nextIdx !== activeIndex && nextIdx >= 0 && nextIdx < offlineVideos.length) {
      setActiveIndex(nextIdx);
    }
  };

  return (
    <div className="relative flex h-full w-full flex-col bg-black text-white select-none overflow-hidden">
      {/* Barra superior superpuesta (Atrás a la izquierda + Ajustes a la derecha) */}
      <header className="pointer-events-none absolute inset-x-0 top-0 z-20 flex h-12 items-center justify-between px-2 pt-1">
        <button
          type="button"
          onClick={onBack}
          aria-label="Volver al perfil"
          className="pointer-events-auto flex h-10 w-10 items-center justify-center rounded-full bg-black/25 text-white backdrop-blur-sm transition-colors hover:bg-black/45"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>

        <span className="rounded-full bg-black/35 px-2.5 py-0.5 text-[11px] font-semibold text-white/85 backdrop-blur-sm tabular-nums">
          {activeIndex + 1} / {offlineVideos.length}
        </span>

        <button
          type="button"
          onClick={() => setIsSettingsOpen(true)}
          aria-label="Ajustes de vídeos sin conexión"
          className="pointer-events-auto flex h-10 w-10 items-center justify-center rounded-full bg-black/25 text-white backdrop-blur-sm transition-colors hover:bg-black/45"
        >
          <Settings className="h-5 w-5" />
        </button>
      </header>

      {/* Feed vertical (300 videos con scroll snap) */}
      <div
        ref={feedRef}
        onScroll={handleScroll}
        className="flex-1 min-h-0 snap-y snap-mandatory overflow-y-auto no-scrollbar"
      >
        {offlineVideos.map((post, idx) => {
          const isActive = idx === activeIndex;
          const isLiked = Boolean(likedIds[post.id]);
          const isBookmarked = Boolean(bookmarkedIds[post.id]);
          const isFollowed = Boolean(followedUsers[post.username]);

          return (
            <div
              key={post.id}
              className="relative h-full w-full shrink-0 snap-start overflow-hidden bg-zinc-950"
            >
              {/* Poster base + video activo */}
              <img
                src={post.posterUrl}
                alt={post.caption}
                className="absolute inset-0 h-full w-full object-cover"
              />
              {isActive && (
                <video
                  src={post.videoUrl}
                  poster={post.posterUrl}
                  autoPlay
                  loop
                  muted
                  playsInline
                  className="absolute inset-0 h-full w-full object-cover"
                />
              )}

              {/* Scrims de legibilidad */}
              <div
                aria-hidden="true"
                className="pointer-events-none absolute inset-0"
                style={{
                  background:
                    'linear-gradient(180deg, rgba(0,0,0,0.45) 0%, rgba(0,0,0,0) 24%, rgba(0,0,0,0.12) 60%, rgba(0,0,0,0.84) 100%)',
                }}
              />

              {/* Indicador sutil si es vídeo offline en caché */}
              <div className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 opacity-0">
                <Play className="h-12 w-12 text-white/70" />
              </div>

              {/* Barra lateral derecha superpuesta */}
              <div className="absolute bottom-4 right-2.5 z-10 flex flex-col items-center gap-4">
                {/* Avatar + botón + rojo debajo */}
                <div className="relative mb-1.5">
                  <img
                    src={post.avatarUrl}
                    alt={post.username}
                    className="h-11 w-11 rounded-full border-2 border-white object-cover shadow-md"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      setFollowedUsers((prev) => ({
                        ...prev,
                        [post.username]: !prev[post.username],
                      }));
                      onNotify?.(
                        isFollowed
                          ? `Dejaste de seguir a ${post.username}`
                          : `Siguiendo a ${post.username}`
                      );
                    }}
                    aria-label="Seguir creador"
                    className={`absolute -bottom-2 left-1/2 flex h-5 w-5 -translate-x-1/2 items-center justify-center rounded-full text-white shadow ${
                      isFollowed ? 'bg-zinc-700' : 'bg-[#FF2D55]'
                    }`}
                  >
                    {isFollowed ? (
                      <Check className="h-3 w-3 stroke-[3]" />
                    ) : (
                      <Plus className="h-3 w-3 stroke-[3]" />
                    )}
                  </button>
                </div>

                {/* Corazón + contador */}
                <button
                  type="button"
                  onClick={() =>
                    setLikedIds((prev) => ({
                      ...prev,
                      [post.id]: !prev[post.id],
                    }))
                  }
                  className="flex flex-col items-center gap-0.5"
                >
                  <Heart
                    className={`h-7 w-7 drop-shadow transition-transform active:scale-110 ${
                      isLiked
                        ? 'fill-[#FF2D55] text-[#FF2D55]'
                        : 'fill-white/90 text-white'
                    }`}
                  />
                  <span className="text-[11px] font-semibold tabular-nums text-white drop-shadow">
                    {post.likes + (isLiked ? 1 : 0)}
                  </span>
                </button>

                {/* Comentario + contador */}
                <button
                  type="button"
                  onClick={() =>
                    onNotify?.('Comentarios disponibles al reconectar')
                  }
                  className="flex flex-col items-center gap-0.5"
                >
                  <MessageCircle className="h-7 w-7 fill-white/90 text-white drop-shadow" />
                  <span className="text-[11px] font-semibold tabular-nums text-white drop-shadow">
                    {post.commentsCount}
                  </span>
                </button>

                {/* Guardar (Bookmark) + contador */}
                <button
                  type="button"
                  onClick={() =>
                    setBookmarkedIds((prev) => ({
                      ...prev,
                      [post.id]: !prev[post.id],
                    }))
                  }
                  className="flex flex-col items-center gap-0.5"
                >
                  <Bookmark
                    className={`h-7 w-7 drop-shadow transition-transform active:scale-110 ${
                      isBookmarked
                        ? 'fill-amber-400 text-amber-400'
                        : 'fill-white/90 text-white'
                    }`}
                  />
                  <span className="text-[11px] font-semibold tabular-nums text-white drop-shadow">
                    {post.bookmarksCount + (isBookmarked ? 1 : 0)}
                  </span>
                </button>

                {/* Compartir + contador */}
                <button
                  type="button"
                  onClick={() =>
                    onNotify?.('Conéctate a internet para compartir este clip')
                  }
                  className="flex flex-col items-center gap-0.5"
                >
                  <Share2 className="h-7 w-7 fill-white/90 text-white drop-shadow" />
                  <span className="text-[11px] font-semibold tabular-nums text-white drop-shadow">
                    {post.sharesCount}
                  </span>
                </button>
              </div>

              {/* Información inferior izquierda + barra de búsqueda */}
              <div className="absolute bottom-3 left-3 right-16 z-10 space-y-2">
                <div className="flex items-baseline gap-2">
                  <span className="text-sm font-bold text-white drop-shadow">
                    {post.username}
                  </span>
                  <span className="text-xs font-medium text-white/75 drop-shadow">
                    · {post.dateLabel}
                  </span>
                </div>

                <p className="line-clamp-2 text-xs leading-relaxed text-white/95 drop-shadow">
                  {post.caption}
                </p>

                {/* Barra de búsqueda inferior semi-transparente */}
                <button
                  type="button"
                  onClick={() =>
                    onNotify?.(`Búsqueda guardada: ${post.searchHint}`)
                  }
                  className="flex w-full items-center justify-between gap-2 rounded-lg bg-black/50 px-2.5 py-2 text-left backdrop-blur-sm transition-colors hover:bg-black/65"
                >
                  <div className="flex min-w-0 items-center gap-1.5">
                    <Search className="h-3.5 w-3.5 shrink-0 text-white/85" />
                    <span className="truncate text-[11px] font-medium text-white/95">
                      Búsqueda · {post.searchHint}
                    </span>
                  </div>
                  <ChevronRight className="h-3.5 w-3.5 shrink-0 text-white/75" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Banner fijo de modo offline en la parte más baja (negro puro) */}
      <div className="flex shrink-0 items-center justify-center gap-1.5 border-t border-white/10 bg-black px-3 py-2.5 text-center">
        <WifiOff className="h-3.5 w-3.5 text-white/80" />
        <span className="text-xs font-medium text-white">
          Estás mirando vídeos sin conexión
        </span>
      </div>

      {/* Modal de ajustes de descarga sin conexión */}
      {isSettingsOpen && (
        <div
          className="absolute inset-0 z-30 flex items-end bg-black/60"
          onClick={() => setIsSettingsOpen(false)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full rounded-t-2xl bg-[#1C1C1E] p-4 pb-6 text-white shadow-2xl"
          >
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <span className="text-sm font-bold">Vídeos sin conexión</span>
              <button
                type="button"
                onClick={() => setIsSettingsOpen(false)}
                className="flex h-8 w-8 items-center justify-center rounded-full hover:bg-white/10"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="mt-3 space-y-2 text-xs text-zinc-300">
              <div className="flex items-center justify-between rounded-xl bg-white/5 px-3 py-2.5">
                <span>Vídeos en caché</span>
                <span className="font-bold text-white">300 vídeos</span>
              </div>
              <div className="flex items-center justify-between rounded-xl bg-white/5 px-3 py-2.5">
                <span>Espacio utilizado</span>
                <span className="font-bold text-white">420 MB</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
