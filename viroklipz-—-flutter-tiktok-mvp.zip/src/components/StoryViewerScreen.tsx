import React, { useEffect, useState } from 'react';
import { Heart, Send, Share2, X } from 'lucide-react';

export interface StoryHighlightSlide {
  id: string;
  url: string;
  caption?: string;
}

interface StoryViewerScreenProps {
  title: string;
  timeAgo: string;
  avatarUrl: string;
  slides: StoryHighlightSlide[];
  onClose: () => void;
  onNotify?: (message: string) => void;
}

export const StoryViewerScreen: React.FC<StoryViewerScreenProps> = ({
  title,
  timeAgo,
  avatarUrl,
  slides,
  onClose,
  onNotify,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [liked, setLiked] = useState(false);
  const [replyText, setReplyText] = useState('');
  const [floatingEmoji, setFloatingEmoji] = useState<string | null>(null);

  const safeSlides =
    slides.length > 0
      ? slides
      : [
          {
            id: 'fallback-slide',
            url: '/src/assets/images/story_hinduismo_temple_1794607243976.jpg',
          },
        ];

  const activeSlide = safeSlides[currentIndex] ?? safeSlides[0];

  useEffect(() => {
    const timer = window.setTimeout(() => {
      if (currentIndex < safeSlides.length - 1) {
        setCurrentIndex((prev) => prev + 1);
      } else {
        onClose();
      }
    }, 4500);

    return () => window.clearTimeout(timer);
  }, [currentIndex, safeSlides.length, onClose]);

  const handleTapZone = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const tapX = e.clientX - rect.left;
    if (tapX < rect.width * 0.35) {
      setCurrentIndex((prev) => Math.max(0, prev - 1));
    } else if (currentIndex < safeSlides.length - 1) {
      setCurrentIndex((prev) => prev + 1);
    } else {
      onClose();
    }
  };

  const handleEmoji = (emoji: string) => {
    setFloatingEmoji(emoji);
    onNotify?.(`Reaccionaste ${emoji} a "${title}"`);
    window.setTimeout(() => {
      setFloatingEmoji((prev) => (prev === emoji ? null : prev));
    }, 750);
  };

  const handleSendReply = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = replyText.trim();
    if (!trimmed) return;
    onNotify?.(`Comentario enviado en "${title}"`);
    setReplyText('');
  };

  return (
    <div className="relative flex h-full w-full flex-col overflow-hidden bg-black text-white select-none">
      {/* Imagen / media del Story */}
      <img
        src={activeSlide.url}
        alt={title}
        className="absolute inset-0 h-full w-full object-cover"
      />

      {/* Scrim para legibilidad */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            'linear-gradient(180deg, rgba(0,0,0,0.6) 0%, rgba(0,0,0,0.08) 28%, rgba(0,0,0,0.12) 68%, rgba(0,0,0,0.82) 100%)',
        }}
      />

      {/* Zona táctil izquierda / derecha para avanzar o retroceder */}
      <div
        onClick={handleTapZone}
        className="absolute inset-x-0 top-16 bottom-20 z-10 cursor-pointer"
        aria-label="Cambiar story"
      />

      {/* Texto opcional en el centro si el slide tiene caption */}
      {activeSlide.caption && (
        <div className="pointer-events-none absolute inset-0 z-10 flex items-center justify-center px-6">
          <p
            className="text-center font-display text-3xl font-black tracking-wide text-white"
            style={{ textShadow: '0 4px 14px rgba(0,0,0,0.7)' }}
          >
            {activeSlide.caption}
          </p>
        </div>
      )}

      {/* Reacción flotante */}
      {floatingEmoji && (
        <div className="pointer-events-none absolute inset-0 z-20 flex items-center justify-center">
          <span className="text-6xl animate-bounce drop-shadow-2xl">
            {floatingEmoji}
          </span>
        </div>
      )}

      {/* Barra de progreso + Header */}
      <header className="relative z-20 px-3 pt-3 space-y-2.5">
        <div className="flex items-center gap-1">
          {safeSlides.map((slide, idx) => (
            <div
              key={slide.id}
              className="h-0.5 flex-1 overflow-hidden rounded-full bg-white/30"
            >
              <div
                className={`h-full bg-white transition-all duration-300 ${
                  idx < currentIndex
                    ? 'w-full'
                    : idx === currentIndex
                    ? 'w-full'
                    : 'w-0'
                }`}
              />
            </div>
          ))}
        </div>

        <div className="flex items-center justify-between gap-2">
          <div className="flex min-w-0 items-center gap-2.5">
            <img
              src={avatarUrl}
              alt={title}
              className="h-8 w-8 shrink-0 rounded-full border border-white/50 object-cover"
            />
            <div className="min-w-0">
              <p className="truncate text-sm font-bold text-white drop-shadow">
                {title}
              </p>
              <p className="text-[11px] text-white/75">{timeAgo}</p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Cerrar visor de story"
            className="flex h-9 w-9 items-center justify-center rounded-full text-white hover:bg-white/15"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
      </header>

      {/* Barra inferior de respuesta y reacciones */}
      <div className="relative z-20 mt-auto flex items-center gap-2.5 px-3 pb-4 pt-2">
        <form
          onSubmit={handleSendReply}
          className="flex h-10 flex-1 items-center gap-2 rounded-full border border-white/30 bg-white/15 px-3.5 backdrop-blur-md"
        >
          <input
            type="text"
            value={replyText}
            onChange={(e) => setReplyText(e.target.value)}
            placeholder="Enviar mensaje..."
            className="min-w-0 flex-1 bg-transparent text-xs text-white placeholder:text-white/75 focus:outline-none"
          />
          <button
            type="button"
            onClick={() => handleEmoji('😍')}
            className="text-base leading-none"
            aria-label="Reaccionar 😍"
          >
            😍
          </button>
          <button
            type="button"
            onClick={() => handleEmoji('🔥')}
            className="text-base leading-none"
            aria-label="Reaccionar 🔥"
          >
            🔥
          </button>
          {replyText.trim() && (
            <button
              type="submit"
              aria-label="Enviar"
              className="text-white hover:opacity-80"
            >
              <Send className="h-4 w-4" />
            </button>
          )}
        </form>

        <button
          type="button"
          onClick={() => setLiked((prev) => !prev)}
          aria-label="Me gusta"
          className="flex h-10 w-10 items-center justify-center rounded-full text-white hover:bg-white/10"
        >
          <Heart
            className={`h-5 w-5 ${
              liked ? 'fill-[#FF2D55] text-[#FF2D55]' : 'text-white'
            }`}
          />
        </button>

        <button
          type="button"
          onClick={() => onNotify?.(`Destacado "${title}" compartido`)}
          aria-label="Compartir destacado"
          className="flex h-10 w-10 items-center justify-center rounded-full text-white hover:bg-white/10"
        >
          <Share2 className="h-5 w-5" />
        </button>
      </div>
    </div>
  );
};
