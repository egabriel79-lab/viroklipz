import React, { useState } from 'react';
import { ArrowLeft, ChevronDown, Play, X } from 'lucide-react';

type ActivityTab = 'actividad' | 'seguidores';

interface ActivityScreenProps {
  onBack: () => void;
  onNotify?: (message: string) => void;
}

interface RecommendedAccount {
  id: string;
  name: string;
  subtitle: string;
  avatarUrl: string;
  initials: string;
  thumbnails: { id: string; src: string; views: string }[];
}

interface FollowerItem {
  id: string;
  name: string;
  time: string;
  avatarUrl: string;
  initials: string;
}

const INITIAL_RECOMMENDED: RecommendedAccount[] = [
  {
    id: 'rec-1',
    name: 'mateo.cine',
    subtitle: 'Compartió videos contigo',
    avatarUrl: '/src/assets/images/avatar_creator_mateo_1794604321715.jpg',
    initials: 'MC',
    thumbnails: [
      {
        id: 't1',
        src: '/src/assets/images/hero_cyber_astronaut_1794614449948.jpg',
        views: '14.8K',
      },
      {
        id: 't2',
        src: '/src/assets/images/story_hinduismo_temple_1794607243976.jpg',
        views: '9.2K',
      },
      {
        id: 't3',
        src: '/src/assets/images/avatar_creator_mateo_1794604321715.jpg',
        views: '21.1K',
      },
      {
        id: 't4',
        src: '/src/assets/images/avatar_creator_lucas_1794604322245.jpg',
        views: '6.4K',
      },
    ],
  },
  {
    id: 'rec-2',
    name: 'sofia.beats',
    subtitle: 'Compartió videos contigo',
    avatarUrl: '/src/assets/images/avatar_creator_sofia_1794604322145.jpg',
    initials: 'SB',
    thumbnails: [
      {
        id: 't5',
        src: '/src/assets/images/avatar_creator_sofia_1794604322145.jpg',
        views: '32.4K',
      },
      {
        id: 't6',
        src: '/src/assets/images/avatar_creator_valeria_1794604321625.jpg',
        views: '18.7K',
      },
      {
        id: 't7',
        src: '/src/assets/images/hero_cyber_astronaut_1794614449948.jpg',
        views: '11.0K',
      },
    ],
  },
  {
    id: 'rec-3',
    name: 'diego.skate',
    subtitle: 'Compartió videos contigo',
    avatarUrl: '/src/assets/images/avatar_creator_diego_1794604323122.jpg',
    initials: 'DS',
    thumbnails: [
      {
        id: 't8',
        src: '/src/assets/images/avatar_creator_diego_1794604323122.jpg',
        views: '45.2K',
      },
      {
        id: 't9',
        src: '/src/assets/images/story_hinduismo_temple_1794607243976.jpg',
        views: '8.9K',
      },
      {
        id: 't10',
        src: '/src/assets/images/avatar_creator_lucas_1794604322245.jpg',
        views: '5.1K',
      },
    ],
  },
];

const INITIAL_FOLLOWERS: FollowerItem[] = [
  {
    id: 'fol-1',
    name: 'Proyectos Yomi c.a',
    time: '2 d',
    avatarUrl: '/src/assets/images/avatar_creator_diego_1794604323122.jpg',
    initials: 'PY',
  },
  {
    id: 'fol-2',
    name: 'Valery🦋',
    time: '3 d',
    avatarUrl: '/src/assets/images/avatar_creator_valeria_1794604321625.jpg',
    initials: 'VL',
  },
  {
    id: 'fol-3',
    name: 'Panelscleandr',
    time: '4 d',
    avatarUrl: '/src/assets/images/avatar_creator_lucas_1794604322245.jpg',
    initials: 'PC',
  },
];

interface AvatarCircleProps {
  src: string;
  alt: string;
  initials: string;
  sizeClass?: string;
}

const AvatarCircle: React.FC<AvatarCircleProps> = ({
  src,
  alt,
  initials,
  sizeClass = 'h-11 w-11',
}) => {
  const [hasError, setHasError] = useState(false);

  if (hasError) {
    return (
      <div
        className={`flex ${sizeClass} shrink-0 items-center justify-center rounded-full border border-white/10 bg-zinc-800 text-xs font-bold text-white`}
      >
        {initials}
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setHasError(true)}
      className={`${sizeClass} shrink-0 rounded-full border border-white/10 bg-zinc-800 object-cover`}
    />
  );
};

interface TabContentProps {
  followedIds: Record<string, boolean>;
  dismissedRecIds: Record<string, boolean>;
  onToggleFollow: (id: string, name: string) => void;
  onDismissRec: (id: string) => void;
}

export const ActivityTabContent: React.FC<TabContentProps> = ({
  followedIds,
  dismissedRecIds,
  onToggleFollow,
  onDismissRec,
}) => {
  const [showAllNotifications, setShowAllNotifications] = useState(false);

  const visibleRecommended = INITIAL_RECOMMENDED.filter(
    (item) => !dismissedRecIds[item.id]
  );

  return (
    <div className="flex-1 min-h-0 overflow-y-auto pb-6 no-scrollbar">
      {/* Notificaciones de Actividad */}
      <div className="py-1">
        {/* Notificación 1 */}
        <div className="flex items-center gap-3 px-4 py-3 transition-colors hover:bg-white/[0.03]">
          <AvatarCircle
            src="/src/assets/images/avatar_creator_valeria_1794604321625.jpg"
            alt="NANCY🦋"
            initials="NA"
          />
          <div className="min-w-0 flex-1">
            <p className="text-[13.5px] leading-snug text-zinc-200">
              <span className="font-bold text-white">NANCY🦋</span> le dio me gusta a tu comentario
            </p>
            <p className="mt-0.5 text-xs text-zinc-500 tabular-nums">2 d</p>
          </div>
        </div>

        {/* Notificación 2: Dos avatares superpuestos */}
        <div className="flex items-center gap-3 px-4 py-3 transition-colors hover:bg-white/[0.03]">
          <div className="relative h-11 w-12 shrink-0">
            <img
              src="/src/assets/images/avatar_creator_sofia_1794604322145.jpg"
              alt="Valery🦋"
              referrerPolicy="no-referrer"
              className="absolute left-0 top-0 h-8 w-8 rounded-full border-2 border-[#0F0F0F] bg-zinc-800 object-cover"
            />
            <img
              src="/src/assets/images/avatar_creator_mateo_1794604321715.jpg"
              alt="Richard.A"
              referrerPolicy="no-referrer"
              className="absolute bottom-0 right-0 h-8 w-8 rounded-full border-2 border-[#0F0F0F] bg-zinc-800 object-cover"
            />
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-[13.5px] leading-snug text-zinc-200">
              <span className="font-bold text-white">Valery🦋, Richard.A y Alix</span> han visto tu perfil
            </p>
            <p className="mt-0.5 text-xs text-zinc-500 tabular-nums">2 d</p>
          </div>
        </div>

        {showAllNotifications && (
          <div className="flex items-center gap-3 px-4 py-3 transition-colors hover:bg-white/[0.03]">
            <AvatarCircle
              src="/src/assets/images/avatar_creator_lucas_1794604322245.jpg"
              alt="lucas.ruta"
              initials="LR"
            />
            <div className="min-w-0 flex-1">
              <p className="text-[13.5px] leading-snug text-zinc-200">
                <span className="font-bold text-white">lucas.ruta</span> comentó: &ldquo;Brutal toma!&rdquo;
              </p>
              <p className="mt-0.5 text-xs text-zinc-500 tabular-nums">4 d</p>
            </div>
          </div>
        )}

        {/* Ver todo centrado */}
        <button
          type="button"
          onClick={() => setShowAllNotifications((prev) => !prev)}
          className="flex w-full items-center justify-center gap-1 py-2.5 text-xs font-semibold text-zinc-400 transition-colors hover:text-white"
        >
          <span>{showAllNotifications ? 'Ver menos' : 'Ver todo'}</span>
          <ChevronDown
            className={`h-3.5 w-3.5 transition-transform ${
              showAllNotifications ? 'rotate-180' : ''
            }`}
          />
        </button>
      </div>

      {/* Sección Cuentas recomendadas */}
      {visibleRecommended.length > 0 && (
        <section className="border-t border-white/10 pt-3">
          <h2 className="px-4 pb-2 text-xs font-bold tracking-wide text-zinc-400">
            Cuentas recomendadas
          </h2>

          <div>
            {visibleRecommended.map((account) => {
              const isFollowing = Boolean(followedIds[account.id]);
              return (
                <div
                  key={account.id}
                  className="flex items-center gap-3 px-4 py-2.5 transition-colors hover:bg-white/[0.03]"
                >
                  <AvatarCircle
                    src={account.avatarUrl}
                    alt={account.name}
                    initials={account.initials}
                  />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[14px] font-bold text-white">
                      {account.name}
                    </p>
                    <p className="truncate text-xs text-zinc-400">
                      {account.subtitle}
                    </p>
                  </div>

                  <div className="flex shrink-0 items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => onToggleFollow(account.id, account.name)}
                      className={`min-h-[34px] rounded-md px-3 text-xs font-bold transition-colors whitespace-nowrap ${
                        isFollowing
                          ? 'border border-white/15 bg-white/10 text-zinc-200'
                          : 'bg-[#FF2D55] text-white hover:bg-[#ff4267]'
                      }`}
                    >
                      {isFollowing ? 'Siguiendo' : 'Seguir también'}
                    </button>

                    <button
                      type="button"
                      onClick={() => onDismissRec(account.id)}
                      aria-label={`Ocultar recomendación de ${account.name}`}
                      className="flex h-8 w-8 items-center justify-center rounded-full text-zinc-500 transition-colors hover:bg-white/10 hover:text-zinc-200"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      )}
    </div>
  );
};

export const NewFollowersTabContent: React.FC<TabContentProps> = ({
  followedIds,
  dismissedRecIds,
  onToggleFollow,
  onDismissRec,
}) => {
  const [showAllFollowers, setShowAllFollowers] = useState(false);

  const visibleRecommended = INITIAL_RECOMMENDED.filter(
    (item) => !dismissedRecIds[item.id]
  );

  return (
    <div className="flex-1 min-h-0 overflow-y-auto pb-6 no-scrollbar">
      {/* Lista de nuevos seguidores */}
      <div className="py-1">
        {INITIAL_FOLLOWERS.map((follower) => {
          const isFollowing = Boolean(followedIds[follower.id]);
          return (
            <div
              key={follower.id}
              className="flex items-center gap-3 px-4 py-3 transition-colors hover:bg-white/[0.03]"
            >
              <AvatarCircle
                src={follower.avatarUrl}
                alt={follower.name}
                initials={follower.initials}
              />
              <div className="min-w-0 flex-1">
                <p className="truncate text-[14px] font-bold text-white">
                  {follower.name}
                </p>
                <p className="mt-0.5 text-xs text-zinc-400 tabular-nums">
                  empezó a seguirte. {follower.time}
                </p>
              </div>

              <button
                type="button"
                onClick={() => onToggleFollow(follower.id, follower.name)}
                className={`min-h-[34px] shrink-0 rounded-md px-3.5 text-xs font-bold transition-colors whitespace-nowrap ${
                  isFollowing
                    ? 'border border-white/15 bg-white/10 text-zinc-200'
                    : 'bg-[#FF2D55] text-white hover:bg-[#ff4267]'
                }`}
              >
                {isFollowing ? 'Siguiendo' : 'Seguir también'}
              </button>
            </div>
          );
        })}

        {showAllFollowers && (
          <div className="flex items-center gap-3 px-4 py-3 transition-colors hover:bg-white/[0.03]">
            <AvatarCircle
              src="/src/assets/images/avatar_creator_sofia_1794604322145.jpg"
              alt="1382jovana🇻🇪"
              initials="13"
            />
            <div className="min-w-0 flex-1">
              <p className="truncate text-[14px] font-bold text-white">
                1382jovana🇻🇪
              </p>
              <p className="mt-0.5 text-xs text-zinc-400 tabular-nums">
                empezó a seguirte. 6 d
              </p>
            </div>
            <button
              type="button"
              onClick={() => onToggleFollow('fol-extra', '1382jovana🇻🇪')}
              className={`min-h-[34px] shrink-0 rounded-md px-3.5 text-xs font-bold transition-colors whitespace-nowrap ${
                followedIds['fol-extra']
                  ? 'border border-white/15 bg-white/10 text-zinc-200'
                  : 'bg-[#FF2D55] text-white hover:bg-[#ff4267]'
              }`}
            >
              {followedIds['fol-extra'] ? 'Siguiendo' : 'Seguir también'}
            </button>
          </div>
        )}

        {/* Ver todo centrado */}
        <button
          type="button"
          onClick={() => setShowAllFollowers((prev) => !prev)}
          className="flex w-full items-center justify-center gap-1 py-2.5 text-xs font-semibold text-zinc-400 transition-colors hover:text-white"
        >
          <span>{showAllFollowers ? 'Ver menos' : 'Ver todo'}</span>
          <ChevronDown
            className={`h-3.5 w-3.5 transition-transform ${
              showAllFollowers ? 'rotate-180' : ''
            }`}
          />
        </button>
      </div>

      {/* Sección Cuentas recomendadas con miniaturas de video */}
      {visibleRecommended.length > 0 && (
        <section className="border-t border-white/10 pt-3">
          <h2 className="px-4 pb-2 text-xs font-bold tracking-wide text-zinc-400">
            Cuentas recomendadas
          </h2>

          <div className="space-y-4">
            {visibleRecommended.map((account) => {
              const isFollowing = Boolean(followedIds[account.id]);
              return (
                <div key={account.id} className="px-4 space-y-2.5">
                  <div className="flex items-center gap-3">
                    <AvatarCircle
                      src={account.avatarUrl}
                      alt={account.name}
                      initials={account.initials}
                    />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[14px] font-bold text-white">
                        {account.name}
                      </p>
                      <p className="truncate text-xs text-zinc-400">
                        {account.subtitle}
                      </p>
                    </div>

                    <div className="flex shrink-0 items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => onToggleFollow(account.id, account.name)}
                        className={`min-h-[34px] rounded-md px-3 text-xs font-bold transition-colors whitespace-nowrap ${
                          isFollowing
                            ? 'border border-white/15 bg-white/10 text-zinc-200'
                            : 'bg-[#FF2D55] text-white hover:bg-[#ff4267]'
                        }`}
                      >
                        {isFollowing ? 'Siguiendo' : 'Seguir también'}
                      </button>

                      <button
                        type="button"
                        onClick={() => onDismissRec(account.id)}
                        aria-label={`Ocultar recomendación de ${account.name}`}
                        className="flex h-8 w-8 items-center justify-center rounded-full text-zinc-500 transition-colors hover:bg-white/10 hover:text-zinc-200"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                  </div>

                  {/* Fila de 3-4 miniaturas de video rectangulares */}
                  <div className="grid grid-cols-4 gap-1.5 pl-14">
                    {account.thumbnails.slice(0, 4).map((thumb) => (
                      <div
                        key={thumb.id}
                        className="relative aspect-[3/4] overflow-hidden rounded-lg border border-white/10 bg-zinc-900"
                      >
                        <img
                          src={thumb.src}
                          alt={`Clip de ${account.name}`}
                          referrerPolicy="no-referrer"
                          className="h-full w-full object-cover"
                        />
                        <div className="pointer-events-none absolute inset-x-0 bottom-0 flex items-center gap-0.5 bg-gradient-to-t from-black/80 via-black/30 to-transparent px-1.5 pb-1 pt-3 text-[9.5px] font-semibold text-white tabular-nums">
                          <Play className="h-2.5 w-2.5 fill-white" />
                          <span>{thumb.views}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      )}
    </div>
  );
};

export const ActivityScreen: React.FC<ActivityScreenProps> = ({
  onBack,
  onNotify,
}) => {
  const [activeTab, setActiveTab] = useState<ActivityTab>('actividad');
  const [followedIds, setFollowedIds] = useState<Record<string, boolean>>({});
  const [dismissedRecIds, setDismissedRecIds] = useState<Record<string, boolean>>({});

  const handleToggleFollow = (id: string, name: string) => {
    const next = !followedIds[id];
    setFollowedIds((prev) => ({ ...prev, [id]: next }));
    onNotify?.(next ? `Ahora sigues a ${name}` : `Dejaste de seguir a ${name}`);
  };

  const handleDismissRec = (id: string) => {
    setDismissedRecIds((prev) => ({ ...prev, [id]: true }));
  };

  return (
    <div className="flex h-full w-full flex-col bg-[#0F0F0F] text-white">
      {/* AppBar superior con botón volver atrás + TabBar */}
      <header className="shrink-0 border-b border-white/10 bg-[#0F0F0F]">
        <div className="flex items-center px-2 pt-2">
          <button
            type="button"
            onClick={onBack}
            aria-label="Volver a mensajes"
            className="flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>

          <div className="flex flex-1 items-center justify-center pr-10">
            <span className="text-[16px] font-bold text-white">Actividad</span>
          </div>
        </div>

        {/* Pestañas: Actividad | Nuevos seguidores */}
        <div className="grid grid-cols-2">
          <button
            type="button"
            onClick={() => setActiveTab('actividad')}
            className="relative flex min-h-[42px] items-center justify-center px-2 text-sm font-bold transition-colors"
          >
            <span
              className={
                activeTab === 'actividad' ? 'text-white' : 'text-zinc-500 hover:text-zinc-300'
              }
            >
              Actividad
            </span>
            {activeTab === 'actividad' && (
              <span className="absolute bottom-0 left-6 right-6 h-[2.5px] rounded-full bg-[#FF2D55]" />
            )}
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('seguidores')}
            className="relative flex min-h-[42px] items-center justify-center px-2 text-sm font-bold transition-colors"
          >
            <span
              className={
                activeTab === 'seguidores' ? 'text-white' : 'text-zinc-500 hover:text-zinc-300'
              }
            >
              Nuevos seguidores
            </span>
            {activeTab === 'seguidores' && (
              <span className="absolute bottom-0 left-6 right-6 h-[2.5px] rounded-full bg-[#FF2D55]" />
            )}
          </button>
        </div>
      </header>

      {/* Contenido separado por pestaña */}
      {activeTab === 'actividad' ? (
        <ActivityTabContent
          followedIds={followedIds}
          dismissedRecIds={dismissedRecIds}
          onToggleFollow={handleToggleFollow}
          onDismissRec={handleDismissRec}
        />
      ) : (
        <NewFollowersTabContent
          followedIds={followedIds}
          dismissedRecIds={dismissedRecIds}
          onToggleFollow={handleToggleFollow}
          onDismissRec={handleDismissRec}
        />
      )}
    </div>
  );
};
