import React from 'react';
import { Check, Plus, X } from 'lucide-react';
import { UserAccount } from '../hooks/useAuthProvider';

interface SwitchAccountBottomSheetProps {
  open: boolean;
  accounts: UserAccount[];
  currentUser: UserAccount | null;
  onSelectAccount: (account: UserAccount) => void;
  onAddAccount: () => void;
  onClose: () => void;
}

export const SwitchAccountBottomSheet: React.FC<
  SwitchAccountBottomSheetProps
> = ({
  open,
  accounts,
  currentUser,
  onSelectAccount,
  onAddAccount,
  onClose,
}) => {
  if (!open) return null;

  return (
    <div
      className="absolute inset-0 z-50 flex items-end bg-black/60 backdrop-blur-[1px]"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full rounded-t-[20px] bg-[#1E1E1E] px-4 pt-3 pb-7 text-white shadow-2xl"
      >
        {/* Indicador superior */}
        <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-zinc-600" />

        {/* Título centrado con X a la derecha */}
        <div className="relative mb-4 flex items-center justify-center py-1">
          <h2 className="text-[16px] font-bold text-white">
            Cambiar de cuenta
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Cerrar"
            className="absolute right-0 flex h-8 w-8 items-center justify-center rounded-full text-zinc-300 transition-colors hover:bg-white/10"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Lista de hasta 10 cuentas */}
        <div className="max-h-72 space-y-1 overflow-y-auto no-scrollbar">
          {accounts.map((account) => {
            const isActive = currentUser?.id === account.id;
            return (
              <button
                key={account.id}
                type="button"
                onClick={() => onSelectAccount(account)}
                className="flex w-full items-center justify-between rounded-xl px-2 py-2.5 text-left transition-colors hover:bg-white/5"
              >
                <div className="flex min-w-0 items-center gap-3 pr-2">
                  <img
                    src={account.avatarUrl}
                    alt={account.username}
                    className="h-11 w-11 shrink-0 rounded-full border border-white/10 object-cover"
                  />
                  <span className="truncate text-[15px] font-semibold text-zinc-100">
                    {account.username}
                  </span>
                </div>

                {isActive ? (
                  <Check
                    className="h-5 w-5 shrink-0 text-[#FE2C55]"
                    strokeWidth={2.75}
                  />
                ) : account.unreadCount > 0 ? (
                  <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-[#FE2C55] text-[11px] font-bold text-white">
                    {account.unreadCount}
                  </span>
                ) : null}
              </button>
            );
          })}

          {/* Botón Agregar cuenta */}
          <button
            type="button"
            onClick={onAddAccount}
            className="flex w-full items-center gap-3 rounded-xl px-2 py-2.5 text-left transition-colors hover:bg-white/5"
          >
            <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-zinc-700 text-white">
              <Plus className="h-5 w-5" />
            </span>
            <span className="text-[15px] font-semibold text-zinc-100">
              Agregar cuenta
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
