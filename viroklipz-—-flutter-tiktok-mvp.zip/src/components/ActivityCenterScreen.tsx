import React, { useState } from 'react';
import {
  ArrowLeft,
  AtSign,
  ChevronRight,
  MessageSquare,
  PlayCircle,
  Repeat,
  Search,
  Settings,
  User,
} from 'lucide-react';
import { VideoHistoryScreen } from './VideoHistoryScreen';
import { CommentHistoryScreen } from './CommentHistoryScreen';
import { SearchHistoryScreen } from './SearchHistoryScreen';
import { AdActivityHistoryScreen } from './AdActivityHistoryScreen';
import { MentionHistoryScreen } from './MentionHistoryScreen';
import { AccountHistoryScreen } from './AccountHistoryScreen';
import { ContentReuseHistoryScreen } from './ContentReuseHistoryScreen';

type ActivitySubView =
  | 'menu'
  | 'video'
  | 'comments'
  | 'search'
  | 'ads'
  | 'mentions'
  | 'account'
  | 'reuse';

interface ActivityCenterScreenProps {
  onBack: () => void;
  onNotify?: (message: string) => void;
}

export const ActivityCenterScreen: React.FC<ActivityCenterScreenProps> = ({
  onBack,
  onNotify,
}) => {
  const [subView, setSubView] = useState<ActivitySubView>('menu');

  if (subView === 'video') {
    return (
      <VideoHistoryScreen
        onBack={() => setSubView('menu')}
        onNotify={onNotify}
      />
    );
  }

  if (subView === 'comments') {
    return (
      <CommentHistoryScreen
        onBack={() => setSubView('menu')}
        onNotify={onNotify}
      />
    );
  }

  if (subView === 'search') {
    return (
      <SearchHistoryScreen
        onBack={() => setSubView('menu')}
        onNotify={onNotify}
      />
    );
  }

  if (subView === 'ads') {
    return <AdActivityHistoryScreen onBack={() => setSubView('menu')} />;
  }

  if (subView === 'mentions') {
    return (
      <MentionHistoryScreen
        onBack={() => setSubView('menu')}
        onNotify={onNotify}
      />
    );
  }

  if (subView === 'account') {
    return <AccountHistoryScreen onBack={() => setSubView('menu')} />;
  }

  if (subView === 'reuse') {
    return (
      <ContentReuseHistoryScreen
        onBack={() => setSubView('menu')}
        onNotify={onNotify}
      />
    );
  }

  const menuItems = [
    {
      id: 'watched_videos',
      label: 'Historial de videos vistos',
      icon: 'play' as const,
      onPress: () => setSubView('video'),
    },
    {
      id: 'comments',
      label: 'Historial de comentarios',
      icon: 'comment' as const,
      onPress: () => setSubView('comments'),
    },
    {
      id: 'search',
      label: 'Historial de búsqueda',
      icon: 'search' as const,
      onPress: () => setSubView('search'),
    },
    {
      id: 'ads',
      label: 'Historial de actividad publicitaria',
      icon: 'ad' as const,
      onPress: () => setSubView('ads'),
    },
    {
      id: 'mentions',
      label: 'Historial de menciones',
      icon: 'at' as const,
      onPress: () => setSubView('mentions'),
    },
    {
      id: 'account',
      label: 'Historial de la cuenta',
      icon: 'user' as const,
      onPress: () => setSubView('account'),
    },
    {
      id: 'reuse',
      label: 'Historial de reutilización de contenido',
      icon: 'loop' as const,
      onPress: () => setSubView('reuse'),
    },
  ];

  const renderIcon = (
    type: 'play' | 'comment' | 'search' | 'ad' | 'at' | 'user' | 'loop'
  ) => {
    switch (type) {
      case 'play':
        return <PlayCircle className="h-5 w-5 text-zinc-200" />;
      case 'comment':
        return <MessageSquare className="h-5 w-5 text-zinc-200" />;
      case 'search':
        return <Search className="h-5 w-5 text-zinc-200" />;
      case 'ad':
        return (
          <span className="inline-flex h-5 w-5 items-center justify-center rounded border border-zinc-300 text-[9px] font-black tracking-tighter text-zinc-100">
            AD
          </span>
        );
      case 'at':
        return <AtSign className="h-5 w-5 text-zinc-200" />;
      case 'user':
        return <User className="h-5 w-5 text-zinc-200" />;
      case 'loop':
        return <Repeat className="h-5 w-5 text-zinc-200" />;
    }
  };

  return (
    <div className="flex h-full w-full flex-col bg-[#121212] text-white select-none overflow-hidden">
      {/* AppBar: Atrás, Centro de actividades centrado, Engranaje a la derecha */}
      <header className="flex h-12 shrink-0 items-center justify-between border-b border-white/10 px-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Volver al perfil"
          className="flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>

        <h1 className="text-[15px] font-bold text-white">
          Centro de actividades
        </h1>

        <button
          type="button"
          onClick={() => onNotify?.('Preferencias del Centro de actividades')}
          aria-label="Configuración del centro de actividades"
          className="flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <Settings className="h-5 w-5" />
        </button>
      </header>

      {/* ListView de opciones */}
      <div className="flex-1 min-h-0 overflow-y-auto py-2 no-scrollbar">
        <div className="divide-y divide-white/5">
          {menuItems.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={item.onPress}
              className="flex w-full items-center justify-between px-4 py-3.5 text-left transition-colors hover:bg-white/5 active:bg-white/10"
            >
              <div className="flex min-w-0 items-center gap-3.5 pr-3">
                <span className="shrink-0">{renderIcon(item.icon)}</span>
                <span className="truncate text-sm font-medium text-zinc-100">
                  {item.label}
                </span>
              </div>
              <ChevronRight className="h-4 w-4 shrink-0 text-zinc-500" />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
