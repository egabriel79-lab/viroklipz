import React, { useState } from 'react';
import { ArrowLeft } from 'lucide-react';

interface PlaybackSettingsScreenProps {
  onBack: () => void;
  onNotify?: (message: string) => void;
}

export const PlaybackSettingsScreen: React.FC<PlaybackSettingsScreenProps> = ({
  onBack,
  onNotify,
}) => {
  const [openMuted, setOpenMuted] = useState(false);
  const [autoVolume, setAutoVolume] = useState(true);
  const [autoRotation, setAutoRotation] = useState(false);
  const [objectLabels, setObjectLabels] = useState(true);

  const items = [
    {
      id: 'openMuted',
      title: 'Abrir Viroklipz en silencio',
      subtitle: 'Los videos comenzarán sin sonido al abrir la aplicación.',
      checked: openMuted,
      toggle: () => {
        const next = !openMuted;
        setOpenMuted(next);
        onNotify?.(`Abrir Viroklipz en silencio: ${next ? 'Activado' : 'Desactivado'}`);
      },
    },
    {
      id: 'autoVolume',
      title: 'Ajuste automático del volumen',
      subtitle: 'Equilibra el audio entre diferentes clips para evitar picos repentinos.',
      checked: autoVolume,
      toggle: () => {
        const next = !autoVolume;
        setAutoVolume(next);
        onNotify?.(`Ajuste automático del volumen: ${next ? 'Activado' : 'Desactivado'}`);
      },
    },
    {
      id: 'autoRotation',
      title: 'Rotación automática',
      subtitle: 'Permite rotar automáticamente los videos compatibles en pantalla horizontal.',
      checked: autoRotation,
      toggle: () => {
        const next = !autoRotation;
        setAutoRotation(next);
        onNotify?.(`Rotación automática: ${next ? 'Activado' : 'Desactivado'}`);
      },
    },
    {
      id: 'objectLabels',
      title: 'Mostrar etiquetas de objetos',
      subtitle: 'Muestra etiquetas interactivas en elementos identificados dentro del video.',
      checked: objectLabels,
      toggle: () => {
        const next = !objectLabels;
        setObjectLabels(next);
        onNotify?.(`Etiquetas de objetos: ${next ? 'Activado' : 'Desactivado'}`);
      },
    },
  ];

  return (
    <div className="flex h-full w-full flex-col bg-[#121212] text-white select-none overflow-hidden">
      <header className="relative flex h-12 shrink-0 items-center justify-center border-b border-white/10 bg-[#121212] px-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Atrás"
          className="absolute left-2 flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="text-[15px] font-bold text-white">Reproducción</h1>
      </header>

      <div className="flex-1 min-h-0 overflow-y-auto px-4 py-4 no-scrollbar">
        <div className="divide-y divide-white/5 overflow-hidden rounded-xl bg-[#1E1E1E]">
          {items.map((item) => (
            <div
              key={item.id}
              className="flex items-start justify-between gap-4 px-4 py-3.5"
            >
              <div className="min-w-0 flex-1">
                <p className="text-[14px] font-medium text-white">{item.title}</p>
                <p className="mt-1 text-xs leading-relaxed text-zinc-400">
                  {item.subtitle}
                </p>
              </div>
              <button
                type="button"
                role="switch"
                aria-checked={item.checked}
                onClick={item.toggle}
                className={`relative mt-0.5 inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors ${
                  item.checked ? 'bg-[#FF5722]' : 'bg-zinc-600'
                }`}
              >
                <span
                  className={`inline-block h-5 w-5 transform rounded-full bg-white shadow transition-transform ${
                    item.checked ? 'translate-x-5' : 'translate-x-0.5'
                  }`}
                />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
