import React from 'react';
import { ArrowLeft, UserRound } from 'lucide-react';

interface BlockedAccountsScreenProps {
  onBack: () => void;
}

export const BlockedAccountsScreen: React.FC<BlockedAccountsScreenProps> = ({
  onBack,
}) => {
  return (
    <div className="flex h-full w-full flex-col bg-[#121212] text-white select-none overflow-hidden">
      {/* AppBar */}
      <header className="relative flex h-12 shrink-0 items-center justify-center border-b border-white/10 bg-[#121212] px-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Atrás"
          className="absolute left-2 flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="text-[15px] font-bold text-white">
          Cuentas bloqueadas
        </h1>
      </header>

      {/* Estado vacío centrado */}
      <div className="flex flex-1 flex-col items-center justify-center px-6 text-center">
        <div className="mb-4 flex h-20 w-20 items-center justify-center rounded-full bg-[#1E1E1E] text-zinc-500">
          <UserRound className="h-11 w-11" />
        </div>
        <p className="text-[15px] font-semibold text-white">
          No hay cuentas bloqueadas
        </p>
      </div>
    </div>
  );
};
