import React, { useState } from 'react';
import { ArrowLeft } from 'lucide-react';

interface InboxSettingsScreenProps {
  onBack: () => void;
  onNotify?: (message: string) => void;
}

export const InboxSettingsScreen: React.FC<InboxSettingsScreenProps> = ({
  onBack,
  onNotify,
}) => {
  const [experience, setExperience] = useState<'personal' | 'profesional'>('personal');

  const selectExperience = (mode: 'personal' | 'profesional') => {
    setExperience(mode);
    onNotify?.(
      mode === 'personal'
        ? 'Experiencia seleccionada: Personal'
        : 'Experiencia seleccionada: Profesional'
    );
  };

  return (
    <div className="flex h-full w-full flex-col bg-[#121212] text-white select-none overflow-hidden">
      <header className="relative flex h-12 shrink-0 items-center justify-center border-b border-white/10 bg-[#121212] px-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Atrás"
          className="absolute left-2 flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="text-[15px] font-bold text-white">
          Bandeja de entrada y mensajes
        </h1>
      </header>

      <div className="flex-1 min-h-0 overflow-y-auto px-4 py-5 space-y-4 no-scrollbar">
        <h2 className="text-[22px] font-bold leading-snug text-white">
          Selecciona una experiencia de mensajería
        </h2>

        <div className="space-y-3 pt-1">
          {/* Tarjeta 1: Personal */}
          <button
            type="button"
            onClick={() => selectExperience('personal')}
            className={`w-full rounded-2xl border p-4 text-left transition-colors ${
              experience === 'personal'
                ? 'border-[#E91E63]/75 bg-[#1E1E1E]'
                : 'border-white/5 bg-[#1E1E1E] hover:border-white/15'
            }`}
          >
            <div className="flex items-start justify-between gap-3">
              <h3 className="text-[15px] font-bold text-white">
                Personal: chatea con amigos
              </h3>
              <span
                className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full border-2 ${
                  experience === 'personal' ? 'border-[#E91E63]' : 'border-zinc-500'
                }`}
              >
                {experience === 'personal' && (
                  <span className="h-2.5 w-2.5 rounded-full bg-[#E91E63]" />
                )}
              </span>
            </div>

            <ul className="mt-3 space-y-1.5 text-xs text-zinc-300">
              <li className="flex items-start gap-2">
                <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-zinc-400" />
                <span>Herramientas de mensajería básicas.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-zinc-400" />
                <span>Recibir todas las notificaciones.</span>
              </li>
            </ul>
          </button>

          {/* Tarjeta 2: Profesional */}
          <button
            type="button"
            onClick={() => selectExperience('profesional')}
            className={`w-full rounded-2xl border p-4 text-left transition-colors ${
              experience === 'profesional'
                ? 'border-[#E91E63]/75 bg-[#1E1E1E]'
                : 'border-white/5 bg-[#1E1E1E] hover:border-white/15'
            }`}
          >
            <div className="flex items-start justify-between gap-3">
              <h3 className="text-[15px] font-bold text-white">
                Profesional: interactúa con tus seguidores
              </h3>
              <span
                className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full border-2 ${
                  experience === 'profesional' ? 'border-[#E91E63]' : 'border-zinc-500'
                }`}
              >
                {experience === 'profesional' && (
                  <span className="h-2.5 w-2.5 rounded-full bg-[#E91E63]" />
                )}
              </span>
            </div>

            <ul className="mt-3 space-y-1.5 text-xs text-zinc-300">
              <li className="flex items-start gap-2">
                <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-zinc-400" />
                <span>Carpetas organizadas para mensajes principales, colaboraciones y no leídos.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-zinc-400" />
                <span>Respuestas automáticas, palabras clave y mensajes de bienvenida avanzados.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-zinc-400" />
                <span>Filtros avanzados para gestionar consultas de seguidores y marcas.</span>
              </li>
            </ul>
          </button>
        </div>
      </div>
    </div>
  );
};
