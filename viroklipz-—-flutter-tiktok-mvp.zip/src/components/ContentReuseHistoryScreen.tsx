import React from 'react';
import { ArrowLeft, ChevronRight, Repeat } from 'lucide-react';

interface ContentReuseItem {
  id: string;
  thumbUrl: string;
  hashtags: string;
  publicationsLabel: string;
  group: string;
}

const REUSE_ITEMS: ContentReuseItem[] = [
  {
    id: 'cr-1',
    thumbUrl: '/src/assets/images/story_hinduismo_temple_1794607243976.jpg',
    hashtags: '#desarrollopersonal #gabriel #mentalidad',
    publicationsLabel: '1 publicación',
    group: 'Esta semana',
  },
  {
    id: 'cr-2',
    thumbUrl: '/src/assets/images/avatar_creator_valeria_1794604321625.jpg',
    hashtags: '#beats #musicaproduccion #studio',
    publicationsLabel: '3 publicaciones',
    group: 'Esta semana',
  },
  {
    id: 'cr-3',
    thumbUrl: '/src/assets/images/avatar_creator_diego_1794604323122.jpg',
    hashtags: '#fotografia #35mm #viajes',
    publicationsLabel: '1 publicación',
    group: 'Noviembre',
  },
];

interface ContentReuseHistoryScreenProps {
  onBack: () => void;
  onNotify?: (message: string) => void;
}

export const ContentReuseHistoryScreen: React.FC<
  ContentReuseHistoryScreenProps
> = ({ onBack, onNotify }) => {
  const groups = Array.from(new Set(REUSE_ITEMS.map((item) => item.group)));

  return (
    <div className="flex h-full w-full flex-col bg-[#121212] text-white select-none overflow-hidden">
      {/* AppBar */}
      <header className="flex h-12 shrink-0 items-center gap-1 border-b border-white/10 px-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Volver al centro de actividades"
          className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>

        <h1 className="truncate text-[15px] font-bold text-white">
          Historial de reutilización de contenido
        </h1>
      </header>

      {/* Lista agrupada por fechas */}
      <div className="flex-1 min-h-0 overflow-y-auto pb-6 no-scrollbar">
        {groups.map((group) => {
          const entries = REUSE_ITEMS.filter((item) => item.group === group);
          return (
            <section key={group} className="pt-3">
              <h2 className="px-4 pb-1.5 text-xs font-semibold uppercase tracking-wide text-zinc-400">
                {group}
              </h2>
              <div className="divide-y divide-white/5">
                {entries.map((entry) => (
                  <button
                    key={entry.id}
                    type="button"
                    onClick={() =>
                      onNotify?.(`Viendo ${entry.publicationsLabel}`)
                    }
                    className="flex w-full items-center gap-3 px-4 py-3 text-left transition-colors hover:bg-white/5"
                  >
                    <img
                      src={entry.thumbUrl}
                      alt={entry.hashtags}
                      className="h-14 w-11 shrink-0 rounded-lg bg-zinc-800 object-cover"
                    />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium text-white">
                        {entry.hashtags}
                      </p>
                      <div className="mt-1 flex items-center gap-1.5 text-xs text-zinc-400">
                        <Repeat className="h-3.5 w-3.5 text-zinc-400" />
                        <span>{entry.publicationsLabel}</span>
                      </div>
                    </div>
                    <ChevronRight className="h-4 w-4 shrink-0 text-zinc-500" />
                  </button>
                ))}
              </div>
            </section>
          );
        })}
      </div>
    </div>
  );
};
