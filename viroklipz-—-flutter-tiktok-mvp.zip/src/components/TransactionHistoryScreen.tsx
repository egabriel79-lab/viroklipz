import React, { useState } from 'react';
import {
  ArrowLeft,
  Check,
  Mail,
  SlidersHorizontal,
  X,
} from 'lucide-react';

export const TRANSACTION_FILTERS = [
  'Todo',
  'Comprar',
  'Recompensas',
  'Pago',
  'Ajuste de la plataforma',
  'Reembolsar',
  'Deducción',
] as const;

export type TransactionFilter = (typeof TRANSACTION_FILTERS)[number];

interface TransactionHistoryScreenProps {
  onBack: () => void;
  onNotify?: (message: string) => void;
}

export const TransactionHistoryScreen: React.FC<
  TransactionHistoryScreenProps
> = ({ onBack }) => {
  const [selectedFilter, setSelectedFilter] =
    useState<TransactionFilter>('Todo');
  const [showFilterSheet, setShowFilterSheet] = useState(false);

  return (
    <div className="relative flex h-full w-full flex-col bg-white text-zinc-950 select-none overflow-hidden">
      {/* AppBar */}
      <header className="flex h-12 shrink-0 items-center justify-between border-b border-zinc-100 bg-white px-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Atrás"
          className="flex h-10 w-10 items-center justify-center rounded-full text-zinc-900 transition-colors hover:bg-zinc-100"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>

        <h1 className="text-[15.5px] font-bold tracking-tight text-zinc-950">
          Historial de transacciones
        </h1>

        <button
          type="button"
          onClick={() => setShowFilterSheet(true)}
          aria-label="Filtrar transacciones"
          className="flex h-10 w-10 items-center justify-center rounded-full text-zinc-800 transition-colors hover:bg-zinc-100"
        >
          <SlidersHorizontal className="h-4.5 w-4.5" />
        </button>
      </header>

      {/* Fila de Filtros horizontal */}
      <div className="shrink-0 border-b border-zinc-100 bg-white">
        <div className="flex items-center gap-2 overflow-x-auto px-4 py-3 no-scrollbar">
          {TRANSACTION_FILTERS.map((filter) => {
            const isSelected = selectedFilter === filter;
            return (
              <button
                key={filter}
                type="button"
                onClick={() => setSelectedFilter(filter)}
                className={`shrink-0 rounded-lg px-3.5 py-1.5 text-xs font-semibold whitespace-nowrap transition-colors ${
                  isSelected
                    ? 'bg-zinc-950 text-white'
                    : 'bg-zinc-100 text-zinc-700 hover:bg-zinc-200'
                }`}
              >
                {filter}
              </button>
            );
          })}
        </div>
      </div>

      {/* Estado Vacío */}
      <main className="flex flex-1 min-h-0 flex-col items-center justify-center px-6 text-center">
        <div className="flex h-20 w-20 items-center justify-center rounded-full bg-zinc-50 text-zinc-300">
          <Mail className="h-12 w-12 stroke-[1.4]" />
        </div>

        <p className="mt-4 text-[15px] font-bold text-zinc-900">
          Aún no hay transacciones
        </p>

        {selectedFilter !== 'Todo' && (
          <p className="mt-1 text-xs text-zinc-500">
            Filtro activo: {selectedFilter}
          </p>
        )}

        <button
          type="button"
          onClick={() => setShowFilterSheet(true)}
          className="mt-2.5 px-3 py-1.5 text-xs font-bold text-[#FE2C55] transition-opacity hover:opacity-80"
        >
          Selecciona otro filtro
        </button>
      </main>

      {/* Footer informativo */}
      <footer className="shrink-0 px-6 pb-5 pt-3 text-center">
        <p className="text-[11px] leading-relaxed text-zinc-400">
          Saldo no es un producto financiero. Los detalles que se muestran son
          solo para fines informativos.
        </p>
      </footer>

      {/* Bottom Sheet de selección de filtro */}
      {showFilterSheet && (
        <div
          className="absolute inset-0 z-30 flex items-end bg-black/45"
          onClick={() => setShowFilterSheet(false)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full rounded-t-3xl bg-white px-5 pt-4 pb-6 shadow-2xl"
          >
            <div className="flex items-center justify-between pb-3 border-b border-zinc-100">
              <h2 className="text-sm font-bold text-zinc-950">
                Filtrar por tipo de transacción
              </h2>
              <button
                type="button"
                onClick={() => setShowFilterSheet(false)}
                aria-label="Cerrar filtros"
                className="flex h-8 w-8 items-center justify-center rounded-full text-zinc-500 hover:bg-zinc-100"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="mt-2 divide-y divide-zinc-100">
              {TRANSACTION_FILTERS.map((filter) => {
                const isSelected = selectedFilter === filter;
                return (
                  <button
                    key={filter}
                    type="button"
                    onClick={() => {
                      setSelectedFilter(filter);
                      setShowFilterSheet(false);
                    }}
                    className="flex w-full items-center justify-between py-3 text-left text-sm transition-colors hover:bg-zinc-50"
                  >
                    <span
                      className={
                        isSelected
                          ? 'font-bold text-zinc-950'
                          : 'font-medium text-zinc-700'
                      }
                    >
                      {filter}
                    </span>
                    {isSelected && (
                      <Check className="h-4 w-4 text-[#FE2C55]" />
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
