import { useCallback, useState } from 'react';

export interface UserAccount {
  id: string;
  username: string;
  displayName: string;
  email: string;
  avatarUrl: string;
  unreadCount: number;
}

export const MAX_SAVED_ACCOUNTS = 10;

const INITIAL_ACCOUNTS: UserAccount[] = [
  {
    id: 'acc-gabriel',
    username: 'gabriel_12343',
    displayName: 'Eloy',
    email: 'gabriel_12343@viroklipz.app',
    avatarUrl: '/src/assets/images/avatar_creator_mateo_1794604321715.jpg',
    unreadCount: 0,
  },
  {
    id: 'acc-eloy',
    username: 'eloy_p79',
    displayName: 'Eloy Palma',
    email: 'eloy_p79@viroklipz.app',
    avatarUrl: '/src/assets/images/avatar_creator_lucas_1794604322245.jpg',
    unreadCount: 1,
  },
];

export function useAuthProvider() {
  const [savedAccounts, setSavedAccounts] = useState<UserAccount[]>(INITIAL_ACCOUNTS);
  const [currentUser, setCurrentUser] = useState<UserAccount | null>(INITIAL_ACCOUNTS[0]);

  const switchAccount = useCallback((account: UserAccount) => {
    setSavedAccounts((prev) =>
      prev.map((item) =>
        item.id === account.id ? { ...item, unreadCount: 0 } : item
      )
    );
    setCurrentUser({ ...account, unreadCount: 0 });
  }, []);

  const addAccount = useCallback(
    (account: UserAccount): { ok: boolean; error?: string } => {
      const existing = savedAccounts.find(
        (item) =>
          item.id === account.id ||
          item.username.toLowerCase() === account.username.toLowerCase()
      );
      if (existing) {
        switchAccount(existing);
        return { ok: true };
      }

      if (savedAccounts.length >= MAX_SAVED_ACCOUNTS) {
        return {
          ok: false,
          error: `No puedes guardar más de ${MAX_SAVED_ACCOUNTS} cuentas en este dispositivo.`,
        };
      }

      const normalized: UserAccount = { ...account, unreadCount: 0 };
      setSavedAccounts((prev) => [...prev, normalized]);
      setCurrentUser(normalized);
      return { ok: true };
    },
    [savedAccounts, switchAccount]
  );

  const signOut = useCallback(() => {
    setCurrentUser(null);
  }, []);

  const deleteAccount = useCallback(
    (account: UserAccount): { signedOut: boolean } => {
      const wasCurrent = currentUser?.id === account.id;
      setSavedAccounts((prev) => prev.filter((item) => item.id !== account.id));
      if (wasCurrent) {
        setCurrentUser(null);
      }
      return { signedOut: wasCurrent };
    },
    [currentUser]
  );

  const ensureActiveUser = useCallback(() => {
    if (currentUser) return currentUser;
    const fallback = savedAccounts[0] ?? INITIAL_ACCOUNTS[0];
    setCurrentUser(fallback);
    if (savedAccounts.length === 0) {
      setSavedAccounts([fallback]);
    }
    return fallback;
  }, [currentUser, savedAccounts]);

  const updateCurrentUserProfile = useCallback(
    (updates: Partial<Pick<UserAccount, 'avatarUrl' | 'displayName' | 'username'>>) => {
      setCurrentUser((prev) => {
        if (!prev) return prev;
        const updated = { ...prev, ...updates };
        setSavedAccounts((accounts) =>
          accounts.map((acc) => (acc.id === updated.id ? updated : acc))
        );
        return updated;
      });
    },
    []
  );

  return {
    savedAccounts,
    currentUser,
    switchAccount,
    addAccount,
    deleteAccount,
    signOut,
    ensureActiveUser,
    updateCurrentUserProfile,
  };
}
