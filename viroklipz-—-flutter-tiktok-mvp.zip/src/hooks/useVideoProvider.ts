import { useCallback, useMemo, useState } from 'react';
import { VideoItem } from '../data/mockVideos';

export function useVideoProvider(currentUserId: string, currentUsername: string) {
  const [followingIds, setFollowingIds] = useState<Set<string>>(() => new Set());
  const [allVideos, setAllVideos] = useState<VideoItem[]>([]);

  // Para ti / Radar: devuelve todos los videos publicados reales
  const forYouFeed = useMemo(() => allVideos, [allVideos]);

  // Comunidad / Círculo: devuelve solo los videos cuyo authorId está en followingIds o es mi propio ID
  const friendsFeed = useMemo(
    () =>
      allVideos.filter(
        (video) =>
          followingIds.has(video.authorId) || video.authorId === currentUserId
      ),
    [allVideos, followingIds, currentUserId]
  );

  const isFollowing = useCallback(
    (authorId: string) => followingIds.has(authorId),
    [followingIds]
  );

  const toggleFollow = useCallback(
    (authorId: string): boolean => {
      if (authorId === currentUserId) return true;
      const nowFollowing = !followingIds.has(authorId);
      setFollowingIds((prev) => {
        const next = new Set(prev);
        if (next.has(authorId)) {
          next.delete(authorId);
        } else {
          next.add(authorId);
        }
        return next;
      });
      return nowFollowing;
    },
    [currentUserId, followingIds]
  );

  const loadMoreVideos = useCallback(() => {
    // Sin generación artificial de datos falsos
  }, []);

  const incrementCommentsCount = useCallback((videoId: string) => {
    setAllVideos((prev) =>
      prev.map((video) =>
        video.id === videoId
          ? { ...video, commentsCount: video.commentsCount + 1 }
          : video
      )
    );
  }, []);

  const uploadVideo = useCallback(
    (payload: {
      videoUrl: string;
      description: string;
      hashtags?: string[];
      audioName: string;
      audioUrl?: string;
      effectUsed?: string;
      effectVideoUrl?: string;
      cssFilter?: string;
      avatarUrl?: string;
    }) => {
      const created: VideoItem = {
        id: `vk-user-${Date.now()}`,
        authorId: currentUserId,
        username: currentUsername,
        displayName: currentUsername,
        avatarUrl:
          payload.avatarUrl ??
          '/src/assets/images/avatar_creator_mateo_1794604321715.jpg',
        videoUrl: payload.videoUrl,
        caption: payload.description,
        hashtags: payload.hashtags ?? [],
        audioName: payload.audioName,
        audioUrl: payload.audioUrl,
        effectUsed: payload.effectUsed,
        effectVideoUrl: payload.effectVideoUrl,
        cssFilter: payload.cssFilter,
        likes: 0,
        commentsCount: 0,
        shares: 0,
        isFollowing: true,
        feedType: 'para_ti',
        comments: [],
      };
      setAllVideos((prev) => [created, ...prev]);
    },
    [currentUserId, currentUsername]
  );

  return {
    followingIds,
    allVideos,
    forYouFeed,
    friendsFeed,
    isFollowing,
    toggleFollow,
    loadMoreVideos,
    incrementCommentsCount,
    uploadVideo,
  };
}
