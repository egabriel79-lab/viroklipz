export interface VideoComment {
  id: string;
  username: string;
  text: string;
  timeAgo: string;
  likes: number;
}

export interface VideoItem {
  id: string;
  authorId: string;
  username: string;
  displayName: string;
  avatarUrl: string;
  videoUrl: string;
  caption: string;
  hashtags?: string[];
  audioName: string;
  audioUrl?: string;
  effectUsed?: string;
  effectVideoUrl?: string;
  cssFilter?: string;
  likes: number;
  commentsCount: number;
  shares: number;
  isFollowing: boolean;
  feedType: 'para_ti' | 'siguiendo';
  comments: VideoComment[];
}

export const CURRENT_USER_ID = 'me';

export const INITIAL_FOLLOWING_IDS: string[] = [];

export const MOCK_VIDEOS: VideoItem[] = [];
