export interface CoinPackage {
  id: string;
  coins: number;
  bonus: number;
  priceText: string;
}

export const COIN_PACKAGES: CoinPackage[] = [
  { id: 'pkg-10', coins: 10, bonus: 5, priceText: 'USD 0,08' },
  { id: 'pkg-50', coins: 50, bonus: 15, priceText: 'USD 0,39' },
  { id: 'pkg-100', coins: 100, bonus: 30, priceText: 'USD 0,79' },
  { id: 'pkg-500', coins: 500, bonus: 150, priceText: 'USD 3,99' },
  { id: 'pkg-1000', coins: 1000, bonus: 300, priceText: 'USD 7,99' },
  { id: 'pkg-2000', coins: 2000, bonus: 600, priceText: 'USD 14,99' },
];
