export interface FlutterSourceFile {
  id: string;
  path: string;
  phase: string;
  language: 'yaml' | 'dart' | 'sql' | 'xml' | 'javascript' | 'json' | 'rules';
  summary: string;
  code: string;
}

export const FLUTTER_FOLDER_TREE = `viroklipz/
├── pubspec.yaml
├── firestore.rules                      (Reglas de seguridad Cloud Firestore para producción)
├── supabase_schema.sql                  (SQL para Supabase Editor)
├── android_ios_permissions.xml          (AndroidManifest.xml + Info.plist + POST_NOTIFICATIONS)
├── firebase_setup_guide.yaml            (CLI FlutterFire + Gradle + Cloud Functions)
├── android_release_guide.yaml           (Keystore + flutter build appbundle + Checklist Play Store)
├── functions/
│   ├── index.js                         (Cloud Function Firestore -> FCM Admin SDK)
│   └── package.json                     (Dependencias firebase-admin + firebase-functions)
└── lib/
    ├── main.dart                        (Firebase.initializeApp + FCM Background + MultiProvider)
    ├── firebase_options.dart            (Generado por flutterfire configure)
    ├── config/
    │   └── env_config.dart              (Variables --dart-define)
    ├── models/
    │   ├── app_user.dart                (Modelo de usuario AppUser)
    │   ├── user_account.dart            (Modelo UserAccount para multicuenta)
    │   ├── coin_package.dart            (Paquetes de recarga de Monedas Viroklipz)
    │   ├── video_post.dart              (Modelo VideoPost con AppUser)
    │   └── video_model.dart             (Modelo alineado a tabla videos)
    ├── providers/
    │   ├── auth_provider.dart           (AuthProvider: cuentas + registro de fcmToken)
    │   ├── user_provider.dart           (UserProvider: stream users/{uid} + upload avatarUrl)
    │   └── video_provider.dart          (VideoProvider: likes, comments, follow + notifications)
    ├── services/
    │   ├── push_notification_service.dart (FCM + flutter_local_notifications + deep-link)
    │   ├── supabase_video_service.dart  (Fetch & Insert en Supabase)
    │   ├── r2_upload_service.dart       (Subida S3 a Cloudflare R2)
    │   ├── video_download_service.dart  (Descarga con Dio + Gal + Permisos)
    │   └── royalty_free_media_service.dart (APIs Jamendo, Freesound y overlays)
    ├── theme/
    │   └── app_colors.dart              (Paleta Viroklipz: #FF5722, #E91E63, #673AB7)
    ├── screens/
    │   ├── landing_screen.dart          (Landing IA Glassmorphism antes del Login)
    │   ├── register_form_screen.dart    (Registro con país, verificación de edad < 18 y tutor legal)
    │   ├── auth_screen.dart             (Login / Registro Supabase Auth)
    │   ├── main_screen.dart             (BottomAppBar + Botón Circular Glow Viroklipz)
    │   ├── feed_screen.dart             (Feed Radar / Círculo conectado a VideoProvider)
    │   ├── video_detail_screen.dart     (Visor directo de video abierto desde notificación FCM)
    │   ├── friends_feed_screen.dart     (Comunidad inmersiva a pantalla completa)
    │   ├── messages_screen.dart         (Bandeja de entrada)
    │   ├── chat_screen.dart             (Chat 1 a 1 con indicador Escribiendo... en Firestore)
    │   ├── activity_screen.dart         (TabBar Actividad + Nuevos seguidores)
    │   ├── system_notifications_screen.dart (Filtros + Tarjetas de sistema)
    │   ├── profile_screen.dart          (Perfil + SliverGrid 9:16)
    │   ├── edit_profile_screen.dart     (Editar perfil + Bottom Sheet Agregar fondo)
    │   ├── media_picker_screen.dart     (Selector de publicaciones 9:16)
    │   ├── edit_description_screen.dart (Editar descripción + retorno a Perfil)
    │   ├── viroklipz_studio_screen.dart (Métricas de creador + Monetización)
    │   ├── select_highlight_media_screen.dart (Galería para nuevo destacado)
    │   ├── story_viewer_screen.dart     (Visor full-screen de Stories / Destacados)
    │   ├── qr_profile_screen.dart       (Tarjeta QR del perfil + copiar/compartir + escáner)
    │   ├── qr_scanner_screen.dart       (Escáner QR en vivo con mobile_scanner + flash)
    │   ├── activity_center_screen.dart  (Centro de actividades Dark Mode)
    │   ├── video_history_screen.dart    (Historial de videos + Filtro por fecha)
    │   ├── comment_history_screen.dart  (Historial de comentarios + Ordenar por)
    │   ├── search_history_screen.dart   (Historial de búsqueda agrupado)
    │   ├── ad_activity_history_screen.dart (Actividad publicitaria 3 pestañas)
    │   ├── mention_history_screen.dart  (Historial de menciones en fotos)
    │   ├── account_history_screen.dart  (Historial de inicios de sesión)
    │   ├── content_reuse_history_screen.dart (Historial de reutilización)
    │   ├── offline_videos_screen.dart   (300 vídeos sin conexión + PageView)
    │   ├── settings_privacy_screen.dart (Ajustes y privacidad Dark Mode + Cambiar cuenta)
    │   ├── content_preferences_screen.dart (Preferencias de contenido + Bottom Sheet Switch)
    │   ├── notifications_settings_screen.dart (Notificaciones Push y en app + Switches)
    │   ├── wellbeing_screen.dart        (Tiempo y bienestar + Gráfico + Tarjetas)
    │   ├── family_sync_screen.dart      (Sincronización familiar + Tutor/Adolescente)
    │   ├── invite_family_screen.dart    (Invitación familiar + Buscador + Código QR)
    │   ├── account_settings_screen.dart (Ajustes de Cuenta Dark Mode)
    │   ├── security_permissions_screen.dart (Seguridad y permisos + Switch inicio sesión)
    │   ├── share_profile_bottom_sheet.dart (Bottom Sheet blanco Compartir perfil)
    │   ├── private_account_screen.dart  (Cuenta privada + Switch)
    │   ├── blocked_accounts_screen.dart (Cuentas bloqueadas Empty State)
    │   ├── mentions_settings_screen.dart (Menciones + Audiencia)
    │   ├── comments_settings_screen.dart (Comentarios + Modal + Filtros)
    │   ├── direct_messages_settings_screen.dart (Mensajes directos + Modo seguro)
    │   ├── reuse_content_screen.dart    (Reutilizar contenido + Historial)
    │   ├── downloads_settings_screen.dart (Descargas de videos + Switch)
    │   ├── privacy_audience_bottom_sheet.dart (Bottom Sheet blanco Lista Siguiendo / Me gusta)
    │   ├── viewers_settings_screen.dart (Espectadores + Banner fusionado + Switch)
    │   ├── music_settings_screen.dart   (Aplicación de música + Vincular)
    │   ├── inbox_settings_screen.dart   (Experiencia Personal / Profesional)
    │   ├── audience_control_screen.dart (Control del público +18)
    │   ├── ads_settings_screen.dart     (Plan y anuncios + Datos fuera de Viroklipz)
    │   ├── playback_settings_screen.dart (Reproducción + 4 Switches)
    │   ├── display_settings_screen.dart  (Mostrar + Claro/Oscuro + Dispositivo)
    │   ├── language_settings_screen.dart (Idiomas + Traducción)
    │   ├── accessibility_settings_screen.dart (Accesibilidad + Aspecto/Contenido/Movimiento)
    │   ├── contacts_location_settings_screen.dart (Contactos y ubicación + Switches)
    │   ├── lite_mode_screen.dart          (Modo lite + Switch activado por defecto)
    │   ├── data_saver_screen.dart         (Ahorro de datos + Switch)
    │   ├── clear_space_screen.dart        (Liberar espacio + Caché + Progreso)
    │   ├── wallpaper_settings_screen.dart (Fondo de pantalla Empty State + Flujo)
    │   ├── how_to_wallpaper_bottom_sheet.dart (Bottom Sheet Cómo establecer fondo)
    │   ├── search_wallpaper_screen.dart   (Buscador Live Wallpaper + Tabs + Grid)
    │   ├── help_center_screen.dart        (Centro de ayuda 3 pestañas + Chat soporte)
    │   ├── help_category_screen.dart      (Categorías de ayuda 3 pestañas)
    │   ├── switch_account_bottom_sheet.dart (Bottom Sheet oscuro Cambiar de cuenta)
    │   ├── get_coins_screen.dart        (Obtener Monedas · Grid 3 columnas + Banner regalo)
    │   ├── balance_screen.dart          (Saldo VES degradado suave + Monedas + Bottom Sheet)
    │   ├── transaction_history_screen.dart (Historial de transacciones + Chips de filtro)
    │   ├── privacy_center_screen.dart     (Centro de privacidad Viroklipz + Footer)
    │   ├── legal_screen.dart              (LegalScreen reutilizable StatefulWidget + Términos/Privacidad)
    │   ├── privacy_policy_screen.dart     (Política de privacidad · SingleChildScrollView)
    │   ├── terms_of_service_screen.dart   (Términos y políticas · SingleChildScrollView)
    │   ├── camera_screen.dart           (Cámara real + galería nativa image_picker)
    │   ├── video_preview_screen.dart    (Previsualización de video grabado)
    │   ├── post_video_screen.dart       (Preview + Firebase Storage + Firestore)
    │   └── create_video_screen.dart     (Preview loop + R2 + Supabase)
    └── widgets/
        ├── video_card.dart              (VideoCard: Stack dual VideoPlayer + visibility_detector)
        ├── video_overlay.dart             (StreamBuilder likesCount, commentsCount y Follow)
        ├── comments_bottom_sheet.dart   (Bottom Sheet comentarios en tiempo real + Firestore)
        ├── sound_picker_sheet.dart      (Bottom Sheet Música Jamendo / Efectos Freesound + just_audio)
        ├── effects_gallery_sheet.dart   (Galería de efectos visuales overlay MP4)
        └── marquee_text.dart`;

export const FLUTTER_FILES: FlutterSourceFile[] = [
  {
    id: 'app_colors',
    path: 'lib/theme/app_colors.dart',
    phase: 'Branding Viroklipz · Paleta y Degradados',
    language: 'dart',
    summary:
      'Constantes oficiales de Viroklipz: Naranja (#FF5722), Magenta (#E91E63), Morado Oscuro (#673AB7), degradado principal y superficies oscuras.',
    code: `import 'package:flutter/material.dart';

class AppColors {
  AppColors._();

  static const Color orange = Color(0xFFFF5722);
  static const Color magenta = Color(0xFFE91E63);
  static const Color deepPurple = Color(0xFF673AB7);

  static const Color background = Color(0xFF121212);
  static const Color surface = Color(0xFF1E1E1E);

  static const LinearGradient brandGradient = LinearGradient(
    colors: [orange, magenta, deepPurple],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}`,
  },
  {
    id: 'pubspec',
    path: 'pubspec.yaml',
    phase: 'Backend, Audio just_audio, FCM & Descargas · Dependencias',
    language: 'yaml',
    summary:
      'Incluye firebase_messaging, flutter_local_notifications, just_audio, http, video_player, visibility_detector, firebase_core, firebase_auth, cloud_firestore, firebase_storage, uuid, camera, image_picker, dio, gal y permission_handler.',
    code: `name: viroklipz
description: MVP móvil de videos verticales estilo TikTok con Firebase, FCM Push, Supabase, Cloudflare R2, just_audio y efectos overlay.
publish_to: 'none'
version: 1.0.0+1

environment:
  sdk: '>=3.3.0 <4.0.0'

dependencies:
  flutter:
    sdk: flutter
  cupertino_icons: ^1.0.8
  firebase_core: ^3.6.0
  firebase_auth: ^5.3.1
  cloud_firestore: ^5.4.4
  firebase_storage: ^12.3.4
  firebase_messaging: ^15.1.3
  flutter_local_notifications: ^17.2.3
  uuid: ^4.5.1
  provider: ^6.1.1
  video_player: ^2.9.2
  visibility_detector: ^0.4.0+2
  just_audio: ^0.9.40
  http: ^1.2.2
  marquee: ^2.2.3
  supabase_flutter: ^2.8.0
  image_picker: ^1.1.2
  file_picker: ^8.1.2
  camera: ^0.11.0+2
  dio: ^5.7.0
  gal: ^2.3.0
  permission_handler: ^11.3.1
  path_provider: ^2.1.4
  device_info_plus: ^10.1.2
  minio: ^3.5.7
  path: ^1.9.0
  qr_flutter: ^4.1.0
  share_plus: ^10.1.0
  mobile_scanner: ^6.0.2

dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^4.0.0

flutter:
  uses-material-design: true`,
  },
  {
    id: 'supabase_sql',
    path: 'supabase_schema.sql',
    phase: 'Backend · Esquema SQL',
    language: 'sql',
    summary:
      'Ejecutar en el SQL Editor de Supabase: crea public.users, public.videos, trigger automático de perfil y políticas RLS.',
    code: `-- 1. Tabla pública de perfiles vinculada a auth.users
create table if not exists public.users (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  avatar_url text,
  created_at timestamptz not null default now()
);

-- 2. Tabla de videos del feed
create table if not exists public.videos (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users(id) on delete cascade,
  username text not null,
  video_url text not null,
  description text not null default '',
  audio_name text not null default 'Sonido original',
  likes_count integer not null default 0,
  created_at timestamptz not null default now()
);

create index if not exists videos_created_at_idx
  on public.videos (created_at desc);

-- 3. Trigger para crear perfil en public.users automáticamente al registrarse
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.users (id, username)
  values (
    new.id,
    coalesce(
      new.raw_user_meta_data ->> 'username',
      split_part(new.email, '@', 1)
    )
  );
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- 4. Row Level Security (RLS)
alter table public.users enable row level security;
alter table public.videos enable row level security;

-- Lectura pública para el feed y perfiles
create policy "Perfiles visibles para todos"
  on public.users for select
  using (true);

create policy "Videos visibles para todos"
  on public.videos for select
  using (true);

-- Solo usuarios autenticados insertan sus propios videos
create policy "Usuarios autenticados crean sus videos"
  on public.videos for insert
  to authenticated
  with check (auth.uid() = user_id);

-- Solo el dueño puede actualizar o borrar su video
create policy "Solo el dueño edita su video"
  on public.videos for update
  to authenticated
  using (auth.uid() = user_id);`,
  },
  {
    id: 'env_config',
    path: 'lib/config/env_config.dart',
    phase: 'Paso 1 · Variables de Entorno',
    language: 'dart',
    summary:
      'Centraliza las credenciales de Supabase, Cloudflare R2, Jamendo Client ID y Freesound API Key mediante --dart-define sin quemar secretos en el código.',
    code: `class EnvConfig {
  static const String supabaseUrl = String.fromEnvironment(
    'SUPABASE_URL',
    defaultValue: 'https://TU_PROYECTO.supabase.co',
  );

  static const String supabaseAnonKey = String.fromEnvironment(
    'SUPABASE_ANON_KEY',
    defaultValue: 'TU_SUPABASE_ANON_KEY',
  );

  // Cloudflare R2 (endpoint S3 SIN https://)
  static const String r2Endpoint = String.fromEnvironment(
    'R2_ENDPOINT',
    defaultValue: 'TU_ACCOUNT_ID.r2.cloudflarestorage.com',
  );

  static const String r2AccessKey = String.fromEnvironment(
    'R2_ACCESS_KEY',
    defaultValue: 'TU_R2_ACCESS_KEY_ID',
  );

  static const String r2SecretKey = String.fromEnvironment(
    'R2_SECRET_KEY',
    defaultValue: 'TU_R2_SECRET_ACCESS_KEY',
  );

  static const String r2BucketName = String.fromEnvironment(
    'R2_BUCKET_NAME',
    defaultValue: 'viroklipz-videos',
  );

  // Dominio público del bucket (r2.dev o dominio personalizado)
  static const String r2PublicBaseUrl = String.fromEnvironment(
    'R2_PUBLIC_BASE_URL',
    defaultValue: 'https://pub-TU_HASH.r2.dev',
  );

  // Jamendo API (Música libre de derechos: https://devportal.jamendo.com)
  static const String jamendoClientId = String.fromEnvironment(
    'JAMENDO_CLIENT_ID',
    defaultValue: 'TU_JAMENDO_CLIENT_ID',
  );

  // Freesound API (Efectos de sonido: https://freesound.org/apiv2/apply)
  static const String freesoundApiKey = String.fromEnvironment(
    'FREESOUND_API_KEY',
    defaultValue: 'TU_FREESOUND_API_KEY',
  );
}`,
  },
  {
    id: 'main',
    path: 'lib/main.dart',
    phase: 'Paso 1 & 2 · Firebase Init + FCM Background + MultiProvider',
    language: 'dart',
    summary:
      'Inicializa Firebase, registra FirebaseMessaging.onBackgroundMessage, inicializa PushNotificationService con navigatorKey global y configura MultiProvider + AuthGate.',
    code: `import 'package:firebase_auth/firebase_auth.dart' hide AuthProvider;
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'firebase_options.dart';
import 'providers/auth_provider.dart';
import 'providers/user_provider.dart';
import 'providers/video_provider.dart';
import 'screens/landing_screen.dart';
import 'screens/main_screen.dart';
import 'services/push_notification_service.dart';

Future<void> main() async {
  // 1. Obligatorio antes de inicializar plugins nativos
  WidgetsFlutterBinding.ensureInitialized();

  // 2. Inicializar Firebase antes de arrancar la aplicación
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  // 3. Registrar handler para notificaciones Push cuando la app está cerrada/background
  FirebaseMessaging.onBackgroundMessage(firebaseMessagingBackgroundHandler);

  // 4. Inicializar FCM + flutter_local_notifications (foreground + clics)
  await PushNotificationService.instance.initialize();

  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: Colors.black,
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (context) => AuthProvider()),
        ChangeNotifierProvider(create: (context) => UserProvider()),
        ChangeNotifierProvider(create: (context) => VideoProvider()),
      ],
      child: const ViroklipzApp(),
    ),
  );
}

class ViroklipzApp extends StatelessWidget {
  const ViroklipzApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Viroklipz',
      navigatorKey: PushNotificationService.navigatorKey,
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF121212),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFFFF5722),
          secondary: Color(0xFFE91E63),
          surface: Color(0xFF1E1E1E),
        ),
        useMaterial3: true,
      ),
      routes: {
        '/landing': (context) => const LandingScreen(),
      },
      home: const AuthGate(),
    );
  }
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            backgroundColor: Color(0xFF121212),
            body: Center(
              child: CircularProgressIndicator(color: Color(0xFFFF5722)),
            ),
          );
        }
        if (snapshot.hasData) {
          return const MainScreen();
        }
        return const LandingScreen();
      },
    );
  }
}`,
  },
  {
    id: 'app_user_model',
    path: 'lib/models/app_user.dart',
    phase: 'Modelos MVP · Usuario',
    language: 'dart',
    summary:
      'Modelo AppUser (id, username, avatarUrl) para autores y sesión actual dentro del MVP con Provider.',
    code: `class AppUser {
  final String id;
  final String username;
  final String avatarUrl;

  AppUser({
    required this.id,
    required this.username,
    required this.avatarUrl,
  });

  factory AppUser.fromMap(Map<String, dynamic> map) {
    return AppUser(
      id: (map['id'] ?? '').toString(),
      username: (map['username'] ?? 'usuario').toString(),
      avatarUrl: (map['avatar_url'] ?? '').toString(),
    );
  }
}`,
  },
  {
    id: 'video_post_model',
    path: 'lib/models/video_post.dart',
    phase: 'Modelos MVP · Post de Video (Firestore)',
    language: 'dart',
    summary:
      'Modelo VideoPost con videoUrl, audioName, audioUrl, effectUsed, effectVideoUrl, caption, author, likes, comments y factory VideoPost.fromFirestore.',
    code: `import 'package:cloud_firestore/cloud_firestore.dart';
import 'app_user.dart';

class VideoPost {
  final String id;
  final AppUser author;
  final String videoUrl;
  final String? imageUrl;
  final String? audioName;
  final String? audioUrl;
  final String? effectUsed;
  final String? effectVideoUrl;
  final String caption;
  final List<String> hashtags;
  final int likes;
  final int comments;
  final List<String> likedBy;

  VideoPost({
    required this.id,
    required this.author,
    required this.videoUrl,
    this.imageUrl,
    this.audioName,
    this.audioUrl,
    this.effectUsed,
    this.effectVideoUrl,
    required this.caption,
    this.hashtags = const [],
    this.likes = 0,
    this.comments = 0,
    this.likedBy = const [],
  });

  factory VideoPost.fromFirestore(
    DocumentSnapshot<Map<String, dynamic>> doc,
  ) {
    final data = doc.data() ?? <String, dynamic>{};
    final String rawAudioName = (data['audioName'] ?? '').toString().trim();
    final String rawAudioUrl = (data['audioUrl'] ?? '').toString().trim();
    final String rawEffectUsed = (data['effectUsed'] ?? '').toString().trim();
    final String rawEffectUrl =
        (data['effectVideoUrl'] ?? '').toString().trim();
    final rawLikes = data['likes'] ?? data['likesCount'] ?? 0;
    final rawComments = data['comments'] ?? data['commentsCount'] ?? 0;
    final String resolvedUid =
        (data['uid'] ?? data['authorId'] ?? '').toString();

    return VideoPost(
      id: doc.id,
      author: AppUser(
        id: resolvedUid,
        username: (data['username'] ?? 'usuario').toString(),
        avatarUrl: (data['avatarUrl'] ?? '').toString(),
      ),
      videoUrl: (data['videoUrl'] ?? '').toString(),
      audioName: rawAudioName.isEmpty ? null : rawAudioName,
      audioUrl: rawAudioUrl.isEmpty ? null : rawAudioUrl,
      effectUsed:
          (rawEffectUsed.isEmpty || rawEffectUsed == 'Ninguno')
              ? null
              : rawEffectUsed,
      effectVideoUrl: rawEffectUrl.isEmpty ? null : rawEffectUrl,
      caption: (data['caption'] ?? '').toString(),
      hashtags: List<String>.from(data['hashtags'] ?? const <String>[]),
      likes: (rawLikes is num)
          ? rawLikes.toInt()
          : int.tryParse(rawLikes.toString()) ?? 0,
      comments: (rawComments is num)
          ? rawComments.toInt()
          : int.tryParse(rawComments.toString()) ?? 0,
      likedBy: List<String>.from(data['likedBy'] ?? const <String>[]),
    );
  }

  VideoPost copyWith({
    String? id,
    AppUser? author,
    String? videoUrl,
    String? imageUrl,
    String? audioName,
    String? audioUrl,
    String? effectUsed,
    String? effectVideoUrl,
    String? caption,
    List<String>? hashtags,
    int? likes,
    int? comments,
    List<String>? likedBy,
  }) {
    return VideoPost(
      id: id ?? this.id,
      author: author ?? this.author,
      videoUrl: videoUrl ?? this.videoUrl,
      imageUrl: imageUrl ?? this.imageUrl,
      audioName: audioName ?? this.audioName,
      audioUrl: audioUrl ?? this.audioUrl,
      effectUsed: effectUsed ?? this.effectUsed,
      effectVideoUrl: effectVideoUrl ?? this.effectVideoUrl,
      caption: caption ?? this.caption,
      hashtags: hashtags ?? this.hashtags,
      likes: likes ?? this.likes,
      comments: comments ?? this.comments,
      likedBy: likedBy ?? this.likedBy,
    );
  }
}`,
  },
  {
    id: 'user_account_model',
    path: 'lib/models/user_account.dart',
    phase: 'Modelos · UserAccount (Multicuenta)',
    language: 'dart',
    summary:
      'Modelo UserAccount para gestionar hasta 10 cuentas guardadas en AuthProvider.',
    code: `class UserAccount {
  final String id;
  final String username;
  final String email;
  final String avatarUrl;
  final int unreadCount;

  const UserAccount({
    required this.id,
    required this.username,
    required this.email,
    required this.avatarUrl,
    this.unreadCount = 0,
  });

  UserAccount copyWith({
    String? id,
    String? username,
    String? email,
    String? avatarUrl,
    int? unreadCount,
  }) {
    return UserAccount(
      id: id ?? this.id,
      username: username ?? this.username,
      email: email ?? this.email,
      avatarUrl: avatarUrl ?? this.avatarUrl,
      unreadCount: unreadCount ?? this.unreadCount,
    );
  }
}`,
  },
  {
    id: 'auth_provider',
    path: 'lib/providers/auth_provider.dart',
    phase: 'Estado · AuthProvider (FirebaseAuth + Firestore + Multicuenta)',
    language: 'dart',
    summary:
      'ChangeNotifier conectado a FirebaseAuth.instance y Cloud Firestore (colección users) con signIn, signUp, signOut, manejo de errores en español y soporte multicuenta.',
    code: `import 'dart:async';
import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../models/user_account.dart';
import '../services/push_notification_service.dart';

class AuthProvider extends ChangeNotifier {
  static const int maxSavedAccounts = 10;

  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  late final StreamSubscription<User?> _authSubscription;

  User? _firebaseUser;
  Map<String, dynamic>? _userProfile;
  bool _isLoading = false;

  final List<UserAccount> _savedAccounts = [
    const UserAccount(
      id: 'acc_gabriel',
      username: 'gabriel_12343',
      email: 'gabriel_12343@viroklipz.app',
      avatarUrl:
          'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop',
      unreadCount: 0,
    ),
    const UserAccount(
      id: 'acc_eloy',
      username: 'eloy_p79',
      email: 'eloy_p79@viroklipz.app',
      avatarUrl:
          'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop',
      unreadCount: 1,
    ),
  ];

  UserAccount? _currentUser;

  AuthProvider() {
    _firebaseUser = _auth.currentUser;
    if (_firebaseUser != null) {
      _loadUserProfile(_firebaseUser!.uid);
      PushNotificationService.instance
          .requestPermissionAndSaveToken(_firebaseUser!.uid);
    } else if (_savedAccounts.isNotEmpty) {
      _currentUser = _savedAccounts.first;
    }

    _authSubscription = _auth.authStateChanges().listen((User? user) async {
      _firebaseUser = user;
      if (user != null) {
        await _loadUserProfile(user.uid);
        await PushNotificationService.instance
            .requestPermissionAndSaveToken(user.uid);
      } else {
        _userProfile = null;
      }
      notifyListeners();
    });
  }

  User? get firebaseUser => _firebaseUser;
  Map<String, dynamic>? get userProfile => _userProfile;
  bool get isLoading => _isLoading;
  List<UserAccount> get savedAccounts => List.unmodifiable(_savedAccounts);
  UserAccount? get currentUser => _currentUser;

  Future<void> _loadUserProfile(String uid) async {
    try {
      final doc = await _firestore.collection('users').doc(uid).get();
      if (doc.exists) {
        _userProfile = doc.data();
        final data = doc.data()!;
        final account = UserAccount(
          id: uid,
          username: (data['username'] ?? 'usuario').toString(),
          email: (data['email'] ?? _firebaseUser?.email ?? '').toString(),
          avatarUrl: (data['avatarUrl'] ??
                  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop')
              .toString(),
          unreadCount: 0,
        );
        addAccount(account);
      }
    } catch (_) {
      // Silencioso si no hay conexión temporal al cargar perfil
    }
  }

  String _mapAuthError(FirebaseAuthException e) {
    switch (e.code) {
      case 'user-not-found':
        return 'Usuario no encontrado. Verifica tu correo.';
      case 'wrong-password':
        return 'Contraseña incorrecta. Intenta nuevamente.';
      case 'invalid-credential':
        return 'Correo o contraseña incorrectos.';
      case 'invalid-email':
        return 'El correo electrónico no tiene un formato válido.';
      case 'email-already-in-use':
        return 'Este correo ya está registrado en Viroklipz.';
      case 'weak-password':
        return 'La contraseña es muy débil. Usa al menos 6 caracteres.';
      case 'user-disabled':
        return 'Esta cuenta ha sido deshabilitada.';
      case 'too-many-requests':
        return 'Demasiados intentos fallidos. Espera unos minutos.';
      case 'network-request-failed':
        return 'Sin conexión a internet. Verifica tu red.';
      default:
        return e.message ?? 'Error de autenticación (\${e.code}).';
    }
  }

  /// Inicia sesión con correo y contraseña. Devuelve null si fue exitoso, o mensaje de error en español.
  Future<String?> signIn(String email, String password) async {
    _isLoading = true;
    notifyListeners();

    try {
      final credential = await _auth.signInWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );
      if (credential.user != null) {
        await _loadUserProfile(credential.user!.uid);
        // Solicitar permiso Push y guardar fcmToken en users/{uid}/fcmToken
        await PushNotificationService.instance
            .requestPermissionAndSaveToken(credential.user!.uid);
      }
      return null;
    } on FirebaseAuthException catch (e) {
      return _mapAuthError(e);
    } on SocketException {
      return 'Sin conexión a internet. Verifica tu red.';
    } catch (_) {
      return 'Ocurrió un error inesperado al iniciar sesión.';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Crea el usuario en Firebase Auth y guarda su documento en Firestore (colección "users").
  /// Si [isMinor] es true (edad < 18), exige y almacena el sub-mapa [tutor] junto con [isMinor: true].
  Future<String?> signUp(
    String email,
    String password,
    String username, {
    String? firstName,
    String? lastName,
    String? country,
    int? age,
    bool isMinor = false,
    Map<String, dynamic>? tutor,
  }) async {
    if (isMinor) {
      final tutorNombre = (tutor?['nombre'] ?? '').toString().trim();
      final tutorApellido = (tutor?['apellido'] ?? '').toString().trim();
      final tutorEmail = (tutor?['email'] ?? '').toString().trim();
      if (tutorNombre.isEmpty || tutorApellido.isEmpty || tutorEmail.isEmpty) {
        return 'Debes completar toda la información del representante legal.';
      }
    }

    _isLoading = true;
    notifyListeners();

    try {
      final cleanEmail = email.trim();
      final cleanUsername = username.trim().replaceFirst('@', '').toLowerCase();

      final credential = await _auth.createUserWithEmailAndPassword(
        email: cleanEmail,
        password: password,
      );

      final User? user = credential.user;
      if (user == null) {
        return 'No se pudo crear la cuenta de usuario.';
      }

      await user.updateDisplayName(cleanUsername);

      final Map<String, dynamic> userData = {
        'uid': user.uid,
        'email': cleanEmail,
        'username': cleanUsername,
        if (firstName != null && firstName.trim().isNotEmpty)
          'firstName': firstName.trim(),
        if (lastName != null && lastName.trim().isNotEmpty)
          'lastName': lastName.trim(),
        if (country != null && country.trim().isNotEmpty)
          'country': country.trim(),
        if (age != null) 'age': age,
        'isMinor': isMinor,
        if (isMinor && tutor != null) 'tutor': tutor,
        'avatarUrl': '',
        'createdAt': FieldValue.serverTimestamp(),
      };

      await _firestore.collection('users').doc(user.uid).set(userData);
      _userProfile = userData;

      // Solicitar permisos FCM y almacenar fcmToken en users/{uid}
      await PushNotificationService.instance
          .requestPermissionAndSaveToken(user.uid);

      addAccount(
        UserAccount(
          id: user.uid,
          username: cleanUsername,
          email: cleanEmail,
          avatarUrl:
              'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop',
          unreadCount: 0,
        ),
      );
      return null;
    } on FirebaseAuthException catch (e) {
      return _mapAuthError(e);
    } on FirebaseException catch (e) {
      return 'Error al guardar tu perfil en Firestore: \${e.message ?? e.code}';
    } on SocketException {
      return 'Sin conexión a internet. Verifica tu red.';
    } catch (_) {
      return 'Ocurrió un error inesperado al crear la cuenta.';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  void switchAccount(UserAccount account) {
    final index = _savedAccounts.indexWhere((item) => item.id == account.id);
    if (index != -1) {
      _savedAccounts[index] = _savedAccounts[index].copyWith(unreadCount: 0);
      _currentUser = _savedAccounts[index];
    } else {
      _currentUser = account.copyWith(unreadCount: 0);
    }
    notifyListeners();
  }

  String? addAccount(UserAccount account) {
    final existingIndex = _savedAccounts.indexWhere(
      (item) =>
          item.id == account.id ||
          item.username.toLowerCase() == account.username.toLowerCase(),
    );
    if (existingIndex != -1) {
      switchAccount(_savedAccounts[existingIndex]);
      return null;
    }

    if (_savedAccounts.length >= maxSavedAccounts) {
      return 'Error: límite máximo de \$maxSavedAccounts cuentas alcanzado';
    }

    final normalized = account.copyWith(unreadCount: 0);
    _savedAccounts.add(normalized);
    _currentUser = normalized;
    notifyListeners();
    return null;
  }

  Future<void> signOut() async {
    _currentUser = null;
    _userProfile = null;
    try {
      await _auth.signOut();
    } catch (_) {}
    notifyListeners();
  }

  Future<bool> deleteAccount(UserAccount account) async {
    final bool isCurrent = _currentUser?.id == account.id;
    _savedAccounts.removeWhere((item) => item.id == account.id);
    if (isCurrent) {
      try {
        final String? uid = _auth.currentUser?.uid;
        if (uid != null) {
          await _firestore.collection('users').doc(uid).delete();
        }
        await _auth.currentUser?.delete();
      } catch (_) {}
      await signOut();
      return true;
    }
    notifyListeners();
    return false;
  }

  /// Elimina permanentemente el documento en Firestore (users/{uid}) y la cuenta en FirebaseAuth.
  /// Devuelve null si tuvo éxito, o un mensaje de error en español (incluyendo requires-recent-login).
  Future<String?> deleteCurrentUserAccount() async {
    final User? user = _auth.currentUser;
    if (user == null) {
      return 'No hay una sesión activa para eliminar.';
    }

    try {
      // Paso A: Eliminar documento del usuario en Firestore
      await _firestore.collection('users').doc(user.uid).delete();

      // Paso B: Eliminar cuenta en Firebase Authentication
      await user.delete();

      _savedAccounts.removeWhere((item) => item.id == user.uid);
      _currentUser = null;
      _userProfile = null;
      notifyListeners();
      return null;
    } on FirebaseAuthException catch (e) {
      if (e.code == 'requires-recent-login') {
        return 'Por seguridad, debes cerrar sesión y volver a iniciarla antes de eliminar tu cuenta';
      }
      return _mapAuthError(e);
    } on FirebaseException catch (e) {
      return 'Error al eliminar los datos en Firestore: \${e.message ?? e.code}';
    } catch (_) {
      return 'Ocurrió un error inesperado al eliminar tu cuenta.';
    }
  }

  @override
  void dispose() {
    _authSubscription.cancel();
    super.dispose();
  }
}

`,
  },
  {
    id: 'user_provider',
    path: 'lib/providers/user_provider.dart',
    phase: 'Estado · UserProvider (Avatar en Tiempo Real + Storage)',
    language: 'dart',
    summary:
      'ChangeNotifier conectado en tiempo real al documento users/{uid} de Firestore y FirebaseStorage (avatars/{uid}.jpg) para actualizar la foto de perfil en toda la app.',
    code: `import 'dart:async';
import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';

class UserProvider extends ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;

  StreamSubscription<User?>? _authSubscription;
  StreamSubscription<DocumentSnapshot<Map<String, dynamic>>>? _userDocSubscription;

  String? _uid;
  String _avatarUrl = '';
  String _username = '';
  String _displayName = '';
  String _bio = '';
  bool _isUploadingAvatar = false;

  UserProvider() {
    _bindUser(_auth.currentUser);
    _authSubscription = _auth.authStateChanges().listen(_bindUser);
  }

  String? get uid => _uid;
  String get avatarUrl => _avatarUrl;
  String get username => _username;
  String get displayName => _displayName;
  String get bio => _bio;
  bool get isUploadingAvatar => _isUploadingAvatar;

  void _bindUser(User? user) {
    _userDocSubscription?.cancel();
    _userDocSubscription = null;

    if (user == null) {
      _uid = null;
      _avatarUrl = '';
      _username = '';
      _displayName = '';
      _bio = '';
      notifyListeners();
      return;
    }

    _uid = user.uid;
    _avatarUrl = user.photoURL ?? '';
    _username = user.displayName ?? '';
    notifyListeners();

    _userDocSubscription = _firestore
        .collection('users')
        .doc(user.uid)
        .snapshots()
        .listen((snapshot) {
      final data = snapshot.data();
      if (data == null) return;
      _avatarUrl = (data['avatarUrl'] ?? user.photoURL ?? '').toString();
      _username = (data['username'] ?? user.displayName ?? '').toString();
      _displayName = (data['firstName'] ?? data['username'] ?? '').toString();
      _bio = (data['bio'] ?? '').toString();
      notifyListeners();
    });
  }

  /// Sube la imagen a avatars/{uid}.jpg, actualiza FirebaseAuth photoURL y Firestore users/{uid}.avatarUrl
  Future<String?> updateProfileAvatar(File imageFile) async {
    final User? user = _auth.currentUser;
    if (user == null) {
      throw Exception('Debes iniciar sesión para actualizar tu foto.');
    }

    _isUploadingAvatar = true;
    notifyListeners();

    try {
      final Reference storageRef = _storage.ref('avatars/\${user.uid}.jpg');
      await storageRef.putFile(imageFile);
      final String downloadUrl = await storageRef.getDownloadURL();

      await user.updatePhotoURL(downloadUrl);
      await _firestore.collection('users').doc(user.uid).set(
        {'avatarUrl': downloadUrl},
        SetOptions(merge: true),
      );

      _avatarUrl = downloadUrl;
      notifyListeners();
      return downloadUrl;
    } finally {
      _isUploadingAvatar = false;
      notifyListeners();
    }
  }

  /// Permite asignar una URL existente (ej. desde publicaciones) y propagarla en tiempo real
  Future<void> updateAvatarFromUrl(String url) async {
    final User? user = _auth.currentUser;
    if (user == null) return;

    _isUploadingAvatar = true;
    notifyListeners();

    try {
      await user.updatePhotoURL(url);
      await _firestore.collection('users').doc(user.uid).set(
        {'avatarUrl': url},
        SetOptions(merge: true),
      );
      _avatarUrl = url;
      notifyListeners();
    } finally {
      _isUploadingAvatar = false;
      notifyListeners();
    }
  }

  @override
  void dispose() {
    _userDocSubscription?.cancel();
    _authSubscription?.cancel();
    super.dispose();
  }
}`,
  },
  {
    id: 'video_provider',
    path: 'lib/providers/video_provider.dart',
    phase: 'Estado · VideoProvider (Firestore Real sin Mock Data)',
    language: 'dart',
    summary:
      'ChangeNotifier conectado en tiempo real a Cloud Firestore (videos, following, likes, comments y notifications) sin datos de prueba estáticos.',
    code: `import 'dart:async';
import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:uuid/uuid.dart';
import '../models/app_user.dart';
import '../models/video_model.dart';
import '../models/video_post.dart';

class VideoProvider extends ChangeNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  StreamSubscription<User?>? _authSub;
  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? _followingSub;

  AppUser get currentUser {
    final User? user = _auth.currentUser;
    return AppUser(
      id: user?.uid ?? '',
      username: user?.displayName ?? user?.email?.split('@').first ?? 'usuario',
      avatarUrl: user?.photoURL ?? '',
    );
  }

  // Set de IDs de usuarios a los que sigo (sincronizado desde Firestore)
  final Set<String> followingIds = {};
  final Set<String> likedPostIds = {};

  // Lista reactiva proveniente de Firestore (sin datos estáticos falsos)
  final List<VideoPost> allVideos = [];

  VideoProvider() {
    _bindFollowingStream();
  }

  void _bindFollowingStream() {
    _listenFollowing(_auth.currentUser?.uid);
    _authSub = _auth.authStateChanges().listen((user) {
      _listenFollowing(user?.uid);
      notifyListeners();
    });
  }

  void _listenFollowing(String? uid) {
    _followingSub?.cancel();
    followingIds.clear();
    if (uid == null) {
      notifyListeners();
      return;
    }

    _followingSub = _firestore
        .collection('users')
        .doc(uid)
        .collection('following')
        .snapshots()
        .listen((snap) {
      followingIds
        ..clear()
        ..addAll(snap.docs.map((doc) => doc.id));
      notifyListeners();
    });
  }

  @override
  void dispose() {
    _followingSub?.cancel();
    _authSub?.cancel();
    super.dispose();
  }

  List<VideoPost> get forYouFeed => List.unmodifiable(allVideos);

  List<VideoPost> get friendsFeed {
    final String myUid = currentUser.id;
    return allVideos
        .where(
          (video) =>
              followingIds.contains(video.author.id) ||
              (myUid.isNotEmpty && video.author.id == myUid),
        )
        .toList();
  }

  bool isFollowing(String userId) => followingIds.contains(userId);
  bool isLiked(String videoId) => likedPostIds.contains(videoId);

  void syncFromFirestore(List<VideoPost> remoteVideos) {
    allVideos
      ..clear()
      ..addAll(remoteVideos);
    notifyListeners();
  }

  void syncFromSupabase(List<VideoModel> remoteVideos) {
    final mapped = remoteVideos
        .map(
          (v) => VideoPost(
            id: v.id,
            author: AppUser(id: v.userId, username: v.username, avatarUrl: ''),
            videoUrl: v.videoUrl,
            caption: v.description,
            likes: v.likesCount,
          ),
        )
        .toList();

    allVideos
      ..clear()
      ..addAll(mapped);
    notifyListeners();
  }

  Future<String?> _resolveSenderName(User user) async {
    try {
      final userDoc = await _firestore.collection('users').doc(user.uid).get();
      final String name = (userDoc.data()?['username'] ??
              user.displayName ??
              user.email?.split('@').first ??
              'Alguien')
          .toString()
          .trim();
      return name.isNotEmpty ? name : 'Alguien';
    } catch (_) {
      return user.displayName ?? user.email?.split('@').first ?? 'Alguien';
    }
  }

  /// Registra una notificación en Firestore ("notifications") para que la Cloud Function envíe el Push FCM.
  Future<void> _createNotification({
    required String receiverUid,
    required String type,
    String? videoId,
    String? senderNameOverride,
  }) async {
    final User? user = _auth.currentUser;
    if (user == null || receiverUid.isEmpty || receiverUid == user.uid) {
      return;
    }

    final String senderName = (senderNameOverride != null &&
            senderNameOverride.trim().isNotEmpty)
        ? senderNameOverride.trim()
        : (await _resolveSenderName(user)) ?? 'Alguien';

    await _firestore.collection('notifications').add({
      'senderUid': user.uid,
      'senderName': senderName,
      'receiverUid': receiverUid,
      'type': type, // 'like' | 'comment' | 'follow'
      if (videoId != null && videoId.isNotEmpty) 'videoId': videoId,
      'read': false,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  // Seguir / Dejar de seguir en Firestore (users/{miUid}/following + users/{suUid}/followers)
  Future<void> toggleFollow(String targetUid) async {
    final String? myUid = _auth.currentUser?.uid;
    if (myUid == null || targetUid.isEmpty || targetUid == myUid) {
      return;
    }

    final bool currentlyFollowing = followingIds.contains(targetUid);
    if (currentlyFollowing) {
      followingIds.remove(targetUid);
    } else {
      followingIds.add(targetUid);
    }
    notifyListeners();

    final DocumentReference<Map<String, dynamic>> myFollowingRef = _firestore
        .collection('users')
        .doc(myUid)
        .collection('following')
        .doc(targetUid);
    final DocumentReference<Map<String, dynamic>> targetFollowersRef = _firestore
        .collection('users')
        .doc(targetUid)
        .collection('followers')
        .doc(myUid);

    try {
      final snapshot = await myFollowingRef.get();
      final WriteBatch batch = _firestore.batch();
      final bool willFollow = !snapshot.exists;

      if (snapshot.exists) {
        batch.delete(myFollowingRef);
        batch.delete(targetFollowersRef);
      } else {
        batch.set(myFollowingRef, {
          'uid': targetUid,
          'createdAt': FieldValue.serverTimestamp(),
        });
        batch.set(targetFollowersRef, {
          'uid': myUid,
          'createdAt': FieldValue.serverTimestamp(),
        });
      }

      await batch.commit();

      if (willFollow) {
        await _createNotification(
          receiverUid: targetUid,
          type: 'follow',
        );
      }
    } catch (_) {
      // Revertir en caso de error de red
      if (currentlyFollowing) {
        followingIds.add(targetUid);
      } else {
        followingIds.remove(targetUid);
      }
      notifyListeners();
    }
  }

  /// Sube el video a Firebase Storage (videos/<uuid>.mp4) y crea el documento en Firestore ("videos").
  Future<void> uploadVideoToFirebase({
    required String videoPath,
    required String caption,
    String? username,
    String? avatarUrl,
  }) async {
    final User? user = _auth.currentUser;
    if (user == null) {
      throw Exception('Debes iniciar sesión para publicar un video.');
    }

    String resolvedUsername = (username ?? '').trim();
    String resolvedAvatarUrl = (avatarUrl ?? '').trim();

    if (resolvedUsername.isEmpty || resolvedAvatarUrl.isEmpty) {
      try {
        final userDoc = await _firestore
            .collection('users')
            .doc(user.uid)
            .get();
        final data = userDoc.data();
        if (resolvedUsername.isEmpty) {
          resolvedUsername = (data?['username'] ??
                  user.displayName ??
                  user.email?.split('@').first ??
                  'usuario')
              .toString();
        }
        if (resolvedAvatarUrl.isEmpty) {
          resolvedAvatarUrl =
              (data?['avatarUrl'] ?? user.photoURL ?? '').toString();
        }
      } catch (_) {
        if (resolvedUsername.isEmpty) {
          resolvedUsername =
              user.displayName ?? user.email?.split('@').first ?? 'usuario';
        }
      }
    }

    // Paso A: Garantizar extensión .mp4 y subir con SettableMetadata(contentType: 'video/mp4')
    File file = File(videoPath);
    if (!file.path.toLowerCase().endsWith('.mp4')) {
      final Directory tempDir = await getTemporaryDirectory();
      final String mp4Path =
          '\${tempDir.path}/viroklipz_\${DateTime.now().millisecondsSinceEpoch}.mp4';
      file = await file.copy(mp4Path);
    }

    final String uniqueId = const Uuid().v4();
    final Reference storageRef =
        FirebaseStorage.instance.ref('videos/\$uniqueId.mp4');
    final metadata = SettableMetadata(contentType: 'video/mp4');
    final UploadTask uploadTask = storageRef.putFile(file, metadata);
    final TaskSnapshot snapshot = await uploadTask;
    final String downloadUrl = await snapshot.ref.getDownloadURL();

    // Paso B: Extraer hashtags y guardar metadata del video en Cloud Firestore
    final String cleanCaption = caption.trim();
    final List<String> hashtags = RegExp(r'#([\p{L}\p{N}_]+)', unicode: true)
        .allMatches(cleanCaption)
        .map((m) => (m.group(1) ?? '').trim().toLowerCase())
        .where((tag) => tag.isNotEmpty)
        .toSet()
        .toList();

    await _firestore.collection('videos').add({
      'videoUrl': downloadUrl,
      'caption': cleanCaption,
      'hashtags': hashtags,
      'uid': user.uid,
      'authorId': user.uid,
      'username': resolvedUsername,
      'avatarUrl': resolvedAvatarUrl,
      'likedBy': <String>[],
      'likes': 0,
      'likesCount': 0,
      'comments': 0,
      'commentsCount': 0,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  /// Like (Fuego) conectado a Firestore: likedBy + likes/likesCount con FieldValue.increment(1 / -1)
  Future<void> toggleLike(String videoId) async {
    final String? uid = _auth.currentUser?.uid;
    if (uid == null || videoId.isEmpty) return;

    final bool localLiked = likedPostIds.contains(videoId);
    if (localLiked) {
      likedPostIds.remove(videoId);
    } else {
      likedPostIds.add(videoId);
    }
    notifyListeners();

    final DocumentReference<Map<String, dynamic>> videoRef =
        _firestore.collection('videos').doc(videoId);

    String? receiverUid;
    bool didLike = false;

    try {
      await _firestore.runTransaction((transaction) async {
        final DocumentSnapshot<Map<String, dynamic>> snap =
            await transaction.get(videoRef);
        if (!snap.exists) return;

        final data = snap.data();
        receiverUid = (data?['uid'] ?? data?['authorId'] ?? '').toString();
        final List<dynamic> likedBy =
            (data?['likedBy'] as List<dynamic>?) ?? <dynamic>[];
        final bool alreadyLiked = likedBy.contains(uid);

        if (alreadyLiked) {
          didLike = false;
          transaction.update(videoRef, {
            'likedBy': FieldValue.arrayRemove([uid]),
            'likes': FieldValue.increment(-1),
            'likesCount': FieldValue.increment(-1),
          });
        } else {
          didLike = true;
          transaction.update(videoRef, {
            'likedBy': FieldValue.arrayUnion([uid]),
            'likes': FieldValue.increment(1),
            'likesCount': FieldValue.increment(1),
          });
        }
      });

      if (didLike) {
        likedPostIds.add(videoId);
      } else {
        likedPostIds.remove(videoId);
      }
      notifyListeners();

      // Al dar like, guardar documento en "notifications" para disparar Cloud Function FCM
      if (didLike && receiverUid != null && receiverUid!.isNotEmpty) {
        await _createNotification(
          receiverUid: receiverUid!,
          type: 'like',
          videoId: videoId,
        );
      }
    } catch (_) {
      // Revertir en caso de error
      if (localLiked) {
        likedPostIds.add(videoId);
      } else {
        likedPostIds.remove(videoId);
      }
      notifyListeners();
    }
  }

  /// Guarda un comentario en videos/{videoId}/comments, incrementa comments/commentsCount y notifica al autor
  Future<void> addComment({
    required String videoId,
    required String text,
    String? username,
  }) async {
    final String trimmed = text.trim();
    final User? user = _auth.currentUser;
    if (trimmed.isEmpty || user == null) return;

    String resolvedUsername = (username ?? '').trim();
    if (resolvedUsername.isEmpty) {
      resolvedUsername = (await _resolveSenderName(user)) ?? 'usuario';
    }

    final DocumentReference<Map<String, dynamic>> videoRef =
        _firestore.collection('videos').doc(videoId);
    final DocumentReference<Map<String, dynamic>> commentRef =
        videoRef.collection('comments').doc();

    final WriteBatch batch = _firestore.batch();
    batch.set(commentRef, {
      'uid': user.uid,
      'username': resolvedUsername,
      'text': trimmed,
      'createdAt': FieldValue.serverTimestamp(),
    });
    batch.set(
      videoRef,
      {
        'comments': FieldValue.increment(1),
        'commentsCount': FieldValue.increment(1),
      },
      SetOptions(merge: true),
    );
    await batch.commit();

    try {
      final videoSnap = await videoRef.get();
      final String receiverUid =
          (videoSnap.data()?['uid'] ?? videoSnap.data()?['authorId'] ?? '')
              .toString();
      if (receiverUid.isNotEmpty) {
        await _createNotification(
          receiverUid: receiverUid,
          type: 'comment',
          videoId: videoId,
          senderNameOverride: resolvedUsername,
        );
      }
    } catch (_) {}
  }
}`,
  },
  {
    id: 'model',
    path: 'lib/models/video_model.dart',
    phase: 'Paso 1 · Modelo Supabase',
    language: 'dart',
    summary:
      'Modelo tipado con los campos exactos de la tabla videos (id, user_id, username, video_url, description, audio_name, likes_count).',
    code: `class VideoModel {
  final String id;
  final String userId;
  final String username;
  final String videoUrl;
  final String description;
  final String audioName;
  final int likesCount;

  const VideoModel({
    required this.id,
    required this.userId,
    required this.username,
    required this.videoUrl,
    required this.description,
    required this.audioName,
    required this.likesCount,
  });

  factory VideoModel.fromMap(Map<String, dynamic> map) {
    return VideoModel(
      id: (map['id'] ?? '').toString(),
      userId: (map['user_id'] ?? '').toString(),
      username: (map['username'] ?? 'usuario').toString(),
      videoUrl: (map['video_url'] ?? '').toString(),
      description: (map['description'] ?? '').toString(),
      audioName: (map['audio_name'] ?? 'Sonido original').toString(),
      likesCount: (map['likes_count'] as num?)?.toInt() ?? 0,
    );
  }

  Map<String, dynamic> toInsertMap() {
    return {
      'user_id': userId,
      'username': username,
      'video_url': videoUrl,
      'description': description,
      'audio_name': audioName,
      'likes_count': likesCount,
    };
  }
}`,
  },
  {
    id: 'landing_screen',
    path: 'lib/screens/landing_screen.dart',
    phase: 'Rediseño · Landing Page Social (Antes del Login)',
    language: 'dart',
    summary:
      'Landing page en #0F0F0F para red social de videos verticales con navegación a RegisterFormScreen y AuthScreen.',
    code: `import 'dart:ui';
import 'package:flutter/material.dart';
import 'auth_screen.dart';
import 'register_form_screen.dart';

class LandingScreen extends StatefulWidget {
  const LandingScreen({super.key});

  @override
  State<LandingScreen> createState() => _LandingScreenState();
}

class _LandingScreenState extends State<LandingScreen> {
  final ScrollController _scrollController = ScrollController();

  void _navigateToLogin() {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const AuthScreen()),
    );
  }

  void _navigateToRegister() {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const RegisterFormScreen()),
    );
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F0F0F),
      body: Stack(
        children: [
          // Resplandores ambientales neón de fondo
          Positioned(
            top: -90,
            left: -60,
            child: _AmbientGlow(
              size: 280,
              color: const Color(0xFFFF6B00).withValues(alpha: 0.22),
            ),
          ),
          Positioned(
            top: 220,
            right: -80,
            child: _AmbientGlow(
              size: 260,
              color: const Color(0xFF9333EA).withValues(alpha: 0.22),
            ),
          ),

          SafeArea(
            child: SingleChildScrollView(
              controller: _scrollController,
              padding: const EdgeInsets.only(bottom: 40),
              child: LayoutBuilder(
                builder: (context, constraints) {
                  final bool isCompact = constraints.maxWidth < 520;

                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      // 1. BARRA DE NAVEGACIÓN SUPERIOR (Solo Logo + Únete gratis)
                      Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 14,
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text(
                              'Viroklipz',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 21,
                                fontWeight: FontWeight.w900,
                                letterSpacing: -0.6,
                              ),
                            ),
                            _NeonGradientButton(
                              label: 'Únete gratis',
                              compact: isCompact,
                              onPressed: _navigateToRegister,
                            ),
                          ],
                        ),
                      ),

                      // 2. SECCIÓN HERO
                      Padding(
                        padding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
                        child: Column(
                          children: [
                            Text(
                              'Viroklipz',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: isCompact ? 44 : 54,
                                fontWeight: FontWeight.w900,
                                height: 1.0,
                                letterSpacing: -1.2,
                                color: Colors.white,
                              ),
                            ),
                            const SizedBox(height: 12),
                            RichText(
                              textAlign: TextAlign.center,
                              text: TextSpan(
                                style: TextStyle(
                                  fontSize: isCompact ? 32 : 42,
                                  fontWeight: FontWeight.w900,
                                  height: 1.08,
                                  letterSpacing: -0.8,
                                  color: Colors.white,
                                ),
                                children: [
                                  const TextSpan(text: 'Comparte tus '),
                                  WidgetSpan(
                                    alignment: PlaceholderAlignment.baseline,
                                    baseline: TextBaseline.alphabetic,
                                    child: ShaderMask(
                                      shaderCallback: (bounds) =>
                                          const LinearGradient(
                                        colors: [
                                          Color(0xFFFF8A00),
                                          Color(0xFFFF3D5A),
                                          Color(0xFFEC4899),
                                        ],
                                      ).createShader(bounds),
                                      child: Text(
                                        'Videos',
                                        style: TextStyle(
                                          fontSize: isCompact ? 32 : 42,
                                          fontWeight: FontWeight.w900,
                                          height: 1.08,
                                          letterSpacing: -0.8,
                                          color: Colors.white,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 14),
                            const ConstrainedBox(
                              constraints: BoxConstraints(maxWidth: 520),
                              child: Text(
                                'La red social de videos verticales. Sube tus clips, descubre creadores increíbles y hazte viral en segundos.',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: Color(0xFFA1A1AA),
                                  fontSize: 15,
                                  height: 1.5,
                                ),
                              ),
                            ),
                            const SizedBox(height: 24),
                            Wrap(
                              spacing: 12,
                              runSpacing: 12,
                              alignment: WrapAlignment.center,
                              children: [
                                _NeonGradientButton(
                                  label: 'Crear cuenta',
                                  onPressed: _navigateToRegister,
                                ),
                                OutlinedButton.icon(
                                  onPressed: _navigateToLogin,
                                  icon: const Icon(
                                    Icons.login_rounded,
                                    color: Colors.white,
                                    size: 18,
                                  ),
                                  label: const Text(
                                    'Inicio',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                  style: OutlinedButton.styleFrom(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 20,
                                      vertical: 14,
                                    ),
                                    side: BorderSide(
                                      color: Colors.white.withValues(alpha: 0.25),
                                    ),
                                    backgroundColor:
                                        Colors.white.withValues(alpha: 0.04),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(14),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 28),

                            // Visual central 3D futurista con Glassmorphism frame
                            _GlassCard(
                              padding: const EdgeInsets.all(6),
                              borderRadius: 22,
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(16),
                                child: AspectRatio(
                                  aspectRatio: 4 / 3,
                                  child: Image.network(
                                    'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=1000&auto=format&fit=crop',
                                    fit: BoxFit.cover,
                                    errorBuilder: (_, __, ___) => Container(
                                      decoration: const BoxDecoration(
                                        gradient: LinearGradient(
                                          begin: Alignment.topLeft,
                                          end: Alignment.bottomRight,
                                          colors: [
                                            Color(0xFFFF6B00),
                                            Color(0xFF9333EA),
                                            Color(0xFF1D4ED8),
                                          ],
                                        ),
                                      ),
                                      child: const Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Icon(
                                            Icons.view_in_ar_rounded,
                                            color: Colors.white,
                                            size: 54,
                                          ),
                                          SizedBox(height: 10),
                                          Text(
                                            'Viroklipz Social',
                                            style: TextStyle(
                                              color: Colors.white,
                                              fontSize: 16,
                                              fontWeight: FontWeight.w800,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),

                      // Cómo funciona
                      const Padding(
                        padding: EdgeInsets.symmetric(
                          horizontal: 20,
                          vertical: 10,
                        ),
                        child: _GlassCard(
                          padding: EdgeInsets.all(18),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Cómo funciona',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 17,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                              SizedBox(height: 10),
                              Text(
                                '01. Graba o sube tus videos verticales directamente desde tu teléfono.\n'
                                '02. Edita, ponle tu música favorita y dale tu estilo único.\n'
                                '03. Publica en el feed, compártelo con tus amigos y consigue seguidores.',
                                style: TextStyle(
                                  color: Color(0xFFD4D4D8),
                                  fontSize: 13.5,
                                  height: 1.6,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),

                      // 4. SOCIAL PROOF (Testimonios)
                      const SizedBox(height: 22),
                      Column(
                        children: [
                          SizedBox(
                            height: 38,
                            width: 150,
                            child: Stack(
                              alignment: Alignment.center,
                              children: List.generate(5, (index) {
                                final colors = [
                                  const Color(0xFFFF6B00),
                                  const Color(0xFFEC4899),
                                  const Color(0xFF9333EA),
                                  const Color(0xFF3B82F6),
                                  const Color(0xFF10B981),
                                ];
                                return Positioned(
                                  left: index * 24.0,
                                  child: Container(
                                    width: 36,
                                    height: 36,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: colors[index],
                                      border: Border.all(
                                        color: const Color(0xFF0F0F0F),
                                        width: 2.5,
                                      ),
                                    ),
                                    child: const Icon(
                                      Icons.person_rounded,
                                      color: Colors.white,
                                      size: 18,
                                    ),
                                  ),
                                );
                              }),
                            ),
                          ),
                          const SizedBox(height: 10),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: List.generate(
                              5,
                              (_) => const Icon(
                                Icons.star_rounded,
                                color: Color(0xFFFBBF24),
                                size: 20,
                              ),
                            ),
                          ),
                          const SizedBox(height: 6),
                          const Text(
                            'Amado por más de 100,000 creadores',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 13.5,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ],
                      ),
                    ],
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _AmbientGlow extends StatelessWidget {
  final double size;
  final Color color;

  const _AmbientGlow({required this.size, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(
            color: color,
            blurRadius: 110,
            spreadRadius: 40,
          ),
        ],
      ),
    );
  }
}

class _NeonGradientButton extends StatelessWidget {
  final String label;
  final VoidCallback onPressed;
  final bool compact;

  const _NeonGradientButton({
    required this.label,
    required this.onPressed,
    this.compact = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(compact ? 11 : 14),
        gradient: const LinearGradient(
          colors: [Color(0xFFFF6B00), Color(0xFFEC4899)],
        ),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFFF6B00).withValues(alpha: 0.45),
            blurRadius: 20,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(compact ? 11 : 14),
          onTap: onPressed,
          child: Padding(
            padding: EdgeInsets.symmetric(
              horizontal: compact ? 13 : 22,
              vertical: compact ? 9 : 14,
            ),
            child: Text(
              label,
              style: TextStyle(
                color: Colors.white,
                fontSize: compact ? 12.5 : 14.5,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final double borderRadius;
  final Color? borderColor;

  const _GlassCard({
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.borderRadius = 18,
    this.borderColor,
  });

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(borderRadius),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.05),
            borderRadius: BorderRadius.circular(borderRadius),
            border: Border.all(
              color: borderColor ?? Colors.white.withValues(alpha: 0.12),
            ),
          ),
          child: child,
        ),
      ),
    );
  }
}`,
  },
  {
    id: 'register_form_screen',
    path: 'lib/screens/register_form_screen.dart',
    phase: 'Registro · RegisterFormScreen (Protección de Menores + Tutor Legal)',
    language: 'dart',
    summary:
      'StatefulWidget con campo País, listener en Edad (< 18), formulario dinámico de Representante Legal y conexión a AuthProvider.signUp con isMinor y sub-mapa tutor en Firestore.',
    code: `import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import 'auth_screen.dart';
import 'main_screen.dart';

class RegisterFormScreen extends StatefulWidget {
  const RegisterFormScreen({super.key});

  @override
  State<RegisterFormScreen> createState() => _RegisterFormScreenState();
}

class _RegisterFormScreenState extends State<RegisterFormScreen> {
  final _formKey = GlobalKey<FormState>();

  // Datos principales del creador
  final _firstNameController = TextEditingController();
  final _lastNameController = TextEditingController();
  final _countryController = TextEditingController();
  final _ageController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();

  // Datos del representante legal (solo cuando edad < 18)
  final _tutorFirstNameController = TextEditingController();
  final _tutorLastNameController = TextEditingController();
  final _tutorEmailController = TextEditingController();

  bool _isMinor = false;
  bool _isSubmitting = false;
  bool _obscurePassword = true;

  @override
  void initState() {
    super.initState();
    _ageController.addListener(_onAgeChanged);
  }

  void _onAgeChanged() {
    final int? parsedAge = int.tryParse(_ageController.text.trim());
    final bool nextIsMinor =
        parsedAge != null && parsedAge > 0 && parsedAge < 18;
    if (nextIsMinor != _isMinor) {
      setState(() {
        _isMinor = nextIsMinor;
      });
    }
  }

  @override
  void dispose() {
    _ageController.removeListener(_onAgeChanged);
    _firstNameController.dispose();
    _lastNameController.dispose();
    _countryController.dispose();
    _ageController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _tutorFirstNameController.dispose();
    _tutorLastNameController.dispose();
    _tutorEmailController.dispose();
    super.dispose();
  }

  void _showErrorSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: const Color(0xFFDC2626),
        content: Text(
          message,
          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
        ),
      ),
    );
  }

  Future<void> _submitForm() async {
    final bool isValidForm = _formKey.currentState?.validate() ?? false;
    if (!isValidForm) {
      if (_isMinor &&
          (_tutorFirstNameController.text.trim().isEmpty ||
              _tutorLastNameController.text.trim().isEmpty ||
              _tutorEmailController.text.trim().isEmpty)) {
        _showErrorSnackBar(
          'Debes completar todos los campos del representante legal.',
        );
      }
      return;
    }

    final int? parsedAge = int.tryParse(_ageController.text.trim());
    if (parsedAge == null || parsedAge <= 0) {
      _showErrorSnackBar('Ingresa una edad válida.');
      return;
    }

    final bool minorAccount = parsedAge < 18;
    if (minorAccount &&
        (_tutorFirstNameController.text.trim().isEmpty ||
            _tutorLastNameController.text.trim().isEmpty ||
            _tutorEmailController.text.trim().isEmpty)) {
      _showErrorSnackBar(
        'Para menores de 18 años es obligatorio completar los datos del tutor legal.',
      );
      return;
    }

    setState(() => _isSubmitting = true);

    final String generatedUsername =
        '\${_firstNameController.text.trim()}.\${_lastNameController.text.trim()}'
            .toLowerCase()
            .replaceAll(RegExp(r'\\s+'), '');

    final authProvider = context.read<AuthProvider>();
    final String? errorMessage = await authProvider.signUp(
      _emailController.text.trim(),
      _passwordController.text,
      generatedUsername.isEmpty ? 'creador' : generatedUsername,
      firstName: _firstNameController.text.trim(),
      lastName: _lastNameController.text.trim(),
      country: _countryController.text.trim(),
      age: parsedAge,
      isMinor: minorAccount,
      tutor: minorAccount
          ? {
              'nombre': _tutorFirstNameController.text.trim(),
              'apellido': _tutorLastNameController.text.trim(),
              'email': _tutorEmailController.text.trim(),
            }
          : null,
    );

    if (!mounted) return;
    setState(() => _isSubmitting = false);

    if (errorMessage != null) {
      _showErrorSnackBar(errorMessage);
      return;
    }

    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const MainScreen()),
      (route) => false,
    );
  }

  InputDecoration _fieldDecoration({
    required String hint,
    required IconData icon,
    Widget? suffixIcon,
    Color focusColor = const Color(0xFFFF6B00),
  }) {
    return InputDecoration(
      hintText: hint,
      hintStyle: const TextStyle(color: Color(0xFF71717A), fontSize: 14),
      prefixIcon: Icon(icon, color: const Color(0xFFA1A1AA), size: 20),
      suffixIcon: suffixIcon,
      filled: true,
      fillColor: const Color(0xFF161616),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide(color: Colors.white.withValues(alpha: 0.14)),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide(color: Colors.white.withValues(alpha: 0.14)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide(color: focusColor, width: 1.5),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: Color(0xFFFF4D6D)),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: Color(0xFFFF4D6D), width: 1.5),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F0F0F),
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: const Text(
          'Viroklipz',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w900,
            letterSpacing: -0.5,
          ),
        ),
        centerTitle: true,
      ),
      body: Stack(
        children: [
          Positioned(
            top: -90,
            left: -60,
            child: Container(
              width: 260,
              height: 260,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFFFF6B00).withValues(alpha: 0.16),
                    blurRadius: 110,
                    spreadRadius: 40,
                  ),
                ],
              ),
            ),
          ),
          Positioned(
            bottom: 40,
            right: -80,
            child: Container(
              width: 240,
              height: 240,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF9333EA).withValues(alpha: 0.16),
                    blurRadius: 110,
                    spreadRadius: 40,
                  ),
                ],
              ),
            ),
          ),
          SafeArea(
            child: SingleChildScrollView(
              keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Text(
                      'Crea tu perfil de creador',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 26,
                        fontWeight: FontWeight.w900,
                        letterSpacing: -0.6,
                      ),
                    ),
                    const SizedBox(height: 6),
                    const Text(
                      'Completa tus datos para personalizar tu cuenta en Viroklipz.',
                      style: TextStyle(
                        color: Color(0xFFA1A1AA),
                        fontSize: 13.5,
                        height: 1.45,
                      ),
                    ),
                    const SizedBox(height: 24),

                    const _FieldLabel('Nombres'),
                    TextFormField(
                      controller: _firstNameController,
                      textInputAction: TextInputAction.next,
                      style: const TextStyle(color: Colors.white),
                      decoration: _fieldDecoration(
                        hint: 'Ej. Mateo Sebastián',
                        icon: Icons.person_outline_rounded,
                      ),
                      validator: (value) {
                        if (value == null || value.trim().isEmpty) {
                          return 'Ingresa tus nombres';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 16),

                    const _FieldLabel('Apellidos'),
                    TextFormField(
                      controller: _lastNameController,
                      textInputAction: TextInputAction.next,
                      style: const TextStyle(color: Colors.white),
                      decoration: _fieldDecoration(
                        hint: 'Ej. Rivera Gómez',
                        icon: Icons.person_outline_rounded,
                      ),
                      validator: (value) {
                        if (value == null || value.trim().isEmpty) {
                          return 'Ingresa tus apellidos';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 16),

                    // 1. País en lugar de Ciudad
                    const _FieldLabel('País'),
                    TextFormField(
                      controller: _countryController,
                      textInputAction: TextInputAction.next,
                      style: const TextStyle(color: Colors.white),
                      decoration: _fieldDecoration(
                        hint: 'Escribe tu país (ej. Colombia, España, México...)',
                        icon: Icons.location_on_outlined,
                      ),
                      validator: (value) {
                        if (value == null || value.trim().isEmpty) {
                          return 'Ingresa tu país';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 16),

                    // 2. Edad con listener en tiempo real
                    const _FieldLabel('Edad'),
                    TextFormField(
                      controller: _ageController,
                      keyboardType: TextInputType.number,
                      textInputAction: TextInputAction.next,
                      style: const TextStyle(color: Colors.white),
                      decoration: _fieldDecoration(
                        hint: 'Ej. 22',
                        icon: Icons.calendar_today_outlined,
                      ),
                      validator: (value) {
                        final int? age = int.tryParse(value?.trim() ?? '');
                        if (age == null || age <= 0 || age > 120) {
                          return 'Ingresa una edad numérica válida (1 a 120)';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 16),

                    const _FieldLabel('Correo electrónico'),
                    TextFormField(
                      controller: _emailController,
                      keyboardType: TextInputType.emailAddress,
                      textInputAction: TextInputAction.next,
                      style: const TextStyle(color: Colors.white),
                      decoration: _fieldDecoration(
                        hint: 'correo@ejemplo.com',
                        icon: Icons.mail_outline_rounded,
                      ),
                      validator: (value) {
                        if (value == null || !value.contains('@')) {
                          return 'Ingresa un correo electrónico válido';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 16),

                    const _FieldLabel('Contraseña'),
                    TextFormField(
                      controller: _passwordController,
                      obscureText: _obscurePassword,
                      textInputAction:
                          _isMinor ? TextInputAction.next : TextInputAction.done,
                      style: const TextStyle(color: Colors.white),
                      decoration: _fieldDecoration(
                        hint: 'Mínimo 6 caracteres',
                        icon: Icons.lock_outline_rounded,
                        suffixIcon: IconButton(
                          icon: Icon(
                            _obscurePassword
                                ? Icons.visibility_outlined
                                : Icons.visibility_off_outlined,
                            color: const Color(0xFFA1A1AA),
                            size: 20,
                          ),
                          onPressed: () {
                            setState(() => _obscurePassword = !_obscurePassword);
                          },
                        ),
                      ),
                      validator: (value) {
                        if (value == null || value.length < 6) {
                          return 'La contraseña debe tener al menos 6 caracteres';
                        }
                        return null;
                      },
                    ),

                    // 3. Formulario dinámico para menores de 18 años
                    AnimatedSize(
                      duration: const Duration(milliseconds: 280),
                      curve: Curves.easeOutCubic,
                      child: Visibility(
                        visible: _isMinor,
                        child: Container(
                          margin: const EdgeInsets.only(top: 22),
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: const Color(0xFF161616),
                            borderRadius: BorderRadius.circular(18),
                            border: Border.all(
                              color: const Color(0xFFF59E0B).withValues(alpha: 0.35),
                            ),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: const Color(0xFFF59E0B).withValues(alpha: 0.12),
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(
                                    color: const Color(0xFFF59E0B).withValues(alpha: 0.3),
                                  ),
                                ),
                                child: const Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Icon(
                                      Icons.warning_amber_rounded,
                                      color: Color(0xFFFBBF24),
                                      size: 20,
                                    ),
                                    SizedBox(width: 10),
                                    Expanded(
                                      child: Text(
                                        'Debes tener al menos 18 años o contar con la autorización de un tutor legal',
                                        style: TextStyle(
                                          color: Color(0xFFFDE68A),
                                          fontSize: 12.5,
                                          fontWeight: FontWeight.w500,
                                          height: 1.4,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 18),
                              const Row(
                                children: [
                                  Icon(
                                    Icons.verified_user_outlined,
                                    color: Color(0xFFEC4899),
                                    size: 18,
                                  ),
                                  SizedBox(width: 8),
                                  Text(
                                    'Información del Representante Legal',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 14,
                                      fontWeight: FontWeight.w800,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 14),

                              const _FieldLabel('Nombres (del tutor)'),
                              TextFormField(
                                controller: _tutorFirstNameController,
                                textInputAction: TextInputAction.next,
                                style: const TextStyle(color: Colors.white),
                                decoration: _fieldDecoration(
                                  hint: 'Nombres del representante legal',
                                  icon: Icons.person_outline_rounded,
                                  focusColor: const Color(0xFFEC4899),
                                ),
                                validator: (value) {
                                  if (!_isMinor) return null;
                                  if (value == null || value.trim().isEmpty) {
                                    return 'Ingresa los nombres del tutor legal';
                                  }
                                  return null;
                                },
                              ),
                              const SizedBox(height: 14),

                              const _FieldLabel('Apellidos (del tutor)'),
                              TextFormField(
                                controller: _tutorLastNameController,
                                textInputAction: TextInputAction.next,
                                style: const TextStyle(color: Colors.white),
                                decoration: _fieldDecoration(
                                  hint: 'Apellidos del representante legal',
                                  icon: Icons.person_outline_rounded,
                                  focusColor: const Color(0xFFEC4899),
                                ),
                                validator: (value) {
                                  if (!_isMinor) return null;
                                  if (value == null || value.trim().isEmpty) {
                                    return 'Ingresa los apellidos del tutor legal';
                                  }
                                  return null;
                                },
                              ),
                              const SizedBox(height: 14),

                              const _FieldLabel('Correo electrónico (del tutor)'),
                              TextFormField(
                                controller: _tutorEmailController,
                                keyboardType: TextInputType.emailAddress,
                                textInputAction: TextInputAction.done,
                                style: const TextStyle(color: Colors.white),
                                decoration: _fieldDecoration(
                                  hint: 'tutor@ejemplo.com',
                                  icon: Icons.mail_outline_rounded,
                                  focusColor: const Color(0xFFEC4899),
                                ),
                                validator: (value) {
                                  if (!_isMinor) return null;
                                  final clean = value?.trim() ?? '';
                                  if (clean.isEmpty || !clean.contains('@')) {
                                    return 'Ingresa un correo válido del tutor legal';
                                  }
                                  return null;
                                },
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 28),

                    // 4. Botón dinámico según edad (< 18 vs 18+)
                    if (!_isMinor)
                      Container(
                        height: 54,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(14),
                          gradient: const LinearGradient(
                            colors: [Color(0xFFFF6B00), Color(0xFFEC4899)],
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: const Color(0xFFFF6B00).withValues(alpha: 0.45),
                              blurRadius: 22,
                              offset: const Offset(0, 6),
                            ),
                          ],
                        ),
                        child: ElevatedButton(
                          onPressed: _isSubmitting ? null : _submitForm,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.transparent,
                            shadowColor: Colors.transparent,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14),
                            ),
                          ),
                          child: _isSubmitting
                              ? const SizedBox(
                                  width: 22,
                                  height: 22,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2.5,
                                    color: Colors.white,
                                  ),
                                )
                              : const Text(
                                  'Crear mi cuenta',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 15.5,
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                        ),
                      )
                    else
                      Container(
                        height: 54,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(14),
                          gradient: const LinearGradient(
                            colors: [Color(0xFF673AB7), Color(0xFFEC4899)],
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: const Color(0xFF9333EA).withValues(alpha: 0.45),
                              blurRadius: 22,
                              offset: const Offset(0, 6),
                            ),
                          ],
                        ),
                        child: ElevatedButton.icon(
                          onPressed: _isSubmitting ? null : _submitForm,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.transparent,
                            shadowColor: Colors.transparent,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14),
                            ),
                          ),
                          icon: _isSubmitting
                              ? const SizedBox.shrink()
                              : const Icon(
                                  Icons.verified_user_rounded,
                                  color: Colors.white,
                                  size: 18,
                                ),
                          label: _isSubmitting
                              ? const SizedBox(
                                  width: 22,
                                  height: 22,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2.5,
                                    color: Colors.white,
                                  ),
                                )
                              : const Text(
                                  'Soy representante legal de menor de edad',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 14.5,
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                        ),
                      ),
                    const SizedBox(height: 12),

                    TextButton(
                      onPressed: _isSubmitting
                          ? null
                          : () {
                              Navigator.of(context).pushReplacement(
                                MaterialPageRoute(
                                  builder: (_) => const LoginScreen(),
                                ),
                              );
                            },
                      child: const Text(
                        '¿Ya tienes cuenta? Inicia sesión',
                        style: TextStyle(
                          color: Color(0xFFA1A1AA),
                          fontSize: 13,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _FieldLabel extends StatelessWidget {
  final String text;
  const _FieldLabel(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Text(
        text,
        style: const TextStyle(
          color: Color(0xFFE4E4E7),
          fontSize: 12.5,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}`,
  },
  {
    id: 'auth_screen',
    path: 'lib/screens/auth_screen.dart',
    phase: 'Paso 2 · LoginScreen / AuthScreen (FirebaseAuth)',
    language: 'dart',
    summary:
      'Pantalla LoginScreen (alias AuthScreen) conectada a AuthProvider.signIn / signUp, con CircularProgressIndicator, SnackBar rojo en errores y navegación a MainScreen.',
    code: `import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import 'main_screen.dart';

typedef AuthScreen = LoginScreen;

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _usernameController = TextEditingController();

  bool _isLogin = true;
  bool _isLoading = false;

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    _usernameController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    final authProvider = context.read<AuthProvider>();
    final email = _emailController.text.trim();
    final password = _passwordController.text;

    final String? errorMessage = _isLogin
        ? await authProvider.signIn(email, password)
        : await authProvider.signUp(
            email,
            password,
            _usernameController.text.trim(),
          );

    if (!mounted) return;
    setState(() => _isLoading = false);

    if (errorMessage != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: const Color(0xFFDC2626),
          content: Text(
            errorMessage,
            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
          ),
        ),
      );
      return;
    }

    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const MainScreen()),
      (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F0F0F),
      extendBodyBehindAppBar: true,
      appBar: Navigator.of(context).canPop()
          ? AppBar(
              backgroundColor: Colors.transparent,
              elevation: 0,
              leading: IconButton(
                icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white),
                onPressed: () => Navigator.of(context).pop(),
              ),
            )
          : null,
      body: Stack(
        children: [
          Positioned(
            top: -90,
            left: -60,
            child: Container(
              width: 260,
              height: 260,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFFFF6B00).withValues(alpha: 0.16),
                    blurRadius: 110,
                    spreadRadius: 40,
                  ),
                ],
              ),
            ),
          ),
          Positioned(
            bottom: 40,
            right: -80,
            child: Container(
              width: 240,
              height: 240,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF9333EA).withValues(alpha: 0.16),
                    blurRadius: 110,
                    spreadRadius: 40,
                  ),
                ],
              ),
            ),
          ),
          SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const Text(
                        'Viroklipz',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 34,
                          fontWeight: FontWeight.w900,
                          letterSpacing: -0.6,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        _isLogin
                            ? 'Inicia sesión para ver y publicar clips'
                            : 'Crea tu cuenta de creador',
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: Color(0xFFA1A1AA), fontSize: 14),
                      ),
                      const SizedBox(height: 32),
                      if (!_isLogin) ...[
                        TextFormField(
                          controller: _usernameController,
                          style: const TextStyle(color: Colors.white),
                          decoration: _inputDecoration(
                            'Nombre de usuario (ej. mateo.cine)',
                            Icons.person_outline_rounded,
                          ),
                          validator: (v) {
                            if (!_isLogin && (v == null || v.trim().length < 3)) {
                              return 'Ingresa al menos 3 caracteres';
                            }
                            return null;
                          },
                        ),
                        const SizedBox(height: 14),
                      ],
                      TextFormField(
                        controller: _emailController,
                        keyboardType: TextInputType.emailAddress,
                        style: const TextStyle(color: Colors.white),
                        decoration: _inputDecoration(
                          'Correo electrónico',
                          Icons.mail_outline_rounded,
                        ),
                        validator: (v) {
                          if (v == null || !v.contains('@')) {
                            return 'Ingresa un correo válido';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 14),
                      TextFormField(
                        controller: _passwordController,
                        obscureText: true,
                        style: const TextStyle(color: Colors.white),
                        decoration: _inputDecoration(
                          'Contraseña',
                          Icons.lock_outline_rounded,
                        ),
                        validator: (v) {
                          if (v == null || v.length < 6) {
                            return 'Mínimo 6 caracteres';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 24),
                      Container(
                        height: 54,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(14),
                          gradient: const LinearGradient(
                            colors: [Color(0xFFFF6B00), Color(0xFFEC4899)],
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: const Color(0xFFFF6B00).withValues(alpha: 0.45),
                              blurRadius: 22,
                              offset: const Offset(0, 6),
                            ),
                          ],
                        ),
                        child: ElevatedButton(
                          onPressed: _isLoading ? null : _submit,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.transparent,
                            shadowColor: Colors.transparent,
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14),
                            ),
                          ),
                          child: _isLoading
                              ? const SizedBox(
                                  height: 20,
                                  width: 20,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2.5,
                                    color: Colors.white,
                                  ),
                                )
                              : Text(
                                  _isLogin ? 'Entrar' : 'Crear cuenta',
                                  style: const TextStyle(
                                    fontSize: 15.5,
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      TextButton(
                        onPressed: _isLoading
                            ? null
                            : () {
                                setState(() => _isLogin = !_isLogin);
                              },
                        child: Text(
                          _isLogin
                              ? '¿No tienes cuenta? Regístrate'
                              : '¿Ya tienes cuenta? Inicia sesión',
                          style: const TextStyle(color: Color(0xFFA1A1AA)),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  InputDecoration _inputDecoration(String label, IconData icon) {
    return InputDecoration(
      hintText: label,
      hintStyle: const TextStyle(color: Color(0xFF71717A), fontSize: 14),
      prefixIcon: Icon(icon, color: const Color(0xFFA1A1AA), size: 20),
      filled: true,
      fillColor: const Color(0xFF161616),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide(color: Colors.white.withValues(alpha: 0.14)),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide(color: Colors.white.withValues(alpha: 0.14)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: Color(0xFFFF6B00), width: 1.5),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: Color(0xFFFF4D6D)),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: Color(0xFFFF4D6D), width: 1.5),
      ),
    );
  }
}`,
  },
  {
    id: 'supabase_video_service',
    path: 'lib/services/supabase_video_service.dart',
    phase: 'Paso 3 & 4 · Servicio Supabase',
    language: 'dart',
    summary:
      'Encapsula las consultas SELECT e INSERT a la tabla videos de Supabase con manejo explícito de PostgrestException y red.',
    code: `import 'dart:io';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/video_model.dart';

class SupabaseVideoService {
  final SupabaseClient _client = Supabase.instance.client;

  Future<List<VideoModel>> fetchFeedVideos() async {
    try {
      final List<dynamic> rows = await _client
          .from('videos')
          .select('id, user_id, username, video_url, description, audio_name, likes_count')
          .order('created_at', ascending: false)
          .limit(30);

      return rows
          .map((row) => VideoModel.fromMap(row as Map<String, dynamic>))
          .toList();
    } on PostgrestException catch (e) {
      throw Exception('Error en Supabase: \${e.message}');
    } on SocketException {
      throw Exception('Sin conexión a internet. Verifica tu red.');
    } catch (_) {
      throw Exception('No se pudieron cargar los videos.');
    }
  }

  Future<void> createVideoRecord({
    required String videoUrl,
    required String description,
    required String audioName,
  }) async {
    final user = _client.auth.currentUser;
    if (user == null) {
      throw Exception('Debes iniciar sesión para publicar un video.');
    }

    final String username =
        (user.userMetadata?['username'] as String?)?.trim().isNotEmpty == true
            ? user.userMetadata!['username'] as String
            : (user.email?.split('@').first ?? 'usuario');

    try {
      await _client.from('videos').insert({
        'user_id': user.id,
        'username': username,
        'video_url': videoUrl,
        'description': description,
        'audio_name': audioName.isEmpty ? 'Sonido original — \$username' : audioName,
        'likes_count': 0,
      });
    } on PostgrestException catch (e) {
      throw Exception('Error al guardar en base de datos: \${e.message}');
    } on SocketException {
      throw Exception('Se perdió la conexión al guardar el registro.');
    }
  }
}`,
  },
  {
    id: 'feed_screen',
    path: 'lib/screens/feed_screen.dart',
    phase: 'Paso 3 · Feed Radar & Círculo (Firestore StreamBuilder)',
    language: 'dart',
    summary:
      'Feed principal conectado en tiempo real a Cloud Firestore (colección videos ordenada por createdAt desc) mediante StreamBuilder, pasando datos reales a VideoCard y mostrando Empty State con botón a la cámara.',
    code: `import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart' hide AuthProvider;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/video_provider.dart';
import '../theme/app_colors.dart';
import '../widgets/video_card.dart';
import 'camera_screen.dart';

class FeedScreen extends StatefulWidget {
  final bool isFeedVisible;
  final VoidCallback? onOpenCamera;

  const FeedScreen({
    super.key,
    this.isFeedVisible = true,
    this.onOpenCamera,
  });

  @override
  State<FeedScreen> createState() => _FeedScreenState();
}

class _FeedScreenState extends State<FeedScreen> {
  late final PageController _pageController;

  int _currentPage = 0;
  int _selectedTopTab = 1; // 0 = Círculo, 1 = Radar (Inicio)

  @override
  void initState() {
    super.initState();
    _pageController = PageController();
  }

  void _switchTopTab(int tabIndex) {
    if (_selectedTopTab == tabIndex) return;
    setState(() {
      _selectedTopTab = tabIndex;
      _currentPage = 0;
    });
    if (_pageController.hasClients) {
      _pageController.jumpToPage(0);
    }
  }

  void _openCameraFallback() {
    if (widget.onOpenCamera != null) {
      widget.onOpenCamera!();
      return;
    }
    Navigator.of(context).push(
      MaterialPageRoute(
        fullscreenDialog: true,
        builder: (_) => const CameraScreen(),
      ),
    );
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final videoProvider = context.watch<VideoProvider>();
    final String? currentUid = FirebaseAuth.instance.currentUser?.uid;

    return Stack(
      children: [
        StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: FirebaseFirestore.instance
              .collection('videos')
              .orderBy('createdAt', descending: true)
              .snapshots(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting &&
                !snapshot.hasData) {
              return const Center(
                child: CircularProgressIndicator(color: AppColors.orange),
              );
            }

            if (snapshot.hasError) {
              return _FeedEmptyState(
                isCircleTab: false,
                onExploreRadar: () => _switchTopTab(1),
                onOpenCamera: _openCameraFallback,
                errorText: 'No se pudieron cargar los videos de Firestore.',
              );
            }

            final allDocs = snapshot.data?.docs ?? [];

            if (allDocs.isEmpty) {
              return _FeedEmptyState(
                isCircleTab: false,
                onExploreRadar: () => _switchTopTab(1),
                onOpenCamera: _openCameraFallback,
              );
            }

            final List<QueryDocumentSnapshot<Map<String, dynamic>>> docs =
                _selectedTopTab == 0
                    ? allDocs.where((doc) {
                        final data = doc.data();
                        final String uid =
                            (data['uid'] ?? data['authorId'] ?? '').toString();
                        return videoProvider.followingIds.contains(uid) ||
                            (currentUid != null && uid == currentUid);
                      }).toList()
                    : allDocs;

            if (docs.isEmpty) {
              return _FeedEmptyState(
                isCircleTab: _selectedTopTab == 0,
                onExploreRadar: () => _switchTopTab(1),
                onOpenCamera: _openCameraFallback,
              );
            }

            final int safePage = _currentPage.clamp(0, docs.length - 1);

            return PageView.builder(
              key: ValueKey(_selectedTopTab),
              controller: _pageController,
              scrollDirection: Axis.vertical,
              itemCount: docs.length,
              onPageChanged: (index) {
                setState(() => _currentPage = index);
              },
              itemBuilder: (context, index) {
                final doc = docs[index];
                final data = doc.data();

                final String videoUrl = (data['videoUrl'] ?? '').toString();
                final String username =
                    (data['username'] ?? 'usuario').toString();
                final String caption = (data['caption'] ?? '').toString();
                final int likes =
                    ((data['likes'] ?? data['likesCount'] ?? 0) as num).toInt();
                final int comments =
                    ((data['comments'] ?? data['commentsCount'] ?? 0) as num)
                        .toInt();
                final String avatarUrl = (data['avatarUrl'] ?? '').toString();
                final String uid =
                    (data['uid'] ?? data['authorId'] ?? '').toString();
                final List<String> likedBy = List<String>.from(
                  data['likedBy'] ?? const <String>[],
                );
                final String audioName = (data['audioName'] ?? '').toString();
                final String effectUsed = (data['effectUsed'] ?? '').toString();
                final String effectVideoUrl =
                    (data['effectVideoUrl'] ?? '').toString();

                final isActive = widget.isFeedVisible && safePage == index;

                return VideoCard(
                  key: ValueKey(doc.id),
                  videoId: doc.id,
                  videoUrl: videoUrl,
                  username: username,
                  caption: caption,
                  likes: likes,
                  comments: comments,
                  avatarUrl: avatarUrl,
                  uid: uid,
                  likedBy: likedBy,
                  audioName: audioName,
                  effectUsed: effectUsed,
                  effectVideoUrl: effectVideoUrl,
                  isActive: isActive,
                );
              },
            );
          },
        ),

        // Tabs Superiores: Círculo | Radar
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.only(top: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _TopTabButton(
                  label: 'Círculo',
                  isSelected: _selectedTopTab == 0,
                  onTap: () => _switchTopTab(0),
                ),
                const SizedBox(width: 24),
                _TopTabButton(
                  label: 'Radar',
                  isSelected: _selectedTopTab == 1,
                  onTap: () => _switchTopTab(1),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _FeedEmptyState extends StatelessWidget {
  final bool isCircleTab;
  final VoidCallback onExploreRadar;
  final VoidCallback onOpenCamera;
  final String? errorText;

  const _FeedEmptyState({
    required this.isCircleTab,
    required this.onExploreRadar,
    required this.onOpenCamera,
    this.errorText,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(
              Icons.videocam_outlined,
              size: 52,
              color: AppColors.orange,
            ),
            const SizedBox(height: 14),
            Text(
              errorText ??
                  (isCircleTab
                      ? 'Aún no hay clips en tu Círculo'
                      : 'Aún no hay videos. ¡Sé el primero en subir uno!'),
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              isCircleTab
                  ? 'Sigue a creadores en Radar para ver sus videos aquí.'
                  : 'Graba o selecciona un video desde tu cámara y compártelo en Viroklipz.',
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white54, fontSize: 13),
            ),
            const SizedBox(height: 20),
            Container(
              decoration: BoxDecoration(
                gradient: AppColors.brandGradient,
                borderRadius: BorderRadius.circular(24),
              ),
              child: ElevatedButton.icon(
                onPressed: isCircleTab ? onExploreRadar : onOpenCamera,
                icon: Icon(
                  isCircleTab ? Icons.explore_outlined : Icons.videocam_rounded,
                  size: 18,
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent,
                  shadowColor: Colors.transparent,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 22,
                    vertical: 12,
                  ),
                ),
                label: Text(isCircleTab ? 'Ir a Radar' : 'Subir primer video'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _TopTabButton extends StatelessWidget {
  final String label;
  final bool isSelected;
  final VoidCallback onTap;

  const _TopTabButton({
    required this.label,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            label,
            style: TextStyle(
              color: isSelected ? Colors.white : Colors.white60,
              fontSize: 16,
              fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
              shadows: const [Shadow(color: Colors.black54, blurRadius: 8)],
            ),
          ),
          const SizedBox(height: 5),
          AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            height: 3,
            width: isSelected ? 30 : 0,
            decoration: BoxDecoration(
              gradient: AppColors.brandGradient,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
        ],
      ),
    );
  }
}`,
  },
  {
    id: 'r2_upload_service',
    path: 'lib/services/r2_upload_service.dart',
    phase: 'Paso 4 · Cloudflare R2 S3',
    language: 'dart',
    summary:
      'Sube el MP4 mediante streaming a Cloudflare R2 usando minio (endpoint S3 compatible, region auto) y devuelve la URL pública.',
    code: `import 'dart:io';
import 'dart:typed_data';
import 'package:minio/minio.dart';
import 'package:path/path.dart' as p;
import '../config/env_config.dart';

class R2UploadService {
  late final Minio _minio;

  R2UploadService() {
    _minio = Minio(
      endPoint: EnvConfig.r2Endpoint,
      accessKey: EnvConfig.r2AccessKey,
      secretKey: EnvConfig.r2SecretKey,
      useSSL: true,
      region: 'auto',
    );
  }

  /// Sube el archivo de video a Cloudflare R2 y retorna su URL pública HTTPS.
  Future<String> uploadVideo({
    required File videoFile,
    required String userId,
    void Function(double progress)? onProgress,
  }) async {
    final int totalBytes = await videoFile.length();
    final String extension = p.extension(videoFile.path).isNotEmpty
        ? p.extension(videoFile.path)
        : '.mp4';
    final String objectKey =
        'videos/\$userId/\${DateTime.now().millisecondsSinceEpoch}\$extension';

    try {
      int uploadedBytes = 0;

      final Stream<Uint8List> stream = videoFile.openRead().map((chunk) {
        uploadedBytes += chunk.length;
        if (onProgress != null && totalBytes > 0) {
          onProgress((uploadedBytes / totalBytes).clamp(0.0, 1.0));
        }
        return Uint8List.fromList(chunk);
      });

      await _minio.putObject(
        EnvConfig.r2BucketName,
        objectKey,
        stream,
        size: totalBytes,
        metadata: {
          'content-type': 'video/mp4',
        },
      );

      final String baseUrl = EnvConfig.r2PublicBaseUrl.endsWith('/')
          ? EnvConfig.r2PublicBaseUrl.substring(0, EnvConfig.r2PublicBaseUrl.length - 1)
          : EnvConfig.r2PublicBaseUrl;

      return '\$baseUrl/\$objectKey';
    } on SocketException {
      throw Exception('Sin conexión durante la subida a Cloudflare R2.');
    } catch (e) {
      throw Exception('Fallo al subir el video a R2: \$e');
    }
  }
}`,
  },
  {
    id: 'video_download_service',
    path: 'lib/services/video_download_service.dart',
    phase: 'Descargas · Dio + Gal + Permisos',
    language: 'dart',
    summary:
      'Solicita permisos (Android 13+ videos/photos, Android <=12 storage, iOS photosAddOnly), descarga con Dio y guarda en la galería con Gal.',
    code: `import 'dart:io';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:dio/dio.dart';
import 'package:gal/gal.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';

class VideoDownloadService {
  final Dio _dio = Dio();

  /// Verifica y solicita permisos de almacenamiento según plataforma y versión.
  Future<bool> requestGalleryPermission() async {
    if (Platform.isIOS) {
      final status = await Permission.photosAddOnly.request();
      if (status.isGranted || status.isLimited) return true;
      final fallback = await Permission.photos.request();
      return fallback.isGranted || fallback.isLimited;
    }

    if (Platform.isAndroid) {
      final androidInfo = await DeviceInfoPlugin().androidInfo;
      final int sdkInt = androidInfo.version.sdkInt;

      if (sdkInt >= 33) {
        // Android 13+ (API 33+): permisos granulares de media
        final statuses = await [
          Permission.videos,
          Permission.photos,
        ].request();

        final bool videosGranted = statuses[Permission.videos]?.isGranted ?? false;
        final bool photosGranted = statuses[Permission.photos]?.isGranted ?? false;
        return videosGranted || photosGranted;
      } else {
        // Android 12 e inferiores (API <= 32)
        final status = await Permission.storage.request();
        return status.isGranted;
      }
    }

    return false;
  }

  /// Descarga el video desde [videoUrl] (Firebase / R2 / HTTP) y lo guarda en la galería.
  Future<void> downloadAndSaveToGallery({
    required String videoUrl,
    void Function(double progress)? onProgress,
  }) async {
    final bool hasPermission = await requestGalleryPermission();
    if (!hasPermission) {
      throw Exception(
        'Permiso de galería denegado. Habilítalo en los ajustes de la app.',
      );
    }

    // Si es un archivo local (ej. recién grabado en modo MVP), guárdalo directo
    if (!videoUrl.startsWith('http')) {
      await Gal.putVideo(videoUrl, album: 'Viroklipz');
      return;
    }

    final Directory tempDir = await getTemporaryDirectory();
    final String filePath =
        '\${tempDir.path}/viroklipz_\${DateTime.now().millisecondsSinceEpoch}.mp4';

    try {
      await _dio.download(
        videoUrl,
        filePath,
        onReceiveProgress: (received, total) {
          if (onProgress != null && total > 0) {
            onProgress((received / total).clamp(0.0, 1.0));
          }
        },
      );

      await Gal.putVideo(filePath, album: 'Viroklipz');
    } on DioException catch (e) {
      throw Exception('Error de descarga: \${e.message ?? "Verifica tu conexión"}');
    } on GalException catch (e) {
      throw Exception('No se pudo guardar en galería: \${e.type.message}');
    } finally {
      final tempFile = File(filePath);
      if (await tempFile.exists()) {
        await tempFile.delete();
      }
    }
  }
}`,
  },
  {
    id: 'camera_screen',
    path: 'lib/screens/camera_screen.dart',
    phase: 'Paso 4 · Cámara Real + Audio just_audio + Overlays Visuales',
    language: 'dart',
    summary:
      'CameraController con reproducción en bucle via just_audio (selectedAudioUrl / selectedAudioName + indicador flotante), selectedEffectId con BlendMode.screen en Stack sobre CameraPreview y envío a PostVideoScreen.',
    code: `import 'dart:async';
import 'dart:io';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:just_audio/just_audio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:video_player/video_player.dart';
import '../services/royalty_free_media_service.dart';
import '../widgets/effects_gallery_sheet.dart';
import '../widgets/sound_picker_sheet.dart';
import 'post_video_screen.dart';

class CameraScreen extends StatefulWidget {
  const CameraScreen({super.key});

  @override
  State<CameraScreen> createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen>
    with WidgetsBindingObserver {
  CameraController? _controller;
  List<CameraDescription> _cameras = [];
  CameraLensDirection _currentDirection = CameraLensDirection.back;

  bool _isInitializing = true;
  bool _permissionDenied = false;
  bool isSimulated = false;
  bool _isRecording = false;
  bool _isPickingFromGallery = false;
  bool _returningFromSettings = false;
  bool _hasShownSettingsDialog = false;
  int _recordSeconds = 0;
  Timer? _recordTimer;

  String _selectedTime = '15 s';

  // Estados solicitados para Audio y Efecto Visual
  String? selectedAudioUrl;
  String? selectedAudioName;
  String? selectedEffectId = 'Ninguno';

  final AudioPlayer _audioPlayer = AudioPlayer();
  VideoEffectOverlay? _selectedEffect;
  VideoPlayerController? _effectController;
  bool _isEffectReady = false;

  final ImagePicker _picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    isSimulated = false;
    _requestPermissionsAndInitCamera(showFeedbackOnDeny: false);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final CameraController? cameraController = _controller;

    if (state == AppLifecycleState.inactive) {
      if (cameraController != null && cameraController.value.isInitialized) {
        cameraController.dispose();
        _controller = null;
      }
      _effectController?.pause();
      _audioPlayer.pause();
    } else if (state == AppLifecycleState.resumed) {
      if (_returningFromSettings) {
        _returningFromSettings = false;
        _recheckPermissionsAfterSettings();
      } else if (!isSimulated && _controller == null && !_permissionDenied) {
        _requestPermissionsAndInitCamera(showFeedbackOnDeny: false);
      }
      if (_isEffectReady) {
        _effectController?.play();
      }
      if (selectedAudioUrl != null) {
        _audioPlayer.play();
      }
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _recordTimer?.cancel();
    _audioPlayer.dispose();
    _effectController?.dispose();
    _controller?.dispose();
    super.dispose();
  }

  Future<void> _stopCameraAudio() async {
    try {
      await _audioPlayer.stop();
    } catch (_) {}
  }

  Future<void> _playSelectedSoundInLoop(String url) async {
    try {
      await _audioPlayer.stop();
      await _audioPlayer.setUrl(url);
      await _audioPlayer.setLoopMode(LoopMode.one);
      await _audioPlayer.play();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: const Color(0xFF1E1E1E),
          content: Text('No se pudo reproducir el audio seleccionado: \$e'),
        ),
      );
    }
  }

  Future<void> _applyVisualEffect(VideoEffectOverlay? effect) async {
    final VideoPlayerController? oldController = _effectController;
    setState(() {
      selectedEffectId = effect?.id ?? 'Ninguno';
      _selectedEffect = effect;
      _effectController = null;
      _isEffectReady = false;
    });
    await oldController?.dispose();

    if (effect == null) return;

    final VideoPlayerController nextController =
        VideoPlayerController.networkUrl(Uri.parse(effect.videoUrl));
    try {
      await nextController.initialize();
      await nextController.setLooping(true);
      await nextController.setVolume(0.0);
      await nextController.play();
      if (!mounted) {
        await nextController.dispose();
        return;
      }
      setState(() {
        _effectController = nextController;
        _isEffectReady = true;
      });
    } catch (_) {
      await nextController.dispose();
    }
  }

  bool get _hasActiveEffect =>
      selectedEffectId != null && selectedEffectId != 'Ninguno';

  ColorFilter get _activeCameraColorFilter {
    switch (selectedEffectId) {
      case 'light_leaks':
        return const ColorFilter.mode(
          Color(0x55FF6B35),
          BlendMode.softLight,
        );
      case 'neon_particles':
        return const ColorFilter.mode(
          Color(0x4425F4EE),
          BlendMode.screen,
        );
      case 'bokeh_nights':
        return const ColorFilter.mode(
          Color(0x557C3AED),
          BlendMode.softLight,
        );
      case 'vhs_retro':
        return const ColorFilter.mode(
          Color(0x55F59E0B),
          BlendMode.color,
        );
      default:
        return const ColorFilter.mode(
          Colors.transparent,
          BlendMode.dst,
        );
    }
  }

  /// Overlay visual en tiempo real sobre CameraPreview (ColorFiltered + BlendMode.screen + VideoPlayer MP4)
  Widget _buildCameraEffectLayer() {
    if (!_hasActiveEffect) return const SizedBox.shrink();

    final String effectId = selectedEffectId!;
    final List<Color> gradientColors;

    switch (effectId) {
      case 'light_leaks':
        gradientColors = const [
          Color(0xAAFF6B35),
          Color(0x44FF2E63),
          Color(0x00000000),
          Color(0x77FFB703),
        ];
        break;
      case 'neon_particles':
        gradientColors = const [
          Color(0x8825F4EE),
          Color(0x44673AB7),
          Color(0x88FE2C55),
        ];
        break;
      case 'bokeh_nights':
        gradientColors = const [
          Color(0x88E91E63),
          Color(0x447C3AED),
          Color(0x6638BDF8),
        ];
        break;
      case 'vhs_retro':
      default:
        gradientColors = const [
          Color(0x66F59E0B),
          Color(0x3310B981),
          Color(0x66EF4444),
        ];
        break;
    }

    return Positioned.fill(
      child: IgnorePointer(
        child: Stack(
          fit: StackFit.expand,
          children: [
            // Capa luminosa con BlendMode.screen sobre el CameraPreview
            Opacity(
              opacity: 0.42,
              child: Container(
                decoration: BoxDecoration(
                  backgroundBlendMode: BlendMode.screen,
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: gradientColors,
                  ),
                ),
              ),
            ),

            // Overlay de video MP4 transparente en bucle
            if (_isEffectReady && _effectController != null)
              Opacity(
                opacity: 0.40,
                child: FittedBox(
                  fit: BoxFit.cover,
                  clipBehavior: Clip.hardEdge,
                  child: SizedBox(
                    width: _effectController!.value.size.width > 0
                        ? _effectController!.value.size.width
                        : 1080,
                    height: _effectController!.value.size.height > 0
                        ? _effectController!.value.size.height
                        : 1920,
                    child: AspectRatio(
                      aspectRatio: _effectController!.value.aspectRatio > 0
                          ? _effectController!.value.aspectRatio
                          : 9 / 16,
                      child: VideoPlayer(_effectController!),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Future<void> _showPermanentPermissionDialog() async {
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          backgroundColor: const Color(0xFF1E1E1E),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          title: const Text(
            'Permiso requerido',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
          ),
          content: const Text(
            'Ve a Ajustes para habilitar la cámara y el micrófono.',
            style: TextStyle(color: Colors.white70, fontSize: 14),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text(
                'Cerrar',
                style: TextStyle(color: Colors.white54),
              ),
            ),
            ElevatedButton(
              onPressed: () async {
                _returningFromSettings = true;
                Navigator.pop(dialogContext);
                await openAppSettings();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFE2C55),
                foregroundColor: Colors.white,
              ),
              child: const Text('Ir a Ajustes'),
            ),
          ],
        );
      },
    );
  }

  /// Re-evalúa permisos al volver desde los Ajustes del sistema (AppLifecycleState.resumed)
  Future<void> _recheckPermissionsAfterSettings() async {
    final PermissionStatus cameraStatus = await Permission.camera.status;
    final PermissionStatus micStatus = await Permission.microphone.status;

    if (!mounted) return;

    if (!cameraStatus.isGranted) {
      setState(() {
        _isInitializing = false;
        _permissionDenied = true;
        isSimulated = false;
      });
      return;
    }

    await _initializeAvailableCamera(micGranted: micStatus.isGranted);
  }

  // 1. Solicitar Permission.camera + Permission.microphone (permission_handler), manejar permanentlyDenied -> openAppSettings() y denied -> aviso nativo
  Future<void> _requestPermissionsAndInitCamera({
    bool showFeedbackOnDeny = true,
  }) async {
    setState(() {
      _isInitializing = true;
      _permissionDenied = false;
      isSimulated = false;
    });

    final PermissionStatus cameraStatus = await Permission.camera.request();
    final PermissionStatus micStatus = await Permission.microphone.request();

    if (!cameraStatus.isGranted) {
      if (!mounted) return;
      setState(() {
        _isInitializing = false;
        _permissionDenied = true;
        isSimulated = false;
      });

      if (cameraStatus == PermissionStatus.permanentlyDenied ||
          cameraStatus.isRestricted) {
        if (showFeedbackOnDeny) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              backgroundColor: Color(0xFFDC2626),
              content: Text(
                'Abre los ajustes y activa los permisos de cámara',
                style: TextStyle(color: Colors.white),
              ),
            ),
          );
          _returningFromSettings = true;
          await openAppSettings();
        } else if (!_hasShownSettingsDialog) {
          _hasShownSettingsDialog = true;
          await _showPermanentPermissionDialog();
        }
      } else if (cameraStatus == PermissionStatus.denied && showFeedbackOnDeny) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            backgroundColor: Color(0xFF1E1E1E),
            content: Text(
              'Acepta el permiso de cámara en la ventana del sistema para continuar.',
              style: TextStyle(color: Colors.white),
            ),
          ),
        );
      }
      return;
    }

    await _initializeAvailableCamera(micGranted: micStatus.isGranted);
  }

  Future<void> _initializeAvailableCamera({required bool micGranted}) async {
    try {
      _cameras = await availableCameras();

      // Solo si no existe ninguna cámara física en el dispositivo, mostrar fondo negro sin texto simulado
      if (_cameras.isEmpty) {
        if (!mounted) return;
        setState(() {
          _isInitializing = false;
          _permissionDenied = false;
          isSimulated = true;
        });
        return;
      }

      // Hay cámaras físicas: inicializar CameraController y asegurar isSimulated = false
      await _initializeController(
        _cameras.first,
        enableAudio: micGranted,
      );
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isInitializing = false;
        _permissionDenied = true;
        isSimulated = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error al iniciar la cámara física: \$e')),
      );
    }
  }

  Future<void> _closeCamera() async {
    _recordTimer?.cancel();
    await _stopCameraAudio();
    final CameraController? activeController = _controller;
    _controller = null;
    await activeController?.dispose();
    if (!mounted) return;
    Navigator.pop(context, false);
  }

  Future<void> _initializeController(
    CameraDescription description, {
    bool enableAudio = true,
  }) async {
    final CameraController? previousController = _controller;

    final CameraController newController = CameraController(
      description,
      ResolutionPreset.high,
      enableAudio: enableAudio,
    );

    if (mounted) {
      setState(() {
        _isInitializing = true;
        _controller = null;
        isSimulated = false;
      });
    }

    await previousController?.dispose();

    try {
      await newController.initialize();
      if (!mounted) {
        await newController.dispose();
        return;
      }
      setState(() {
        _controller = newController;
        _currentDirection = description.lensDirection;
        _permissionDenied = false;
        isSimulated = false;
        _isInitializing = false;
      });
    } catch (e) {
      await newController.dispose();
      // Reintentar con resolución media sin bloquear la cámara física si high falla
      final CameraController fallbackController = CameraController(
        description,
        ResolutionPreset.medium,
        enableAudio: false,
      );
      try {
        await fallbackController.initialize();
        if (!mounted) {
          await fallbackController.dispose();
          return;
        }
        setState(() {
          _controller = fallbackController;
          _currentDirection = description.lensDirection;
          _permissionDenied = false;
          isSimulated = false;
          _isInitializing = false;
        });
      } catch (_) {
        await fallbackController.dispose();
        if (!mounted) return;
        setState(() {
          _isInitializing = false;
          _permissionDenied = true;
          isSimulated = false;
        });
      }
    }
  }

  // 2. Botón Voltear Cámara (trasera <-> frontal)
  Future<void> _flipCamera() async {
    if (_isRecording || _isInitializing || _cameras.isEmpty) return;

    final CameraLensDirection targetDirection =
        _currentDirection == CameraLensDirection.back
            ? CameraLensDirection.front
            : CameraLensDirection.back;

    final int targetIndex = _cameras.indexWhere(
      (cam) => cam.lensDirection == targetDirection,
    );

    if (targetIndex == -1) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('No se encontró una cámara frontal disponible'),
        ),
      );
      return;
    }

    final bool micGranted = await Permission.microphone.isGranted;
    await _initializeController(
      _cameras[targetIndex],
      enableAudio: micGranted,
    );
  }

  // 4. Pasar audioUrl, audioName y effectUsed a PostVideoScreen
  Future<void> _navigateToPostVideo(String videoPath) async {
    await _stopCameraAudio();
    await _effectController?.pause();
    if (!mounted) return;

    final bool? published = await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (_) => PostVideoScreen(
          videoPath: videoPath,
          audioName: selectedAudioName,
          audioUrl: selectedAudioUrl,
          effectUsed: _hasActiveEffect ? (_selectedEffect?.name ?? selectedEffectId) : 'Ninguno',
          effectVideoUrl: _selectedEffect?.videoUrl,
        ),
      ),
    );
    if (mounted && published == true) {
      Navigator.pop(context, true);
    } else if (mounted) {
      if (_isEffectReady) {
        await _effectController?.play();
      }
      if (selectedAudioUrl != null) {
        await _playSelectedSoundInLoop(selectedAudioUrl!);
      }
    }
  }

  Future<void> _continueWithoutCamera() async {
    const String samplePreviewUrl =
        'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4';
    await _navigateToPostVideo(samplePreviewUrl);
  }

  // 3. Botón Grabar / Detener Video con hardware real
  Future<void> _toggleRecording() async {
    final CameraController? controller = _controller;
    if (controller == null || !controller.value.isInitialized) return;

    if (!_isRecording) {
      try {
        await controller.startVideoRecording();
        _recordTimer?.cancel();
        setState(() {
          _isRecording = true;
          _recordSeconds = 0;
        });
        _recordTimer = Timer.periodic(const Duration(seconds: 1), (_) {
          if (!mounted) return;
          setState(() => _recordSeconds++);
        });
      } catch (e) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('No se pudo iniciar la grabación: \$e')),
        );
      }
    } else {
      _recordTimer?.cancel();
      try {
        final XFile recordedFile = await controller.stopVideoRecording();
        final Directory tempDir = await getTemporaryDirectory();
        final String tempPath =
            '\${tempDir.path}/viroklipz_\${DateTime.now().millisecondsSinceEpoch}.mp4';
        String finalPath = recordedFile.path;
        try {
          await recordedFile.saveTo(tempPath);
          finalPath = tempPath;
        } catch (_) {}

        if (!mounted) return;
        setState(() => _isRecording = false);

        await _navigateToPostVideo(finalPath);
      } catch (e) {
        if (!mounted) return;
        setState(() => _isRecording = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error al guardar el video: \$e')),
        );
      }
    }
  }

  String _formatTimer(int totalSeconds) {
    final String mins = (totalSeconds ~/ 60).toString().padLeft(2, '0');
    final String secs = (totalSeconds % 60).toString().padLeft(2, '0');
    return '\$mins:\$secs';
  }

  Future<void> _showGalleryPermissionDialog() async {
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          backgroundColor: const Color(0xFF1E1E1E),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          title: const Text(
            'Permiso de galería requerido',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
          ),
          content: const Text(
            'Para elegir videos de tu galería, otorga permiso de acceso a fotos y videos en los ajustes del teléfono.',
            style: TextStyle(color: Colors.white70, fontSize: 14),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text(
                'Cancelar',
                style: TextStyle(color: Colors.white54),
              ),
            ),
            ElevatedButton(
              onPressed: () async {
                Navigator.pop(dialogContext);
                await openAppSettings();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFE2C55),
                foregroundColor: Colors.white,
              ),
              child: const Text('Abrir Ajustes'),
            ),
          ],
        );
      },
    );
  }

  // Botón "Galería" -> selector nativo del teléfono (Android & iOS) con image_picker
  Future<void> _openGallery() async {
    if (_isPickingFromGallery || _isRecording) return;
    _isPickingFromGallery = true;

    try {
      if (Platform.isIOS) {
        final PermissionStatus photosStatus = await Permission.photos.status;
        if (photosStatus.isPermanentlyDenied || photosStatus.isRestricted) {
          await _showGalleryPermissionDialog();
          return;
        }
      }

      final XFile? video = await _picker.pickVideo(
        source: ImageSource.gallery,
        maxDuration: const Duration(seconds: 60),
      );

      if (!mounted || video == null) return;

      await _navigateToPostVideo(video.path);
    } on PlatformException catch (e) {
      if (!mounted) return;
      final String code = e.code.toLowerCase();
      final String msg = (e.message ?? '').toLowerCase();
      final bool isPermissionError = code.contains('photo_access_denied') ||
          code.contains('camera_access_denied') ||
          code.contains('permission') ||
          msg.contains('permission') ||
          msg.contains('denied');

      if (isPermissionError) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            backgroundColor: const Color(0xFFDC2626),
            content: const Text(
              'Permiso de galería denegado. Actívalo en los ajustes del teléfono.',
              style: TextStyle(color: Colors.white),
            ),
            action: SnackBarAction(
              label: 'Ajustes',
              textColor: Colors.white,
              onPressed: openAppSettings,
            ),
          ),
        );
        await _showGalleryPermissionDialog();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            backgroundColor: const Color(0xFFDC2626),
            content: Text('No se pudo abrir la galería: \${e.message ?? e.code}'),
          ),
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: const Color(0xFFDC2626),
          content: Text('Error al acceder a la galería: \$e'),
          action: SnackBarAction(
            label: 'Ajustes',
            textColor: Colors.white,
            onPressed: openAppSettings,
          ),
        ),
      );
    } finally {
      _isPickingFromGallery = false;
    }
  }

  void _openTextInput() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF2C2C2C),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom,
            left: 16,
            right: 16,
            top: 20,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'Escribe tu texto',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              const TextField(
                autofocus: true,
                style: TextStyle(color: Colors.white, fontSize: 24),
                textAlign: TextAlign.center,
                decoration: InputDecoration(
                  hintText: 'Escribe aquí...',
                  hintStyle: TextStyle(color: Colors.white54),
                  border: InputBorder.none,
                ),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () => Navigator.pop(context),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.redAccent,
                  minimumSize: const Size(double.infinity, 50),
                ),
                child: const Text(
                  'Listo',
                  style: TextStyle(color: Colors.white, fontSize: 16),
                ),
              ),
              const SizedBox(height: 20),
            ],
          ),
        );
      },
    );
  }

  // Galería de Sonidos: al tocar "Usar", guarda selectedAudioUrl y selectedAudioName y reproduce en bucle con just_audio
  Future<void> _openSoundPicker() async {
    final RoyaltyFreeSound? chosen = await showModalBottomSheet<RoyaltyFreeSound>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => SoundPickerSheet(initialSelectedUrl: selectedAudioUrl),
    );

    if (!mounted || chosen == null) return;

    setState(() {
      selectedAudioName = chosen.title;
      selectedAudioUrl = chosen.audioUrl;
    });
    await _playSelectedSoundInLoop(chosen.audioUrl);
  }

  // Galería de Efectos Visuales: al tocar una tarjeta o "Ninguno", actualiza selectedEffectId y aplica en Stack
  Future<void> _openEffectsGallery() async {
    final EffectsPickerResult? result =
        await showModalBottomSheet<EffectsPickerResult>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => EffectsGallerySheet(
        selectedEffectId: _hasActiveEffect ? selectedEffectId : null,
      ),
    );

    if (!mounted || result == null) return;
    await _applyVisualEffect(result.effect);
  }

  @override
  Widget build(BuildContext context) {
    if (_isInitializing && !isSimulated) {
      return const Scaffold(
        backgroundColor: Colors.black,
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(color: Color(0xFF25F4EE)),
              SizedBox(height: 14),
              Text(
                'Inicializando cámara...',
                style: TextStyle(color: Colors.white70, fontSize: 13),
              ),
            ],
          ),
        ),
      );
    }

    if (_permissionDenied && !isSimulated) {
      return Scaffold(
        backgroundColor: const Color(0xFF0E0E10),
        appBar: AppBar(
          backgroundColor: const Color(0xFF0E0E10),
          elevation: 0,
          leading: IconButton(
            icon: const Icon(Icons.close, color: Colors.white),
            onPressed: _closeCamera,
          ),
        ),
        body: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 16),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 96,
                  height: 96,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white.withValues(alpha: 0.05),
                    border: Border.all(
                      color: Colors.white.withValues(alpha: 0.10),
                    ),
                  ),
                  child: const Icon(
                    Icons.videocam_off_outlined,
                    color: Colors.white70,
                    size: 52,
                  ),
                ),
                const SizedBox(height: 22),
                const Text(
                  'Cámara en vista previa',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 19,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  'Activa el permiso en tu teléfono o continúa con un clip de prueba para recorrer el flujo.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.grey[400],
                    fontSize: 13,
                    height: 1.4,
                  ),
                ),
                const SizedBox(height: 26),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _continueWithoutCamera,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFFE2C55),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(
                        vertical: 14,
                        horizontal: 16,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: const Text(
                      'Continuar sin cámara (para pruebas en web)',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton(
                    onPressed: () => _requestPermissionsAndInitCamera(
                      showFeedbackOnDeny: true,
                    ),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.white,
                      side: const BorderSide(color: Colors.white24),
                      backgroundColor: Colors.white.withValues(alpha: 0.06),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: const Text(
                      'Solicitar permiso',
                      style: TextStyle(fontWeight: FontWeight.w600),
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                TextButton(
                  onPressed: () async {
                    _returningFromSettings = true;
                    await openAppSettings();
                  },
                  child: Text(
                    'Ir a Ajustes',
                    style: TextStyle(
                      color: Colors.grey[400],
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  'Nota: La cámara solo funciona en la app instalada en tu teléfono, no en la vista previa web.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.grey[500],
                    fontSize: 12,
                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Stack(
          fit: StackFit.expand,
          children: [
            // Capa 1: CameraPreview real ocupando toda la pantalla (fondo negro si _cameras está vacía)
            if (isSimulated)
              const ColoredBox(color: Colors.black)
            else if (_isInitializing ||
                _controller == null ||
                !_controller!.value.isInitialized)
              const ColoredBox(
                color: Colors.black,
                child: Center(
                  child: CircularProgressIndicator(color: Color(0xFF25F4EE)),
                ),
              )
            else
              Positioned.fill(
                child: ColorFiltered(
                  colorFilter: _activeCameraColorFilter,
                  child: FittedBox(
                    fit: BoxFit.cover,
                    child: SizedBox(
                      width: _controller!.value.previewSize?.height ?? 1080,
                      height: _controller!.value.previewSize?.width ?? 1920,
                      child: CameraPreview(_controller!),
                    ),
                  ),
                ),
              ),

            // Capa 2: Efecto visual en Stack (BlendMode.screen + opacity + VideoPlayer overlay)
            _buildCameraEffectLayer(),

            // Barra Superior
            Positioned(
              top: 10,
              left: 16,
              right: 16,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  IconButton(
                    icon: const Icon(Icons.close, color: Colors.white),
                    onPressed: _closeCamera,
                  ),
                  Flexible(
                    child: GestureDetector(
                      onTap: _openSoundPicker,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 14,
                          vertical: 8,
                        ),
                        decoration: BoxDecoration(
                          color: selectedAudioUrl != null
                              ? const Color(0xFFE91E63).withValues(alpha: 0.88)
                              : Colors.black.withValues(alpha: 0.45),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            if (selectedAudioUrl == null) ...[
                              const Icon(
                                Icons.music_note,
                                color: Colors.white,
                                size: 16,
                              ),
                              const SizedBox(width: 6),
                            ],
                            Flexible(
                              child: Text(
                                selectedAudioName != null
                                    ? '🎵 \$selectedAudioName'
                                    : 'Agregar sonido',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                            if (selectedAudioUrl != null) ...[
                              const SizedBox(width: 6),
                              GestureDetector(
                                onTap: () async {
                                  await _stopCameraAudio();
                                  if (!mounted) return;
                                  setState(() {
                                    selectedAudioName = null;
                                    selectedAudioUrl = null;
                                  });
                                },
                                child: const Icon(
                                  Icons.close,
                                  color: Colors.white,
                                  size: 14,
                                ),
                              ),
                            ],
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 40),
                ],
              ),
            ),

            // Indicador flotante de canción seleccionada, efecto activo o grabación
            if (_isRecording || _hasActiveEffect || selectedAudioName != null)
              Positioned(
                top: 62,
                left: 16,
                right: 16,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (selectedAudioName != null)
                      Container(
                        margin: const EdgeInsets.only(bottom: 6),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 5,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha: 0.62),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: Colors.white12),
                        ),
                        child: Text(
                          '🎵 \$selectedAudioName',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    if (_isRecording || _hasActiveEffect)
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 5,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha: 0.58),
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            if (_isRecording) ...[
                              const CircleAvatar(
                                radius: 4,
                                backgroundColor: Colors.redAccent,
                              ),
                              const SizedBox(width: 6),
                              Text(
                                _formatTimer(_recordSeconds),
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 13,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ] else if (_hasActiveEffect) ...[
                              const Icon(
                                Icons.auto_awesome,
                                color: Color(0xFF25F4EE),
                                size: 14,
                              ),
                              const SizedBox(width: 6),
                              Text(
                                _selectedEffect?.name ?? selectedEffectId!,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              const SizedBox(width: 6),
                              GestureDetector(
                                onTap: () => _applyVisualEffect(null),
                                child: const Icon(
                                  Icons.close,
                                  color: Colors.white70,
                                  size: 14,
                                ),
                              ),
                            ],
                          ],
                        ),
                      ),
                  ],
                ),
              ),

            // Barra Lateral Derecha
            Positioned(
              right: 16,
              top: 80,
              child: Column(
                children: [
                  GestureDetector(
                    onTap: _flipCamera,
                    child: _buildSideIcon(Icons.cameraswitch),
                  ),
                  const SizedBox(height: 20),
                  GestureDetector(
                    onTap: _openEffectsGallery,
                    child: _buildSideIcon(Icons.auto_fix_high),
                  ),
                  const SizedBox(height: 20),
                  _buildSideIcon(Icons.timer),
                  const SizedBox(height: 20),
                  _buildSideIcon(Icons.grid_view),
                  const SizedBox(height: 20),
                  _buildSideIcon(Icons.person_add_alt_1),
                  const SizedBox(height: 20),
                  _buildSideIcon(Icons.filter),
                  const SizedBox(height: 20),
                  _buildSideIcon(Icons.keyboard_arrow_down),
                ],
              ),
            ),

            // Controles Inferiores
            Positioned(
              bottom: 20,
              left: 0,
              right: 0,
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      _buildOption('10 min'),
                      _buildOption('60 s'),
                      _buildOption('15 s'),
                      _buildOption('FOTO', isAction: true, onTap: _openGallery),
                      _buildOption(
                        'TEXTO',
                        isAction: true,
                        onTap: _openTextInput,
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      // Miniatura Galería
                      GestureDetector(
                        onTap: _openGallery,
                        child: Column(
                          children: [
                            Container(
                              width: 45,
                              height: 45,
                              decoration: BoxDecoration(
                                color: const Color(0xFF27272A),
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(color: Colors.white30),
                              ),
                              child: const Icon(
                                Icons.photo_library_outlined,
                                color: Colors.white,
                                size: 22,
                              ),
                            ),
                            const SizedBox(height: 4),
                            const Text(
                              'Galería',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ),

                      // Botón Grabar animado (círculo <-> cuadrado pequeño)
                      GestureDetector(
                        onTap: _toggleRecording,
                        child: Container(
                          width: 80,
                          height: 80,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.white, width: 4),
                          ),
                          child: Center(
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 180),
                              width: _isRecording ? 30 : 60,
                              height: _isRecording ? 30 : 60,
                              decoration: BoxDecoration(
                                color: const Color(0xFFFE2C55),
                                borderRadius: BorderRadius.circular(
                                  _isRecording ? 8 : 30,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),

                      // Miniatura Efectos Visuales (abre galería de overlays)
                      GestureDetector(
                        onTap: _openEffectsGallery,
                        child: Column(
                          children: [
                            Container(
                              width: 45,
                              height: 45,
                              decoration: BoxDecoration(
                                color: _hasActiveEffect
                                    ? const Color(0xFF25F4EE)
                                        .withValues(alpha: 0.2)
                                    : const Color(0xFF27272A),
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: _hasActiveEffect
                                      ? const Color(0xFF25F4EE)
                                      : Colors.white30,
                                  width: _hasActiveEffect ? 2 : 1,
                                ),
                              ),
                              child: Icon(
                                Icons.auto_awesome,
                                color: _hasActiveEffect
                                    ? const Color(0xFF25F4EE)
                                    : Colors.white,
                                size: 22,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              _hasActiveEffect ? 'Activo' : 'Efectos',
                              style: TextStyle(
                                color: _hasActiveEffect
                                    ? const Color(0xFF25F4EE)
                                    : Colors.white,
                                fontSize: 12,
                                fontWeight: _hasActiveEffect
                                    ? FontWeight.w700
                                    : FontWeight.normal,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 25),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      const Text(
                        'CÁMARA',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                      ),
                      GestureDetector(
                        onTap: _openGallery,
                        child: const Text(
                          'CREAR',
                          style: TextStyle(
                            color: Colors.white54,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSideIcon(IconData icon) {
    return Icon(icon, color: Colors.white, size: 28);
  }

  Widget _buildOption(
    String text, {
    bool isAction = false,
    VoidCallback? onTap,
  }) {
    final bool isSelected = _selectedTime == text;

    return GestureDetector(
      onTap: () {
        if (isAction && onTap != null) {
          onTap();
        } else {
          setState(() => _selectedTime = text);
        }
      },
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 6),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: isSelected && !isAction
              ? Colors.white.withValues(alpha: 0.2)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(6),
        ),
        child: Text(
          text,
          style: TextStyle(
            color: (isSelected && !isAction) || isAction
                ? Colors.white
                : Colors.white54,
            fontWeight: (isSelected && !isAction) || isAction
                ? FontWeight.bold
                : FontWeight.normal,
            fontSize: 14,
          ),
        ),
      ),
    );
  }
}`,
  },
  {
    id: 'video_preview_screen',
    path: 'lib/screens/video_preview_screen.dart',
    phase: 'Paso 4 · Previsualización de Video Grabado',
    language: 'dart',
    summary:
      'Pantalla de Previsualización que reproduce en bucle el video grabado desde la ruta temporal y permite descartarlo o continuar a CreateVideoScreen.',
    code: `import 'dart:io';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'create_video_screen.dart';

class VideoPreviewScreen extends StatefulWidget {
  final String videoPath;

  const VideoPreviewScreen({super.key, required this.videoPath});

  @override
  State<VideoPreviewScreen> createState() => _VideoPreviewScreenState();
}

class _VideoPreviewScreenState extends State<VideoPreviewScreen> {
  late VideoPlayerController _videoController;
  bool _isReady = false;

  @override
  void initState() {
    super.initState();
    _videoController = VideoPlayerController.file(File(widget.videoPath))
      ..setLooping(true)
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() => _isReady = true);
        _videoController.play();
      });
  }

  @override
  void dispose() {
    _videoController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (_isReady)
              Center(
                child: AspectRatio(
                  aspectRatio: _videoController.value.aspectRatio,
                  child: VideoPlayer(_videoController),
                ),
              )
            else
              const Center(
                child: CircularProgressIndicator(color: Colors.white),
              ),

            Positioned(
              top: 12,
              left: 16,
              right: 16,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  IconButton(
                    icon: const Icon(Icons.arrow_back, color: Colors.white),
                    onPressed: () => Navigator.pop(context),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 6,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.black54,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: const Text(
                      'Previsualización',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  const SizedBox(width: 48),
                ],
              ),
            ),

            Positioned(
              bottom: 24,
              left: 20,
              right: 20,
              child: Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(context),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Colors.white,
                        side: const BorderSide(color: Colors.white38),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: const Text('Volver a grabar'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => CreateVideoScreen(
                              initialVideoFile: File(widget.videoPath),
                            ),
                          ),
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFFE2C55),
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: const Text(
                        'Siguiente',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}`,
  },
  {
    id: 'post_video_screen',
    path: 'lib/screens/post_video_screen.dart',
    phase: 'Paso 4 · Publicar Video en Firebase (Storage + Firestore + Hashtags)',
    language: 'dart',
    summary:
      'Recibe videoPath, audioName, audioUrl, effectUsed y effectVideoUrl; muestra nombre de usuario, campo de descripción con extracción RegEx de hashtags (#palabra -> List<String> sin #), campo de audio opcional y guarda caption + hashtags en Firestore.',
    code: `import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart' hide AuthProvider;
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';
import 'package:video_player/video_player.dart';
import '../providers/auth_provider.dart';
import '../providers/user_provider.dart';
import '../theme/app_colors.dart';

class PostVideoScreen extends StatefulWidget {
  final String videoPath;
  final String? audioName;
  final String? audioUrl;
  final String? effectUsed;
  final String? effectVideoUrl;

  const PostVideoScreen({
    super.key,
    required this.videoPath,
    this.audioName,
    this.audioUrl,
    this.effectUsed,
    this.effectVideoUrl,
  });

  @override
  State<PostVideoScreen> createState() => _PostVideoScreenState();
}

class _PostVideoScreenState extends State<PostVideoScreen> {
  final TextEditingController _captionController = TextEditingController();
  late final TextEditingController _audioController;
  late final VideoPlayerController _videoController;
  VideoPlayerController? _effectController;
  final AudioPlayer _audioPlayer = AudioPlayer();

  bool _isVideoReady = false;
  bool _isEffectReady = false;
  bool _isUploading = false;
  bool _canPublish = false;
  double _uploadProgress = 0.0;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _audioController = TextEditingController(text: widget.audioName ?? '');
    _captionController.addListener(_handleCaptionChanged);

    final bool isRemote = widget.videoPath.startsWith('http');
    _videoController = isRemote
        ? VideoPlayerController.networkUrl(Uri.parse(widget.videoPath))
        : VideoPlayerController.file(File(widget.videoPath));

    _videoController
      ..setLooping(true)
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() => _isVideoReady = true);
        _videoController.play();
      });

    if (widget.effectVideoUrl != null && widget.effectVideoUrl!.isNotEmpty) {
      _effectController = VideoPlayerController.networkUrl(
        Uri.parse(widget.effectVideoUrl!),
      )
        ..setLooping(true)
        ..setVolume(0.0)
        ..initialize().then((_) {
          if (!mounted) return;
          setState(() => _isEffectReady = true);
          _effectController?.play();
        });
    }

    if (widget.audioUrl != null && widget.audioUrl!.isNotEmpty) {
      _startBackgroundAudio(widget.audioUrl!);
    }
  }

  void _handleCaptionChanged() {
    final bool hasText = _captionController.text.trim().isNotEmpty;
    if (hasText != _canPublish && mounted) {
      setState(() => _canPublish = hasText);
    }
  }

  List<String> _extractHashtags(String text) {
    final RegExp hashtagRegex = RegExp(r'#([\\p{L}\\p{N}_]+)', unicode: true);
    final Set<String> extracted = <String>{};
    for (final Match match in hashtagRegex.allMatches(text)) {
      final String? rawTag = match.group(1)?.trim().toLowerCase();
      if (rawTag != null && rawTag.isNotEmpty) {
        extracted.add(rawTag);
      }
    }
    return extracted.toList();
  }

  Future<void> _startBackgroundAudio(String url) async {
    try {
      await _audioPlayer.setUrl(url);
      await _audioPlayer.setLoopMode(LoopMode.one);
      await _videoController.setVolume(0.25);
      await _audioPlayer.play();
    } catch (_) {}
  }

  @override
  void dispose() {
    _captionController.removeListener(_handleCaptionChanged);
    _audioPlayer.dispose();
    _effectController?.dispose();
    _videoController.dispose();
    _captionController.dispose();
    _audioController.dispose();
    super.dispose();
  }

  void _togglePreviewPlayback() {
    if (!_isVideoReady) return;
    setState(() {
      if (_videoController.value.isPlaying) {
        _videoController.pause();
        _effectController?.pause();
        _audioPlayer.pause();
      } else {
        _videoController.play();
        _effectController?.play();
        if (widget.audioUrl != null && widget.audioUrl!.isNotEmpty) {
          _audioPlayer.play();
        }
      }
    });
  }

  Future<void> _publishVideo() async {
    final String caption = _captionController.text.trim();
    if (_isUploading || caption.isEmpty) return;

    final User? user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          backgroundColor: Color(0xFFDC2626),
          content: Text('Debes iniciar sesión para publicar un video.'),
        ),
      );
      return;
    }

    setState(() {
      _isUploading = true;
      _uploadProgress = 0.0;
      _errorMessage = null;
    });

    try {
      final authProvider = context.read<AuthProvider>();
      String username = (authProvider.userProfile?['username'] ??
              authProvider.currentUser?.username ??
              user.displayName ??
              user.email?.split('@').first ??
              'usuario')
          .toString();
      String avatarUrl = (authProvider.userProfile?['avatarUrl'] ??
              authProvider.currentUser?.avatarUrl ??
              user.photoURL ??
              '')
          .toString();

      try {
        final userDoc = await FirebaseFirestore.instance
            .collection('users')
            .doc(user.uid)
            .get();
        final data = userDoc.data();
        if (data != null) {
          username = (data['username'] ?? username).toString();
          avatarUrl = (data['avatarUrl'] ?? avatarUrl).toString();
        }
      } catch (_) {}

      // Paso A (Storage): Si viene de prueba web (http), reutilizar URL; si es archivo local, subir como .mp4
      late final String downloadUrl;
      if (widget.videoPath.startsWith('http')) {
        setState(() => _uploadProgress = 1.0);
        downloadUrl = widget.videoPath;
      } else {
        File file = File(widget.videoPath);
        if (!file.path.toLowerCase().endsWith('.mp4')) {
          final Directory tempDir = await getTemporaryDirectory();
          final String mp4Path =
              '\${tempDir.path}/viroklipz_\${DateTime.now().millisecondsSinceEpoch}.mp4';
          file = await file.copy(mp4Path);
        }

        final String uniqueId = const Uuid().v4();
        final Reference storageRef =
            FirebaseStorage.instance.ref('videos/\$uniqueId.mp4');
        final metadata = SettableMetadata(contentType: 'video/mp4');
        final UploadTask uploadTask = storageRef.putFile(file, metadata);

        final sub = uploadTask.snapshotEvents.listen((TaskSnapshot snap) {
          if (mounted && snap.totalBytes > 0) {
            setState(() {
              _uploadProgress =
                  (snap.bytesTransferred / snap.totalBytes).clamp(0.0, 1.0);
            });
          }
        });

        final TaskSnapshot completedSnapshot = await uploadTask;
        await sub.cancel();
        downloadUrl = await completedSnapshot.ref.getDownloadURL();
      }

      // Paso B (Hashtags + Firestore): Extraer hashtags (#palabra -> "palabra") y guardar en "videos"
      final List<String> hashtags = _extractHashtags(caption);
      final String audioName = _audioController.text.trim();

      await FirebaseFirestore.instance.collection('videos').add({
        'videoUrl': downloadUrl,
        'caption': caption,
        'hashtags': hashtags,
        'audioName': audioName,
        'audioUrl': widget.audioUrl ?? '',
        'effectUsed': widget.effectUsed ?? 'Ninguno',
        'effectVideoUrl': widget.effectVideoUrl ?? '',
        'uid': user.uid,
        'authorId': user.uid,
        'username': username,
        'avatarUrl': avatarUrl,
        'likedBy': <String>[],
        'likes': 0,
        'likesCount': 0,
        'comments': 0,
        'commentsCount': 0,
        'createdAt': FieldValue.serverTimestamp(),
      });

      if (!mounted) return;
      await _videoController.pause();
      await _effectController?.pause();
      await _audioPlayer.stop();

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          backgroundColor: Color(0xFF10B981),
          content: Text('¡Video publicado en Viroklipz!'),
        ),
      );

      Navigator.of(context).pop(true);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _errorMessage = 'No se pudo subir el video: \$e';
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: const Color(0xFFDC2626),
          content: Text('Error al publicar: \$e'),
        ),
      );
    } finally {
      if (mounted) {
        setState(() => _isUploading = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final bool hasEffect =
        widget.effectUsed != null &&
        widget.effectUsed!.isNotEmpty &&
        widget.effectUsed != 'Ninguno';
    final userProvider = context.watch<UserProvider>();
    final authProvider = context.watch<AuthProvider>();
    final User? firebaseUser = FirebaseAuth.instance.currentUser;
    final String displayAuthorName = userProvider.displayName.isNotEmpty
        ? userProvider.displayName
        : (userProvider.username.isNotEmpty
            ? userProvider.username
            : (authProvider.currentUser?.username ??
                firebaseUser?.displayName ??
                firebaseUser?.email?.split('@').first ??
                'Eloy'));
    final String authorAvatarUrl = userProvider.avatarUrl.isNotEmpty
        ? userProvider.avatarUrl
        : (authProvider.currentUser?.avatarUrl ?? firebaseUser?.photoURL ?? '');
    final bool isPublishDisabled = _isUploading || !_canPublish;

    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF121212),
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white),
          onPressed: _isUploading ? null : () => Navigator.of(context).pop(false),
        ),
        title: const Text(
          'Publicar clip',
          style: TextStyle(
            color: Colors.white,
            fontSize: 17,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // 1. Previsualización con Stack: VideoPlayer base + efecto overlay
                    GestureDetector(
                      onTap: _togglePreviewPlayback,
                      child: Container(
                        height: 320,
                        decoration: BoxDecoration(
                          color: Colors.black,
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(color: Colors.white12),
                        ),
                        clipBehavior: Clip.antiAlias,
                        child: !_isVideoReady
                            ? const Center(
                                child: CircularProgressIndicator(
                                  color: AppColors.orange,
                                ),
                              )
                            : Stack(
                                fit: StackFit.expand,
                                children: [
                                  FittedBox(
                                    fit: BoxFit.cover,
                                    child: SizedBox(
                                      width: _videoController.value.size.width > 0
                                          ? _videoController.value.size.width
                                          : 1080,
                                      height: _videoController.value.size.height > 0
                                          ? _videoController.value.size.height
                                          : 1920,
                                      child: AspectRatio(
                                        aspectRatio:
                                            _videoController.value.aspectRatio > 0
                                                ? _videoController.value.aspectRatio
                                                : 9 / 16,
                                        child: VideoPlayer(_videoController),
                                      ),
                                    ),
                                  ),
                                  if (hasEffect)
                                    Positioned.fill(
                                      child: IgnorePointer(
                                        child: Opacity(
                                          opacity: 0.42,
                                          child: Container(
                                            decoration: const BoxDecoration(
                                              backgroundBlendMode:
                                                  BlendMode.screen,
                                              gradient: LinearGradient(
                                                begin: Alignment.topLeft,
                                                end: Alignment.bottomRight,
                                                colors: [
                                                  Color(0x9925F4EE),
                                                  Color(0x55E91E63),
                                                  Color(0x88FF5722),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  if (_isEffectReady && _effectController != null)
                                    Positioned.fill(
                                      child: IgnorePointer(
                                        child: Opacity(
                                          opacity: 0.42,
                                          child: FittedBox(
                                            fit: BoxFit.cover,
                                            child: SizedBox(
                                              width: _effectController!.value.size.width > 0
                                                  ? _effectController!.value.size.width
                                                  : 1080,
                                              height: _effectController!.value.size.height > 0
                                                  ? _effectController!.value.size.height
                                                  : 1920,
                                              child: AspectRatio(
                                                aspectRatio: _effectController!.value.aspectRatio > 0
                                                    ? _effectController!.value.aspectRatio
                                                    : 9 / 16,
                                                child: VideoPlayer(_effectController!),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  if (!_videoController.value.isPlaying)
                                    Center(
                                      child: Icon(
                                        Icons.play_arrow_rounded,
                                        size: 72,
                                        color: Colors.white.withValues(alpha: 0.75),
                                      ),
                                    ),
                                ],
                              ),
                      ),
                    ),

                    const SizedBox(height: 18),

                    // 2. Nombre del usuario
                    Row(
                      children: [
                        CircleAvatar(
                          radius: 16,
                          backgroundColor: const Color(0xFF27272A),
                          backgroundImage: authorAvatarUrl.isNotEmpty
                              ? NetworkImage(authorAvatarUrl)
                              : null,
                          child: authorAvatarUrl.isEmpty
                              ? Text(
                                  displayAuthorName.isNotEmpty
                                      ? displayAuthorName[0].toUpperCase()
                                      : 'E',
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 13,
                                    fontWeight: FontWeight.w700,
                                  ),
                                )
                              : null,
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            displayAuthorName,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 15.5,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 6),

                    // 3. Campo de descripción y hashtags (justo debajo del nombre y antes del audio)
                    TextField(
                      controller: _captionController,
                      enabled: !_isUploading,
                      maxLines: 3,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 14.5,
                        height: 1.4,
                      ),
                      cursorColor: AppColors.orange,
                      decoration: const InputDecoration(
                        hintText:
                            'Describe tu video y agrega hashtags (ej. #humor #baile #musica)',
                        hintStyle: TextStyle(color: Color(0xFF71717A)),
                        filled: true,
                        fillColor: Colors.transparent,
                        contentPadding: EdgeInsets.symmetric(
                          horizontal: 2,
                          vertical: 10,
                        ),
                        border: UnderlineInputBorder(
                          borderSide: BorderSide(color: Colors.white12),
                        ),
                        enabledBorder: UnderlineInputBorder(
                          borderSide: BorderSide(color: Colors.white12),
                        ),
                        focusedBorder: UnderlineInputBorder(
                          borderSide: BorderSide(
                            color: Colors.white38,
                            width: 1.2,
                          ),
                        ),
                      ),
                    ),

                    const SizedBox(height: 12),

                    // 4. Campo de audio opcional (y efecto seleccionado si aplica)
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: const Color(0xFF18181B),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.white10),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              const Icon(
                                Icons.music_note_rounded,
                                color: AppColors.magenta,
                                size: 18,
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: TextField(
                                  controller: _audioController,
                                  enabled: !_isUploading,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 13.5,
                                    fontWeight: FontWeight.w500,
                                  ),
                                  cursorColor: AppColors.orange,
                                  decoration: const InputDecoration(
                                    hintText: 'Nombre del audio (opcional)',
                                    hintStyle: TextStyle(
                                      color: Color(0xFF71717A),
                                      fontSize: 13.5,
                                    ),
                                    border: InputBorder.none,
                                    isDense: true,
                                    contentPadding: EdgeInsets.symmetric(
                                      vertical: 10,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          if (hasEffect) ...[
                            const Divider(color: Colors.white10, height: 1),
                            Padding(
                              padding: const EdgeInsets.symmetric(vertical: 8),
                              child: Row(
                                children: [
                                  const Icon(
                                    Icons.auto_awesome,
                                    color: Color(0xFF25F4EE),
                                    size: 16,
                                  ),
                                  const SizedBox(width: 8),
                                  Text(
                                    'Efecto: \${widget.effectUsed!}',
                                    style: const TextStyle(
                                      color: Colors.white70,
                                      fontSize: 12.5,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),

                    if (_isUploading) ...[
                      const SizedBox(height: 16),
                      Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: const Color(0xFF1E1E1E),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: Colors.white12),
                        ),
                        child: Row(
                          children: [
                            SizedBox(
                              width: 24,
                              height: 24,
                              child: CircularProgressIndicator(
                                value: _uploadProgress > 0 ? _uploadProgress : null,
                                color: AppColors.orange,
                                strokeWidth: 2.8,
                              ),
                            ),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Text(
                                _uploadProgress > 0
                                    ? 'Subiendo video... \${(_uploadProgress * 100).toStringAsFixed(0)}%'
                                    : 'Subiendo video...',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],

                    if (_errorMessage != null) ...[
                      const SizedBox(height: 10),
                      Text(
                        _errorMessage!,
                        style: const TextStyle(
                          color: Color(0xFFFF4D6D),
                          fontSize: 13,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),

            // 5. Botón grande "Publicar" (deshabilitado si la descripción está vacía o está subiendo)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
              child: AnimatedOpacity(
                duration: const Duration(milliseconds: 180),
                opacity: isPublishDisabled ? 0.45 : 1.0,
                child: Container(
                  height: 54,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    gradient: AppColors.brandGradient,
                    borderRadius: BorderRadius.circular(14),
                    boxShadow: isPublishDisabled
                        ? const <BoxShadow>[]
                        : [
                            BoxShadow(
                              color: AppColors.orange.withValues(alpha: 0.35),
                              blurRadius: 18,
                              offset: const Offset(0, 6),
                            ),
                          ],
                  ),
                  child: ElevatedButton(
                    onPressed: isPublishDisabled ? null : _publishVideo,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.transparent,
                      disabledBackgroundColor: Colors.transparent,
                      disabledForegroundColor: Colors.white70,
                      shadowColor: Colors.transparent,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                    ),
                    child: _isUploading
                        ? const Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                  color: Colors.white,
                                  strokeWidth: 2.5,
                                ),
                              ),
                              SizedBox(width: 12),
                              Text(
                                'Subiendo video...',
                                style: TextStyle(
                                  fontSize: 15.5,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ],
                          )
                        : const Text(
                            'Publicar',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}`,
  },
  {
    id: 'create_video_screen',
    path: 'lib/screens/create_video_screen.dart',
    phase: 'Paso 4 · Publicar Viroklip (Recibe Archivo)',
    language: 'dart',
    summary:
      'Recibe el archivo real seleccionado, lo reproduce en loop a pantalla completa, actualiza VideoProvider.uploadVideo y sube a Cloudflare R2 + Supabase.',
    code: `import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:video_player/video_player.dart';
import '../providers/video_provider.dart';
import '../services/r2_upload_service.dart';
import '../services/supabase_video_service.dart';

class CreateVideoScreen extends StatefulWidget {
  final File? initialVideoFile;
  final VoidCallback? onVideoPublished;

  const CreateVideoScreen({
    super.key,
    this.initialVideoFile,
    this.onVideoPublished,
  });

  @override
  State<CreateVideoScreen> createState() => _CreateVideoScreenState();
}

class _CreateVideoScreenState extends State<CreateVideoScreen> {
  final _picker = ImagePicker();
  final _r2Service = R2UploadService();
  final _videoService = SupabaseVideoService();

  final _descriptionController = TextEditingController();
  final _audioController = TextEditingController();

  File? _selectedVideo;
  VideoPlayerController? _previewController;
  bool _isUploading = false;
  double _uploadProgress = 0.0;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    if (widget.initialVideoFile != null) {
      _loadPreviewFile(widget.initialVideoFile!);
    }
  }

  @override
  void dispose() {
    _previewController?.dispose();
    _descriptionController.dispose();
    _audioController.dispose();
    super.dispose();
  }

  Future<void> _loadPreviewFile(File videoFile) async {
    final oldController = _previewController;
    final nextController = VideoPlayerController.file(videoFile);
    await nextController.initialize();
    await nextController.setLooping(true);
    await nextController.play();
    await oldController?.dispose();

    if (!mounted) {
      await nextController.dispose();
      return;
    }

    setState(() {
      _selectedVideo = videoFile;
      _previewController = nextController;
      _errorMessage = null;
    });
  }

  Future<void> _pickVideoFromGallery() async {
    if (_isUploading) return;
    try {
      final XFile? file = await _picker.pickVideo(
        source: ImageSource.gallery,
        maxDuration: const Duration(seconds: 60),
      );
      if (file == null) return;
      await _loadPreviewFile(File(file.path));
    } catch (e) {
      setState(() => _errorMessage = 'No se pudo cargar el video: \$e');
    }
  }

  Future<void> _publishVideo() async {
    if (_selectedVideo == null || _isUploading) return;

    final user = Supabase.instance.client.auth.currentUser;
    final String caption = _descriptionController.text.trim();
    final String audioName = _audioController.text.trim();

    setState(() {
      _isUploading = true;
      _uploadProgress = 0.0;
      _errorMessage = null;
    });

    try {
      if (user != null) {
        final String publicVideoUrl = await _r2Service.uploadVideo(
          videoFile: _selectedVideo!,
          userId: user.id,
          onProgress: (progress) {
            if (mounted) {
              setState(() => _uploadProgress = progress);
            }
          },
        );

        await _videoService.createVideoRecord(
          videoUrl: publicVideoUrl,
          description: caption,
          audioName: audioName,
        );

        if (mounted) {
          context.read<VideoProvider>().uploadVideo(publicVideoUrl, caption);
        }
      } else {
        // Modo MVP local: publica directo en VideoProvider con la ruta del archivo
        context.read<VideoProvider>().uploadVideo(_selectedVideo!.path, caption);
      }

      if (!mounted) return;
      widget.onVideoPublished?.call();
      Navigator.of(context).pop(true);
    } catch (e) {
      setState(() {
        _errorMessage = e.toString().replaceFirst('Exception: ', '');
      });
    } finally {
      if (mounted) {
        setState(() => _isUploading = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final bool hasReadyPreview =
        _previewController != null && _previewController!.value.isInitialized;

    return Scaffold(
      backgroundColor: Colors.black,
      extendBodyBehindAppBar: true,
      body: Stack(
        fit: StackFit.expand,
        children: [
          // 1. Capa base 100%: Video en bucle o invitación de galería
          Positioned.fill(
            child: hasReadyPreview
                ? FittedBox(
                    fit: BoxFit.cover,
                    child: SizedBox(
                      width: _previewController!.value.size.width,
                      height: _previewController!.value.size.height,
                      child: VideoPlayer(_previewController!),
                    ),
                  )
                : GestureDetector(
                    onTap: _pickVideoFromGallery,
                    behavior: HitTestBehavior.opaque,
                    child: Container(
                      color: const Color(0xFF09090B),
                      child: const Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.photo_library_outlined,
                            size: 56,
                            color: Colors.white70,
                          ),
                          SizedBox(height: 14),
                          Text(
                            'Toca para subir un video',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
          ),

          // 2. Scrim superior e inferior para garantizar legibilidad de la UI
          Positioned.fill(
            child: IgnorePointer(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.black.withValues(alpha: 0.55),
                      Colors.transparent,
                      Colors.transparent,
                      Colors.black.withValues(alpha: 0.88),
                    ],
                    stops: const [0.0, 0.22, 0.52, 1.0],
                  ),
                ),
              ),
            ),
          ),

          // 3. Arriba a la izquierda: Botón X (Cerrar) y botón opcional para cambiar video
          SafeArea(
            child: Align(
              alignment: Alignment.topCenter,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                      onPressed: _isUploading
                          ? null
                          : () => Navigator.of(context).pop(false),
                      icon: const Icon(Icons.close_rounded, color: Colors.white, size: 28),
                      style: IconButton.styleFrom(
                        backgroundColor: Colors.black.withValues(alpha: 0.35),
                      ),
                    ),
                    if (_selectedVideo != null && !_isUploading)
                      TextButton.icon(
                        onPressed: _pickVideoFromGallery,
                        icon: const Icon(Icons.refresh_rounded, color: Colors.white, size: 18),
                        label: const Text(
                          'Cambiar',
                          style: TextStyle(color: Colors.white, fontSize: 13),
                        ),
                        style: TextButton.styleFrom(
                          backgroundColor: Colors.black.withValues(alpha: 0.45),
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ),

          // 4. Abajo (estilo TikTok): Inputs transparentes + botón Publicar vibrante
          SafeArea(
            child: Align(
              alignment: Alignment.bottomCenter,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 18),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    TextField(
                      controller: _descriptionController,
                      enabled: !_isUploading,
                      maxLines: 2,
                      style: const TextStyle(color: Colors.white, fontSize: 15),
                      cursorColor: const Color(0xFFFE2C55),
                      decoration: const InputDecoration(
                        hintText: 'Escribe una descripción y #hashtags...',
                        hintStyle: TextStyle(color: Colors.white60, fontSize: 15),
                        filled: false,
                        border: UnderlineInputBorder(
                          borderSide: BorderSide(color: Colors.white24),
                        ),
                        enabledBorder: UnderlineInputBorder(
                          borderSide: BorderSide(color: Colors.white24),
                        ),
                        focusedBorder: UnderlineInputBorder(
                          borderSide: BorderSide(color: Colors.white70),
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    TextField(
                      controller: _audioController,
                      enabled: !_isUploading,
                      style: const TextStyle(color: Colors.white, fontSize: 14),
                      cursorColor: const Color(0xFFFE2C55),
                      decoration: const InputDecoration(
                        prefixIcon: Icon(
                          Icons.music_note_rounded,
                          color: Colors.white70,
                          size: 18,
                        ),
                        prefixIconConstraints: BoxConstraints(minWidth: 28, minHeight: 28),
                        hintText: 'Nombre del audio (opcional)',
                        hintStyle: TextStyle(color: Colors.white60, fontSize: 14),
                        filled: false,
                        border: UnderlineInputBorder(
                          borderSide: BorderSide(color: Colors.white24),
                        ),
                        enabledBorder: UnderlineInputBorder(
                          borderSide: BorderSide(color: Colors.white24),
                        ),
                        focusedBorder: UnderlineInputBorder(
                          borderSide: BorderSide(color: Colors.white70),
                        ),
                      ),
                    ),
                    if (_isUploading) ...[
                      const SizedBox(height: 14),
                      LinearProgressIndicator(
                        value: _uploadProgress > 0 ? _uploadProgress : null,
                        color: const Color(0xFFFE2C55),
                        backgroundColor: Colors.white24,
                      ),
                      const SizedBox(height: 6),
                      Text(
                        'Publicando... \${(_uploadProgress * 100).toStringAsFixed(0)}%',
                        textAlign: TextAlign.right,
                        style: const TextStyle(color: Colors.white70, fontSize: 12),
                      ),
                    ],
                    if (_errorMessage != null) ...[
                      const SizedBox(height: 10),
                      Text(
                        _errorMessage!,
                        style: const TextStyle(color: Color(0xFFFF4D6D), fontSize: 13),
                      ),
                    ],
                    const SizedBox(height: 16),
                    SizedBox(
                      height: 48,
                      child: ElevatedButton(
                        onPressed: (_selectedVideo == null || _isUploading)
                            ? null
                            : _publishVideo,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFFFE2C55),
                          disabledBackgroundColor:
                              const Color(0xFFFE2C55).withValues(alpha: 0.35),
                          foregroundColor: Colors.white,
                          disabledForegroundColor: Colors.white54,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                        child: const Text(
                          'Publicar',
                          style: TextStyle(
                            fontSize: 15.5,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}`,
  },
  {
    id: 'friends_feed_screen',
    path: 'lib/screens/friends_feed_screen.dart',
    phase: 'Paso 4 · Comunidad (Firestore StreamBuilder)',
    language: 'dart',
    summary:
      'Feed de Comunidad conectado en tiempo real a Cloud Firestore (videos ordenados por createdAt desc) filtrando seguidos y propios, con Empty State hacia la cámara.',
    code: `import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart' hide AuthProvider;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/video_provider.dart';
import '../theme/app_colors.dart';
import '../widgets/video_card.dart';
import 'camera_screen.dart';

class FriendsFeedScreen extends StatefulWidget {
  final bool isFeedVisible;
  final VoidCallback? onOpenCamera;

  const FriendsFeedScreen({
    super.key,
    this.isFeedVisible = true,
    this.onOpenCamera,
  });

  @override
  State<FriendsFeedScreen> createState() => _FriendsFeedScreenState();
}

class _FriendsFeedScreenState extends State<FriendsFeedScreen> {
  late final PageController _pageController;
  int _currentPage = 0;

  @override
  void initState() {
    super.initState();
    _pageController = PageController();
  }

  void _openCameraFallback() {
    if (widget.onOpenCamera != null) {
      widget.onOpenCamera!();
      return;
    }
    Navigator.of(context).push(
      MaterialPageRoute(
        fullscreenDialog: true,
        builder: (_) => const CameraScreen(),
      ),
    );
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final videoProvider = context.watch<VideoProvider>();
    final String? currentUid = FirebaseAuth.instance.currentUser?.uid;

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
            stream: FirebaseFirestore.instance
                .collection('videos')
                .orderBy('createdAt', descending: true)
                .snapshots(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting &&
                  !snapshot.hasData) {
                return const Center(
                  child: CircularProgressIndicator(color: AppColors.orange),
                );
              }

              final allDocs = snapshot.data?.docs ?? [];
              final communityDocs = allDocs.where((doc) {
                final data = doc.data();
                final String uid =
                    (data['uid'] ?? data['authorId'] ?? '').toString();
                return videoProvider.followingIds.contains(uid) ||
                    (currentUid != null && uid == currentUid);
              }).toList();

              if (allDocs.isEmpty || communityDocs.isEmpty) {
                final bool noVideosAtAll = allDocs.isEmpty;
                return Center(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 28),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(
                          Icons.people_outline,
                          size: 52,
                          color: AppColors.orange,
                        ),
                        const SizedBox(height: 12),
                        Text(
                          noVideosAtAll
                              ? 'Aún no hay videos. ¡Sé el primero en subir uno!'
                              : 'Aún no hay videos en Comunidad',
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          noVideosAtAll
                              ? 'Graba o selecciona un clip desde tu cámara para iniciar el feed.'
                              : 'Sigue a creadores en "Radar" o sube tu propio video para verlo aquí.',
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            color: Colors.white54,
                            fontSize: 13,
                          ),
                        ),
                        const SizedBox(height: 18),
                        Container(
                          decoration: BoxDecoration(
                            gradient: AppColors.brandGradient,
                            borderRadius: BorderRadius.circular(24),
                          ),
                          child: ElevatedButton.icon(
                            onPressed: _openCameraFallback,
                            icon: const Icon(Icons.videocam_rounded, size: 18),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.transparent,
                              shadowColor: Colors.transparent,
                              foregroundColor: Colors.white,
                              padding: const EdgeInsets.symmetric(
                                horizontal: 20,
                                vertical: 11,
                              ),
                            ),
                            label: const Text('Subir video'),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }

              final int safePage =
                  _currentPage.clamp(0, communityDocs.length - 1);

              return PageView.builder(
                controller: _pageController,
                scrollDirection: Axis.vertical,
                itemCount: communityDocs.length,
                onPageChanged: (index) {
                  setState(() => _currentPage = index);
                },
                itemBuilder: (context, index) {
                  final doc = communityDocs[index];
                  final data = doc.data();

                  final String videoUrl = (data['videoUrl'] ?? '').toString();
                  final String username =
                      (data['username'] ?? 'usuario').toString();
                  final String caption = (data['caption'] ?? '').toString();
                  final int likes =
                      ((data['likes'] ?? data['likesCount'] ?? 0) as num)
                          .toInt();
                  final int comments =
                      ((data['comments'] ?? data['commentsCount'] ?? 0) as num)
                          .toInt();
                  final String avatarUrl = (data['avatarUrl'] ?? '').toString();
                  final String uid =
                      (data['uid'] ?? data['authorId'] ?? '').toString();
                  final List<String> likedBy = List<String>.from(
                    data['likedBy'] ?? const <String>[],
                  );
                  final String audioName = (data['audioName'] ?? '').toString();
                  final String effectUsed =
                      (data['effectUsed'] ?? '').toString();
                  final String effectVideoUrl =
                      (data['effectVideoUrl'] ?? '').toString();

                  final isActive = widget.isFeedVisible && safePage == index;

                  return VideoCard(
                    key: ValueKey(doc.id),
                    videoId: doc.id,
                    videoUrl: videoUrl,
                    username: username,
                    caption: caption,
                    likes: likes,
                    comments: comments,
                    avatarUrl: avatarUrl,
                    uid: uid,
                    likedBy: likedBy,
                    audioName: audioName,
                    effectUsed: effectUsed,
                    effectVideoUrl: effectVideoUrl,
                    isActive: isActive,
                  );
                },
              );
            },
          ),

          // Barra Superior de Comunidad
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: 16.0,
                vertical: 10.0,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const SizedBox(width: 28),
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text(
                        'Comunidad',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Container(
                        width: 30,
                        height: 3,
                        decoration: BoxDecoration(
                          gradient: AppColors.brandGradient,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ],
                  ),
                  const Icon(Icons.search, color: Colors.white, size: 28),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}`,
  },
  {
    id: 'messages_screen',
    path: 'lib/screens/messages_screen.dart',
    phase: 'Mensajes · Bandeja de Entrada estilo TikTok',
    language: 'dart',
    summary:
      'Pantalla scrolleable de Mensajes en #0F0F0F con AppBar centrado, navegación a ActivityScreen y SystemNotificationsScreen, y lista de chats.',
    code: `import 'package:flutter/material.dart';
import 'activity_screen.dart';
import 'chat_screen.dart';
import 'system_notifications_screen.dart';

class _ChatItemData {
  final String chatId;
  final String otherUserId;
  final String name;
  final String lastMessage;
  final String time;
  final String avatarUrl;
  final String initials;
  final bool showCameraIcon;

  const _ChatItemData({
    required this.chatId,
    required this.otherUserId,
    required this.name,
    required this.lastMessage,
    required this.time,
    required this.avatarUrl,
    required this.initials,
    this.showCameraIcon = false,
  });
}

class MessagesScreen extends StatelessWidget {
  const MessagesScreen({super.key});

  static const List<_ChatItemData> _mockChats = [
    _ChatItemData(
      chatId: 'chat_bicorne',
      otherUserId: 'uid_bicorne',
      name: 'El Bicorne',
      lastMessage: 'As Salam aleykum...',
      time: '5 nov',
      avatarUrl:
          'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop',
      initials: 'EB',
      showCameraIcon: true,
    ),
    _ChatItemData(
      chatId: 'chat_toxica',
      otherUserId: 'uid_toxica',
      name: 'la toxica #1🦋',
      lastMessage: 'Enviado',
      time: '10:30 AM',
      avatarUrl:
          'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop',
      initials: 'LT',
      showCameraIcon: true,
    ),
    _ChatItemData(
      chatId: 'chat_jovana',
      otherUserId: 'uid_jovana',
      name: '1382jovana🇻🇪',
      lastMessage: 'Hola, ¿cómo estás?',
      time: 'Ayer',
      avatarUrl:
          'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&auto=format&fit=crop',
      initials: '13',
      showCameraIcon: false,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F0F0F),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0F0F0F),
        elevation: 0,
        centerTitle: true,
        automaticallyImplyLeading: false,
        title: const Text(
          'Mensajes',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.w700,
          ),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(
            height: 1,
            color: Colors.white.withValues(alpha: 0.08),
          ),
        ),
      ),
      body: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.symmetric(vertical: 8),
        children: [
          // A. SECCIÓN DE SISTEMA (Arriba de todo)
          _SystemTile(
            icon: Icons.bolt_rounded,
            iconColor: const Color(0xFFFF2D55),
            circleColor: const Color(0xFFFF2D55).withValues(alpha: 0.18),
            title: 'Actividad y nuevos seguidores',
            subtitle: 'Tienes nuevas visitas en tu perfil',
            onTap: () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const ActivityScreen()),
              );
            },
          ),
          _SystemTile(
            icon: Icons.inventory_2_outlined,
            iconColor: const Color(0xFF25F4EE),
            circleColor: const Color(0xFF25F4EE).withValues(alpha: 0.14),
            title: 'Notificación del sistema',
            subtitle: 'Bienvenido a Viroklipz. ¡Sube tu primer video!',
            onTap: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => const SystemNotificationsScreen(),
                ),
              );
            },
          ),

          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
            child: Divider(
              height: 1,
              color: Colors.white.withValues(alpha: 0.08),
            ),
          ),

          // B. SECCIÓN DE MENSAJES ENTRE USUARIOS
          ..._mockChats.map(
            (chat) => _UserChatTile(
              chat: chat,
              onTap: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => ChatScreen(
                      chatId: chat.chatId,
                      otherUserId: chat.otherUserId,
                      otherUserName: chat.name,
                      otherUserAvatarUrl: chat.avatarUrl,
                      otherUserInitials: chat.initials,
                    ),
                  ),
                );
              },
              onCameraTap: () => _showSnack(
                context,
                'Enviar video rápido a \${chat.name}',
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showSnack(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: const Color(0xFF1F1F23),
        content: Text(message, style: const TextStyle(color: Colors.white)),
        duration: const Duration(seconds: 2),
      ),
    );
  }
}

class _SystemTile extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final Color circleColor;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _SystemTile({
    required this.icon,
    required this.iconColor,
    required this.circleColor,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: onTap,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      leading: Container(
        width: 48,
        height: 48,
        decoration: BoxDecoration(
          color: circleColor,
          shape: BoxShape.circle,
        ),
        child: Icon(icon, color: iconColor, size: 24),
      ),
      title: Text(
        title,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 15,
          fontWeight: FontWeight.w700,
        ),
      ),
      subtitle: Padding(
        padding: const EdgeInsets.only(top: 2),
        child: Text(
          subtitle,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(
            color: Color(0xFFA1A1AA),
            fontSize: 13,
          ),
        ),
      ),
      trailing: const Icon(
        Icons.chevron_right_rounded,
        color: Color(0xFF71717A),
        size: 20,
      ),
    );
  }
}

class _UserChatTile extends StatelessWidget {
  final _ChatItemData chat;
  final VoidCallback onTap;
  final VoidCallback onCameraTap;

  const _UserChatTile({
    required this.chat,
    required this.onTap,
    required this.onCameraTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        child: Row(
          children: [
            ClipOval(
              child: SizedBox(
                width: 50,
                height: 50,
                child: Image.network(
                  chat.avatarUrl,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(
                    color: const Color(0xFF27272A),
                    alignment: Alignment.center,
                    child: Text(
                      chat.initials,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    chat.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    chat.lastMessage,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Color(0xFFA1A1AA),
                      fontSize: 13,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 10),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  chat.time,
                  style: const TextStyle(
                    color: Color(0xFF71717A),
                    fontSize: 11.5,
                  ),
                ),
                if (chat.showCameraIcon) ...[
                  const SizedBox(width: 8),
                  IconButton(
                    onPressed: onCameraTap,
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(
                      minWidth: 32,
                      minHeight: 32,
                    ),
                    icon: const Icon(
                      Icons.camera_alt_outlined,
                      color: Color(0xFFA1A1AA),
                      size: 20,
                    ),
                  ),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }
}`,
  },
  {
    id: 'chat_screen',
    path: 'lib/screens/chat_screen.dart',
    phase: 'Chat en Tiempo Real · Indicador "Escribiendo..." con Firestore',
    language: 'dart',
    summary:
      'ChatScreen conectado a Firestore chats/{chatId}: actualiza typingStatus.{miUid} con Timer debounce de 2.5s al escribir, lo apaga al enviar y escucha el documento con StreamBuilder + AnimatedSwitcher.',
    code: `import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class ChatScreen extends StatefulWidget {
  final String chatId;
  final String otherUserId;
  final String otherUserName;
  final String otherUserAvatarUrl;
  final String otherUserInitials;

  const ChatScreen({
    super.key,
    required this.chatId,
    required this.otherUserId,
    required this.otherUserName,
    required this.otherUserAvatarUrl,
    required this.otherUserInitials,
  });

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  Timer? _typingDebounce;
  bool _isCurrentlyTyping = false;

  String get _myUid => FirebaseAuth.instance.currentUser?.uid ?? '';

  DocumentReference<Map<String, dynamic>> get _chatDocRef =>
      FirebaseFirestore.instance.collection('chats').doc(widget.chatId);

  @override
  void dispose() {
    _typingDebounce?.cancel();
    if (_isCurrentlyTyping && _myUid.isNotEmpty) {
      _updateTypingStatus(false);
    }
    _messageController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  /// Actualiza chats/{chatId} -> typingStatus.{_myUid} = isTyping
  Future<void> _updateTypingStatus(bool isTyping) async {
    final uid = _myUid;
    if (uid.isEmpty) return;
    if (_isCurrentlyTyping == isTyping && isTyping) return;

    _isCurrentlyTyping = isTyping;

    try {
      await _chatDocRef.set(
        {
          'typingStatus': {uid: isTyping},
        },
        SetOptions(merge: true),
      );
    } catch (_) {
      // Silenciar errores transitorios de red al escribir
    }
  }

  /// Lógica del emisor: onChanged + Timer Debounce de 2.5 segundos
  void _onMessageChanged(String value) {
    _typingDebounce?.cancel();

    if (value.trim().isEmpty) {
      _updateTypingStatus(false);
      return;
    }

    _updateTypingStatus(true);

    _typingDebounce = Timer(const Duration(milliseconds: 2500), () {
      _updateTypingStatus(false);
    });
  }

  /// Envía el mensaje y apaga typingStatus.{_myUid} = false inmediatamente
  Future<void> _sendMessage() async {
    final text = _messageController.text.trim();
    final uid = _myUid;
    if (text.isEmpty || uid.isEmpty) return;

    _typingDebounce?.cancel();
    _messageController.clear();
    await _updateTypingStatus(false);

    await _chatDocRef.collection('messages').add({
      'senderId': uid,
      'text': text,
      'createdAt': FieldValue.serverTimestamp(),
    });

    await _chatDocRef.set(
      {
        'lastMessage': text,
        'updatedAt': FieldValue.serverTimestamp(),
        'typingStatus': {uid: false},
      },
      SetOptions(merge: true),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F0F0F),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0F0F0F),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios_new_rounded,
            color: Colors.white,
            size: 20,
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
        titleSpacing: 0,
        title: Row(
          children: [
            CircleAvatar(
              radius: 18,
              backgroundColor: const Color(0xFF27272A),
              backgroundImage: NetworkImage(widget.otherUserAvatarUrl),
              child: widget.otherUserAvatarUrl.isEmpty
                  ? Text(
                      widget.otherUserInitials,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                      ),
                    )
                  : null,
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                widget.otherUserName,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ],
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(
            height: 1,
            color: Colors.white.withValues(alpha: 0.08),
          ),
        ),
      ),
      body: Column(
        children: [
          // 1. LÓGICA DEL RECEPTOR: StreamBuilder escuchando chats/{chatId}
          StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
            stream: _chatDocRef.snapshots(),
            builder: (context, snapshot) {
              final data = snapshot.data?.data();
              final typingStatus =
                  data?['typingStatus'] as Map<String, dynamic>?;
              final isOtherTyping =
                  typingStatus?[widget.otherUserId] == true;

              return AnimatedSwitcher(
                duration: const Duration(milliseconds: 220),
                switchInCurve: Curves.easeOut,
                switchOutCurve: Curves.easeIn,
                transitionBuilder: (child, animation) => FadeTransition(
                  opacity: animation,
                  child: child,
                ),
                child: isOtherTyping
                    ? Container(
                        key: const ValueKey('typing_indicator_active'),
                        width: double.infinity,
                        padding: const EdgeInsets.fromLTRB(16, 8, 16, 2),
                        alignment: Alignment.centerLeft,
                        child: const Text(
                          'Escribiendo...',
                          style: TextStyle(
                            color: Color(0xFF9CA3AF),
                            fontSize: 12,
                            fontStyle: FontStyle.italic,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      )
                    : const SizedBox.shrink(
                        key: ValueKey('typing_indicator_idle'),
                      ),
              );
            },
          ),

          // 2. LISTA DE MENSAJES EN TIEMPO REAL
          Expanded(
            child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
              stream: _chatDocRef
                  .collection('messages')
                  .orderBy('createdAt', descending: false)
                  .snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const Center(
                    child: CircularProgressIndicator(
                      color: Color(0xFFFF2D55),
                    ),
                  );
                }

                final docs = snapshot.data!.docs;
                if (docs.isEmpty) {
                  return const Center(
                    child: Text(
                      'Envía un mensaje para iniciar la conversación',
                      style: TextStyle(
                        color: Color(0xFF71717A),
                        fontSize: 13,
                      ),
                    ),
                  );
                }

                return ListView.builder(
                  controller: _scrollController,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 12,
                  ),
                  itemCount: docs.length,
                  itemBuilder: (context, index) {
                    final msg = docs[index].data();
                    final isMe = msg['senderId'] == _myUid;
                    final text = (msg['text'] as String?) ?? '';

                    return Align(
                      alignment: isMe
                          ? Alignment.centerRight
                          : Alignment.centerLeft,
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 10),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 14,
                          vertical: 10,
                        ),
                        constraints: BoxConstraints(
                          maxWidth: MediaQuery.of(context).size.width * 0.75,
                        ),
                        decoration: BoxDecoration(
                          color: isMe
                              ? const Color(0xFFFF2D55)
                              : const Color(0xFF1B1B1F),
                          borderRadius: BorderRadius.circular(18),
                          border: isMe
                              ? null
                              : Border.all(
                                  color: Colors.white.withValues(alpha: 0.1),
                                ),
                        ),
                        child: Text(
                          text,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 14,
                          ),
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),

          // 3. CAMPO DE ENTRADA DEL EMISOR
          SafeArea(
            top: false,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                color: const Color(0xFF0F0F0F),
                border: Border(
                  top: BorderSide(
                    color: Colors.white.withValues(alpha: 0.1),
                  ),
                ),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _messageController,
                      onChanged: _onMessageChanged,
                      style: const TextStyle(color: Colors.white, fontSize: 14),
                      decoration: InputDecoration(
                        hintText: 'Enviar mensaje...',
                        hintStyle: const TextStyle(color: Color(0xFF71717A)),
                        filled: true,
                        fillColor: const Color(0xFF18181B),
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 10,
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(24),
                          borderSide: BorderSide(
                            color: Colors.white.withValues(alpha: 0.1),
                          ),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(24),
                          borderSide: BorderSide(
                            color: Colors.white.withValues(alpha: 0.1),
                          ),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(24),
                          borderSide: const BorderSide(
                            color: Color(0xFFFF2D55),
                          ),
                        ),
                      ),
                      onSubmitted: (_) => _sendMessage(),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton(
                    onPressed: _sendMessage,
                    style: IconButton.styleFrom(
                      backgroundColor: const Color(0xFFFF2D55),
                      foregroundColor: Colors.white,
                    ),
                    icon: const Icon(Icons.send_rounded, size: 18),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}`,
  },
  {
    id: 'activity_screen',
    path: 'lib/screens/activity_screen.dart',
    phase: 'Actividad · ActivityScreen (TabBar + Cuentas Recomendadas)',
    language: 'dart',
    summary:
      'DefaultTabController con pestañas Actividad (ActivityTabContent) y Nuevos seguidores (NewFollowersTabContent), avatares superpuestos y miniaturas de video.',
    code: `import 'package:flutter/material.dart';

class ActivityScreen extends StatelessWidget {
  const ActivityScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      initialIndex: 0,
      child: Scaffold(
        backgroundColor: const Color(0xFF0F0F0F),
        appBar: AppBar(
          backgroundColor: const Color(0xFF0F0F0F),
          elevation: 0,
          centerTitle: true,
          leading: IconButton(
            icon: const Icon(
              Icons.arrow_back_ios_new_rounded,
              color: Colors.white,
              size: 20,
            ),
            onPressed: () => Navigator.of(context).pop(),
          ),
          title: const Text(
            'Actividad',
            style: TextStyle(
              color: Colors.white,
              fontSize: 17,
              fontWeight: FontWeight.w700,
            ),
          ),
          bottom: const TabBar(
            indicatorColor: Color(0xFFFF2D55),
            indicatorWeight: 2.5,
            labelColor: Colors.white,
            unselectedLabelColor: Color(0xFF71717A),
            labelStyle: TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
            unselectedLabelStyle:
                TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
            tabs: [
              Tab(text: 'Actividad'),
              Tab(text: 'Nuevos seguidores'),
            ],
          ),
        ),
        body: const TabBarView(
          children: [
            ActivityTabContent(),
            NewFollowersTabContent(),
          ],
        ),
      ),
    );
  }
}

class _RecommendedUser {
  final String id;
  final String name;
  final String subtitle;
  final String avatarUrl;
  final String initials;
  final List<String> videoThumbnails;

  const _RecommendedUser({
    required this.id,
    required this.name,
    required this.subtitle,
    required this.avatarUrl,
    required this.initials,
    required this.videoThumbnails,
  });
}

const List<_RecommendedUser> _mockRecommendedUsers = [
  _RecommendedUser(
    id: 'rec_1',
    name: 'mateo.cine',
    subtitle: 'Compartió videos contigo',
    avatarUrl:
        'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop',
    initials: 'MC',
    videoThumbnails: [
      'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=300&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1536240478700-b869070f9279?w=300&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?w=300&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=300&auto=format&fit=crop',
    ],
  ),
  _RecommendedUser(
    id: 'rec_2',
    name: 'sofia.beats',
    subtitle: 'Compartió videos contigo',
    avatarUrl:
        'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&auto=format&fit=crop',
    initials: 'SB',
    videoThumbnails: [
      'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=300&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=300&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=300&auto=format&fit=crop',
    ],
  ),
  _RecommendedUser(
    id: 'rec_3',
    name: 'diego.skate',
    subtitle: 'Compartió videos contigo',
    avatarUrl:
        'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&auto=format&fit=crop',
    initials: 'DS',
    videoThumbnails: [
      'https://images.unsplash.com/photo-1547447134-cd3f5c716030?w=300&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1520045892732-304bc3ac5d8e?w=300&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1504450758481-7338eba7524a?w=300&auto=format&fit=crop',
    ],
  ),
];

class ActivityTabContent extends StatefulWidget {
  const ActivityTabContent({super.key});

  @override
  State<ActivityTabContent> createState() => _ActivityTabContentState();
}

class _ActivityTabContentState extends State<ActivityTabContent> {
  final Set<String> _followedIds = {};
  final Set<String> _dismissedIds = {};
  bool _showAll = false;

  @override
  Widget build(BuildContext context) {
    final visibleRecommended = _mockRecommendedUsers
        .where((u) => !_dismissedIds.contains(u.id))
        .toList();

    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.symmetric(vertical: 8),
      children: [
        // Notificación 1
        ListTile(
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          leading: const _RoundAvatar(
            url:
                'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop',
            initials: 'NA',
          ),
          title: RichText(
            text: const TextSpan(
              style: TextStyle(color: Color(0xFFE4E4E7), fontSize: 13.5),
              children: [
                TextSpan(
                  text: 'NANCY🦋 ',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                TextSpan(text: 'le dio me gusta a tu comentario'),
              ],
            ),
          ),
          subtitle: const Padding(
            padding: EdgeInsets.only(top: 3),
            child: Text(
              '2 d',
              style: TextStyle(color: Color(0xFF71717A), fontSize: 12),
            ),
          ),
        ),

        // Notificación 2 (Avatares superpuestos)
        ListTile(
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          leading: SizedBox(
            width: 48,
            height: 44,
            child: Stack(
              children: [
                const Positioned(
                  left: 0,
                  top: 0,
                  child: _RoundAvatar(
                    url:
                        'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&auto=format&fit=crop',
                    initials: 'VL',
                    size: 32,
                  ),
                ),
                Positioned(
                  right: 0,
                  bottom: 0,
                  child: Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: const Color(0xFF0F0F0F),
                        width: 2,
                      ),
                    ),
                    child: const _RoundAvatar(
                      url:
                          'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop',
                      initials: 'RA',
                      size: 30,
                    ),
                  ),
                ),
              ],
            ),
          ),
          title: RichText(
            text: const TextSpan(
              style: TextStyle(color: Color(0xFFE4E4E7), fontSize: 13.5),
              children: [
                TextSpan(
                  text: 'Valery🦋, Richard.A y Alix ',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                TextSpan(text: 'han visto tu perfil'),
              ],
            ),
          ),
          subtitle: const Padding(
            padding: EdgeInsets.only(top: 3),
            child: Text(
              '2 d',
              style: TextStyle(color: Color(0xFF71717A), fontSize: 12),
            ),
          ),
        ),

        if (_showAll)
          const ListTile(
            contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            leading: _RoundAvatar(
              url:
                  'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&auto=format&fit=crop',
              initials: 'LR',
            ),
            title: Text(
              'lucas.ruta comentó tu video',
              style: TextStyle(
                color: Colors.white,
                fontSize: 13.5,
                fontWeight: FontWeight.w600,
              ),
            ),
            subtitle: Text(
              '4 d',
              style: TextStyle(color: Color(0xFF71717A), fontSize: 12),
            ),
          ),

        // Ver todo centrado
        Center(
          child: TextButton.icon(
            onPressed: () => setState(() => _showAll = !_showAll),
            icon: Icon(
              _showAll
                  ? Icons.keyboard_arrow_up_rounded
                  : Icons.keyboard_arrow_down_rounded,
              color: const Color(0xFFA1A1AA),
              size: 18,
            ),
            label: Text(
              _showAll ? 'Ver menos' : 'Ver todo',
              style: const TextStyle(
                color: Color(0xFFA1A1AA),
                fontSize: 12.5,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ),

        if (visibleRecommended.isNotEmpty) ...[
          Divider(color: Colors.white.withValues(alpha: 0.08), height: 20),
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 4, 16, 8),
            child: Text(
              'Cuentas recomendadas',
              style: TextStyle(
                color: Color(0xFFA1A1AA),
                fontSize: 12.5,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          ...visibleRecommended.map((user) {
            final bool isFollowing = _followedIds.contains(user.id);
            return _RecommendedAccountRow(
              user: user,
              isFollowing: isFollowing,
              onFollowTap: () {
                setState(() {
                  if (isFollowing) {
                    _followedIds.remove(user.id);
                  } else {
                    _followedIds.add(user.id);
                  }
                });
              },
              onDismissTap: () => setState(() => _dismissedIds.add(user.id)),
            );
          }),
        ],
      ],
    );
  }
}

class NewFollowersTabContent extends StatefulWidget {
  const NewFollowersTabContent({super.key});

  @override
  State<NewFollowersTabContent> createState() => _NewFollowersTabContentState();
}

class _NewFollowersTabContentState extends State<NewFollowersTabContent> {
  final Set<String> _followedIds = {};
  final Set<String> _dismissedIds = {};
  bool _showAll = false;

  static const List<Map<String, String>> _followers = [
    {
      'id': 'f1',
      'name': 'Proyectos Yomi c.a',
      'time': '2 d',
      'initials': 'PY',
      'avatar':
          'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&auto=format&fit=crop',
    },
    {
      'id': 'f2',
      'name': 'Valery🦋',
      'time': '3 d',
      'initials': 'VL',
      'avatar':
          'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop',
    },
    {
      'id': 'f3',
      'name': 'Panelscleandr',
      'time': '4 d',
      'initials': 'PC',
      'avatar':
          'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop',
    },
  ];

  @override
  Widget build(BuildContext context) {
    final visibleRecommended = _mockRecommendedUsers
        .where((u) => !_dismissedIds.contains(u.id))
        .toList();

    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.symmetric(vertical: 8),
      children: [
        ..._followers.map((follower) {
          final id = follower['id']!;
          final bool isFollowing = _followedIds.contains(id);

          return ListTile(
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            leading: _RoundAvatar(
              url: follower['avatar']!,
              initials: follower['initials']!,
            ),
            title: Text(
              follower['name']!,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 14.5,
                fontWeight: FontWeight.w700,
              ),
            ),
            subtitle: Text(
              'empezó a seguirte. \${follower['time']}',
              style: const TextStyle(color: Color(0xFFA1A1AA), fontSize: 12.5),
            ),
            trailing: _FollowButton(
              isFollowing: isFollowing,
              onTap: () {
                setState(() {
                  if (isFollowing) {
                    _followedIds.remove(id);
                  } else {
                    _followedIds.add(id);
                  }
                });
              },
            ),
          );
        }),

        if (_showAll)
          ListTile(
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            leading: const _RoundAvatar(
              url:
                  'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&auto=format&fit=crop',
              initials: '13',
            ),
            title: const Text(
              '1382jovana🇻🇪',
              style: TextStyle(
                color: Colors.white,
                fontSize: 14.5,
                fontWeight: FontWeight.w700,
              ),
            ),
            subtitle: const Text(
              'empezó a seguirte. 6 d',
              style: TextStyle(color: Color(0xFFA1A1AA), fontSize: 12.5),
            ),
            trailing: _FollowButton(
              isFollowing: _followedIds.contains('f4'),
              onTap: () {
                setState(() {
                  if (_followedIds.contains('f4')) {
                    _followedIds.remove('f4');
                  } else {
                    _followedIds.add('f4');
                  }
                });
              },
            ),
          ),

        Center(
          child: TextButton.icon(
            onPressed: () => setState(() => _showAll = !_showAll),
            icon: Icon(
              _showAll
                  ? Icons.keyboard_arrow_up_rounded
                  : Icons.keyboard_arrow_down_rounded,
              color: const Color(0xFFA1A1AA),
              size: 18,
            ),
            label: Text(
              _showAll ? 'Ver menos' : 'Ver todo',
              style: const TextStyle(
                color: Color(0xFFA1A1AA),
                fontSize: 12.5,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ),

        if (visibleRecommended.isNotEmpty) ...[
          Divider(color: Colors.white.withValues(alpha: 0.08), height: 20),
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 4, 16, 8),
            child: Text(
              'Cuentas recomendadas',
              style: TextStyle(
                color: Color(0xFFA1A1AA),
                fontSize: 12.5,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          ...visibleRecommended.map((user) {
            final bool isFollowing = _followedIds.contains(user.id);
            return Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _RecommendedAccountRow(
                  user: user,
                  isFollowing: isFollowing,
                  onFollowTap: () {
                    setState(() {
                      if (isFollowing) {
                        _followedIds.remove(user.id);
                      } else {
                        _followedIds.add(user.id);
                      }
                    });
                  },
                  onDismissTap: () =>
                      setState(() => _dismissedIds.add(user.id)),
                ),
                // Fila de 3-4 miniaturas de video rectangulares
                Padding(
                  padding: const EdgeInsets.fromLTRB(74, 2, 16, 14),
                  child: Row(
                    children: user.videoThumbnails.take(4).map((thumbUrl) {
                      return Expanded(
                        child: Padding(
                          padding: const EdgeInsets.only(right: 6),
                          child: AspectRatio(
                            aspectRatio: 3 / 4,
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(8),
                              child: Stack(
                                fit: StackFit.expand,
                                children: [
                                  Image.network(
                                    thumbUrl,
                                    fit: BoxFit.cover,
                                    errorBuilder: (_, __, ___) => Container(
                                      color: const Color(0xFF1F1F23),
                                      child: const Icon(
                                        Icons.play_arrow_rounded,
                                        color: Colors.white54,
                                      ),
                                    ),
                                  ),
                                  const Positioned(
                                    left: 4,
                                    bottom: 4,
                                    child: Icon(
                                      Icons.play_arrow_rounded,
                                      color: Colors.white,
                                      size: 14,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ],
            );
          }),
        ],
      ],
    );
  }
}

class _RecommendedAccountRow extends StatelessWidget {
  final _RecommendedUser user;
  final bool isFollowing;
  final VoidCallback onFollowTap;
  final VoidCallback onDismissTap;

  const _RecommendedAccountRow({
    required this.user,
    required this.isFollowing,
    required this.onFollowTap,
    required this.onDismissTap,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          _RoundAvatar(url: user.avatarUrl, initials: user.initials),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  user.name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  user.subtitle,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Color(0xFFA1A1AA),
                    fontSize: 12.5,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          _FollowButton(isFollowing: isFollowing, onTap: onFollowTap),
          const SizedBox(width: 4),
          IconButton(
            onPressed: onDismissTap,
            padding: EdgeInsets.zero,
            constraints: const BoxConstraints(minWidth: 28, minHeight: 28),
            icon: const Icon(
              Icons.close_rounded,
              color: Color(0xFF71717A),
              size: 18,
            ),
          ),
        ],
      ),
    );
  }
}

class _FollowButton extends StatelessWidget {
  final bool isFollowing;
  final VoidCallback onTap;

  const _FollowButton({required this.isFollowing, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 34,
      child: ElevatedButton(
        onPressed: onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor:
              isFollowing ? const Color(0xFF27272A) : const Color(0xFFFF2D55),
          foregroundColor: Colors.white,
          elevation: 0,
          padding: const EdgeInsets.symmetric(horizontal: 12),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(6),
            side: isFollowing
                ? BorderSide(color: Colors.white.withValues(alpha: 0.15))
                : BorderSide.none,
          ),
        ),
        child: Text(
          isFollowing ? 'Siguiendo' : 'Seguir también',
          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
        ),
      ),
    );
  }
}

class _RoundAvatar extends StatelessWidget {
  final String url;
  final String initials;
  final double size;

  const _RoundAvatar({
    required this.url,
    required this.initials,
    this.size = 46,
  });

  @override
  Widget build(BuildContext context) {
    return ClipOval(
      child: SizedBox(
        width: size,
        height: size,
        child: Image.network(
          url,
          fit: BoxFit.cover,
          errorBuilder: (_, __, ___) => Container(
            color: const Color(0xFF27272A),
            alignment: Alignment.center,
            child: Text(
              initials,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 12,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ),
      ),
    );
  }
}`,
  },
  {
    id: 'system_notifications_screen',
    path: 'lib/screens/system_notifications_screen.dart',
    phase: 'Paso 4 · Notificaciones del sistema',
    language: 'dart',
    summary:
      'SystemNotificationsScreen (StatefulWidget) con SingleChildScrollView horizontal de 4 chips (Todo, Viroklipz, Actualizaciones de creadores, Asistente para transacciones) y listas filtradas por categoría.',
    code: `import 'package:flutter/material.dart';

enum _SystemFilter { todo, viroklipz, creadores, transacciones }

class _SystemCardData {
  final String id;
  final _SystemFilter category;
  final IconData icon;
  final Color iconColor;
  final Color iconBgColor;
  final String sender;
  final String timeAgo;
  final String title;
  final String subtitle;
  final String extraDetail;

  const _SystemCardData({
    required this.id,
    required this.category,
    required this.icon,
    required this.iconColor,
    required this.iconBgColor,
    required this.sender,
    required this.timeAgo,
    required this.title,
    required this.subtitle,
    required this.extraDetail,
  });
}

class SystemNotificationsScreen extends StatefulWidget {
  const SystemNotificationsScreen({super.key});

  @override
  State<SystemNotificationsScreen> createState() =>
      _SystemNotificationsScreenState();
}

class _SystemNotificationsScreenState extends State<SystemNotificationsScreen> {
  _SystemFilter _selectedFilter = _SystemFilter.todo;
  final Set<String> _expandedIds = <String>{};

  // Lista de tarjetas de la app (Viroklipz)
  static const List<_SystemCardData> _viroklipzCards = [
    _SystemCardData(
      id: 'sys-1',
      category: _SystemFilter.viroklipz,
      icon: Icons.music_note_rounded,
      iconColor: Color(0xFFFF2D55),
      iconBgColor: Color(0x33FF2D55),
      sender: 'Viroklipz · Actividades',
      timeAgo: '1 d',
      title:
          'Tus fans están buscando contenido. Asegúrate de que te encuentren.',
      subtitle:
          'Mira lo que es popular en tu nicho, respaldado por millones de búsquedas reales...',
      extraDetail:
          'Usa palabras clave claras en la descripción de tus videos verticales y aprovecha sonidos en tendencia para multiplicar tu alcance orgánico.',
    ),
    _SystemCardData(
      id: 'sys-4',
      category: _SystemFilter.viroklipz,
      icon: Icons.live_tv_rounded,
      iconColor: Color(0xFF25F4EE),
      iconBgColor: Color(0x3325F4EE),
      sender: 'LIVE · Actividades',
      timeAgo: '3 d',
      title: 'Tus espectadores quieren ver más de ti',
      subtitle:
          'Tu contenido LIVE genera comentarios. ¡Mantén el ritmo! LIVE Studio te permite iniciar...',
      extraDetail:
          'Conecta directamente con tus seguidores en tiempo real, responde preguntas de la comunidad y convierte los mejores momentos en clips.',
    ),
  ];

  // Lista de tarjetas de estadísticas y actualizaciones de creadores
  static const List<_SystemCardData> _creatorCards = [
    _SystemCardData(
      id: 'sys-2',
      category: _SystemFilter.creadores,
      icon: Icons.lightbulb_outline_rounded,
      iconColor: Color(0xFFFBBF24),
      iconBgColor: Color(0x33FBBF24),
      sender: 'Actualizaciones de creadores',
      timeAgo: '2 d',
      title: 'Hola, @mateo.cine, ¡la semana pasada te fue muy bien!',
      subtitle:
          '¿Estás ofreciendo lo que la gente busca? Descubre cómo te fue y obtén inspiración...',
      extraDetail:
          'Tus clips obtuvieron un 28% más de retención en los primeros 3 segundos. Publicar entre 7:00 PM y 9:00 PM mantiene el mejor ritmo.',
    ),
    _SystemCardData(
      id: 'sys-3',
      category: _SystemFilter.creadores,
      icon: Icons.lightbulb_outline_rounded,
      iconColor: Color(0xFFFBBF24),
      iconBgColor: Color(0x33FBBF24),
      sender: 'Actualizaciones de creadores',
      timeAgo: '10 mar',
      title: 'Perfecto para tu estilo creativo',
      subtitle:
          'activar monetización por vistas es un tema popular ahora. Explora tendencias relacionadas en Estadísticas de...',
      extraDetail:
          'Los creadores en tu categoría están generando un 35% más de ingresos activando la monetización en videos originales de más de 30 segundos.',
    ),
  ];

  // Lista de tarjetas de pagos y transacciones
  static const List<_SystemCardData> _transactionCards = [
    _SystemCardData(
      id: 'sys-5',
      category: _SystemFilter.transacciones,
      icon: Icons.attach_money_rounded,
      iconColor: Colors.white,
      iconBgColor: Color(0xFF2563EB),
      sender: 'Asistente para transacciones',
      timeAgo: '2 ene',
      title: 'Límite de retirada actualizado',
      subtitle: 'Puedes retirar hasta \\$100 al día en 01/2026.',
      extraDetail:
          'Tu cuenta cumple con los requisitos de verificación activa. Los retiros diarios se procesan automáticamente hacia tu método de pago.',
    ),
    _SystemCardData(
      id: 'sys-6',
      category: _SystemFilter.transacciones,
      icon: Icons.attach_money_rounded,
      iconColor: Colors.white,
      iconBgColor: Color(0xFF2563EB),
      sender: 'Asistente para transacciones',
      timeAgo: '19 dic 2025',
      title: 'Identidad verificada',
      subtitle: 'Tu identidad se verificó.',
      extraDetail:
          'Ya tienes acceso completo a retiros, propinas LIVE y herramientas de monetización para creadores en Viroklipz.',
    ),
  ];

  List<_SystemCardData> get _visibleCards {
    switch (_selectedFilter) {
      case _SystemFilter.todo:
        return [
          ..._viroklipzCards,
          ..._creatorCards,
          ..._transactionCards,
        ];
      case _SystemFilter.viroklipz:
        return _viroklipzCards;
      case _SystemFilter.creadores:
        return _creatorCards;
      case _SystemFilter.transacciones:
        return _transactionCards;
    }
  }

  @override
  Widget build(BuildContext context) {
    final cards = _visibleCards;

    return Scaffold(
      backgroundColor: const Color(0xFF0F0F0F),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0F0F0F),
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded,
              color: Colors.white, size: 20),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: const Text(
          'Notificaciones del sistema',
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.w700,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings_outlined,
                color: Colors.white, size: 22),
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Preferencias de notificaciones del sistema'),
                ),
              );
            },
          ),
        ],
      ),
      body: Column(
        children: [
          // Barra de filtros deslizable horizontalmente
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            child: Row(
              children: [
                _buildFilterChip(_SystemFilter.todo, 'Todo'),
                const SizedBox(width: 8),
                _buildFilterChip(_SystemFilter.viroklipz, 'Viroklipz'),
                const SizedBox(width: 8),
                _buildFilterChip(
                  _SystemFilter.creadores,
                  'Actualizaciones de creadores',
                ),
                const SizedBox(width: 8),
                _buildFilterChip(
                  _SystemFilter.transacciones,
                  'Asistente para transacciones',
                ),
              ],
            ),
          ),
          const Divider(height: 1, color: Color(0x14FFFFFF)),
          // Lista de tarjetas filtradas
          Expanded(
            child: ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: cards.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (context, index) => _buildNotificationCard(cards[index]),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNotificationCard(_SystemCardData card) {
    final isExpanded = _expandedIds.contains(card.id);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1E1E1E),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: Colors.white.withValues(alpha: 0.06),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header Row: icono + remitente + tiempo + menú (...)
          Row(
            children: [
              Container(
                width: 26,
                height: 26,
                decoration: BoxDecoration(
                  color: card.iconBgColor,
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  card.icon,
                  size: 15,
                  color: card.iconColor,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  card.sender,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Color(0xFFD4D4D8),
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Text(
                card.timeAgo,
                style: const TextStyle(
                  color: Color(0xFF71717A),
                  fontSize: 12,
                ),
              ),
              const SizedBox(width: 6),
              InkWell(
                borderRadius: BorderRadius.circular(16),
                onTap: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Opciones de \${card.sender}'),
                    ),
                  );
                },
                child: const Padding(
                  padding: EdgeInsets.all(4),
                  child: Icon(
                    Icons.more_horiz_rounded,
                    color: Color(0xFFA1A1AA),
                    size: 18,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          // Título principal en negrita y blanco
          Text(
            card.title,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 15,
              fontWeight: FontWeight.w700,
              height: 1.3,
            ),
          ),
          const SizedBox(height: 6),
          // Subtítulo en gris
          Text(
            card.subtitle,
            style: const TextStyle(
              color: Color(0xFFA1A1AA),
              fontSize: 13,
              height: 1.4,
            ),
          ),
          if (isExpanded) ...[
            const SizedBox(height: 10),
            const Divider(height: 1, color: Color(0x1AFFFFFF)),
            const SizedBox(height: 10),
            Text(
              card.extraDetail,
              style: const TextStyle(
                color: Color(0xFFD4D4D8),
                fontSize: 13,
                height: 1.4,
              ),
            ),
          ],
          const SizedBox(height: 6),
          // Botón de texto "Ver más" en blanco
          TextButton(
            onPressed: () {
              setState(() {
                if (isExpanded) {
                  _expandedIds.remove(card.id);
                } else {
                  _expandedIds.add(card.id);
                }
              });
            },
            style: TextButton.styleFrom(
              padding: EdgeInsets.zero,
              minimumSize: const Size(0, 30),
              tapTargetSize: MaterialTapTargetSize.shrinkWrap,
            ),
            child: Text(
              isExpanded ? 'Ver menos' : 'Ver más',
              style: const TextStyle(
                color: Colors.white,
                fontSize: 13,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterChip(_SystemFilter filter, String label) {
    final isSelected = _selectedFilter == filter;
    return ChoiceChip(
      label: Text(label),
      selected: isSelected,
      showCheckmark: false,
      onSelected: (_) {
        setState(() => _selectedFilter = filter);
      },
      backgroundColor: Colors.transparent,
      selectedColor: const Color(0xFF2D2D34),
      labelStyle: TextStyle(
        color: isSelected ? Colors.white : const Color(0xFFA1A1AA),
        fontSize: 12.5,
        fontWeight: FontWeight.w600,
      ),
      shape: StadiumBorder(
        side: BorderSide(
          color: isSelected
              ? Colors.white.withValues(alpha: 0.35)
              : Colors.white.withValues(alpha: 0.16),
        ),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
    );
  }
}`,
  },
  {
    id: 'profile_screen',
    path: 'lib/screens/profile_screen.dart',
    phase: 'Perfil · ProfileScreen (FirebaseAuth + Firestore)',
    language: 'dart',
    summary:
      'ProfileScreen conectado a FirebaseAuth y Cloud Firestore (users/{uid}) para mostrar username/correo reales, con endDrawer y Cerrar sesión hacia /landing.',
    code: `import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart' hide AuthProvider;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../providers/user_provider.dart';
import '../providers/video_provider.dart';
import 'activity_center_screen.dart';
import 'balance_screen.dart';
import 'edit_description_screen.dart';
import 'edit_profile_screen.dart';
import 'get_coins_screen.dart';
import 'legal_screen.dart';
import 'offline_videos_screen.dart';
import 'qr_profile_screen.dart';
import 'select_highlight_media_screen.dart';
import 'settings_privacy_screen.dart';
import 'story_viewer_screen.dart';
import 'video_detail_screen.dart';
import 'viroklipz_studio_screen.dart';

class ProfileScreen extends StatefulWidget {
  final bool embeddedInMainShell;
  final String? username;
  final String? userId;

  const ProfileScreen({
    super.key,
    this.embeddedInMainShell = true,
    this.username,
    this.userId,
  });

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  // Llave para abrir el menú lateral desde el botón de hamburguesa
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  final String seguidores = '269';
  final String siguiendo = '17';
  final String meGusta = '577';
  String miVariableDescripcion = '';
  int _selectedTabIndex = 0;
  bool _isDeletingAccount = false;
  bool _isFollowingScannedUser = false;

  bool get _isViewingOtherUser =>
      (widget.username != null && widget.username!.trim().isNotEmpty) ||
      (widget.userId != null && widget.userId!.trim().isNotEmpty);

  final List<String> videosUrls = const [
    'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=400&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1561361513-2d000a50f0dc?w=400&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=400&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=400&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=400&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1547447134-cd3f5c716030?w=400&auto=format&fit=crop',
  ];

  String get _resolvedUsername {
    final auth = context.read<AuthProvider>();
    return (auth.userProfile?['username'] ??
            auth.currentUser?.username ??
            FirebaseAuth.instance.currentUser?.displayName ??
            'usuario')
        .toString();
  }

  Future<void> _openEditDescription() async {
    final nuevaDescripcion = await Navigator.push<String>(
      context,
      MaterialPageRoute(
        builder: (context) => EditDescriptionScreen(
          initialDescription: miVariableDescripcion,
        ),
      ),
    );

    if (!mounted || nuevaDescripcion == null) return;
    setState(() {
      miVariableDescripcion = nuevaDescripcion;
    });

    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      try {
        await FirebaseFirestore.instance
            .collection('users')
            .doc(user.uid)
            .update({'bio': nuevaDescripcion});
      } catch (_) {}
    }
  }

  void _openViroklipzStudio() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const ViroklipzStudioScreen(),
      ),
    );
  }

  void _openQrProfile() {
    final username = _resolvedUsername;
    final liveAvatar = context.read<UserProvider>().avatarUrl;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => QrProfileScreen(
          nombreUsuario: username,
          arroba: '@\$username',
          avatarUrl: liveAvatar.isNotEmpty
              ? liveAvatar
              : 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop',
        ),
      ),
    );
  }

  void _openEditProfile() {
    final username = _resolvedUsername;
    final liveAvatar = context.read<UserProvider>().avatarUrl;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => EditProfileScreen(
          nombreUsuario: username,
          arroba: '@\$username',
          descripcion: miVariableDescripcion,
          avatarUrl: liveAvatar,
        ),
      ),
    );
  }

  void _openActivityCenter() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const ActivityCenterScreen(),
      ),
    );
  }

  void _openOfflineVideos() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const OfflineVideosScreen(),
      ),
    );
  }

  void _openBalance() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const BalanceScreen(),
      ),
    );
  }

  void _openGetCoins() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const GetCoinsScreen(),
      ),
    );
  }

  void _openSettingsPrivacy() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const SettingsPrivacyScreen(),
      ),
    );
  }

  Future<void> _handleSignOut() async {
    await context.read<AuthProvider>().signOut();
    if (!mounted) return;
    Navigator.pushNamedAndRemoveUntil(context, '/landing', (route) => false);
  }

  void _showDeleteAccountDialog() {
    showDialog<void>(
      context: context,
      barrierDismissible: !_isDeletingAccount,
      builder: (dialogContext) {
        return AlertDialog(
          backgroundColor: const Color(0xFF1E1E1E),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
          ),
          title: const Text(
            '¿Estás seguro de que deseas eliminar tu cuenta?',
            style: TextStyle(
              color: Colors.white,
              fontSize: 17,
              fontWeight: FontWeight.w800,
            ),
          ),
          content: const Text(
            'Esta acción es permanente e irreversible. Se eliminarán todos tus videos, seguidores y datos personales en Viroklipz.',
            style: TextStyle(
              color: Color(0xFFD4D4D8),
              fontSize: 13.5,
              height: 1.45,
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(),
              child: const Text(
                'Cancelar',
                style: TextStyle(color: Color(0xFFA1A1AA)),
              ),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(dialogContext).pop();
                _confirmDeleteAccount();
              },
              child: const Text(
                'Eliminar',
                style: TextStyle(
                  color: Color(0xFFEF4444),
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  Future<void> _confirmDeleteAccount() async {
    setState(() => _isDeletingAccount = true);

    try {
      final User? currentUser = FirebaseAuth.instance.currentUser;
      if (currentUser == null) {
        if (!mounted) return;
        setState(() => _isDeletingAccount = false);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            backgroundColor: Color(0xFFDC2626),
            content: Text(
              'No se encontró una sesión activa.',
              style: TextStyle(color: Colors.white),
            ),
          ),
        );
        return;
      }

      // Paso A: Eliminar documento del usuario en Firestore
      await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser.uid)
          .delete();

      // Paso B: Eliminar cuenta en Firebase Authentication
      await currentUser.delete();

      if (!mounted) return;
      await context.read<AuthProvider>().signOut();

      if (!mounted) return;
      setState(() => _isDeletingAccount = false);

      // Paso C: Navegar a Landing Page limpiando el historial
      Navigator.pushNamedAndRemoveUntil(context, '/landing', (route) => false);
    } on FirebaseAuthException catch (e) {
      if (!mounted) return;
      setState(() => _isDeletingAccount = false);

      final String message = e.code == 'requires-recent-login'
          ? 'Por seguridad, debes cerrar sesión y volver a iniciarla antes de eliminar tu cuenta'
          : 'Error al eliminar la cuenta: \${e.message ?? e.code}';

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: const Color(0xFFDC2626),
          content: Text(
            message,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      );
    } catch (_) {
      if (!mounted) return;
      setState(() => _isDeletingAccount = false);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          backgroundColor: Color(0xFFDC2626),
          content: Text(
            'No se pudo eliminar tu cuenta. Intenta nuevamente.',
            style: TextStyle(color: Colors.white),
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isViewingOtherUser) {
      final rawHandle = (widget.username ?? 'creador').trim();
      final cleanHandle =
          rawHandle.startsWith('@') ? rawHandle.substring(1) : rawHandle;
      final displayHandle = '@\$cleanHandle';
      final bool lookupByUid =
          widget.userId != null && widget.userId!.trim().isNotEmpty;

      return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: lookupByUid
            ? FirebaseFirestore.instance
                .collection('users')
                .where(FieldPath.documentId, isEqualTo: widget.userId!.trim())
                .limit(1)
                .snapshots()
            : FirebaseFirestore.instance
                .collection('users')
                .where('username', isEqualTo: cleanHandle)
                .limit(1)
                .snapshots(),
        builder: (context, snapshot) {
          final docData = snapshot.data?.docs.isNotEmpty == true
              ? snapshot.data!.docs.first.data()
              : null;
          final resolvedName =
              (docData?['username'] ?? cleanHandle).toString();
          final resolvedBio = (docData?['bio'] ?? '').toString();
          final resolvedAvatar = (docData?['avatarUrl'] ??
                  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop')
              .toString();

          return DefaultTabController(
            length: 2,
            child: Scaffold(
              backgroundColor: Colors.white,
              body: CustomScrollView(
                slivers: [
                  SliverAppBar(
                    backgroundColor: Colors.white,
                    elevation: 0,
                    pinned: true,
                    centerTitle: true,
                    leading: IconButton(
                      icon: const Icon(Icons.arrow_back, color: Colors.black),
                      onPressed: () => Navigator.of(context).pop(),
                    ),
                    title: Text(
                      displayHandle,
                      style: const TextStyle(
                        color: Colors.black,
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  SliverToBoxAdapter(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 16.0,
                        vertical: 8.0,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                resolvedName,
                                style: const TextStyle(
                                  color: Colors.black,
                                  fontSize: 24,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text(
                                displayHandle,
                                style: const TextStyle(
                                  fontSize: 13,
                                  color: Colors.grey,
                                ),
                              ),
                              const SizedBox(height: 12),
                              Row(
                                children: [
                                  _buildStat('142', 'Siguiendo'),
                                  const SizedBox(width: 16),
                                  _buildStat('12.4K', 'Seguidores'),
                                  const SizedBox(width: 16),
                                  _buildStat('84.2K', 'Me gusta'),
                                ],
                              ),
                            ],
                          ),
                          CircleAvatar(
                            radius: 45,
                            backgroundColor: Colors.grey[200],
                            backgroundImage: NetworkImage(resolvedAvatar),
                            onBackgroundImageError: (_, __) {},
                          ),
                        ],
                      ),
                    ),
                  ),
                  SliverToBoxAdapter(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 16.0,
                        vertical: 12.0,
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          if (resolvedBio.isNotEmpty) ...[
                            Text(
                              resolvedBio,
                              style: const TextStyle(
                                color: Colors.black87,
                                fontSize: 13.5,
                              ),
                            ),
                            const SizedBox(height: 12),
                          ],
                          Builder(
                            builder: (context) {
                              final String? myUid =
                                  FirebaseAuth.instance.currentUser?.uid;
                              final String targetUid =
                                  snapshot.data?.docs.isNotEmpty == true
                                      ? snapshot.data!.docs.first.id
                                      : cleanHandle;
                              final videoProvider =
                                  context.watch<VideoProvider>();

                              Widget buildFollowButton(bool isFollowing) {
                                return SizedBox(
                                  width: double.infinity,
                                  height: 42,
                                  child: ElevatedButton(
                                    onPressed: () {
                                      if (myUid == null) {
                                        setState(() {
                                          _isFollowingScannedUser =
                                              !_isFollowingScannedUser;
                                        });
                                      } else {
                                        videoProvider.toggleFollow(targetUid);
                                      }
                                    },
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: isFollowing
                                          ? const Color(0xFFF4F4F5)
                                          : const Color(0xFFFE2C55),
                                      foregroundColor: isFollowing
                                          ? Colors.black
                                          : Colors.white,
                                      elevation: 0,
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                    ),
                                    child: Text(
                                      isFollowing ? 'Siguiendo' : 'Seguir',
                                      style: const TextStyle(
                                        fontWeight: FontWeight.w700,
                                        fontSize: 14,
                                      ),
                                    ),
                                  ),
                                );
                              }

                              if (myUid == null) {
                                return buildFollowButton(
                                  _isFollowingScannedUser,
                                );
                              }

                              return StreamBuilder<
                                  DocumentSnapshot<Map<String, dynamic>>>(
                                stream: FirebaseFirestore.instance
                                    .collection('users')
                                    .doc(myUid)
                                    .collection('following')
                                    .doc(targetUid)
                                    .snapshots(),
                                builder: (context, followSnap) {
                                  final bool isFollowing = followSnap.hasData
                                      ? followSnap.data!.exists
                                      : videoProvider.isFollowing(targetUid);
                                  return buildFollowButton(isFollowing);
                                },
                              );
                            },
                          ),
                        ],
                      ),
                    ),
                  ),
                  SliverGrid(
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 3,
                      mainAxisSpacing: 2,
                      crossAxisSpacing: 2,
                      childAspectRatio: 9 / 16,
                    ),
                    delegate: SliverChildBuilderDelegate(
                      (context, index) => Image.network(
                        videosUrls[index],
                        fit: BoxFit.cover,
                      ),
                      childCount: videosUrls.length,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      );
    }

    final auth = context.watch<AuthProvider>();
    final userProvider = context.watch<UserProvider>();
    final User? fbUser = FirebaseAuth.instance.currentUser ?? auth.firebaseUser;

    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: fbUser != null
          ? FirebaseFirestore.instance
              .collection('users')
              .doc(fbUser.uid)
              .snapshots()
          : null,
      builder: (context, snapshot) {
        final Map<String, dynamic>? firestoreData = snapshot.data?.data();
        final String username = (firestoreData?['username'] ??
                auth.userProfile?['username'] ??
                auth.currentUser?.username ??
                fbUser?.displayName ??
                'gabriel_12343')
            .toString();
        final String email = (firestoreData?['email'] ??
                fbUser?.email ??
                auth.currentUser?.email ??
                '')
            .toString();
        final String liveAvatarUrl = (userProvider.avatarUrl.isNotEmpty
                ? userProvider.avatarUrl
                : (firestoreData?['avatarUrl'] ??
                    fbUser?.photoURL ??
                    'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=300&auto=format&fit=crop'))
            .toString();
        final String nombreUsuario = username;
        final String arroba = '@\$username';

        // DefaultTabController obligatorio para que TabBar funcione sin errores
        return DefaultTabController(
          length: 5,
          child: Scaffold(
            key: _scaffoldKey,
            backgroundColor: Colors.white,

            // MENÚ LATERAL DERECHO (endDrawer)
            endDrawer: _buildEndDrawer(email: email),

            body: Stack(
              children: [
                CustomScrollView(
              slivers: [
                // 1. APP BAR PERSONALIZADO
                SliverAppBar(
                  backgroundColor: Colors.white,
                  elevation: 0,
                  pinned: true,
                  leading: IconButton(
                    icon: const Icon(Icons.edit, color: Colors.black),
                    onPressed: _openEditProfile,
                  ),
                  actions: [
                    IconButton(
                      icon: const Icon(Icons.qr_code_scanner, color: Colors.black),
                      onPressed: _openQrProfile,
                    ),
                    IconButton(
                      icon: const Icon(Icons.person_add_alt, color: Colors.black),
                      onPressed: () {},
                    ),
                    IconButton(
                      icon: const Icon(Icons.menu, color: Colors.black),
                      onPressed: () {
                        _scaffoldKey.currentState?.openEndDrawer();
                      },
                    ),
                  ],
                ),

                // 2. INFORMACIÓN DEL PERFIL (FirebaseAuth + Firestore)
                SliverToBoxAdapter(
                  child: Padding(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              nombreUsuario,
                              style: const TextStyle(
                                color: Colors.black,
                                fontSize: 24,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              email.isNotEmpty ? '\$arroba · \$email' : arroba,
                              style:
                                  const TextStyle(fontSize: 13, color: Colors.grey),
                            ),
                            const SizedBox(height: 12),
                            Row(
                              children: [
                                _buildStat(siguiendo, 'Siguiendo'),
                                const SizedBox(width: 16),
                                _buildStat(seguidores, 'Seguidores'),
                                const SizedBox(width: 16),
                                _buildStat(meGusta, 'Me gusta'),
                              ],
                            ),
                          ],
                        ),
                    GestureDetector(
                      onTap: _openEditProfile,
                      child: CircleAvatar(
                        radius: 45,
                        backgroundColor: Colors.grey[200],
                        backgroundImage: NetworkImage(
                          liveAvatarUrl.isNotEmpty
                              ? liveAvatarUrl
                              : 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=300&auto=format&fit=crop',
                        ),
                        onBackgroundImageError: (_, __) {},
                      ),
                    ),
                  ],
                ),
              ),
            ),

            // 3. BOTONES DE DESCRIPCIÓN Y STUDIO
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.symmetric(
                    horizontal: 16.0, vertical: 12.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // 1. Botón de Agregar Descripción
                    GestureDetector(
                      onTap: _openEditDescription,
                      child: Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(
                            vertical: 12, horizontal: 12),
                        decoration: BoxDecoration(
                          color: Colors.grey[100],
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          miVariableDescripcion.isEmpty
                              ? '+ Agregar descripción'
                              : miVariableDescripcion,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: miVariableDescripcion.isEmpty
                                ? Colors.grey
                                : Colors.black87,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    // 2. Botón de Viroklipz Studio
                    GestureDetector(
                      onTap: _openViroklipzStudio,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.grey[300]!),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: const Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.star, color: Colors.pink, size: 16),
                            SizedBox(width: 4),
                            Text(
                              'Viroklipz Studio',
                              style: TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            // 4. HISTORIAS / DESTACADOS
            SliverToBoxAdapter(
              child: SizedBox(
                height: 100,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  children: [
                    _buildStoryItem('Nuevo', Icons.add),
                    ..._highlights.map(
                      (item) => _buildStoryItem(
                        item.title,
                        null,
                        isImage: true,
                        coverUrl: item.coverUrl,
                        slides: item.slides,
                      ),
                    ),
                    _buildStoryItem('Moment...', null, isImage: true),
                  ],
                ),
              ),
            ),

            // 5. PESTAÑAS FIJAS (TABS)
            SliverPersistentHeader(
              pinned: true,
              delegate: _SliverAppBarDelegate(
                TabBar(
                  onTap: (index) => setState(() => _selectedTabIndex = index),
                  indicatorColor: Colors.black,
                  labelColor: Colors.black,
                  unselectedLabelColor: Colors.grey,
                  tabs: const [
                    Tab(icon: Icon(Icons.grid_on)),
                    Tab(icon: Icon(Icons.lock_outline)),
                    Tab(icon: Icon(Icons.repeat)),
                    Tab(icon: Icon(Icons.bookmark_border)),
                    Tab(icon: Icon(Icons.favorite_border)),
                  ],
                ),
              ),
            ),

            // 6. GRID DE VÍDEOS CONECTADO A FIRESTORE (videos where authorId == miUid)
            if (_selectedTabIndex == 0 && fbUser != null)
              StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                stream: FirebaseFirestore.instance
                    .collection('videos')
                    .where('authorId', isEqualTo: fbUser.uid)
                    .snapshots(),
                builder: (context, videosSnapshot) {
                  if (videosSnapshot.connectionState == ConnectionState.waiting &&
                      !videosSnapshot.hasData) {
                    return const SliverToBoxAdapter(
                      child: Padding(
                        padding: EdgeInsets.symmetric(vertical: 48),
                        child: Center(
                          child: CircularProgressIndicator(
                            color: Color(0xFFFF5722),
                          ),
                        ),
                      ),
                    );
                  }

                  final docs = videosSnapshot.data?.docs ?? [];
                  if (docs.isEmpty) {
                    return const SliverToBoxAdapter(
                      child: Padding(
                        padding: EdgeInsets.symmetric(
                          vertical: 48,
                          horizontal: 24,
                        ),
                        child: Column(
                          children: [
                            Icon(
                              Icons.videocam_outlined,
                              size: 40,
                              color: Colors.grey,
                            ),
                            SizedBox(height: 8),
                            Text(
                              'Aún no has publicado videos',
                              style: TextStyle(
                                color: Colors.black87,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  }

                  return SliverPadding(
                    padding: const EdgeInsets.all(2.0),
                    sliver: SliverGrid(
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 3,
                        mainAxisSpacing: 2,
                        crossAxisSpacing: 2,
                        childAspectRatio: 9 / 16,
                      ),
                      delegate: SliverChildBuilderDelegate(
                        (context, index) {
                          final doc = docs[index];
                          final data = doc.data();
                          final String thumbUrl =
                              (data['thumbnailUrl'] ?? '').toString();
                          final int likesCount =
                              (data['likesCount'] as num?)?.toInt() ??
                                  (data['likes'] as num?)?.toInt() ??
                                  0;

                          return GestureDetector(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) =>
                                      VideoDetailScreen(videoId: doc.id),
                                ),
                              );
                            },
                            child: Container(
                              color: const Color(0xFF1F1F23),
                              child: Stack(
                                fit: StackFit.expand,
                                children: [
                                  if (thumbUrl.isNotEmpty)
                                    Image.network(
                                      thumbUrl,
                                      fit: BoxFit.cover,
                                      errorBuilder: (_, __, ___) => const Center(
                                        child: Icon(
                                          Icons.play_circle_outline,
                                          color: Colors.white54,
                                          size: 32,
                                        ),
                                      ),
                                    )
                                  else
                                    const Center(
                                      child: Icon(
                                        Icons.play_circle_filled_rounded,
                                        color: Colors.white54,
                                        size: 34,
                                      ),
                                    ),
                                  Positioned(
                                    bottom: 8,
                                    left: 8,
                                    child: Row(
                                      children: [
                                        const Icon(
                                          Icons.play_arrow,
                                          color: Colors.white,
                                          size: 16,
                                        ),
                                        const SizedBox(width: 4),
                                        Text(
                                          likesCount.toString(),
                                          style: const TextStyle(
                                            color: Colors.white,
                                            fontSize: 12,
                                            fontWeight: FontWeight.w600,
                                            shadows: [
                                              Shadow(
                                                color: Colors.black54,
                                                blurRadius: 4,
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                        childCount: docs.length,
                      ),
                    ),
                  );
                },
              )
            else
              const SliverToBoxAdapter(
                child: Padding(
                  padding: EdgeInsets.symmetric(vertical: 48, horizontal: 24),
                  child: Column(
                    children: [
                      Icon(Icons.videocam_off_outlined,
                          size: 40, color: Colors.grey),
                      SizedBox(height: 8),
                      Text(
                        'Aún no hay videos en esta pestaña',
                        style: TextStyle(
                          color: Colors.black87,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
                if (_isDeletingAccount)
                  Container(
                    color: Colors.black.withValues(alpha: 0.75),
                    child: const Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          CircularProgressIndicator(color: Color(0xFFEF4444)),
                          SizedBox(height: 14),
                          Text(
                            'Eliminando cuenta...',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
        // Evita duplicar la barra inferior cuando se monta dentro de MainScreen
        bottomNavigationBar: widget.embeddedInMainShell
            ? null
            : BottomNavigationBar(
                type: BottomNavigationBarType.fixed,
                selectedItemColor: Colors.black,
                unselectedItemColor: Colors.grey,
                currentIndex: 4,
                items: [
                  const BottomNavigationBarItem(
                    icon: Icon(Icons.home_outlined),
                    label: 'Inicio',
                  ),
                  const BottomNavigationBarItem(
                    icon: Icon(Icons.people_outline),
                    label: 'Amigos',
                  ),
                  BottomNavigationBarItem(
                    icon: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 4),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Colors.cyan, Colors.pink],
                        ),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Icon(Icons.add, color: Colors.white),
                    ),
                    label: '',
                  ),
                  const BottomNavigationBarItem(
                    icon: Icon(Icons.message_outlined),
                    label: 'Mensajes',
                  ),
                  const BottomNavigationBarItem(
                    icon: Icon(Icons.person),
                    label: 'Perfil',
                  ),
                ],
              ),
          ),
        );
      },
    );
  }

  // ==========================================
  // DISEÑO DEL MENÚ LATERAL (DRAWER)
  // ==========================================
  Widget _buildEndDrawer({String email = ''}) {
    return Drawer(
      backgroundColor: Colors.white,
      child: SafeArea(
        child: ListView(
          padding: const EdgeInsets.symmetric(horizontal: 8.0),
          children: [
            if (email.isNotEmpty) ...[
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Sesión iniciada',
                      style: TextStyle(
                        color: Colors.grey,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      email,
                      style: const TextStyle(
                        color: Colors.black87,
                        fontSize: 13.5,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              const Divider(),
            ],
            const Padding(
              padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
              child: Text(
                'Recursos',
                style:
                    TextStyle(color: Colors.grey, fontWeight: FontWeight.w600),
              ),
            ),
            _buildDrawerItem(
              Icons.account_balance_wallet_outlined,
              'Saldo',
              () {
                Navigator.of(context).pop();
                _openBalance();
              },
            ),
            _buildDrawerItem(
              Icons.monetization_on_outlined,
              'Obtener Monedas',
              () {
                Navigator.of(context).pop();
                _openGetCoins();
              },
            ),
            const Divider(),
            const Padding(
              padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
              child: Text(
                'Herramientas personales',
                style:
                    TextStyle(color: Colors.grey, fontWeight: FontWeight.w600),
              ),
            ),
            _buildDrawerItem(
              Icons.access_time,
              'Centro de actividades',
              () {
                Navigator.of(context).pop();
                _openActivityCenter();
              },
            ),
            _buildDrawerItem(
              Icons.cloud_download_outlined,
              'Vídeos sin conexión',
              () {
                Navigator.of(context).pop();
                _openOfflineVideos();
              },
            ),
            _buildDrawerItem(
              Icons.qr_code,
              'Tu código QR',
              () {
                Navigator.of(context).pop();
                _openQrProfile();
              },
            ),
            const Divider(),
            const Padding(
              padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
              child: Text(
                'Herramientas de creación y negocios',
                style:
                    TextStyle(color: Colors.grey, fontWeight: FontWeight.w600),
              ),
            ),
            _buildDrawerItem(
              Icons.star_border,
              'Viroklipz Studio',
              () {
                Navigator.of(context).pop();
                _openViroklipzStudio();
              },
            ),
            const Divider(),
          // Ajustes y privacidad + Pantallas Legales
          _buildDrawerItem(
            Icons.settings_outlined,
            'Ajustes y privacidad',
            () {
              Navigator.of(context).pop();
              _openSettingsPrivacy();
            },
          ),
          ListTile(
            leading: const Icon(
              Icons.description_outlined,
              color: Colors.black,
              size: 28,
            ),
            title: const Text(
              'Términos y Condiciones',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w500,
                color: Colors.black,
              ),
            ),
            trailing: const Icon(Icons.chevron_right, color: Colors.grey),
            onTap: () {
              Navigator.of(context).pop();
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => const LegalScreen(
                    title: 'Términos y Condiciones',
                    content: LegalTexts.termsAndConditions,
                  ),
                ),
              );
            },
            contentPadding: const EdgeInsets.symmetric(horizontal: 16.0),
          ),
          ListTile(
            leading: const Icon(
              Icons.shield_outlined,
              color: Colors.black,
              size: 28,
            ),
            title: const Text(
              'Política de Privacidad',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w500,
                color: Colors.black,
              ),
            ),
            trailing: const Icon(Icons.chevron_right, color: Colors.grey),
            onTap: () {
              Navigator.of(context).pop();
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => const LegalScreen(
                    title: 'Política de Privacidad',
                    content: LegalTexts.privacyPolicy,
                  ),
                ),
              );
            },
            contentPadding: const EdgeInsets.symmetric(horizontal: 16.0),
          ),
            ListTile(
              leading: const Icon(Icons.logout_rounded,
                  color: Colors.redAccent, size: 26),
              title: const Text(
                'Cerrar sesión',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: Colors.redAccent,
                ),
              ),
              onTap: () async {
                Navigator.of(context).pop();
                await _handleSignOut();
              },
              contentPadding: const EdgeInsets.symmetric(horizontal: 16.0),
            ),
            ListTile(
              leading: Icon(
                Icons.delete_forever_rounded,
                color: Colors.red.shade900,
                size: 26,
              ),
              title: Text(
                'Eliminar cuenta',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: Colors.red.shade900,
                ),
              ),
              onTap: () {
                Navigator.of(context).pop();
                _showDeleteAccountDialog();
              },
              contentPadding: const EdgeInsets.symmetric(horizontal: 16.0),
            ),
          ],
        ),
      ),
    );
  }

  // Widget de ayuda para crear cada ítem del menú
  Widget _buildDrawerItem(IconData icon, String title, VoidCallback onTap) {
    return ListTile(
      leading: Icon(icon, color: Colors.black, size: 28),
      title: Text(
        title,
        style: const TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.w500,
          color: Colors.black,
        ),
      ),
      trailing: const Icon(Icons.chevron_right, color: Colors.grey),
      onTap: onTap,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 0),
    );
  }

  // ==========================================
  // WIDGETS DE AYUDA (ESTADÍSTICAS E HISTORIAS)
  // ==========================================
  Widget _buildStat(String count, String label) {
    return Column(
      children: [
        Text(
          count,
          style: const TextStyle(
            color: Colors.black,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        Text(label, style: const TextStyle(fontSize: 12, color: Colors.grey)),
      ],
    );
  }

  final List<HighlightStoryData> _highlights = [];

  Widget _buildStoryItem(
    String title,
    IconData? icon, {
    bool isImage = false,
    String? coverUrl,
    List<String>? slides,
  }) {
    final String resolvedCover = coverUrl ??
        'https://images.unsplash.com/photo-1561361513-2d000a50f0dc?w=200&auto=format&fit=crop';

    return GestureDetector(
      onTap: () async {
        if (!isImage) {
          // Si es el botón de "Nuevo", abrimos la galería de selección
          final HighlightStoryData? created =
              await Navigator.push<HighlightStoryData>(
            context,
            MaterialPageRoute(
              builder: (context) => const SelectHighlightMediaScreen(),
            ),
          );
          if (created != null && mounted) {
            setState(() => _highlights.insert(0, created));
          }
        } else {
          // Abrimos el visor del Storie / Destacado
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => StoryViewerScreen(
                title: title,
                coverUrl: resolvedCover,
                slides: slides ??
                    const [
                      'https://images.unsplash.com/photo-1561361513-2d000a50f0dc?w=900&auto=format&fit=crop',
                      'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=900&auto=format&fit=crop',
                    ],
              ),
            ),
          );
        }
      },
      child: Padding(
        padding: const EdgeInsets.only(right: 16.0),
        child: Column(
          children: [
            Container(
              width: 60,
              height: 60,
              clipBehavior: Clip.antiAlias,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: Colors.grey[300]!),
              ),
              child: isImage
                  ? Image.network(
                      resolvedCover,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) =>
                          const Icon(Icons.image, color: Colors.grey),
                    )
                  : Icon(icon, color: Colors.black),
            ),
            const SizedBox(height: 4),
            Text(title, style: const TextStyle(fontSize: 12, color: Colors.black)),
          ],
        ),
      ),
    );
  }
}

class _SliverAppBarDelegate extends SliverPersistentHeaderDelegate {
  final TabBar _tabBar;
  _SliverAppBarDelegate(this._tabBar);

  @override
  double get minExtent => _tabBar.preferredSize.height;
  @override
  double get maxExtent => _tabBar.preferredSize.height;

  @override
  Widget build(
      BuildContext context, double shrinkOffset, bool overlapsContent) {
    return Container(color: Colors.white, child: _tabBar);
  }

  @override
  bool shouldRebuild(_SliverAppBarDelegate oldDelegate) => false;
}`,
  },
  {
    id: 'edit_description_screen',
    path: 'lib/screens/edit_description_screen.dart',
    phase: 'Perfil · EditDescriptionScreen',
    language: 'dart',
    summary:
      'Pantalla completa para editar la descripción del perfil con contador (máx. 80 caracteres), etiquetas rápidas y retorno vía Navigator.pop(context, texto).',
    code: `import 'package:flutter/material.dart';

class EditDescriptionScreen extends StatefulWidget {
  final String initialDescription;

  const EditDescriptionScreen({
    super.key,
    this.initialDescription = '',
  });

  @override
  State<EditDescriptionScreen> createState() => _EditDescriptionScreenState();
}

class _EditDescriptionScreenState extends State<EditDescriptionScreen> {
  static const int _maxLength = 80;
  late final TextEditingController _controller;

  static const List<String> _quickTags = [
    '🎬 Creador de clips',
    '🎵 Música & beats',
    '✈️ Viajes y rutas',
    '📸 Fotografía 35mm',
    '🎮 Gaming',
  ];

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: widget.initialDescription);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _appendTag(String tag) {
    final current = _controller.text.trim();
    final next = current.isEmpty ? tag : '\$current · \$tag';
    if (next.length <= _maxLength) {
      setState(() {
        _controller.text = next;
        _controller.selection = TextSelection.collapsed(offset: next.length);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leadingWidth: 92,
        leading: TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text(
            'Cancelar',
            style: TextStyle(color: Colors.black87, fontSize: 15),
          ),
        ),
        centerTitle: true,
        title: const Text(
          'Descripción',
          style: TextStyle(
            color: Colors.black,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop(_controller.text.trim());
            },
            child: const Text(
              'Guardar',
              style: TextStyle(
                color: Color(0xFFFF2D55),
                fontSize: 15,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'TU PRESENTACIÓN',
              style: TextStyle(
                color: Colors.grey,
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _controller,
              maxLength: _maxLength,
              maxLines: 4,
              autofocus: true,
              onChanged: (_) => setState(() {}),
              style: const TextStyle(color: Colors.black, fontSize: 15),
              decoration: InputDecoration(
                hintText: 'Agrega una descripción sobre ti o tus aficiones...',
                hintStyle: const TextStyle(color: Colors.grey),
                filled: true,
                fillColor: Colors.grey[100],
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              'Ideas rápidas',
              style: TextStyle(
                color: Colors.black87,
                fontSize: 13,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: _quickTags.map((tag) {
                return ActionChip(
                  label: Text(
                    tag,
                    style: const TextStyle(color: Colors.black87, fontSize: 12),
                  ),
                  backgroundColor: Colors.grey[100],
                  side: BorderSide(color: Colors.grey[300]!),
                  onPressed: () => _appendTag(tag),
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }
}`,
  },
  {
    id: 'edit_profile_screen',
    path: 'lib/screens/edit_profile_screen.dart',
    phase: 'Perfil · EditProfileScreen (Upload Avatar Firebase Storage + UserProvider)',
    language: 'dart',
    summary:
      'Pantalla Editar perfil con subida real de avatar a FirebaseStorage (avatars/{uid}.jpg), actualización de updatePhotoURL + Firestore users/{uid}.avatarUrl, UserProvider en tiempo real, CircularProgressIndicator sobre la foto y SnackBar "Foto de perfil actualizada".',
    code: `import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart' hide AuthProvider;
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import '../providers/user_provider.dart';
import '../theme/app_colors.dart';
import 'camera_screen.dart';
import 'edit_description_screen.dart';
import 'media_picker_screen.dart';

class EditProfileScreen extends StatefulWidget {
  final String nombreUsuario;
  final String arroba;
  final String descripcion;
  final String avatarUrl;

  const EditProfileScreen({
    super.key,
    this.nombreUsuario = 'Eloy',
    this.arroba = '@gabriel_12343',
    this.descripcion = '',
    this.avatarUrl = '',
  });

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  final ImagePicker _picker = ImagePicker();

  late String _nombre;
  late String _username;
  late String _descripcion;
  String _pronombre = '';
  File? _avatarFile;
  String? _uploadedAvatarUrl;
  bool _isUploadingAvatar = false;
  File? _backgroundFile;
  String? _backgroundPublicationUrl;

  @override
  void initState() {
    super.initState();
    _nombre = widget.nombreUsuario;
    _username = widget.arroba.replaceFirst('@', '');
    _descripcion = widget.descripcion;
    if (widget.avatarUrl.isNotEmpty) {
      _uploadedAvatarUrl = widget.avatarUrl;
    }
  }

  String get _profileUrl => 'viroklipz.app/@\$_username';

  /// Sube el archivo de avatar a FirebaseStorage (avatars/{uid}.jpg),
  /// obtiene getDownloadURL(), actualiza FirebaseAuth.updatePhotoURL y Firestore users/{uid}.avatarUrl.
  Future<void> _uploadAvatarToFirebase(File imageFile) async {
    final User? currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser == null) return;

    setState(() {
      _avatarFile = imageFile;
      _isUploadingAvatar = true;
    });

    try {
      final Reference storageRef = FirebaseStorage.instance
          .ref('avatars/\${currentUser.uid}.jpg');
      await storageRef.putFile(imageFile);
      final String downloadUrl = await storageRef.getDownloadURL();

      await currentUser.updatePhotoURL(downloadUrl);
      await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser.uid)
          .set({'avatarUrl': downloadUrl}, SetOptions(merge: true));

      if (!mounted) return;
      context.read<UserProvider>().updateAvatarFromUrl(downloadUrl);

      setState(() {
        _uploadedAvatarUrl = downloadUrl;
        _isUploadingAvatar = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Foto de perfil actualizada'),
          backgroundColor: Color(0xFF10B981),
        ),
      );
    } catch (_) {
      if (!mounted) return;
      setState(() => _isUploadingAvatar = false);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('No se pudo subir la foto de perfil'),
          backgroundColor: Color(0xFFDC2626),
        ),
      );
    }
  }

  Future<void> _pickImageFromSource({
    required ImageSource source,
    required bool isAvatar,
  }) async {
    final XFile? image = await _picker.pickImage(
      source: source,
      imageQuality: 85,
      maxWidth: 1080,
    );
    if (image == null || !mounted) return;

    final File pickedFile = File(image.path);
    if (isAvatar) {
      await _uploadAvatarToFirebase(pickedFile);
    } else {
      setState(() {
        _backgroundFile = pickedFile;
        _backgroundPublicationUrl = null;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Foto de fondo cargada'),
          backgroundColor: Color(0xFF27272A),
        ),
      );
    }
  }

  Future<void> _openMediaPicker({required bool isAvatar}) async {
    final String? selectedUrl = await Navigator.push<String>(
      context,
      MaterialPageRoute(builder: (context) => const MediaPickerScreen()),
    );
    if (selectedUrl != null && mounted) {
      if (isAvatar) {
        setState(() => _isUploadingAvatar = true);
        await context.read<UserProvider>().updateAvatarFromUrl(selectedUrl);
        if (!mounted) return;
        setState(() {
          _uploadedAvatarUrl = selectedUrl;
          _avatarFile = null;
          _isUploadingAvatar = false;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Foto de perfil actualizada'),
            backgroundColor: Color(0xFF10B981),
          ),
        );
      } else {
        setState(() {
          _backgroundPublicationUrl = selectedUrl;
          _backgroundFile = null;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Imagen seleccionada de tus publicaciones'),
            backgroundColor: Color(0xFF27272A),
          ),
        );
      }
    }
  }

  void _removeBackground() {
    setState(() {
      _backgroundFile = null;
      _backgroundPublicationUrl = null;
    });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Fondo de perfil eliminado'),
        backgroundColor: Color(0xFF27272A),
      ),
    );
  }

  void _showMediaOptionsBottomSheet({required bool isAvatar}) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF1E1E1E),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
      ),
      builder: (BuildContext sheetContext) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(height: 8),
              Container(
                width: 36,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey[700],
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(height: 8),
              // Opción 1 arriba de todo: Cámara
              ListTile(
                leading: const Icon(
                  Icons.camera_alt_outlined,
                  color: AppColors.magenta,
                ),
                title: Text(
                  isAvatar ? 'Tomar foto con cámara' : 'Tomar foto o video',
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Colors.white,
                  ),
                ),
                onTap: () {
                  Navigator.pop(sheetContext);
                  if (isAvatar) {
                    _pickImageFromSource(
                      source: ImageSource.camera,
                      isAvatar: true,
                    );
                  } else {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const CameraScreen(),
                      ),
                    );
                  }
                },
              ),
              const Divider(height: 1, color: Colors.white12),
              ListTile(
                leading: const Icon(
                  Icons.photo_library_outlined,
                  color: Colors.white70,
                ),
                title: const Text(
                  'Cargar foto',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Colors.white,
                  ),
                ),
                onTap: () {
                  Navigator.pop(sheetContext);
                  _pickImageFromSource(
                    source: ImageSource.gallery,
                    isAvatar: isAvatar,
                  );
                },
              ),
              const Divider(height: 1, color: Colors.white12),
              ListTile(
                leading: const Icon(
                  Icons.video_collection_outlined,
                  color: Colors.white70,
                ),
                title: const Text(
                  'Elegir de tus publicaciones',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Colors.white,
                  ),
                ),
                onTap: () {
                  Navigator.pop(sheetContext);
                  _openMediaPicker(isAvatar: isAvatar);
                },
              ),
              Container(height: 8, color: AppColors.background),
              ListTile(
                title: Text(
                  'Cancelar',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                    color: Colors.grey[400],
                  ),
                ),
                onTap: () => Navigator.pop(sheetContext),
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _copyProfileUrl() async {
    await Clipboard.setData(ClipboardData(text: 'https://\$_profileUrl'));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('URL del perfil copiada'),
        backgroundColor: Color(0xFF27272A),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bool hasBackground =
        _backgroundFile != null || _backgroundPublicationUrl != null;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.background,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Editar perfil',
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
        actions: [
          TextButton(
            onPressed: () => _showMediaOptionsBottomSheet(isAvatar: false),
            child: const Text(
              'Agregar fondo',
              style: TextStyle(
                color: Colors.white70,
                fontSize: 13,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
      body: ListView(
        children: [
          // Banner superior con Fondo seleccionado, Cambiar y Eliminar fondo
          if (hasBackground)
            Container(
              height: 96,
              margin: const EdgeInsets.fromLTRB(16, 8, 16, 0),
              clipBehavior: Clip.antiAlias,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Colors.white12),
              ),
              child: Stack(
                fit: StackFit.expand,
                children: [
                  if (_backgroundFile != null)
                    Image.file(_backgroundFile!, fit: BoxFit.cover)
                  else
                    Image.network(_backgroundPublicationUrl!, fit: BoxFit.cover),
                  Container(color: Colors.black45),
                  const Positioned(
                    left: 12,
                    bottom: 10,
                    child: Text(
                      'Fondo seleccionado',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  Positioned(
                    right: 8,
                    bottom: 8,
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        GestureDetector(
                          onTap: () =>
                              _showMediaOptionsBottomSheet(isAvatar: false),
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 5,
                            ),
                            decoration: BoxDecoration(
                              color: Colors.black.withValues(alpha: 0.65),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: const Text(
                              'Cambiar',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 6),
                        GestureDetector(
                          onTap: _removeBackground,
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 5,
                            ),
                            decoration: BoxDecoration(
                              color: Colors.black.withValues(alpha: 0.65),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: const [
                                Icon(
                                  Icons.delete_outline,
                                  color: Colors.redAccent,
                                  size: 13,
                                ),
                                SizedBox(width: 4),
                                Text(
                                  'Eliminar fondo',
                                  style: TextStyle(
                                    color: Colors.redAccent,
                                    fontSize: 11,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

          // Avatar circular grande + cámara / CircularProgressIndicator + "Cambiar foto"
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 24),
            child: Column(
              children: [
                GestureDetector(
                  onTap: _isUploadingAvatar
                      ? null
                      : () => _showMediaOptionsBottomSheet(isAvatar: true),
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      Builder(
                        builder: (context) {
                          final liveUrl = context.watch<UserProvider>().avatarUrl;
                          final effectiveUrl = _uploadedAvatarUrl ??
                              (liveUrl.isNotEmpty
                                  ? liveUrl
                                  : 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop');
                          return CircleAvatar(
                            radius: 46,
                            backgroundColor: AppColors.surface,
                            backgroundImage: _avatarFile != null
                                ? FileImage(_avatarFile!) as ImageProvider
                                : NetworkImage(effectiveUrl),
                          );
                        },
                      ),
                      Container(
                        width: 92,
                        height: 92,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.black.withValues(alpha: 0.45),
                        ),
                        child: _isUploadingAvatar
                            ? const Center(
                                child: SizedBox(
                                  width: 28,
                                  height: 28,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2.8,
                                    color: AppColors.magenta,
                                  ),
                                ),
                              )
                            : const Icon(
                                Icons.camera_alt_outlined,
                                color: Colors.white,
                                size: 28,
                              ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 10),
                GestureDetector(
                  onTap: _isUploadingAvatar
                      ? null
                      : () => _showMediaOptionsBottomSheet(isAvatar: true),
                  child: Text(
                    _isUploadingAvatar ? 'Subiendo foto...' : 'Cambiar foto',
                    style: const TextStyle(
                      color: AppColors.magenta,
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ),

          const Divider(height: 1, color: Colors.white10),

          // Opciones principales
          _buildInfoTile(
            title: 'Nombre',
            value: _nombre,
            onTap: () {},
          ),
          _buildInfoTile(
            title: 'Nombre de usuario',
            value: _username,
            onTap: () {},
          ),
          ListTile(
            title: const Text(
              'URL del perfil',
              style: TextStyle(fontSize: 15, color: Colors.white),
            ),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  _profileUrl,
                  style: TextStyle(fontSize: 13, color: Colors.grey[400]),
                ),
                const SizedBox(width: 8),
                Icon(Icons.copy_rounded, size: 17, color: Colors.grey[400]),
              ],
            ),
            onTap: _copyProfileUrl,
          ),

          const Divider(height: 1, color: Colors.white10),

          // Sección: Información básica
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 6),
            child: Text(
              'Información básica',
              style: TextStyle(
                color: Colors.grey[400],
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          _buildInfoTile(
            title: 'Descripción',
            value: _descripcion.isEmpty
                ? 'Agregar una descripción'
                : _descripcion,
            onTap: () async {
              final result = await Navigator.push<String>(
                context,
                MaterialPageRoute(
                  builder: (context) =>
                      EditDescriptionScreen(initialDescription: _descripcion),
                ),
              );
              if (result != null && mounted) {
                setState(() => _descripcion = result);
              }
            },
          ),
          _buildInfoTile(
            title: 'Pronombre',
            value: _pronombre.isEmpty ? 'Agregar pronombres' : _pronombre,
            onTap: () {},
          ),

          const Divider(height: 1, color: Colors.white10),

          // Sección: Otros
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 6),
            child: Text(
              'Otros',
              style: TextStyle(
                color: Colors.grey[400],
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          _buildInfoTile(
            title: 'AI Self',
            value: 'Configurar',
            onTap: () {},
          ),
        ],
      ),
    );
  }

  Widget _buildInfoTile({
    required String title,
    required String value,
    required VoidCallback onTap,
  }) {
    return ListTile(
      title: Text(
        title,
        style: const TextStyle(fontSize: 15, color: Colors.white),
      ),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 160),
            child: Text(
              value,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: 14, color: Colors.grey[400]),
            ),
          ),
          const SizedBox(width: 4),
          Icon(Icons.chevron_right, color: Colors.grey[500]),
        ],
      ),
      onTap: onTap,
    );
  }
}`,
  },
  {
    id: 'media_picker_screen',
    path: 'lib/screens/media_picker_screen.dart',
    phase: 'Perfil · MediaPickerScreen (Elegir de tus publicaciones)',
    language: 'dart',
    summary:
      'Selector de publicaciones 9:16 con AppBar (X y "Recientes"), GridView.builder con bordes redondeados, ícono Play + vistas y botón píldora "Siguiente".',
    code: `import 'package:flutter/material.dart';

class MediaPickerScreen extends StatefulWidget {
  const MediaPickerScreen({super.key});

  @override
  State<MediaPickerScreen> createState() => _MediaPickerScreenState();
}

class _MediaPickerScreenState extends State<MediaPickerScreen> {
  int _selectedIndex = 0;

  final List<Map<String, String>> _publications = const [
    {
      'url':
          'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=400&auto=format&fit=crop',
      'views': '157',
    },
    {
      'url':
          'https://images.unsplash.com/photo-1561361513-2d000a50f0dc?w=400&auto=format&fit=crop',
      'views': '412',
    },
    {
      'url':
          'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=400&auto=format&fit=crop',
      'views': '1.2K',
    },
    {
      'url':
          'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=400&auto=format&fit=crop',
      'views': '893',
    },
    {
      'url':
          'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=400&auto=format&fit=crop',
      'views': '2.4K',
    },
    {
      'url':
          'https://images.unsplash.com/photo-1547447134-cd3f5c716030?w=400&auto=format&fit=crop',
      'views': '645',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.close, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
        centerTitle: true,
        title: GestureDetector(
          onTap: () {},
          child: const Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Recientes',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(width: 4),
              Icon(Icons.keyboard_arrow_down, color: Colors.black),
            ],
          ),
        ),
      ),
      body: Stack(
        children: [
          GridView.builder(
            padding: const EdgeInsets.fromLTRB(8, 8, 8, 92),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              crossAxisSpacing: 6,
              mainAxisSpacing: 6,
              childAspectRatio: 9 / 16,
            ),
            itemCount: _publications.length,
            itemBuilder: (context, index) {
              final item = _publications[index];
              final bool isSelected = index == _selectedIndex;

              return GestureDetector(
                onTap: () => setState(() => _selectedIndex = index),
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    border: isSelected
                        ? Border.all(color: const Color(0xFFFF2D55), width: 2.5)
                        : null,
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(6),
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        Image.network(item['url']!, fit: BoxFit.cover),
                        Positioned(
                          left: 6,
                          bottom: 6,
                          child: Row(
                            children: [
                              const Icon(
                                Icons.play_arrow_rounded,
                                color: Colors.white,
                                size: 15,
                              ),
                              const SizedBox(width: 2),
                              Text(
                                item['views']!,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 11,
                                  fontWeight: FontWeight.w600,
                                  shadows: [
                                    Shadow(
                                      color: Colors.black54,
                                      blurRadius: 4,
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),

          // Botón flotante tipo píldora "Siguiente"
          Positioned(
            right: 16,
            bottom: 24,
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                gradient: const LinearGradient(
                  colors: [Color(0xFFFF2D55), Color(0xFFFF6B35)],
                ),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFFFF2D55).withOpacity(0.35),
                    blurRadius: 12,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  borderRadius: BorderRadius.circular(30),
                  onTap: () {
                    Navigator.pop(
                      context,
                      _publications[_selectedIndex]['url'],
                    );
                  },
                  child: const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                    child: Text(
                      'Siguiente',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}`,
  },
  {
    id: 'viroklipz_studio_screen',
    path: 'lib/screens/viroklipz_studio_screen.dart',
    phase: 'Perfil · ViroklipzStudioScreen',
    language: 'dart',
    summary:
      'Panel de creadores Viroklipz Studio con métricas (7 y 28 días), progreso de monetización por vistas y rendimiento de videos recientes.',
    code: `import 'package:flutter/material.dart';

class ViroklipzStudioScreen extends StatefulWidget {
  const ViroklipzStudioScreen({super.key});

  @override
  State<ViroklipzStudioScreen> createState() => _ViroklipzStudioScreenState();
}

class _ViroklipzStudioScreenState extends State<ViroklipzStudioScreen> {
  bool _is28Days = false;

  @override
  Widget build(BuildContext context) {
    final views = _is28Days ? '62.4K' : '14.8K';
    final visits = _is28Days ? '7.3K' : '1.9K';
    final likes = _is28Days ? '2.4K' : '577';
    final followers = _is28Days ? '+194' : '+48';

    return Scaffold(
      backgroundColor: const Color(0xFF0F0F0F),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0F0F0F),
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded,
              color: Colors.white, size: 20),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: const Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.star, color: Colors.pink, size: 18),
            SizedBox(width: 6),
            Text(
              'Viroklipz Studio',
              style: TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Resumen de creador',
                    style: TextStyle(color: Colors.grey, fontSize: 12),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    _is28Days
                        ? '+39% vs mes anterior'
                        : '+24% vs semana anterior',
                    style: const TextStyle(
                      color: Color(0xFF34D399),
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
              ToggleButtons(
                isSelected: [!_is28Days, _is28Days],
                onPressed: (index) => setState(() => _is28Days = index == 1),
                borderRadius: BorderRadius.circular(10),
                selectedColor: Colors.black,
                color: Colors.white70,
                fillColor: Colors.white,
                constraints: const BoxConstraints(minHeight: 32, minWidth: 64),
                children: const [
                  Text('7 días', style: TextStyle(fontSize: 12)),
                  Text('28 días', style: TextStyle(fontSize: 12)),
                ],
              ),
            ],
          ),
          const SizedBox(height: 16),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            childAspectRatio: 1.55,
            children: [
              _buildMetricCard('Visualizaciones', views, Icons.visibility_outlined, const Color(0xFF25F4EE)),
              _buildMetricCard('Visitas al perfil', visits, Icons.people_outline, const Color(0xFFFF2D55)),
              _buildMetricCard('Me gusta', likes, Icons.favorite_border, const Color(0xFFF43F5E)),
              _buildMetricCard('Seguidores', followers, Icons.trending_up, const Color(0xFF34D399)),
            ],
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFF1E1E1E),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: Colors.pink.withValues(alpha: 0.25)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  children: [
                    CircleAvatar(
                      radius: 14,
                      backgroundColor: Color(0xFF2563EB),
                      child: Icon(Icons.attach_money, color: Colors.white, size: 16),
                    ),
                    SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Programa de Creadores',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                            ),
                          ),
                          Text(
                            'Monetización por vistas',
                            style: TextStyle(color: Colors.grey, fontSize: 12),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: const LinearProgressIndicator(
                    value: 0.74,
                    minHeight: 8,
                    backgroundColor: Colors.white12,
                    valueColor: AlwaysStoppedAnimation<Color>(Color(0xFFFF2D55)),
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  '7,400 / 10,000 reproducciones elegibles este mes',
                  style: TextStyle(color: Colors.white70, fontSize: 12),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMetricCard(
      String label, String value, IconData icon, Color accent) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF1E1E1E),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Icon(icon, color: accent, size: 16),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Colors.white70, fontSize: 12),
                ),
              ),
            ],
          ),
          Text(
            value,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 22,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}`,
  },
  {
    id: 'select_highlight_media_screen',
    path: 'lib/screens/select_highlight_media_screen.dart',
    phase: 'Perfil · SelectHighlightMediaScreen',
    language: 'dart',
    summary:
      'Galería oscura multi-selección estilo TikTok para crear un nuevo destacado con título y devolver HighlightStoryData al perfil.',
    code: `import 'package:flutter/material.dart';

class HighlightStoryData {
  final String title;
  final String coverUrl;
  final List<String> slides;

  const HighlightStoryData({
    required this.title,
    required this.coverUrl,
    required this.slides,
  });
}

class SelectHighlightMediaScreen extends StatefulWidget {
  const SelectHighlightMediaScreen({super.key});

  @override
  State<SelectHighlightMediaScreen> createState() =>
      _SelectHighlightMediaScreenState();
}

class _SelectHighlightMediaScreenState
    extends State<SelectHighlightMediaScreen> {
  final TextEditingController _titleController =
      TextEditingController(text: 'Destacado');

  final List<String> _galleryUrls = const [
    'https://images.unsplash.com/photo-1561361513-2d000a50f0dc?w=600&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=600&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=600&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?w=600&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=600&auto=format&fit=crop',
  ];

  final List<int> _selectedIndices = [0];

  @override
  void dispose() {
    _titleController.dispose();
    super.dispose();
  }

  void _toggleIndex(int index) {
    setState(() {
      if (_selectedIndices.contains(index)) {
        _selectedIndices.remove(index);
      } else {
        _selectedIndices.add(index);
      }
    });
  }

  void _confirmSelection() {
    if (_selectedIndices.isEmpty) return;
    final List<String> picked =
        _selectedIndices.map((idx) => _galleryUrls[idx]).toList();
    final String cleanTitle = _titleController.text.trim();

    Navigator.pop(
      context,
      HighlightStoryData(
        title: cleanTitle.isEmpty ? 'Destacado' : cleanTitle,
        coverUrl: picked.first,
        slides: picked,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F0F0F),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0F0F0F),
        foregroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.close),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Nuevo destacado',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: TextButton(
              onPressed: _selectedIndices.isEmpty ? null : _confirmSelection,
              style: TextButton.styleFrom(
                backgroundColor: _selectedIndices.isEmpty
                    ? Colors.white12
                    : const Color(0xFFFF2D55),
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              ),
              child: Text(
                'Listo (\${_selectedIndices.length})',
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            child: TextField(
              controller: _titleController,
              maxLength: 18,
              style: const TextStyle(color: Colors.white, fontSize: 14),
              decoration: InputDecoration(
                labelText: 'Nombre del destacado',
                labelStyle: const TextStyle(color: Colors.white54),
                counterText: '',
                filled: true,
                fillColor: const Color(0xFF1B1B1E),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: Colors.white12),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: Colors.white12),
                ),
              ),
            ),
          ),
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.all(2),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                crossAxisSpacing: 2,
                mainAxisSpacing: 2,
                childAspectRatio: 9 / 16,
              ),
              itemCount: _galleryUrls.length,
              itemBuilder: (context, index) {
                final int order = _selectedIndices.indexOf(index);
                final bool isSelected = order != -1;
                return GestureDetector(
                  onTap: () => _toggleIndex(index),
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      Image.network(_galleryUrls[index], fit: BoxFit.cover),
                      if (isSelected)
                        Container(
                          decoration: BoxDecoration(
                            border: Border.all(
                              color: const Color(0xFFFF2D55),
                              width: 2.5,
                            ),
                            color: Colors.black26,
                          ),
                        ),
                      Positioned(
                        top: 6,
                        right: 6,
                        child: CircleAvatar(
                          radius: 12,
                          backgroundColor: isSelected
                              ? const Color(0xFFFF2D55)
                              : Colors.black45,
                          child: Text(
                            isSelected ? '\${order + 1}' : '',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 11,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}`,
  },
  {
    id: 'story_viewer_screen',
    path: 'lib/screens/story_viewer_screen.dart',
    phase: 'Perfil · StoryViewerScreen',
    language: 'dart',
    summary:
      'Visor full-screen de Stories/Destacados con barra de progreso segmentada, tap izquierda/derecha, reacciones y barra inferior de respuesta.',
    code: `import 'dart:async';
import 'package:flutter/material.dart';

class StoryViewerScreen extends StatefulWidget {
  final String title;
  final String coverUrl;
  final List<String> slides;

  const StoryViewerScreen({
    super.key,
    required this.title,
    required this.coverUrl,
    required this.slides,
  });

  @override
  State<StoryViewerScreen> createState() => _StoryViewerScreenState();
}

class _StoryViewerScreenState extends State<StoryViewerScreen> {
  int _currentIndex = 0;
  bool _liked = false;
  Timer? _autoTimer;
  final TextEditingController _replyController = TextEditingController();

  List<String> get _safeSlides =>
      widget.slides.isNotEmpty ? widget.slides : [widget.coverUrl];

  @override
  void initState() {
    super.initState();
    _startTimer();
  }

  void _startTimer() {
    _autoTimer?.cancel();
    _autoTimer = Timer(const Duration(seconds: 5), () {
      if (!mounted) return;
      if (_currentIndex < _safeSlides.length - 1) {
        setState(() => _currentIndex++);
        _startTimer();
      } else {
        Navigator.pop(context);
      }
    });
  }

  void _handleTap(TapUpDetails details, double width) {
    if (details.localPosition.dx < width * 0.35) {
      setState(() => _currentIndex = (_currentIndex - 1).clamp(0, _safeSlides.length - 1));
      _startTimer();
    } else if (_currentIndex < _safeSlides.length - 1) {
      setState(() => _currentIndex++);
      _startTimer();
    } else {
      Navigator.pop(context);
    }
  }

  @override
  void dispose() {
    _autoTimer?.cancel();
    _replyController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final double width = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Stack(
          fit: StackFit.expand,
          children: [
            GestureDetector(
              onTapUp: (details) => _handleTap(details, width),
              child: Image.network(
                _safeSlides[_currentIndex],
                fit: BoxFit.cover,
              ),
            ),
            Positioned(
              top: 12,
              left: 12,
              right: 12,
              child: Column(
                children: [
                  Row(
                    children: List.generate(_safeSlides.length, (idx) {
                      return Expanded(
                        child: Container(
                          height: 2.5,
                          margin: const EdgeInsets.symmetric(horizontal: 2),
                          decoration: BoxDecoration(
                            color: idx <= _currentIndex
                                ? Colors.white
                                : Colors.white30,
                            borderRadius: BorderRadius.circular(2),
                          ),
                        ),
                      );
                    }),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      CircleAvatar(
                        radius: 16,
                        backgroundImage: NetworkImage(widget.coverUrl),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          widget.title,
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.close, color: Colors.white),
                        onPressed: () => Navigator.pop(context),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Positioned(
              left: 12,
              right: 12,
              bottom: 12,
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _replyController,
                      style: const TextStyle(color: Colors.white),
                      decoration: InputDecoration(
                        hintText: 'Enviar mensaje...',
                        hintStyle: const TextStyle(color: Colors.white60),
                        filled: true,
                        fillColor: Colors.white12,
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 10,
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(24),
                          borderSide: BorderSide.none,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  IconButton(
                    icon: Icon(
                      _liked ? Icons.favorite : Icons.favorite_border,
                      color: _liked ? const Color(0xFFFF2D55) : Colors.white,
                    ),
                    onPressed: () => setState(() => _liked = !_liked),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}`,
  },
  {
    id: 'qr_profile_screen',
    path: 'lib/screens/qr_profile_screen.dart',
    phase: 'Perfil · QrProfileScreen (Código QR + Compartir + Escáner)',
    language: 'dart',
    summary:
      'Pantalla QR con fondo degradado azul oscuro, tarjeta blanca con avatar superpuesto, QrImageView, copiar/compartir enlace y guía de integración con mobile_scanner.',
    code: `import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:share_plus/share_plus.dart';
import 'qr_scanner_screen.dart';

class QrProfileScreen extends StatelessWidget {
  final String nombreUsuario;
  final String arroba;
  final String avatarUrl;

  const QrProfileScreen({
    super.key,
    required this.nombreUsuario,
    required this.arroba,
    required this.avatarUrl,
  });

  String get _cleanHandle => arroba.startsWith('@') ? arroba : '@\$arroba';

  String get _profileUrl => 'https://viroklipz.app/profile/\$_cleanHandle';

  Future<void> _copyLink(BuildContext context) async {
    await Clipboard.setData(ClipboardData(text: _profileUrl));
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        behavior: SnackBarBehavior.floating,
        content: Row(
          children: [
            Icon(Icons.check_circle_outline, color: Colors.greenAccent, size: 20),
            SizedBox(width: 10),
            Expanded(
              child: Text('Enlace copiado al portapapeles'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _shareLink() async {
    await Share.share(
      '¡Mira mi perfil en Viroklipz! \$_profileUrl',
      subject: 'Perfil de \$nombreUsuario en Viroklipz',
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Código QR',
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.qr_code_scanner, color: Colors.white),
            tooltip: 'Escanear código QR',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const QrScannerScreen(),
                ),
              );
            },
          ),
        ],
      ),
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFF061026),
              Color(0xFF0D2558),
              Color(0xFF091736),
            ],
          ),
        ),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // Espacio superior para que el avatar superpuesto no se salga de los límites
                  const SizedBox(height: 40),

                  // Tarjeta blanca adaptada al contenido
                  Stack(
                    clipBehavior: Clip.none,
                    alignment: Alignment.topCenter,
                    children: [
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(24.0),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(24),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.35),
                              blurRadius: 28,
                              offset: const Offset(0, 14),
                            ),
                          ],
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            // Compensación interna para la mitad inferior del avatar
                            const SizedBox(height: 24),
                            Text(
                              nombreUsuario,
                              style: const TextStyle(
                                color: Colors.black,
                                fontSize: 22,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              _cleanHandle,
                              style: TextStyle(
                                color: Colors.grey[600],
                                fontSize: 14,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            const SizedBox(height: 16),

                            // Generador de Código QR con tamaño limitado y padding
                            Container(
                              padding: const EdgeInsets.all(14),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(18),
                                border: Border.all(color: Colors.grey[200]!),
                              ),
                              child: QrImageView(
                                data: _profileUrl,
                                version: QrVersions.auto,
                                size: 220,
                                backgroundColor: Colors.white,
                                eyeStyle: const QrEyeStyle(
                                  eyeShape: QrEyeShape.square,
                                  color: Color(0xFF0A1329),
                                ),
                                dataModuleStyle: const QrDataModuleStyle(
                                  dataModuleShape: QrDataModuleShape.square,
                                  color: Color(0xFF0A1329),
                                ),
                              ),
                            ),

                            const SizedBox(height: 16),
                            const Divider(height: 1, color: Color(0xFFEEEEEE)),
                            const SizedBox(height: 12),

                            // Logo de Viroklipz al pie de la tarjeta
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                  width: 24,
                                  height: 24,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(7),
                                    gradient: const LinearGradient(
                                      colors: [
                                        Color(0xFF25F4EE),
                                        Color(0xFFFF2D55),
                                      ],
                                    ),
                                  ),
                                  child: const Icon(
                                    Icons.music_note_rounded,
                                    color: Colors.white,
                                    size: 15,
                                  ),
                                ),
                                const SizedBox(width: 8),
                                const Text(
                                  'Viroklipz',
                                  style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 16,
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: -0.3,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),

                      // Avatar circular superpuesto dentro de los límites
                      Positioned(
                        top: -38,
                        child: Container(
                          padding: const EdgeInsets.all(4),
                          decoration: const BoxDecoration(
                            color: Colors.white,
                            shape: BoxShape.circle,
                          ),
                          child: CircleAvatar(
                            radius: 34,
                            backgroundColor: Colors.grey[200],
                            backgroundImage: NetworkImage(avatarUrl),
                          ),
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 20),

                  // Botones Copiar enlace & Compartir enlace lado a lado
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () => _copyLink(context),
                          icon: const Icon(Icons.link, size: 18),
                          label: const Text(
                            'Copiar enlace',
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.white,
                            foregroundColor: Colors.black,
                            elevation: 2,
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: _shareLink,
                          icon: const Icon(Icons.share_outlined, size: 18),
                          label: const Text(
                            'Compartir enlace',
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.white,
                            foregroundColor: Colors.black,
                            elevation: 2,
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}`,
  },
  {
    id: 'qr_scanner_screen',
    path: 'lib/screens/qr_scanner_screen.dart',
    phase: 'Perfil · QrScannerScreen (MobileScanner + Overlay + Flash)',
    language: 'dart',
    summary:
      'Pantalla negra a pantalla completa con MobileScanner en vivo, overlay transparente con esquinas blancas/marca, botón X superior izquierdo, linterna inferior y extracción de @usuario desde la URL.',
    code: `import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'profile_screen.dart';

class QrScannerScreen extends StatefulWidget {
  const QrScannerScreen({super.key});

  @override
  State<QrScannerScreen> createState() => _QrScannerScreenState();
}

class _QrScannerScreenState extends State<QrScannerScreen> {
  final MobileScannerController controller = MobileScannerController(
    detectionSpeed: DetectionSpeed.noDuplicates,
  );

  bool _isProcessing = false;
  bool _isTorchOn = false;

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  /// Extrae el nombre de usuario (ej. "@mateo") de una URL tipo
  /// https://viroklipz.app/profile/@mateo
  String _extractUsername(String rawValue) {
    final trimmed = rawValue.trim();
    final Uri? uri = Uri.tryParse(trimmed);

    if (uri != null && uri.pathSegments.isNotEmpty) {
      final profileIdx = uri.pathSegments.indexOf('profile');
      String candidate;
      if (profileIdx != -1 && profileIdx + 1 < uri.pathSegments.length) {
        candidate = uri.pathSegments[profileIdx + 1];
      } else {
        candidate = uri.pathSegments.last;
      }

      if (candidate.isNotEmpty) {
        return candidate.startsWith('@') ? candidate : '@\$candidate';
      }
    }

    return trimmed.startsWith('@') ? trimmed : '@\$trimmed';
  }

  Future<void> _onDetect(BarcodeCapture capture) async {
    if (_isProcessing) return;

    final String? rawValue = capture.barcodes.firstOrNull?.rawValue;
    if (rawValue == null || rawValue.trim().isEmpty) return;

    _isProcessing = true;
    await controller.stop();

    final String username = _extractUsername(rawValue);
    if (!mounted) return;

    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => ProfileScreen(
          embeddedInMainShell: false,
          username: username,
        ),
      ),
    );
  }

  Future<void> _toggleTorch() async {
    try {
      await controller.toggleTorch();
      if (!mounted) return;
      setState(() {
        _isTorchOn = !_isTorchOn;
      });
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          behavior: SnackBarBehavior.floating,
          content: Text('Linterna no disponible en este dispositivo'),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    const double scanAreaSize = 250;

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          // 1. Cámara en vivo con MobileScanner
          MobileScanner(
            controller: controller,
            onDetect: _onDetect,
          ),

          // 2. Overlay oscuro con recorte transparente central y bordes
          CustomPaint(
            painter: _ScannerOverlayPainter(
              scanAreaSize: scanAreaSize,
              borderRadius: 20,
              cornerColor: Colors.white,
            ),
          ),

          // 3. Controles superiores, texto guía y linterna inferior
          SafeArea(
            child: Column(
              children: [
                // Botón "X" en la esquina superior izquierda para cancelar
                Align(
                  alignment: Alignment.topLeft,
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: IconButton(
                      onPressed: () => Navigator.of(context).pop(),
                      style: IconButton.styleFrom(
                        backgroundColor: Colors.black.withValues(alpha: 0.45),
                      ),
                      icon: const Icon(
                        Icons.close_rounded,
                        color: Colors.white,
                        size: 26,
                      ),
                    ),
                  ),
                ),

                const Spacer(),

                // Texto guía arriba del recuadro de escaneo
                const Text(
                  'Escanea el código QR de un amigo',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    shadows: [
                      Shadow(color: Colors.black54, blurRadius: 8),
                    ],
                  ),
                ),
                const SizedBox(height: 22),

                // Espacio reservado del recuadro transparente
                const SizedBox(
                  width: scanAreaSize,
                  height: scanAreaSize,
                ),

                const Spacer(),

                // Botón de linterna (flash) en la parte inferior
                Padding(
                  padding: const EdgeInsets.only(bottom: 36),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        onPressed: _toggleTorch,
                        iconSize: 28,
                        padding: const EdgeInsets.all(14),
                        style: IconButton.styleFrom(
                          backgroundColor: _isTorchOn
                              ? Colors.amber.withValues(alpha: 0.2)
                              : const Color(0xFF27272A).withValues(alpha: 0.8),
                          side: BorderSide(
                            color: _isTorchOn
                                ? Colors.amber
                                : Colors.white.withValues(alpha: 0.25),
                            width: _isTorchOn ? 1.5 : 1,
                          ),
                        ),
                        icon: Icon(
                          _isTorchOn
                              ? Icons.flashlight_on_rounded
                              : Icons.flashlight_off_rounded,
                          color: _isTorchOn ? Colors.amber : Colors.white,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        _isTorchOn ? 'Linterna activada' : 'Linterna',
                        style: TextStyle(
                          color: _isTorchOn ? Colors.amber : Colors.white70,
                          fontSize: 12,
                          fontWeight:
                              _isTorchOn ? FontWeight.w600 : FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ScannerOverlayPainter extends CustomPainter {
  final double scanAreaSize;
  final double borderRadius;
  final Color cornerColor;

  _ScannerOverlayPainter({
    required this.scanAreaSize,
    required this.borderRadius,
    required this.cornerColor,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final Rect fullRect = Offset.zero & size;
    final Rect scanRect = Rect.fromCenter(
      center: Offset(size.width / 2, size.height / 2),
      width: scanAreaSize,
      height: scanAreaSize,
    );
    final RRect scanRRect = RRect.fromRectAndRadius(
      scanRect,
      Radius.circular(borderRadius),
    );

    // Oscurece el resto de la pantalla dejando el recuadro central transparente
    final Path overlayPath = Path()
      ..fillType = PathFillType.evenOdd
      ..addRect(fullRect)
      ..addRRect(scanRRect);

    canvas.drawPath(
      overlayPath,
      Paint()..color = Colors.black.withValues(alpha: 0.62),
    );

    // Borde sutil completo
    canvas.drawRRect(
      scanRRect,
      Paint()
        ..color = Colors.white.withValues(alpha: 0.25)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.2,
    );

    // Esquinas blancas destacadas
    final Paint cornerPaint = Paint()
      ..color = cornerColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = 4
      ..strokeCap = StrokeCap.round;

    const double cornerLen = 28;
    final double left = scanRect.left;
    final double top = scanRect.top;
    final double right = scanRect.right;
    final double bottom = scanRect.bottom;

    // Arriba-izquierda
    canvas.drawPath(
      Path()
        ..moveTo(left, top + cornerLen)
        ..lineTo(left, top + borderRadius)
        ..quadraticBezierTo(left, top, left + borderRadius, top)
        ..lineTo(left + cornerLen, top),
      cornerPaint,
    );
    // Arriba-derecha
    canvas.drawPath(
      Path()
        ..moveTo(right - cornerLen, top)
        ..lineTo(right - borderRadius, top)
        ..quadraticBezierTo(right, top, right, top + borderRadius)
        ..lineTo(right, top + cornerLen),
      cornerPaint,
    );
    // Abajo-izquierda
    canvas.drawPath(
      Path()
        ..moveTo(left, bottom - cornerLen)
        ..lineTo(left, bottom - borderRadius)
        ..quadraticBezierTo(left, bottom, left + borderRadius, bottom)
        ..lineTo(left + cornerLen, bottom),
      cornerPaint,
    );
    // Abajo-derecha
    canvas.drawPath(
      Path()
        ..moveTo(right - cornerLen, bottom)
        ..lineTo(right - borderRadius, bottom)
        ..quadraticBezierTo(right, bottom, right, bottom - borderRadius)
        ..lineTo(right, bottom - cornerLen),
      cornerPaint,
    );
  }

  @override
  bool shouldRepaint(covariant _ScannerOverlayPainter oldDelegate) {
    return oldDelegate.scanAreaSize != scanAreaSize ||
        oldDelegate.borderRadius != borderRadius ||
        oldDelegate.cornerColor != cornerColor;
  }
}`,
  },
  {
    id: 'activity_center_screen',
    path: 'lib/screens/activity_center_screen.dart',
    phase: 'Perfil · ActivityCenterScreen (Dark Mode)',
    language: 'dart',
    summary:
      'Pantalla Centro de actividades en Dark Mode (#121212) con AppBar, ícono de configuración y ListView con los 7 historiales de actividad.',
    code: `import 'package:flutter/material.dart';
import 'account_history_screen.dart';
import 'ad_activity_history_screen.dart';
import 'comment_history_screen.dart';
import 'content_reuse_history_screen.dart';
import 'mention_history_screen.dart';
import 'search_history_screen.dart';
import 'video_history_screen.dart';

class ActivityCenterScreen extends StatelessWidget {
  const ActivityCenterScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF121212),
        foregroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        centerTitle: true,
        title: const Text(
          'Centro de actividades',
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings_outlined),
            onPressed: () {},
          ),
        ],
      ),
      body: ListView(
        children: [
          _buildMenuItem(
            context: context,
            leading: const Icon(
              Icons.play_circle_outline,
              color: Colors.white70,
              size: 24,
            ),
            title: 'Historial de videos vistos',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const VideoHistoryScreen(),
                ),
              );
            },
          ),
          _buildMenuItem(
            context: context,
            leading: const Icon(
              Icons.chat_bubble_outline,
              color: Colors.white70,
              size: 22,
            ),
            title: 'Historial de comentarios',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const CommentHistoryScreen(),
                ),
              );
            },
          ),
          _buildMenuItem(
            context: context,
            leading: const Icon(
              Icons.search,
              color: Colors.white70,
              size: 24,
            ),
            title: 'Historial de búsqueda',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const SearchHistoryScreen(),
                ),
              );
            },
          ),
          _buildMenuItem(
            context: context,
            leading: Container(
              width: 24,
              height: 20,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                border: Border.all(color: Colors.white70, width: 1.5),
                borderRadius: BorderRadius.circular(4),
              ),
              child: const Text(
                'AD',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 10,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
            title: 'Historial de actividad publicitaria',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const AdActivityHistoryScreen(),
                ),
              );
            },
          ),
          _buildMenuItem(
            context: context,
            leading: const Icon(
              Icons.alternate_email,
              color: Colors.white70,
              size: 22,
            ),
            title: 'Historial de menciones',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const MentionHistoryScreen(),
                ),
              );
            },
          ),
          _buildMenuItem(
            context: context,
            leading: const Icon(
              Icons.person_outline,
              color: Colors.white70,
              size: 24,
            ),
            title: 'Historial de la cuenta',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const AccountHistoryScreen(),
                ),
              );
            },
          ),
          _buildMenuItem(
            context: context,
            leading: const Icon(
              Icons.repeat_rounded,
              color: Colors.white70,
              size: 24,
            ),
            title: 'Historial de reutilización de contenido',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const ContentReuseHistoryScreen(),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildMenuItem({
    required BuildContext context,
    required Widget leading,
    required String title,
    required VoidCallback onTap,
  }) {
    return ListTile(
      leading: SizedBox(width: 28, child: Center(child: leading)),
      title: Text(
        title,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 15,
          fontWeight: FontWeight.w500,
        ),
      ),
      trailing: const Icon(Icons.chevron_right, color: Colors.white38),
      onTap: onTap,
    );
  }
}`,
  },
  {
    id: 'video_history_screen',
    path: 'lib/screens/video_history_screen.dart',
    phase: 'Perfil · VideoHistoryScreen + Bottom Sheet Filtro por Fecha',
    language: 'dart',
    summary:
      'Historial de videos vistos en Dark Mode con Chip "Filtrar por fecha ⌄", sección "Hoy", GridView.builder de 3 columnas con Play + vistas y showModalBottomSheet con RadioListTile.',
    code: `import 'package:flutter/material.dart';

class VideoHistoryScreen extends StatefulWidget {
  const VideoHistoryScreen({super.key});

  @override
  State<VideoHistoryScreen> createState() => _VideoHistoryScreenState();
}

class _VideoHistoryScreenState extends State<VideoHistoryScreen> {
  String _selectedDateFilter = 'Cualquier fecha';

  final List<String> _dateOptions = const [
    'Cualquier fecha',
    'Ayer',
    'Semana pasada',
    'Último mes',
    'Rango de fechas',
  ];

  final List<Map<String, String>> _watchedVideos = const [
    {
      'thumb':
          'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=400&auto=format&fit=crop',
      'views': '1.6M',
    },
    {
      'thumb':
          'https://images.unsplash.com/photo-1561361513-2d000a50f0dc?w=400&auto=format&fit=crop',
      'views': '842K',
    },
    {
      'thumb':
          'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=400&auto=format&fit=crop',
      'views': '215K',
    },
    {
      'thumb':
          'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=400&auto=format&fit=crop',
      'views': '94.2K',
    },
    {
      'thumb':
          'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=400&auto=format&fit=crop',
      'views': '310K',
    },
    {
      'thumb':
          'https://images.unsplash.com/photo-1547447134-cd3f5c716030?w=400&auto=format&fit=crop',
      'views': '1.1M',
    },
    {
      'thumb':
          'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=400&auto=format&fit=crop',
      'views': '56.8K',
    },
    {
      'thumb':
          'https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?w=400&auto=format&fit=crop',
      'views': '429K',
    },
    {
      'thumb':
          'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=400&auto=format&fit=crop',
      'views': '712K',
    },
  ];

  void _openDateFilterSheet() {
    String tempSelected = _selectedDateFilter;

    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF1C1C1E),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
      ),
      builder: (BuildContext sheetContext) {
        return StatefulBuilder(
          builder: (BuildContext context, StateSetter setSheetState) {
            return SafeArea(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const SizedBox(height: 8),
                  Container(
                    width: 36,
                    height: 4,
                    decoration: BoxDecoration(
                      color: Colors.white24,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 8),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        TextButton(
                          onPressed: () => Navigator.pop(sheetContext),
                          child: const Text(
                            'Cancelar',
                            style: TextStyle(color: Colors.white70),
                          ),
                        ),
                        const Text(
                          'Filtrar por fecha',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        TextButton(
                          onPressed: () {
                            setState(() => _selectedDateFilter = tempSelected);
                            Navigator.pop(sheetContext);
                          },
                          child: const Text(
                            'Aplicar',
                            style: TextStyle(
                              color: Color(0xFFFF2D55),
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const Divider(height: 1, color: Colors.white12),
                  ..._dateOptions.map((option) {
                    final bool isRange = option == 'Rango de fechas';
                    return RadioListTile<String>(
                      value: option,
                      groupValue: tempSelected,
                      activeColor: const Color(0xFFFF2D55),
                      onChanged: (value) {
                        if (value != null) {
                          setSheetState(() => tempSelected = value);
                        }
                      },
                      title: Text(
                        option,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                        ),
                      ),
                      secondary: isRange
                          ? const Icon(
                              Icons.chevron_right,
                              color: Colors.white54,
                            )
                          : null,
                    );
                  }),
                  const SizedBox(height: 8),
                ],
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF121212),
        foregroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Historial de videos vistos',
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () {},
          ),
          IconButton(
            icon: const Icon(Icons.more_vert),
            onPressed: () {},
          ),
        ],
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Chip "Filtrar por fecha ⌄"
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
            child: ActionChip(
              onPressed: _openDateFilterSheet,
              backgroundColor: const Color(0xFF1E1E22),
              side: const BorderSide(color: Colors.white12),
              label: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    _selectedDateFilter == 'Cualquier fecha'
                        ? 'Filtrar por fecha'
                        : _selectedDateFilter,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(width: 4),
                  const Icon(
                    Icons.keyboard_arrow_down,
                    color: Colors.white70,
                    size: 18,
                  ),
                ],
              ),
            ),
          ),

          // Título de sección "Hoy"
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 10, 12, 8),
            child: Text(
              _selectedDateFilter == 'Cualquier fecha'
                  ? 'Hoy'
                  : _selectedDateFilter,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 15,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),

          // GridView.builder de 3 columnas
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 6),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                crossAxisSpacing: 3,
                mainAxisSpacing: 3,
                childAspectRatio: 9 / 16,
              ),
              itemCount: _watchedVideos.length,
              itemBuilder: (context, index) {
                final item = _watchedVideos[index];
                return ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      Image.network(item['thumb']!, fit: BoxFit.cover),
                      Positioned(
                        left: 6,
                        bottom: 6,
                        child: Row(
                          children: [
                            const Icon(
                              Icons.play_arrow_rounded,
                              color: Colors.white,
                              size: 15,
                            ),
                            const SizedBox(width: 2),
                            Text(
                              item['views']!,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                                shadows: [
                                  Shadow(
                                    color: Colors.black54,
                                    blurRadius: 4,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}`,
  },
  {
    id: 'comment_history_screen',
    path: 'lib/screens/comment_history_screen.dart',
    phase: 'Perfil · CommentHistoryScreen + Bottom Sheet Ordenar por',
    language: 'dart',
    summary:
      'Historial de comentarios en Dark Mode (#121212) con Chip dinámico de ordenamiento, ListView.builder (avatar, Eloy, comentario + fecha, miniatura cuadrada) y showModalBottomSheet con RadioListTile.',
    code: `import 'package:flutter/material.dart';

class CommentHistoryScreen extends StatefulWidget {
  const CommentHistoryScreen({super.key});

  @override
  State<CommentHistoryScreen> createState() => _CommentHistoryScreenState();
}

class _CommentHistoryScreenState extends State<CommentHistoryScreen> {
  String _selectedOrder = 'De más recientes a más antiguos';

  final List<String> _orderOptions = const [
    'De más recientes a más antiguos',
    'De más antiguos a más recientes',
  ];

  final List<Map<String, String>> _comments = const [
    {
      'user': 'Eloy',
      'avatar':
          'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop',
      'comment': '[Sticker]',
      'date': '13 nov',
      'videoThumb':
          'https://images.unsplash.com/photo-1561361513-2d000a50f0dc?w=300&auto=format&fit=crop',
    },
    {
      'user': 'Eloy',
      'avatar':
          'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop',
      'comment': '¡Qué transición tan brutal! 🔥',
      'date': '11 nov',
      'videoThumb':
          'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=300&auto=format&fit=crop',
    },
    {
      'user': 'Eloy',
      'avatar':
          'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop',
      'comment': '¿Cómo se llama este audio?',
      'date': '8 nov',
      'videoThumb':
          'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=300&auto=format&fit=crop',
    },
    {
      'user': 'Eloy',
      'avatar':
          'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop',
      'comment': 'Guardado para grabarlo el finde 🙌',
      'date': '4 nov',
      'videoThumb':
          'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=300&auto=format&fit=crop',
    },
    {
      'user': 'Eloy',
      'avatar':
          'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop',
      'comment': 'Me encantó la iluminación 35mm 📸',
      'date': '29 oct',
      'videoThumb':
          'https://images.unsplash.com/photo-1547447134-cd3f5c716030?w=300&auto=format&fit=crop',
    },
  ];

  void _openSortBottomSheet() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF1C1C1E),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
      ),
      builder: (BuildContext sheetContext) {
        return StatefulBuilder(
          builder: (BuildContext context, StateSetter setSheetState) {
            return SafeArea(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const SizedBox(height: 10),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        const Center(
                          child: Text(
                            'Ordenar por',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        Align(
                          alignment: Alignment.centerRight,
                          child: IconButton(
                            icon: const Icon(Icons.close, color: Colors.white70),
                            onPressed: () => Navigator.pop(sheetContext),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const Divider(height: 1, color: Colors.white12),
                  ..._orderOptions.map((option) {
                    return RadioListTile<String>(
                      value: option,
                      groupValue: _selectedOrder,
                      activeColor: const Color(0xFFFF2D55),
                      onChanged: (value) {
                        if (value == null) return;
                        setSheetState(() {});
                        setState(() => _selectedOrder = value);
                        Navigator.pop(sheetContext);
                      },
                      title: Text(
                        option,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                        ),
                      ),
                    );
                  }),
                  const SizedBox(height: 10),
                ],
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final List<Map<String, String>> orderedComments =
        _selectedOrder == 'De más recientes a más antiguos'
            ? _comments
            : _comments.reversed.toList();

    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF121212),
        foregroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        centerTitle: true,
        title: const Text(
          'Historial de comentarios',
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Chip / píldora alineado a la izquierda
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 8),
            child: ActionChip(
              onPressed: _openSortBottomSheet,
              backgroundColor: const Color(0xFF1E1E22),
              side: const BorderSide(color: Colors.white12),
              shape: const StadiumBorder(),
              label: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    _selectedOrder,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(width: 4),
                  const Icon(
                    Icons.keyboard_arrow_down,
                    color: Colors.white70,
                    size: 18,
                  ),
                ],
              ),
            ),
          ),

          // Lista de comentarios
          Expanded(
            child: ListView.builder(
              itemCount: orderedComments.length,
              itemBuilder: (context, index) {
                final item = orderedComments[index];
                return Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 10,
                  ),
                  child: Row(
                    children: [
                      CircleAvatar(
                        radius: 20,
                        backgroundColor: Colors.grey[800],
                        backgroundImage: NetworkImage(item['avatar']!),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              item['user']!,
                              style: const TextStyle(
                                color: Colors.grey,
                                fontSize: 12,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Row(
                              children: [
                                Flexible(
                                  child: Text(
                                    item['comment']!,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 14,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Text(
                                  item['date']!,
                                  style: TextStyle(
                                    color: Colors.grey[400],
                                    fontSize: 12,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 12),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: Image.network(
                          item['videoThumb']!,
                          width: 48,
                          height: 48,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}`,
  },
  {
    id: 'search_history_screen',
    path: 'lib/screens/search_history_screen.dart',
    phase: 'Perfil · SearchHistoryScreen (Dark Mode)',
    language: 'dart',
    summary:
      'Historial de búsqueda en Dark Mode (#121212) con botón Seleccionar, agrupación por fechas ("Ayer", "12 de noviembre"), lupa y hora en gris.',
    code: `import 'package:flutter/material.dart';

class SearchHistoryScreen extends StatelessWidget {
  const SearchHistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> sections = [
      {
        'date': 'Ayer',
        'items': [
          {'query': 'mi próximo auto', 'time': '10:31 p. m.'},
          {'query': 'transiciones rápidas video vertical', 'time': '7:14 p. m.'},
        ],
      },
      {
        'date': '12 de noviembre',
        'items': [
          {'query': 'beats lo-fi sin copyright', 'time': '4:05 p. m.'},
          {'query': 'mejores cámaras 4k para vlogs', 'time': '11:20 a. m.'},
        ],
      },
    ];

    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF121212),
        foregroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Historial de búsqueda',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        actions: [
          TextButton(
            onPressed: () {},
            child: const Text(
              'Seleccionar',
              style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
            ),
          ),
        ],
      ),
      body: ListView.builder(
        itemCount: sections.length,
        itemBuilder: (context, sectionIndex) {
          final section = sections[sectionIndex];
          final items = section['items'] as List<Map<String, String>>;
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 6),
                child: Text(
                  section['date'] as String,
                  style: const TextStyle(
                    color: Colors.grey,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              ...items.map((item) => Column(
                    children: [
                      ListTile(
                        leading: const Icon(Icons.search, color: Colors.grey),
                        title: Text(
                          item['query']!,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 14,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        subtitle: Text(
                          item['time']!,
                          style: const TextStyle(
                            color: Colors.grey,
                            fontSize: 12,
                          ),
                        ),
                      ),
                      const Divider(height: 1, color: Colors.white10),
                    ],
                  )),
            ],
          );
        },
      ),
    );
  }
}`,
  },
  {
    id: 'ad_activity_history_screen',
    path: 'lib/screens/ad_activity_history_screen.dart',
    phase: 'Perfil · AdActivityHistoryScreen (Dark Mode)',
    language: 'dart',
    summary:
      'Historial de actividad de anuncios en Dark Mode (#121212) con DefaultTabController de 3 pestañas y estados vacíos centrados.',
    code: `import 'package:flutter/material.dart';

class AdActivityHistoryScreen extends StatelessWidget {
  const AdActivityHistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        backgroundColor: const Color(0xFF121212),
        appBar: AppBar(
          backgroundColor: const Color(0xFF121212),
          foregroundColor: Colors.white,
          elevation: 0,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () => Navigator.pop(context),
          ),
          title: const Text(
            'Historial de actividad de anuncios',
            style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
          ),
          bottom: const TabBar(
            indicatorColor: Colors.white,
            labelColor: Colors.white,
            unselectedLabelColor: Colors.grey,
            labelStyle: TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
            tabs: [
              Tab(text: 'Historial de anuncios'),
              Tab(text: 'Historial de enlaces'),
              Tab(text: 'Reseñas de anuncios'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            _buildEmptyState(
              icon: Icons.receipt_long_outlined,
              title: 'No hay historial de anuncios',
              description:
                  'Aquí aparecerán los anuncios que hayas visto o con los que hayas interactuado recientemente en Viroklipz.',
            ),
            _buildEmptyState(
              icon: Icons.link_outlined,
              title: 'No hay historial de enlaces',
              description:
                  'Cuando abras enlaces externos desde promociones patrocinadas, se guardarán aquí.',
            ),
            _buildEmptyState(
              icon: Icons.rate_review_outlined,
              title: 'No hay reseñas de anuncios',
              description:
                  'Tus valoraciones y comentarios sobre anuncios relevantes aparecerán en esta pestaña.',
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState({
    required IconData icon,
    required String title,
    required String description,
  }) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 64, color: Colors.grey[600]),
            const SizedBox(height: 16),
            Text(
              title,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              description,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.grey[400],
                fontSize: 13,
                height: 1.4,
              ),
            ),
          ],
        ),
      ),
    );
  }
}`,
  },
  {
    id: 'mention_history_screen',
    path: 'lib/screens/mention_history_screen.dart',
    phase: 'Perfil · MentionHistoryScreen (Dark Mode)',
    language: 'dart',
    summary:
      'Historial de menciones en Dark Mode (#121212) agrupado por fechas, con avatar redondo, texto "[Nombre] te mencionó en una foto", hora y miniatura derecha.',
    code: `import 'package:flutter/material.dart';

class MentionHistoryScreen extends StatelessWidget {
  const MentionHistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> sections = [
      {
        'date': 'Ayer',
        'items': [
          {
            'name': 'Mateo Cine',
            'avatar':
                'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop',
            'time': '9:18 p. m.',
            'thumb':
                'https://images.unsplash.com/photo-1561361513-2d000a50f0dc?w=200&auto=format&fit=crop',
          },
          {
            'name': 'Valeria Beats',
            'avatar':
                'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&auto=format&fit=crop',
            'time': '3:42 p. m.',
            'thumb':
                'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=200&auto=format&fit=crop',
          },
        ],
      },
      {
        'date': '10 de noviembre',
        'items': [
          {
            'name': 'Sofía Fit',
            'avatar':
                'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=200&auto=format&fit=crop',
            'time': '12:05 p. m.',
            'thumb':
                'https://images.unsplash.com/photo-1547447134-cd3f5c716030?w=200&auto=format&fit=crop',
          },
        ],
      },
    ];

    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF121212),
        foregroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        centerTitle: true,
        title: const Text(
          'Historial de menciones',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
      ),
      body: ListView.builder(
        itemCount: sections.length,
        itemBuilder: (context, sectionIndex) {
          final section = sections[sectionIndex];
          final items = section['items'] as List<Map<String, String>>;
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 6),
                child: Text(
                  section['date'] as String,
                  style: const TextStyle(
                    color: Colors.grey,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              ...items.map((item) => Column(
                    children: [
                      ListTile(
                        leading: CircleAvatar(
                          backgroundImage: NetworkImage(item['avatar']!),
                        ),
                        title: Text(
                          '\${item['name']} te mencionó en una foto',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 14,
                          ),
                        ),
                        subtitle: Text(
                          item['time']!,
                          style: const TextStyle(
                            color: Colors.grey,
                            fontSize: 12,
                          ),
                        ),
                        trailing: ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: Image.network(
                            item['thumb']!,
                            width: 46,
                            height: 46,
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                      const Divider(height: 1, color: Colors.white10),
                    ],
                  )),
            ],
          );
        },
      ),
    );
  }
}`,
  },
  {
    id: 'account_history_screen',
    path: 'lib/screens/account_history_screen.dart',
    phase: 'Perfil · AccountHistoryScreen (Dark Mode)',
    language: 'dart',
    summary:
      'Historial de la cuenta en Dark Mode (#121212) con aviso superior del último año y tarjetas Card oscuras de Inicio de sesión agrupadas por fecha.',
    code: `import 'package:flutter/material.dart';

class AccountHistoryScreen extends StatelessWidget {
  const AccountHistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> sections = [
      {
        'date': 'Hoy',
        'events': [
          {
            'device': 'iPhone 15 Pro',
            'location': 'Madrid, España',
            'time': '10:15 a. m.',
          },
        ],
      },
      {
        'date': '12 de noviembre',
        'events': [
          {
            'device': 'Samsung Galaxy S24',
            'location': 'Barcelona, España',
            'time': '8:47 p. m.',
          },
        ],
      },
      {
        'date': '5 de noviembre',
        'events': [
          {
            'device': 'Navegador Web (macOS)',
            'location': 'Madrid, España',
            'time': '6:12 p. m.',
          },
        ],
      },
    ];

    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF121212),
        foregroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        centerTitle: true,
        title: const Text(
          'Historial de la cuenta',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: const Color(0xFF1E1E22),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.white10),
            ),
            child: const Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.info_outline, color: Colors.grey, size: 18),
                SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'Se mostrará el historial de la cuenta correspondiente al último año. Revisa tus inicios de sesión recientes.',
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 12,
                      height: 1.4,
                    ),
                  ),
                ),
              ],
            ),
          ),
          ...sections.map((section) {
            final events = section['events'] as List<Map<String, String>>;
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 18, bottom: 8),
                  child: Text(
                    section['date'] as String,
                    style: const TextStyle(
                      color: Colors.grey,
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                ...events.map((event) => Card(
                      color: const Color(0xFF1C1C1E),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      margin: const EdgeInsets.only(bottom: 10),
                      child: Padding(
                        padding: const EdgeInsets.all(14),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Icon(
                              Icons.login_rounded,
                              color: Colors.white70,
                              size: 22,
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text(
                                    'Inicio de sesión',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 14,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    'Iniciaste sesión en tu cuenta desde un \${event['device']} ubicado en \${event['location']}.',
                                    style: TextStyle(
                                      color: Colors.grey[300],
                                      fontSize: 13,
                                      height: 1.35,
                                    ),
                                  ),
                                  const SizedBox(height: 6),
                                  Text(
                                    event['time']!,
                                    style: const TextStyle(
                                      color: Colors.grey,
                                      fontSize: 11,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    )),
              ],
            );
          }),
        ],
      ),
    );
  }
}`,
  },
  {
    id: 'content_reuse_history_screen',
    path: 'lib/screens/content_reuse_history_screen.dart',
    phase: 'Perfil · ContentReuseHistoryScreen (Dark Mode)',
    language: 'dart',
    summary:
      'Historial de reutilización de contenido en Dark Mode (#121212) agrupado por fechas, con miniatura izquierda, hashtags, contador de publicaciones y flecha derecha.',
    code: `import 'package:flutter/material.dart';

class ContentReuseHistoryScreen extends StatelessWidget {
  const ContentReuseHistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> sections = [
      {
        'date': 'Esta semana',
        'items': [
          {
            'thumb':
                'https://images.unsplash.com/photo-1561361513-2d000a50f0dc?w=200&auto=format&fit=crop',
            'hashtags': '#desarrollopersonal #gabriel #mentalidad',
            'count': '1 publicación',
          },
          {
            'thumb':
                'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=200&auto=format&fit=crop',
            'hashtags': '#beats #musicaproduccion #studio',
            'count': '3 publicaciones',
          },
        ],
      },
      {
        'date': 'Noviembre',
        'items': [
          {
            'thumb':
                'https://images.unsplash.com/photo-1547447134-cd3f5c716030?w=200&auto=format&fit=crop',
            'hashtags': '#fotografia #35mm #viajes',
            'count': '1 publicación',
          },
        ],
      },
    ];

    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF121212),
        foregroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Historial de reutilización de...',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
      ),
      body: ListView.builder(
        itemCount: sections.length,
        itemBuilder: (context, sectionIndex) {
          final section = sections[sectionIndex];
          final items = section['items'] as List<Map<String, String>>;
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 6),
                child: Text(
                  section['date'] as String,
                  style: const TextStyle(
                    color: Colors.grey,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              ...items.map((item) => Column(
                    children: [
                      ListTile(
                        leading: ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: Image.network(
                            item['thumb']!,
                            width: 44,
                            height: 56,
                            fit: BoxFit.cover,
                          ),
                        ),
                        title: Text(
                          item['hashtags']!,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 14,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        subtitle: Padding(
                          padding: const EdgeInsets.only(top: 4),
                          child: Row(
                            children: [
                              const Icon(
                                Icons.repeat_rounded,
                                color: Colors.grey,
                                size: 15,
                              ),
                              const SizedBox(width: 4),
                              Text(
                                item['count']!,
                                style: const TextStyle(
                                  color: Colors.grey,
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          ),
                        ),
                        trailing: const Icon(
                          Icons.chevron_right,
                          color: Colors.white38,
                        ),
                        onTap: () {},
                      ),
                      const Divider(height: 1, color: Colors.white10),
                    ],
                  )),
            ],
          );
        },
      ),
    );
  }
}`,
  },
  {
    id: 'offline_videos_screen',
    path: 'lib/screens/offline_videos_screen.dart',
    phase: 'Perfil · OfflineVideosScreen (300 Vídeos sin conexión)',
    language: 'dart',
    summary:
      'Feed vertical PageView.builder con 300 objetos VideoPost generados en bucle for, barra superior, barra lateral derecha, info inferior con búsqueda y banner negro fijo de modo offline.',
    code: `import 'package:flutter/material.dart';
import '../models/app_user.dart';
import '../models/video_post.dart';

class OfflineVideosScreen extends StatefulWidget {
  const OfflineVideosScreen({super.key});

  @override
  State<OfflineVideosScreen> createState() => _OfflineVideosScreenState();
}

class _OfflineVideosScreenState extends State<OfflineVideosScreen> {
  final PageController _pageController = PageController();
  late final List<VideoPost> _offlineVideos;
  final Set<int> _likedIndices = {};
  final Set<int> _savedIndices = {};

  static const List<String> _sampleImages = [
    'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=800&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1561361513-2d000a50f0dc?w=800&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=800&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=800&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1547447134-cd3f5c716030?w=800&auto=format&fit=crop',
  ];

  static const List<String> _sampleUsernames = [
    'fugr356',
    'mateo.cine',
    'valeria.flow',
    'lucas.ruta',
    'sofia.beats',
    'diego.35mm',
    'tallermadera',
  ];

  @override
  void initState() {
    super.initState();
    _offlineVideos = _generate300OfflineVideos();
  }

  List<VideoPost> _generate300OfflineVideos() {
    final List<VideoPost> list = [];
    for (int i = 0; i < 300; i++) {
      final String username =
          i == 0 ? 'fugr356' : _sampleUsernames[i % _sampleUsernames.length];
      final String mediaUrl = _sampleImages[i % _sampleImages.length];

      list.add(
        VideoPost(
          id: 'offline_\${i + 1}',
          author: AppUser(
            id: 'offline_author_\$i',
            username: username,
            avatarUrl: mediaUrl,
          ),
          videoUrl: mediaUrl,
          caption:
              '#StressRelief#PopularScience#Tips Construyendo clips sin conexión (#\${i + 1})',
          likes: i == 0 ? 3667 : 540 + ((i * 137) % 9200),
        ),
      );
    }
    return list;
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Column(
        children: [
          // Feed vertical de 300 videos
          Expanded(
            child: Stack(
              children: [
                PageView.builder(
                  controller: _pageController,
                  scrollDirection: Axis.vertical,
                  itemCount: _offlineVideos.length,
                  itemBuilder: (context, index) {
                    final VideoPost post = _offlineVideos[index];
                    final bool isLiked = _likedIndices.contains(index);
                    final bool isSaved = _savedIndices.contains(index);
                    final int displayLikes = post.likes + (isLiked ? 1 : 0);
                    final int displayComments = index == 0 ? 22 : 12 + (index % 90);
                    final int displayBookmarks =
                        (index == 0 ? 487 : 40 + (index % 320)) + (isSaved ? 1 : 0);
                    final int displayShares = index == 0 ? 243 : 18 + (index % 180);

                    return Stack(
                      fit: StackFit.expand,
                      children: [
                        Image.network(
                          post.videoUrl,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => Container(
                            color: const Color(0xFF161618),
                            child: const Icon(
                              Icons.play_circle_outline,
                              color: Colors.white54,
                              size: 64,
                            ),
                          ),
                        ),

                        // Scrim para legibilidad
                        Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: [
                                Colors.black.withOpacity(0.45),
                                Colors.transparent,
                                Colors.black.withOpacity(0.82),
                              ],
                              stops: const [0.0, 0.35, 1.0],
                            ),
                          ),
                        ),

                        // Barra lateral derecha superpuesta
                        Positioned(
                          right: 12,
                          bottom: 18,
                          child: Column(
                            children: [
                              Stack(
                                clipBehavior: Clip.none,
                                alignment: Alignment.bottomCenter,
                                children: [
                                  CircleAvatar(
                                    radius: 22,
                                    backgroundColor: Colors.grey[800],
                                    backgroundImage:
                                        NetworkImage(post.author.avatarUrl),
                                  ),
                                  Positioned(
                                    bottom: -8,
                                    child: Container(
                                      width: 20,
                                      height: 20,
                                      decoration: const BoxDecoration(
                                        color: Color(0xFFFF2D55),
                                        shape: BoxShape.circle,
                                      ),
                                      child: const Icon(
                                        Icons.add,
                                        color: Colors.white,
                                        size: 14,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 22),
                              _buildSideAction(
                                icon: isLiked
                                    ? Icons.favorite
                                    : Icons.favorite_border,
                                color: isLiked
                                    ? const Color(0xFFFF2D55)
                                    : Colors.white,
                                count: '\$displayLikes',
                                onTap: () {
                                  setState(() {
                                    if (isLiked) {
                                      _likedIndices.remove(index);
                                    } else {
                                      _likedIndices.add(index);
                                    }
                                  });
                                },
                              ),
                              const SizedBox(height: 16),
                              _buildSideAction(
                                icon: Icons.chat_bubble_rounded,
                                color: Colors.white,
                                count: '\$displayComments',
                                onTap: () {},
                              ),
                              const SizedBox(height: 16),
                              _buildSideAction(
                                icon: isSaved
                                    ? Icons.bookmark
                                    : Icons.bookmark_border,
                                color: isSaved ? Colors.amber : Colors.white,
                                count: '\$displayBookmarks',
                                onTap: () {
                                  setState(() {
                                    if (isSaved) {
                                      _savedIndices.remove(index);
                                    } else {
                                      _savedIndices.add(index);
                                    }
                                  });
                                },
                              ),
                              const SizedBox(height: 16),
                              _buildSideAction(
                                icon: Icons.reply,
                                color: Colors.white,
                                count: '\$displayShares',
                                onTap: () {},
                              ),
                            ],
                          ),
                        ),

                        // Información inferior izquierda + barra de búsqueda
                        Positioned(
                          left: 14,
                          right: 76,
                          bottom: 14,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Row(
                                children: [
                                  Text(
                                    post.author.username,
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  Text(
                                    index == 0 ? '· 11-05' : '· 11-\${((index + 4) % 28 + 1).toString().padLeft(2, '0')}',
                                    style: const TextStyle(
                                      color: Colors.white70,
                                      fontSize: 12,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 6),
                              Text(
                                post.caption,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 13,
                                ),
                              ),
                              const SizedBox(height: 10),

                              // Barra de búsqueda inferior semi-transparente
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 10,
                                  vertical: 8,
                                ),
                                decoration: BoxDecoration(
                                  color: Colors.black.withOpacity(0.55),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: const Row(
                                  children: [
                                    Icon(
                                      Icons.search,
                                      color: Colors.white70,
                                      size: 16,
                                    ),
                                    SizedBox(width: 6),
                                    Expanded(
                                      child: Text(
                                        'Búsqueda · barcos pequeños de madera >',
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 12,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    );
                  },
                ),

                // Barra superior superpuesta (Atrás y Ajustes)
                Positioned(
                  top: 0,
                  left: 0,
                  right: 0,
                  child: SafeArea(
                    bottom: false,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 4,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          IconButton(
                            icon: const Icon(
                              Icons.arrow_back,
                              color: Colors.white,
                            ),
                            onPressed: () => Navigator.pop(context),
                          ),
                          IconButton(
                            icon: const Icon(
                              Icons.settings_outlined,
                              color: Colors.white,
                            ),
                            onPressed: () {},
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Banner fijo de modo offline (negro puro)
          SafeArea(
            top: false,
            child: Container(
              width: double.infinity,
              color: Colors.black,
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: const Text(
                'Estás mirando vídeos sin conexión',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSideAction({
    required IconData icon,
    required Color color,
    required String count,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Icon(icon, color: color, size: 30),
          const SizedBox(height: 3),
          Text(
            count,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}`,
  },
  {
    id: 'settings_privacy_screen',
    path: 'lib/screens/settings_privacy_screen.dart',
    phase: 'Ajustes · SettingsPrivacyScreen + Cambiar de cuenta',
    language: 'dart',
    summary:
      'Pantalla completa de Ajustes y privacidad en modo oscuro (#121212) con 8 secciones, widget reutilizable, versión de app y Bottom Sheet Cambiar de cuenta.',
    code: `import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/user_account.dart';
import '../providers/auth_provider.dart';
import 'accessibility_settings_screen.dart';
import 'account_settings_screen.dart';
import 'activity_center_screen.dart';
import 'ads_settings_screen.dart';
import 'audience_control_screen.dart';
import 'balance_screen.dart';
import 'blocked_accounts_screen.dart';
import 'get_coins_screen.dart';
import 'clear_space_screen.dart';
import 'comments_settings_screen.dart';
import 'contacts_location_settings_screen.dart';
import 'content_preferences_screen.dart';
import 'data_saver_screen.dart';
import 'direct_messages_settings_screen.dart';
import 'display_settings_screen.dart';
import 'downloads_settings_screen.dart';
import 'family_sync_screen.dart';
import 'help_center_screen.dart';
import 'inbox_settings_screen.dart';
import 'language_settings_screen.dart';
import 'lite_mode_screen.dart';
import 'mentions_settings_screen.dart';
import 'music_settings_screen.dart';
import 'notifications_settings_screen.dart';
import 'offline_videos_screen.dart';
import 'playback_settings_screen.dart';
import 'privacy_audience_bottom_sheet.dart';
import 'privacy_center_screen.dart';
import 'privacy_policy_screen.dart';
import 'private_account_screen.dart';
import 'reuse_content_screen.dart';
import 'security_permissions_screen.dart';
import 'share_profile_bottom_sheet.dart';
import 'switch_account_bottom_sheet.dart';
import 'terms_of_service_screen.dart';
import 'viewers_settings_screen.dart';
import 'wallpaper_settings_screen.dart';
import 'wellbeing_screen.dart';

class SettingsPrivacyScreen extends StatefulWidget {
  const SettingsPrivacyScreen({super.key});

  @override
  State<SettingsPrivacyScreen> createState() => _SettingsPrivacyScreenState();
}

class _SettingsPrivacyScreenState extends State<SettingsPrivacyScreen> {
  String _followingListPrivacy = 'Solo tú';
  String _likedVideosPrivacy = 'Solo tú';

  void _showPlaceholderSnack(String title) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Ajustes: \$title'),
        backgroundColor: const Color(0xFF27272A),
        duration: const Duration(seconds: 1),
      ),
    );
  }

  void _openSwitchAccountSheet() {
    showSwitchAccountBottomSheet(context);
  }

  Future<void> _handleSignOut() async {
    final auth = context.read<AuthProvider>();
    await auth.signOut();
    if (!mounted) return;
    Navigator.pushNamedAndRemoveUntil(context, '/landing', (route) => false);
  }

  void _showDeleteAccountDialog(BuildContext context) {
    final auth = context.read<AuthProvider>();
    final UserAccount? activeUser = auth.currentUser;

    showDialog(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          backgroundColor: const Color(0xFF1E1E1E),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          title: const Text(
            '¿Eliminar cuenta?',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
          ),
          content: const Text(
            'Esta acción es permanente y no se puede deshacer. Perderás todos tus videos, seguidores y mensajes.',
            style: TextStyle(color: Colors.white70, fontSize: 13, height: 1.4),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: Text(
                'Cancelar',
                style: TextStyle(color: Colors.grey[400]),
              ),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFE2C55),
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              onPressed: () async {
                Navigator.pop(dialogContext);
                if (activeUser != null) {
                  await auth.deleteAccount(activeUser);
                } else {
                  await auth.signOut();
                }
                if (!mounted) return;
                Navigator.pushNamedAndRemoveUntil(
                  context,
                  '/landing',
                  (route) => false,
                );
              },
              child: const Text(
                'Eliminar',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final String activeAvatar = auth.currentUser?.avatarUrl ??
        'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop';
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF121212),
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Ajustes y privacidad',
          style: TextStyle(
            color: Colors.white,
            fontSize: 17,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
        children: [
          // 1. Actividad
          _buildSectionHeader('Actividad'),
          _buildSectionCard([
            _buildSettingsItem(
              icon: Icons.folder_copy_outlined,
              title: 'Administrar publicaciones',
              onTap: () => _showPlaceholderSnack('Administrar publicaciones'),
            ),
            _buildSettingsItem(
              icon: Icons.auto_awesome_outlined,
              title: 'Preferencias de contenido',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const ContentPreferencesScreen(),
                  ),
                );
              },
            ),
            _buildSettingsItem(
              icon: Icons.live_tv_outlined,
              title: 'LIVE',
              onTap: () => _showPlaceholderSnack('LIVE'),
            ),
            _buildSettingsItem(
              icon: Icons.notifications_none_outlined,
              title: 'Notificaciones',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const NotificationsSettingsScreen(),
                  ),
                );
              },
            ),
            _buildSettingsItem(
              icon: Icons.hourglass_bottom_outlined,
              title: 'Tiempo y bienestar',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const WellbeingScreen(),
                  ),
                );
              },
            ),
            _buildSettingsItem(
              icon: Icons.family_restroom_outlined,
              title: 'Sincronización familiar',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const FamilySyncScreen(),
                  ),
                );
              },
            ),
          ]),

          // 2. Cuenta
          _buildSectionHeader('Cuenta'),
          _buildSectionCard([
            _buildSettingsItem(
              icon: Icons.person_outline,
              title: 'Cuenta',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const AccountSettingsScreen(),
                  ),
                );
              },
            ),
            _buildSettingsItem(
              icon: Icons.account_balance_wallet_outlined,
              title: 'Saldo',
              trailingText: '0.00 VES',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const BalanceScreen(),
                  ),
                );
              },
            ),
            _buildSettingsItem(
              icon: Icons.monetization_on_outlined,
              title: 'Obtener Monedas',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const GetCoinsScreen(),
                  ),
                );
              },
            ),
            _buildSettingsItem(
              icon: Icons.verified_user_outlined,
              title: 'Seguridad y permisos',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const SecurityPermissionsScreen(),
                  ),
                );
              },
            ),
            _buildSettingsItem(
              icon: Icons.share_outlined,
              title: 'Compartir el perfil',
              onTap: () => showShareProfileBottomSheet(context),
            ),
          ]),

          // 3. Visibilidad
          _buildSectionHeader('Visibilidad'),
          _buildSectionCard([
            _buildSettingsItem(
              icon: Icons.lock_outline,
              title: 'Cuenta privada',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const PrivateAccountScreen(),
                  ),
                );
              },
            ),
            _buildSettingsItem(
              icon: Icons.block_outlined,
              title: 'Cuentas bloqueadas',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const BlockedAccountsScreen(),
                  ),
                );
              },
            ),
          ]),

          // 4. Interacciones
          _buildSectionHeader('Interacciones'),
          _buildSectionCard([
            _buildSettingsItem(
              icon: Icons.comment_outlined,
              title: 'Comentarios',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const CommentsSettingsScreen(),
                  ),
                );
              },
            ),
            _buildSettingsItem(
              icon: Icons.alternate_email,
              title: 'Menciones',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const MentionsSettingsScreen(),
                  ),
                );
              },
            ),
            _buildSettingsItem(
              icon: Icons.send_outlined,
              title: 'Mensajes directos',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const DirectMessagesSettingsScreen(),
                  ),
                );
              },
            ),
            _buildSettingsItem(
              icon: Icons.repeat_rounded,
              title: 'Reutilizar contenido',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const ReuseContentScreen(),
                  ),
                );
              },
            ),
            _buildSettingsItem(
              icon: Icons.download_outlined,
              title: 'Descargas',
              trailingText: 'Activado',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const DownloadsSettingsScreen(),
                  ),
                );
              },
            ),
            _buildSettingsItem(
              icon: Icons.people_outline,
              title: 'Lista Siguiendo',
              trailingText: _followingListPrivacy,
              onTap: () {
                showPrivacyAudienceBottomSheet(
                  context: context,
                  title: 'Lista Siguiendo',
                  question: '¿Quién puede ver la lista de cuentas que sigues?',
                  footerNote:
                      'Solo las personas autorizadas podrán consultar los perfiles que sigues.',
                  currentValue: _followingListPrivacy,
                  onSelected: (val) =>
                      setState(() => _followingListPrivacy = val),
                );
              },
            ),
            _buildSettingsItem(
              icon: Icons.favorite_border,
              title: 'Videos que te gustaron',
              trailingText: _likedVideosPrivacy,
              onTap: () {
                showPrivacyAudienceBottomSheet(
                  context: context,
                  title: 'Videos que te gustaron',
                  question:
                      'Permitir que los videos a los que diste me gusta sean visibles para',
                  footerNote:
                      'Incluso si esta lista es privada, los creadores pueden ver quién reaccionó a sus videos.',
                  currentValue: _likedVideosPrivacy,
                  onSelected: (val) =>
                      setState(() => _likedVideosPrivacy = val),
                );
              },
            ),
            _buildSettingsItem(
              icon: Icons.visibility_outlined,
              title: 'Espectadores',
              trailingText: 'Activado',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const ViewersSettingsScreen(),
                  ),
                );
              },
            ),
          ]),

          // 5. Contenido y pantalla
          _buildSectionHeader('Contenido y pantalla'),
          _buildSectionCard([
            _buildSettingsItem(
              icon: Icons.music_note_outlined,
              title: 'Música',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const MusicSettingsScreen(),
                  ),
                );
              },
            ),
            _buildSettingsItem(
              icon: Icons.chat_bubble_outline,
              title: 'Bandeja de entrada y mensajes',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const InboxSettingsScreen(),
                  ),
                );
              },
            ),
            _buildSettingsItem(
              icon: Icons.history,
              title: 'Centro de actividades',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const ActivityCenterScreen(),
                  ),
                );
              },
            ),
            _buildSettingsItem(
              icon: Icons.tune_outlined,
              title: 'Control del público',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const AudienceControlScreen(),
                  ),
                );
              },
            ),
            _buildSettingsItem(
              icon: Icons.campaign_outlined,
              title: 'Anuncios',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const AdsSettingsScreen(),
                  ),
                );
              },
            ),
            _buildSettingsItem(
              icon: Icons.play_circle_outline,
              title: 'Reproducción',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const PlaybackSettingsScreen(),
                  ),
                );
              },
            ),
            _buildSettingsItem(
              icon: Icons.dark_mode_outlined,
              title: 'Mostrar',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const DisplaySettingsScreen(),
                  ),
                );
              },
            ),
            _buildSettingsItem(
              icon: Icons.language_outlined,
              title: 'Idiomas',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const LanguageSettingsScreen(),
                  ),
                );
              },
            ),
            _buildSettingsItem(
              icon: Icons.accessibility_new_outlined,
              title: 'Accesibilidad',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const AccessibilitySettingsScreen(),
                  ),
                );
              },
            ),
            _buildSettingsItem(
              icon: Icons.contacts_outlined,
              title: 'Contactos y ubicación',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) =>
                        const ContactsLocationSettingsScreen(),
                  ),
                );
              },
            ),
          ]),

          // 6. Caché y datos móviles
          _buildSectionHeader('Caché y datos móviles'),
          _buildSectionCard([
            _buildSettingsItem(
              icon: Icons.cloud_download_outlined,
              title: 'Videos sin conexión',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const OfflineVideosScreen(),
                  ),
                );
              },
            ),
            _buildSettingsItem(
              icon: Icons.delete_outline,
              title: 'Liberar espacio',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const ClearSpaceScreen(),
                  ),
                );
              },
            ),
            _buildSettingsItem(
              icon: Icons.data_saver_on_outlined,
              title: 'Ahorro de datos',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const DataSaverScreen(),
                  ),
                );
              },
            ),
            _buildSettingsItem(
              icon: Icons.wallpaper_outlined,
              title: 'Fondo de pantalla',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const WallpaperSettingsScreen(),
                  ),
                );
              },
            ),
            _buildSettingsItem(
              icon: Icons.bolt_outlined,
              title: 'Modo lite',
              trailingText: 'Activado',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const LiteModeScreen(),
                  ),
                );
              },
            ),
          ]),

          // 7. Ayuda e información
          _buildSectionHeader('Ayuda e información'),
          _buildSectionCard([
            _buildSettingsItem(
              icon: Icons.help_outline,
              title: 'Centro de ayuda',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const HelpCenterScreen(),
                  ),
                );
              },
            ),
            _buildSettingsItem(
              icon: Icons.privacy_tip_outlined,
              title: 'Centro de privacidad',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const PrivacyPolicyScreen(),
                  ),
                );
              },
            ),
            _buildSettingsItem(
              icon: Icons.description_outlined,
              title: 'Términos y políticas',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const TermsOfServiceScreen(),
                  ),
                );
              },
            ),
          ]),

          // 8. Inicio de sesión
          _buildSectionHeader('Inicio de sesión'),
          _buildSectionCard([
            _buildSettingsItem(
              icon: Icons.switch_account_outlined,
              title: 'Cambiar de cuenta',
              trailingWidget: CircleAvatar(
                radius: 12,
                backgroundImage: NetworkImage(activeAvatar),
              ),
              onTap: _openSwitchAccountSheet,
            ),
            _buildSettingsItem(
              icon: Icons.logout_rounded,
              title: 'Cerrar sesión',
              isDestructive: true,
              onTap: _handleSignOut,
            ),
            _buildSettingsItem(
              icon: Icons.delete_forever_outlined,
              title: 'Eliminar cuenta',
              isDestructive: true,
              onTap: () => _showDeleteAccountDialog(context),
            ),
          ]),

          const SizedBox(height: 28),
          Center(
            child: Text(
              'v47.7.3(202407030)',
              style: TextStyle(
                color: Colors.grey[600],
                fontSize: 12,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.only(left: 4, top: 20, bottom: 8),
      child: Text(
        title,
        style: TextStyle(
          color: Colors.grey[400],
          fontSize: 13,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  Widget _buildSectionCard(List<Widget> children) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF1E1E1E),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(children: children),
    );
  }

  // Widget reutilizable para cada ítem de Ajustes y privacidad
  Widget _buildSettingsItem({
    required IconData icon,
    required String title,
    String? trailingText,
    Widget? trailingWidget,
    bool isDestructive = false,
    required VoidCallback onTap,
  }) {
    final Color primaryColor =
        isDestructive ? Colors.redAccent : Colors.white;

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        child: Row(
          children: [
            Icon(icon, color: primaryColor, size: 22),
            const SizedBox(width: 14),
            Expanded(
              child: Text(
                title,
                style: TextStyle(
                  color: primaryColor,
                  fontSize: 15,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
            if (trailingText != null) ...[
              Text(
                trailingText,
                style: TextStyle(
                  color: Colors.grey[400],
                  fontSize: 13,
                ),
              ),
              const SizedBox(width: 6),
            ],
            if (trailingWidget != null) ...[
              trailingWidget,
              const SizedBox(width: 8),
            ],
            Icon(
              Icons.chevron_right,
              color: Colors.grey[600],
              size: 20,
            ),
          ],
        ),
      ),
    );
  }
}`,
  },
  {
    id: 'content_preferences_screen',
    path: 'lib/screens/content_preferences_screen.dart',
    phase: 'Ajustes · ContentPreferencesScreen (Preferencias de contenido)',
    language: 'dart',
    summary:
      'StatefulWidget en modo oscuro (#121212 / #1E1E1E) con grupos redondeados y Bottom Sheet con Switch + Guardar para Modo Restringido y Feed STEM.',
    code: `import 'package:flutter/material.dart';

class ContentPreferencesScreen extends StatefulWidget {
  const ContentPreferencesScreen({super.key});

  @override
  State<ContentPreferencesScreen> createState() =>
      _ContentPreferencesScreenState();
}

class _ContentPreferencesScreenState extends State<ContentPreferencesScreen> {
  bool _restrictedMode = false;
  bool _stemFeed = false;

  void _showOptionSnack(String title) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(title),
        backgroundColor: const Color(0xFF27272A),
        duration: const Duration(seconds: 1),
      ),
    );
  }

  void _openModeBottomSheet({
    required String title,
    required String description,
    required String switchLabel,
    required bool currentValue,
    required ValueChanged<bool> onSave,
  }) {
    bool draftValue = currentValue;

    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1E1E1E),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (sheetContext) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 40,
                      height: 4,
                      margin: const EdgeInsets.only(bottom: 14),
                      decoration: BoxDecoration(
                        color: Colors.grey[700],
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                    Stack(
                      alignment: Alignment.center,
                      children: [
                        Text(
                          title,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Align(
                          alignment: Alignment.centerRight,
                          child: IconButton(
                            onPressed: () => Navigator.pop(sheetContext),
                            icon: const Icon(Icons.close, color: Colors.white),
                            padding: EdgeInsets.zero,
                            constraints: const BoxConstraints(),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Text(
                      description,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.grey[400],
                        fontSize: 13,
                        height: 1.4,
                      ),
                    ),
                    const SizedBox(height: 18),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 10,
                      ),
                      decoration: BoxDecoration(
                        color: const Color(0xFF27272A),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                switchLabel,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                draftValue ? 'Activada' : 'Desactivada',
                                style: TextStyle(
                                  color: draftValue
                                      ? const Color(0xFFFE2C55)
                                      : Colors.grey[400],
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          ),
                          Switch(
                            value: draftValue,
                            activeColor: Colors.white,
                            activeTrackColor: const Color(0xFFFE2C55),
                            inactiveThumbColor: Colors.white,
                            inactiveTrackColor: Colors.grey[700],
                            onChanged: (val) {
                              setModalState(() => draftValue = val);
                            },
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 18),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: () {
                          onSave(draftValue);
                          Navigator.pop(sheetContext);
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFFFE2C55),
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        child: const Text(
                          'Guardar',
                          style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF121212),
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Preferencias de contenido',
          style: TextStyle(
            color: Colors.white,
            fontSize: 17,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Grupo 1: Filtros y modos
          _buildGroupCard([
            _buildPreferenceItem(
              icon: Icons.filter_alt_outlined,
              title: 'Filtrar por palabras clave',
              trailingText: '0',
              onTap: () => _showOptionSnack('Filtrar por palabras clave'),
            ),
            _buildDivider(),
            _buildPreferenceItem(
              icon: Icons.verified_user_outlined,
              title: 'Modo Restringido',
              trailingText: _restrictedMode ? 'Activada' : 'Desactivada',
              isActive: _restrictedMode,
              onTap: () {
                _openModeBottomSheet(
                  title: 'Modo Restringido',
                  description:
                      'Limita la aparición de videos que pueden no ser apropiados para todos los públicos.',
                  switchLabel: 'Activar Modo Restringido',
                  currentValue: _restrictedMode,
                  onSave: (val) => setState(() => _restrictedMode = val),
                );
              },
            ),
            _buildDivider(),
            _buildPreferenceItem(
              icon: Icons.science_outlined,
              title: 'Feed STEM',
              trailingText: _stemFeed ? 'Activada' : 'Desactivada',
              isActive: _stemFeed,
              onTap: () {
                _openModeBottomSheet(
                  title: 'Feed STEM',
                  description:
                      'Agrega una pestaña dedicada a Ciencia, Tecnología, Ingeniería y Matemáticas.',
                  switchLabel: 'Mostrar Feed STEM',
                  currentValue: _stemFeed,
                  onSave: (val) => setState(() => _stemFeed = val),
                );
              },
            ),
          ]),
          const SizedBox(height: 16),

          // Grupo 2: Personalización del feed
          _buildGroupCard([
            _buildPreferenceItem(
              icon: Icons.tune_outlined,
              title: 'Gestionar temas',
              onTap: () => _showOptionSnack('Gestionar temas'),
            ),
            _buildDivider(),
            _buildPreferenceItem(
              icon: Icons.refresh_rounded,
              title: 'Actualiza tu feed Para ti',
              onTap: () => _showOptionSnack('Actualiza tu feed Para ti'),
            ),
          ]),
          const SizedBox(height: 16),

          // Grupo 3: Cuentas silenciadas
          _buildGroupCard([
            _buildPreferenceItem(
              icon: Icons.volume_off_outlined,
              title: 'Cuentas silenciadas',
              onTap: () => _showOptionSnack('Cuentas silenciadas'),
            ),
          ]),
        ],
      ),
    );
  }

  Widget _buildGroupCard(List<Widget> children) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF1E1E1E),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(children: children),
    );
  }

  Widget _buildDivider() {
    return Divider(
      height: 1,
      thickness: 1,
      color: Colors.white.withOpacity(0.05),
      indent: 50,
    );
  }

  Widget _buildPreferenceItem({
    required IconData icon,
    required String title,
    String? trailingText,
    bool isActive = false,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 15),
        child: Row(
          children: [
            Icon(icon, color: Colors.white, size: 22),
            const SizedBox(width: 14),
            Expanded(
              child: Text(
                title,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
            if (trailingText != null) ...[
              Text(
                trailingText,
                style: TextStyle(
                  color: isActive ? const Color(0xFFFE2C55) : Colors.grey[400],
                  fontSize: 13,
                  fontWeight: isActive ? FontWeight.w600 : FontWeight.normal,
                ),
              ),
              const SizedBox(width: 6),
            ],
            Icon(Icons.chevron_right, color: Colors.grey[600], size: 20),
          ],
        ),
      ),
    );
  }
}`,
  },
  {
    id: 'notifications_settings_screen',
    path: 'lib/screens/notifications_settings_screen.dart',
    phase: 'Ajustes · NotificationsSettingsScreen (Notificaciones)',
    language: 'dart',
    summary:
      'StatefulWidget en modo oscuro (#121212 / #1E1E1E) con _switchStates, widgets reutilizables _buildSwitchTile y _buildNavigationTile, y las 9 secciones completas.',
    code: `import 'package:flutter/material.dart';

class NotificationsSettingsScreen extends StatefulWidget {
  const NotificationsSettingsScreen({super.key});

  @override
  State<NotificationsSettingsScreen> createState() =>
      _NotificationsSettingsScreenState();
}

class _NotificationsSettingsScreenState
    extends State<NotificationsSettingsScreen> {
  // Mapa de estado para todos los interruptores (todos en true salvo Tiempo en pantalla semanal)
  final Map<String, bool> _switchStates = {
    // Interacciones
    'likes': true,
    'saved_posts': true,
    'comments': true,
    'new_followers': true,
    'profile_views': true,
    'reposts': true,
    'interacted_posts': true,
    'streaks': true,
    // Mensajes
    'direct_messages': true,
    'dm_previews': true,
    'message_requests': true,
    'activity_status': true,
    // Boletín de noticias
    'new_bulletins': true,
    'bulletin_invites': true,
    'bulletin_interactions': true,
    'bulletin_new_members': true,
    // Sugerencias de publicaciones personalizadas
    'posts_people_you_may_know': true,
    'shared_by_others': true,
    'posts_you_might_like': true,
    // LIVE
    'live_creator_rankings': true,
    // Tiempo en pantalla (único en false por defecto)
    'weekly_screen_time': false,
    // Otro
    'people_you_may_know': true,
    'personalized_updates': true,
    'other_accounts_notifications': true,
  };

  void _showNavFeedback(String title) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Abriendo: \$title'),
        backgroundColor: const Color(0xFF27272A),
        duration: const Duration(seconds: 1),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF121212),
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Notificaciones',
          style: TextStyle(
            color: Colors.white,
            fontSize: 17,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
        children: [
          // 1. Sección Superior (Sin título)
          _buildSectionCard([
            _buildNavigationTile(
              'Notificaciones en la aplicación',
              null,
            ),
            _buildDivider(),
            _buildNavigationTile(
              'Horario de notificaciones push',
              'Establece un horario para desactivar las notificaciones push.',
            ),
          ]),

          // 2. Sección "Interacciones"
          _buildSectionTitle('Interacciones'),
          _buildSectionCard([
            _buildSwitchTile('Me gusta', null, 'likes'),
            _buildDivider(),
            _buildSwitchTile('Publicaciones guardadas', null, 'saved_posts'),
            _buildDivider(),
            _buildSwitchTile('Comentarios', null, 'comments'),
            _buildDivider(),
            _buildSwitchTile('Nuevos seguidores', null, 'new_followers'),
            _buildDivider(),
            _buildSwitchTile(
              'Visualizaciones del perfil',
              null,
              'profile_views',
            ),
            _buildDivider(),
            _buildSwitchTile('Publicaciones compartidas', null, 'reposts'),
            _buildDivider(),
            _buildSwitchTile(
              'Publicaciones con las que interactuaste',
              'Recibe notificaciones sobre publicaciones que te gustaron, comentaste o compartiste recientemente.',
              'interacted_posts',
            ),
            _buildDivider(),
            _buildSwitchTile(
              'Rachas',
              'Recibe notificaciones cuando estés a punto de perder una racha de chat con tus amigos.',
              'streaks',
            ),
          ]),

          // 3. Sección "Mensajes"
          _buildSectionTitle('Mensajes'),
          _buildSectionCard([
            _buildSwitchTile('Mensajes directos', null, 'direct_messages'),
            _buildDivider(),
            _buildNavigationTile(
              'Llamadas de voz',
              'Personas a las que sigues',
            ),
            _buildDivider(),
            _buildSwitchTile(
              'Vista previa de mensajes directos',
              null,
              'dm_previews',
            ),
            _buildDivider(),
            _buildSwitchTile(
              'Solicitudes de mensajes',
              'Recibe una notificación cuando alguien te envíe una solicitud de mensaje.',
              'message_requests',
            ),
            _buildDivider(),
            _buildSwitchTile('Estado de actividad', null, 'activity_status'),
            _buildDivider(),
            _buildNavigationTile(
              'Tonos de alerta',
              'Establece tonos de alerta únicos para tus notificaciones de mensajes.',
            ),
          ]),

          // 4. Sección "Boletín de noticias"
          _buildSectionTitle('Boletín de noticias'),
          _buildSectionCard([
            _buildSwitchTile('Boletines nuevos', null, 'new_bulletins'),
            _buildDivider(),
            _buildSwitchTile('Invitaciones', null, 'bulletin_invites'),
            _buildDivider(),
            _buildSwitchTile(
              'Interacciones',
              null,
              'bulletin_interactions',
            ),
            _buildDivider(),
            _buildSwitchTile('Nuevos miembros', null, 'bulletin_new_members'),
          ]),

          // 5. Sección "Sugerencias de publicaciones"
          _buildSectionTitle('Sugerencias de publicaciones'),
          _buildSectionCard([
            _buildNavigationTile(
              'Publicaciones de cuentas que sigues',
              null,
            ),
          ]),

          // 6. Sección "Sugerencias de publicaciones personalizadas"
          _buildSectionTitle('Sugerencias de publicaciones personalizadas'),
          _buildSectionCard([
            _buildSwitchTile(
              'Publicaciones de gente que quizás conozcas',
              null,
              'posts_people_you_may_know',
            ),
            _buildDivider(),
            _buildSwitchTile(
              'Compartidas por otros',
              null,
              'shared_by_others',
            ),
            _buildDivider(),
            _buildSwitchTile(
              'Publicaciones que podrían gustarte',
              null,
              'posts_you_might_like',
            ),
          ]),

          // 7. Sección "LIVE"
          _buildSectionTitle('LIVE'),
          _buildSectionCard([
            _buildNavigationTile('Ajustes de notificaciones de LIVE', null),
            _buildDivider(),
            _buildSwitchTile(
              'Notificaciones de los rankings de creadores',
              'Activa esta opción para recibir notificaciones sobre actualizaciones y logros de los rankings de creadores.',
              'live_creator_rankings',
            ),
          ]),

          // 8. Sección "Tiempo en pantalla"
          _buildSectionTitle('Tiempo en pantalla'),
          _buildSectionCard([
            _buildSwitchTile(
              'Novedades sobre el tiempo en pantalla semanal',
              null,
              'weekly_screen_time',
            ),
          ]),

          // 9. Sección "Otro"
          _buildSectionTitle('Otro'),
          _buildSectionCard([
            _buildSwitchTile(
              'Personas que quizás conozcas',
              'Estas son las notificaciones sobre cuentas sugeridas de personas que podrías conocer.',
              'people_you_may_know',
            ),
            _buildDivider(),
            _buildSwitchTile(
              'Actualizaciones personalizadas y más',
              null,
              'personalized_updates',
            ),
            _buildDivider(),
            _buildNavigationTile(
              'Notificaciones por correo electrónico',
              null,
            ),
            _buildDivider(),
            _buildNavigationTile('Notificaciones por SMS', null),
            _buildDivider(),
            _buildSwitchTile(
              'Notificaciones de tus otras cuentas de TikTok',
              null,
              'other_accounts_notifications',
            ),
          ]),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(left: 4, top: 20, bottom: 8),
      child: Text(
        title,
        style: TextStyle(
          color: Colors.grey[400],
          fontSize: 13,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  Widget _buildSectionCard(List<Widget> children) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF1E1E1E),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(children: children),
    );
  }

  Widget _buildDivider() {
    return Divider(
      height: 1,
      thickness: 1,
      color: Colors.white.withOpacity(0.05),
      indent: 16,
    );
  }

  // Widget reutilizable para ítems con Switch
  Widget _buildSwitchTile(String title, String? subtitle, String id) {
    final bool isActive = _switchStates[id] ?? true;

    return InkWell(
      onTap: () => setState(() => _switchStates[id] = !isActive),
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  if (subtitle != null) ...[
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: TextStyle(
                        color: Colors.grey[400],
                        fontSize: 12,
                        height: 1.35,
                      ),
                    ),
                  ],
                ],
              ),
            ),
            const SizedBox(width: 12),
            Switch(
              value: isActive,
              activeColor: Colors.white,
              activeTrackColor: const Color(0xFF25F4EE),
              inactiveThumbColor: Colors.white,
              inactiveTrackColor: Colors.grey[700],
              onChanged: (value) {
                setState(() => _switchStates[id] = value);
              },
            ),
          ],
        ),
      ),
    );
  }

  // Widget reutilizable para ítems con flecha '>'
  Widget _buildNavigationTile(String title, String? subtitle) {
    return InkWell(
      onTap: () => _showNavFeedback(title),
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  if (subtitle != null) ...[
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: TextStyle(
                        color: Colors.grey[400],
                        fontSize: 12,
                        height: 1.35,
                      ),
                    ),
                  ],
                ],
              ),
            ),
            const SizedBox(width: 12),
            Icon(Icons.chevron_right, color: Colors.grey[600], size: 20),
          ],
        ),
      ),
    );
  }
}`,
  },
  {
    id: 'wellbeing_screen',
    path: 'lib/screens/wellbeing_screen.dart',
    phase: 'Ajustes · WellbeingScreen (Tiempo y bienestar)',
    language: 'dart',
    summary:
      'Pantalla Tiempo y bienestar en Dark Mode (#121212) con saludo + avatar, gráfico semanal de barras, insignias 0/9, tarjetas con LinearGradient y carrusel horizontal.',
    code: `import 'package:flutter/material.dart';

class WellbeingScreen extends StatefulWidget {
  const WellbeingScreen({super.key});

  @override
  State<WellbeingScreen> createState() => _WellbeingScreenState();
}

class _WellbeingScreenState extends State<WellbeingScreen> {
  bool _isMuted = false;

  static const List<Map<String, dynamic>> _weeklyBars = [
    {'day': 'Dom', 'height': 46.0, 'isToday': false},
    {'day': 'Lun', 'height': 62.0, 'isToday': false},
    {'day': 'Mar', 'height': 84.0, 'isToday': false},
    {'day': 'Mié', 'height': 54.0, 'isToday': false},
    {'day': 'Jue', 'height': 74.0, 'isToday': false},
    {'day': 'Vie', 'height': 92.0, 'isToday': false},
    {'day': 'Hoy', 'height': 60.0, 'isToday': true},
  ];

  static const List<Map<String, String>> _resources = [
    {
      'title': 'Cómo crear pausas digitales conscientes',
      'duration': '01:45',
      'thumb':
          'https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=400&auto=format&fit=crop',
    },
    {
      'title': 'Técnica 4-7-8 para reducir el estrés',
      'duration': '02:15',
      'thumb':
          'https://images.unsplash.com/photo-1518241353330-0f7941c2d9b5?w=400&auto=format&fit=crop',
    },
    {
      'title': 'Higiene del sueño antes de dormir',
      'duration': '03:05',
      'thumb':
          'https://images.unsplash.com/photo-1511295742362-92c96b1cf484?w=400&auto=format&fit=crop',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF121212),
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Tiempo y bienestar',
          style: TextStyle(
            color: Colors.white,
            fontSize: 17,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
        children: [
          // 1. Encabezado: "Hola, Eloy" + Avatar redondo
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Hola, Eloy',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 26,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      'Revisa tu tiempo en pantalla, explora herramientas de calma y mantén hábitos digitales saludables.',
                      style: TextStyle(
                        color: Colors.grey[400],
                        fontSize: 13,
                        height: 1.35,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              const CircleAvatar(
                radius: 26,
                backgroundImage: NetworkImage(
                  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop',
                ),
              ),
            ],
          ),
          const SizedBox(height: 22),

          // 2. Sección "Tiempo en pantalla" + Gráfico de barras simulado
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFF1E1E1E),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'TIEMPO EN PANTALLA',
                  style: TextStyle(
                    color: Colors.grey[400],
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.8,
                  ),
                ),
                const SizedBox(height: 6),
                const Text(
                  '2 h 34 min',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 30,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                Text(
                  'Promedio diario',
                  style: TextStyle(color: Colors.grey[400], fontSize: 13),
                ),
                const SizedBox(height: 20),
                SizedBox(
                  height: 122,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: _weeklyBars.map((bar) {
                      final bool isToday = bar['isToday'] as bool;
                      return Column(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Container(
                            width: 24,
                            height: bar['height'] as double,
                            decoration: BoxDecoration(
                              borderRadius: const BorderRadius.vertical(
                                top: Radius.circular(6),
                              ),
                              gradient: LinearGradient(
                                begin: Alignment.bottomCenter,
                                end: Alignment.topCenter,
                                colors: isToday
                                    ? const [
                                        Color(0xFF0284C7),
                                        Color(0xFF22D3EE),
                                      ]
                                    : [
                                        const Color(0xFF2563EB)
                                            .withOpacity(0.7),
                                        const Color(0xFF38BDF8)
                                            .withOpacity(0.85),
                                      ],
                              ),
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            bar['day'] as String,
                            style: TextStyle(
                              color: isToday
                                  ? const Color(0xFF38BDF8)
                                  : Colors.grey[400],
                              fontSize: 11,
                              fontWeight:
                                  isToday ? FontWeight.bold : FontWeight.normal,
                            ),
                          ),
                        ],
                      );
                    }).toList(),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),

          // 3. Sección "Insignias"
          const Text(
            'Insignias',
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            decoration: BoxDecoration(
              color: const Color(0xFF1E1E1E),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      '0/9',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    Text(
                      'Logros de bienestar',
                      style: TextStyle(color: Colors.grey[400], fontSize: 12),
                    ),
                  ],
                ),
                Row(
                  children: [
                    _buildMedalBadge(Icons.emoji_events, Colors.amber),
                    const SizedBox(width: 8),
                    _buildMedalBadge(Icons.workspace_premium, Colors.emerald),
                    const SizedBox(width: 8),
                    _buildMedalBadge(Icons.military_tech, Colors.lightBlue),
                    const SizedBox(width: 8),
                    _buildMedalBadge(Icons.stars_rounded, Colors.pinkAccent),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 22),

          // 4. Sección "Pausar y restablecer"
          const Text(
            'Pausar y restablecer',
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 12),

          // Tarjeta 1 (Morada)
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              gradient: const LinearGradient(
                colors: [Color(0xFF6D28D9), Color(0xFFA855F7)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: Row(
              children: [
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Hoy estoy...',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 17,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        'Elige 2 palabras que describan cómo te sientes hoy.',
                        style: TextStyle(color: Colors.white70, fontSize: 13),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                CircleAvatar(
                  radius: 20,
                  backgroundColor: Colors.white,
                  child: IconButton(
                    icon: const Icon(
                      Icons.arrow_forward,
                      color: Color(0xFF6D28D9),
                      size: 20,
                    ),
                    onPressed: () {},
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),

          // Tarjeta 2 (Celeste)
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              gradient: const LinearGradient(
                colors: [Color(0xFF0284C7), Color(0xFF38BDF8)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Respira de manera uniforme',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 17,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      const Text(
                        'Sigue un ritmo guiado para despejar la mente y recuperar el equilibrio.',
                        style: TextStyle(color: Colors.white70, fontSize: 13),
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          _buildTagChip('Concentrate'),
                          const SizedBox(width: 8),
                          _buildTagChip('2 min'),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                CircleAvatar(
                  radius: 20,
                  backgroundColor: Colors.white,
                  child: IconButton(
                    icon: const Icon(
                      Icons.arrow_forward,
                      color: Color(0xFF0284C7),
                      size: 20,
                    ),
                    onPressed: () {},
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),

          // Tarjeta 3 (Azul claro)
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              gradient: const LinearGradient(
                colors: [Color(0xFF1D4ED8), Color(0xFF60A5FA)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: Row(
              children: [
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Icon(
                            Icons.graphic_eq,
                            color: Colors.white,
                            size: 20,
                          ),
                          SizedBox(width: 8),
                          Text(
                            'Sonidos relajantes',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 17,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 4),
                      Text(
                        'Lluvia suave y ruido blanco para descansar o concentrarte.',
                        style: TextStyle(color: Colors.white70, fontSize: 13),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                CircleAvatar(
                  radius: 20,
                  backgroundColor: Colors.white24,
                  child: IconButton(
                    icon: Icon(
                      _isMuted ? Icons.volume_off : Icons.volume_up,
                      color: Colors.white,
                      size: 20,
                    ),
                    onPressed: () {
                      setState(() => _isMuted = !_isMuted);
                    },
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),

          // 5. Sección "Más recursos" (Carrusel horizontal)
          const Text(
            'Más recursos',
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 12),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: _resources.map((video) {
                return Container(
                  width: 156,
                  margin: const EdgeInsets.only(right: 12),
                  decoration: BoxDecoration(
                    color: const Color(0xFF1E1E1E),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Stack(
                        children: [
                          Image.network(
                            video['thumb']!,
                            width: 156,
                            height: 180,
                            fit: BoxFit.cover,
                          ),
                          const Positioned(
                            top: 8,
                            right: 8,
                            child: CircleAvatar(
                              radius: 14,
                              backgroundColor: Colors.black54,
                              child: Icon(
                                Icons.play_arrow,
                                color: Colors.white,
                                size: 16,
                              ),
                            ),
                          ),
                          Positioned(
                            bottom: 8,
                            right: 8,
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 6,
                                vertical: 2,
                              ),
                              decoration: BoxDecoration(
                                color: Colors.black87,
                                borderRadius: BorderRadius.circular(4),
                              ),
                              child: Text(
                                video['duration']!,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 10,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      Padding(
                        padding: const EdgeInsets.all(10),
                        child: Text(
                          video['title']!,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMedalBadge(IconData icon, Color color) {
    return CircleAvatar(
      radius: 17,
      backgroundColor: color.withOpacity(0.18),
      child: Icon(icon, color: color, size: 18),
    );
  }

  Widget _buildTagChip(String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.22),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        label,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 11,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}`,
  },
  {
    id: 'family_sync_screen',
    path: 'lib/screens/family_sync_screen.dart',
    phase: 'Ajustes · FamilySyncScreen (Sincronización familiar)',
    language: 'dart',
    summary:
      'Pantalla de bienvenida de Sincronización familiar en Dark Mode con casita amarilla sonriente, texto informativo y botones para tutor legal o adolescente.',
    code: `import 'package:flutter/material.dart';
import 'invite_family_screen.dart';

class FamilySyncScreen extends StatelessWidget {
  const FamilySyncScreen({super.key});

  void _openInvite(BuildContext context, {required bool isGuardian}) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => InviteFamilyScreen(isGuardian: isGuardian),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF121212),
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Sincronización familiar',
          style: TextStyle(
            color: Colors.white,
            fontSize: 17,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                // Casita amarilla con sonrisa (100x100, ícono 50, fondo amarillo oscuro/oliva)
                Container(
                  width: 100,
                  height: 100,
                  decoration: BoxDecoration(
                    color: const Color(0xFF332D10),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Stack(
                    alignment: Alignment.center,
                    children: const [
                      Icon(
                        Icons.home_rounded,
                        color: Color(0xFFFACC15),
                        size: 50,
                      ),
                      Positioned(
                        bottom: 26,
                        child: Icon(
                          Icons.sentiment_satisfied_alt_rounded,
                          color: Color(0xFF121212),
                          size: 18,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),

                // Título más compacto y centrado
                const Text(
                  'Acompaña a tu adolescente en Viroklipz',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    height: 1.25,
                  ),
                ),
                const SizedBox(height: 16),

                // Cuadro de texto descriptivo compacto
                Container(
                  padding: const EdgeInsets.all(16.0),
                  decoration: BoxDecoration(
                    color: const Color(0xFF1E1E1E),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const CircleAvatar(
                        radius: 16,
                        backgroundColor: Color(0xFF332D10),
                        child: Icon(
                          Icons.home_outlined,
                          color: Color(0xFFFACC15),
                          size: 18,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          'Vincula tu cuenta con la de tu adolescente para configurar juntos límites de tiempo en pantalla, restricciones de contenido y ajustes de privacidad.',
                          style: TextStyle(
                            color: Colors.grey[300],
                            fontSize: 14,
                            height: 1.4,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 24),

                // Botón negro con texto blanco (altura 50)
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: OutlinedButton(
                    onPressed: () => _openInvite(context, isGuardian: true),
                    style: OutlinedButton.styleFrom(
                      backgroundColor: Colors.black,
                      foregroundColor: Colors.white,
                      side: BorderSide(color: Colors.grey[800]!),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: const Text(
                      'Continuar como tutor legal',
                      style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                const SizedBox(height: 12),

                // Botón blanco con texto negro (altura 50)
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton(
                    onPressed: () => _openInvite(context, isGuardian: false),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: Colors.black,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: const Text(
                      'Continuar como adolescente',
                      style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                const SizedBox(height: 30),
              ],
            ),
          ),
        ),
      ),
    );
  }
}`,
  },
  {
    id: 'invite_family_screen',
    path: 'lib/screens/invite_family_screen.dart',
    phase: 'Ajustes · InviteFamilyScreen (Invitación + QR Familiar)',
    language: 'dart',
    summary:
      'Pantalla para invitar a tu adolescente o tutor legal con TextField de búsqueda, barra de compartir (Link, WhatsApp, Mensaje) y QrImageView con logo de Viroklipz.',
    code: `import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:qr_flutter/qr_flutter.dart';

class InviteFamilyScreen extends StatefulWidget {
  final bool isGuardian;

  const InviteFamilyScreen({
    super.key,
    required this.isGuardian,
  });

  @override
  State<InviteFamilyScreen> createState() => _InviteFamilyScreenState();
}

class _InviteFamilyScreenState extends State<InviteFamilyScreen> {
  final TextEditingController _searchController = TextEditingController();

  String get _inviteUrl => widget.isGuardian
      ? 'https://viroklipz.app/family-sync/invite-teen-7841'
      : 'https://viroklipz.app/family-sync/invite-guardian-7841';

  Future<void> _copyInviteLink() async {
    await Clipboard.setData(ClipboardData(text: _inviteUrl));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Enlace de invitación copiado'),
        backgroundColor: Color(0xFF27272A),
      ),
    );
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final String screenTitle = widget.isGuardian
        ? 'Invita a tu adolescente'
        : 'Invita a tu tutor legal';

    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF121212),
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          screenTitle,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 17,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
        children: [
          // Barra de búsqueda
          TextField(
            controller: _searchController,
            style: const TextStyle(color: Colors.white, fontSize: 14),
            decoration: InputDecoration(
              hintText: 'Buscar por nombre...',
              hintStyle: TextStyle(color: Colors.grey[500]),
              prefixIcon: Icon(Icons.search, color: Colors.grey[400]),
              filled: true,
              fillColor: const Color(0xFF1E1E1E),
              contentPadding: const EdgeInsets.symmetric(vertical: 12),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none,
              ),
            ),
          ),
          const SizedBox(height: 14),

          // Texto explicativo en gris
          Text(
            widget.isGuardian
                ? 'Envía una invitación directa o muestra este código QR para vincular la cuenta de tu adolescente con tu perfil.'
                : 'Envía una invitación directa o comparte este código QR con tu tutor legal para activar la Sincronización familiar.',
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 13,
              height: 1.4,
            ),
          ),
          const SizedBox(height: 18),

          // Sección de compartir
          InkWell(
            onTap: _copyInviteLink,
            borderRadius: BorderRadius.circular(16),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              decoration: BoxDecoration(
                color: const Color(0xFF1E1E1E),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Row(
                children: [
                  const Expanded(
                    child: Text(
                      'Compartir enlace...',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  _buildShareCircle(
                    icon: Icons.link,
                    color: Colors.lightBlue,
                    onTap: _copyInviteLink,
                  ),
                  const SizedBox(width: 8),
                  _buildShareCircle(
                    icon: Icons.chat,
                    color: Colors.green,
                    onTap: _copyInviteLink,
                  ),
                  const SizedBox(width: 8),
                  _buildShareCircle(
                    icon: Icons.sms_outlined,
                    color: Colors.blueAccent,
                    onTap: _copyInviteLink,
                  ),
                  const SizedBox(width: 8),
                  Icon(Icons.chevron_right, color: Colors.grey[500], size: 20),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),

          // Sección QR
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: const Color(0xFF1E1E1E),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              children: [
                const Text(
                  'Escanear o mostrar código QR',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 18),
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      QrImageView(
                        data: _inviteUrl,
                        version: QrVersions.auto,
                        size: 190,
                        backgroundColor: Colors.white,
                      ),
                      // Logo de Viroklipz en el centro
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: Colors.black,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Colors.white, width: 2),
                        ),
                        child: const Icon(
                          Icons.play_arrow_rounded,
                          color: Color(0xFF25F4EE),
                          size: 26,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  widget.isGuardian
                      ? 'Pídele al adolescente que escanee este código QR. Este código expirará el 21 nov.'
                      : 'Pídele a tu tutor legal que escanee este código QR. Este código expirará el 21 nov.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.grey[400],
                    fontSize: 12,
                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildShareCircle({
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: CircleAvatar(
        radius: 17,
        backgroundColor: color,
        child: Icon(icon, color: Colors.white, size: 17),
      ),
    );
  }
}`,
  },
  {
    id: 'account_settings_screen',
    path: 'lib/screens/account_settings_screen.dart',
    phase: 'Ajustes · AccountSettingsScreen (Cuenta)',
    language: 'dart',
    summary:
      'Pantalla Cuenta en modo oscuro (#121212 / #1E1E1E) con las 7 opciones de administración, subtítulos descriptivos y flechas de navegación.',
    code: `import 'package:flutter/material.dart';

class AccountSettingsScreen extends StatelessWidget {
  const AccountSettingsScreen({super.key});

  void _showOptionFeedback(BuildContext context, String title) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Cuenta: \$title'),
        backgroundColor: const Color(0xFF27272A),
        duration: const Duration(seconds: 1),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF121212),
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Cuenta',
          style: TextStyle(
            color: Colors.white,
            fontSize: 17,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            decoration: BoxDecoration(
              color: const Color(0xFF1E1E1E),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              children: [
                _buildAccountItem(
                  context,
                  title: 'Información de la cuenta',
                ),
                _buildDivider(),
                _buildAccountItem(
                  context,
                  title: 'Contraseña',
                ),
                _buildDivider(),
                _buildAccountItem(
                  context,
                  title: 'Verificación',
                ),
                _buildDivider(),
                _buildAccountItem(
                  context,
                  title: 'Pasar a Cuenta de empresa verificada',
                  subtitle:
                      'Estás usando una cuenta personal actualmente. Cambia a una cuenta de empresa para acceder a más herramientas.',
                ),
                _buildDivider(),
                _buildAccountItem(
                  context,
                  title: 'Legado de la cuenta',
                  subtitle:
                      'Planifica con antelación qué ocurrirá con tu cuenta si algo llega a suceder.',
                ),
                _buildDivider(),
                _buildAccountItem(
                  context,
                  title: 'Descargar tus datos',
                  subtitle: 'Obtén una copia de tus datos de Viroklipz.',
                ),
                _buildDivider(),
                _buildAccountItem(
                  context,
                  title: 'Desactivar o eliminar la cuenta',
                  isDestructive: true,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDivider() {
    return Divider(
      height: 1,
      thickness: 1,
      color: Colors.white.withOpacity(0.05),
      indent: 16,
    );
  }

  Widget _buildAccountItem(
    BuildContext context, {
    required String title,
    String? subtitle,
    bool isDestructive = false,
  }) {
    return InkWell(
      onTap: () => _showOptionFeedback(context, title),
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      color: isDestructive ? Colors.redAccent : Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  if (subtitle != null) ...[
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: TextStyle(
                        color: Colors.grey[400],
                        fontSize: 12,
                        height: 1.35,
                      ),
                    ),
                  ],
                ],
              ),
            ),
            const SizedBox(width: 12),
            Icon(Icons.chevron_right, color: Colors.grey[600], size: 20),
          ],
        ),
      ),
    );
  }
}`,
  },
  {
    id: 'security_permissions_screen',
    path: 'lib/screens/security_permissions_screen.dart',
    phase: 'Ajustes · SecurityPermissionsScreen (Seguridad y permisos)',
    language: 'dart',
    summary:
      'StatefulWidget en modo oscuro (#121212) con secciones Seguridad y Permisos, Verificación en dos pasos y Switch funcional para Guardar datos de inicio de sesión.',
    code: `import 'package:flutter/material.dart';

class SecurityPermissionsScreen extends StatefulWidget {
  const SecurityPermissionsScreen({super.key});

  @override
  State<SecurityPermissionsScreen> createState() =>
      _SecurityPermissionsScreenState();
}

class _SecurityPermissionsScreenState extends State<SecurityPermissionsScreen> {
  bool _saveLoginInfo = true;

  void _showSecuritySnack(String title) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Seguridad: \$title'),
        backgroundColor: const Color(0xFF27272A),
        duration: const Duration(seconds: 1),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF121212),
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Seguridad y permisos',
          style: TextStyle(
            color: Colors.white,
            fontSize: 17,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
        children: [
          // Sección "Seguridad"
          _buildSectionTitle('Seguridad'),
          _buildSectionCard([
            _buildNavItem('Alertas de seguridad'),
            _buildDivider(),
            _buildNavItem('Verificación de seguridad'),
            _buildDivider(),
            _buildNavItem('Tus dispositivos'),
            _buildDivider(),
            _buildNavItem(
              'Verificación en dos pasos',
              trailingText: 'Desactivado',
            ),
            _buildDivider(),
            InkWell(
              onTap: () => setState(() => _saveLoginInfo = !_saveLoginInfo),
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Guardar los datos de inicio de sesión',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 15,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'Inicia sesión en gabriel_12343 en este dispositivo sin tener que introducir tus credenciales cada vez.',
                            style: TextStyle(
                              color: Colors.grey[400],
                              fontSize: 12,
                              height: 1.35,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 12),
                    Switch(
                      value: _saveLoginInfo,
                      activeColor: Colors.white,
                      activeTrackColor: const Color(0xFF25F4EE),
                      inactiveThumbColor: Colors.white,
                      inactiveTrackColor: Colors.grey[700],
                      onChanged: (value) {
                        setState(() => _saveLoginInfo = value);
                      },
                    ),
                  ],
                ),
              ),
            ),
            _buildDivider(),
            _buildNavItem('Ayuda a tus amigos a recuperar sus cuentas'),
          ]),

          // Sección "Permisos"
          _buildSectionTitle('Permisos'),
          _buildSectionCard([
            _buildNavItem('Permisos de aplicaciones y servicios'),
            _buildDivider(),
            _buildNavItem('Ajustes del navegador'),
          ]),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(left: 4, top: 16, bottom: 8),
      child: Text(
        title,
        style: TextStyle(
          color: Colors.grey[400],
          fontSize: 13,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  Widget _buildSectionCard(List<Widget> children) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF1E1E1E),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(children: children),
    );
  }

  Widget _buildDivider() {
    return Divider(
      height: 1,
      thickness: 1,
      color: Colors.white.withOpacity(0.05),
      indent: 16,
    );
  }

  Widget _buildNavItem(String title, {String? trailingText}) {
    return InkWell(
      onTap: () => _showSecuritySnack(title),
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
        child: Row(
          children: [
            Expanded(
              child: Text(
                title,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
            if (trailingText != null) ...[
              Text(
                trailingText,
                style: TextStyle(color: Colors.grey[400], fontSize: 13),
              ),
              const SizedBox(width: 6),
            ],
            Icon(Icons.chevron_right, color: Colors.grey[600], size: 20),
          ],
        ),
      ),
    );
  }
}`,
  },
  {
    id: 'share_profile_bottom_sheet',
    path: 'lib/screens/share_profile_bottom_sheet.dart',
    phase: 'Ajustes · ShareProfileBottomSheet (Enviar a)',
    language: 'dart',
    summary:
      'ModalBottomSheet de fondo blanco con esquinas redondeadas, buscador y X, fila horizontal de avatares y botones Copiar enlace (Clipboard), WhatsApp, Facebook, Telegram y SMS con share_plus.',
    code: `import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';

void showShareProfileBottomSheet(
  BuildContext context, {
  String handle = 'gabriel_12343',
}) {
  showModalBottomSheet(
    context: context,
    backgroundColor: Colors.white,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
    ),
    builder: (sheetContext) => ShareProfileBottomSheet(handle: handle),
  );
}

class ShareProfileBottomSheet extends StatelessWidget {
  final String handle;

  const ShareProfileBottomSheet({
    super.key,
    this.handle = 'gabriel_12343',
  });

  static const List<Map<String, String>> _contacts = [
    {
      'name': 'la toxica #1🦋',
      'avatar':
          'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=200&auto=format&fit=crop',
    },
    {
      'name': '1382jovana',
      'avatar':
          'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop',
    },
    {
      'name': 'Tarot Masónico',
      'avatar':
          'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=200&auto=format&fit=crop',
    },
    {
      'name': 'ELOY',
      'avatar':
          'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop',
    },
  ];

  String get _profileUrl => 'https://viroklipz.app/@\$handle';

  Future<void> _copyLink(BuildContext context) async {
    await Clipboard.setData(ClipboardData(text: _profileUrl));
    if (!context.mounted) return;
    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Enlace copiado al portapapeles'),
        backgroundColor: Color(0xFF27272A),
      ),
    );
  }

  Future<void> _shareExternal(BuildContext context) async {
    Navigator.pop(context);
    await Share.share('¡Mira mi perfil en Viroklipz! \$_profileUrl');
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Indicador superior
            Container(
              width: 40,
              height: 4,
              margin: const EdgeInsets.only(bottom: 10),
              decoration: BoxDecoration(
                color: Colors.grey[300],
                borderRadius: BorderRadius.circular(2),
              ),
            ),

            // Encabezado: Lupa (izq), "Enviar a" (centro), X (der)
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton(
                  icon: const Icon(Icons.search, color: Colors.black87),
                  onPressed: () {},
                ),
                const Text(
                  'Enviar a',
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.close, color: Colors.black87),
                  onPressed: () => Navigator.pop(context),
                ),
              ],
            ),
            const SizedBox(height: 8),

            // Fila 1: Scroll horizontal de avatares con nombres
            SizedBox(
              height: 92,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: _contacts.length,
                separatorBuilder: (_, __) => const SizedBox(width: 16),
                itemBuilder: (context, index) {
                  final contact = _contacts[index];
                  return GestureDetector(
                    onTap: () {
                      Navigator.pop(context);
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(
                            'Perfil enviado a \${contact['name']}',
                          ),
                        ),
                      );
                    },
                    child: SizedBox(
                      width: 68,
                      child: Column(
                        children: [
                          CircleAvatar(
                            radius: 28,
                            backgroundImage: NetworkImage(contact['avatar']!),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            contact['name']!,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              color: Colors.black87,
                              fontSize: 11,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),

            const Divider(height: 24),

            // Fila 2: Botones de acción (Copiar enlace, WhatsApp, Facebook, Telegram, SMS)
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildShareAction(
                  label: 'Copiar enlace',
                  icon: Icons.link,
                  bgColor: Colors.grey[200]!,
                  iconColor: Colors.black87,
                  onTap: () => _copyLink(context),
                ),
                _buildShareAction(
                  label: 'WhatsApp',
                  icon: Icons.chat,
                  bgColor: const Color(0xFF25D366),
                  iconColor: Colors.white,
                  onTap: () => _shareExternal(context),
                ),
                _buildShareAction(
                  label: 'Facebook',
                  icon: Icons.facebook,
                  bgColor: const Color(0xFF1877F2),
                  iconColor: Colors.white,
                  onTap: () => _shareExternal(context),
                ),
                _buildShareAction(
                  label: 'Telegram',
                  icon: Icons.send,
                  bgColor: const Color(0xFF229ED9),
                  iconColor: Colors.white,
                  onTap: () => _shareExternal(context),
                ),
                _buildShareAction(
                  label: 'SMS',
                  icon: Icons.sms_outlined,
                  bgColor: const Color(0xFF1E3A8A),
                  iconColor: Colors.white,
                  onTap: () => _shareExternal(context),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildShareAction({
    required String label,
    required IconData icon,
    required Color bgColor,
    required Color iconColor,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          CircleAvatar(
            radius: 24,
            backgroundColor: bgColor,
            child: Icon(icon, color: iconColor, size: 22),
          ),
          const SizedBox(height: 6),
          Text(
            label,
            style: const TextStyle(
              color: Colors.black87,
              fontSize: 11,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}`,
  },
  {
    id: 'private_account_screen',
    path: 'lib/screens/private_account_screen.dart',
    phase: 'Ajustes · PrivateAccountScreen (Cuenta privada)',
    language: 'dart',
    summary:
      'StatefulWidget en modo oscuro (#121212 / #1E1E1E) con Switch funcional para activar o desactivar la Cuenta privada.',
    code: `import 'package:flutter/material.dart';

class PrivateAccountScreen extends StatefulWidget {
  const PrivateAccountScreen({super.key});

  @override
  State<PrivateAccountScreen> createState() => _PrivateAccountScreenState();
}

class _PrivateAccountScreenState extends State<PrivateAccountScreen> {
  bool _isPrivate = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF121212),
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Cuenta privada',
          style: TextStyle(
            color: Colors.white,
            fontSize: 17,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Container(
          decoration: BoxDecoration(
            color: const Color(0xFF1E1E1E),
            borderRadius: BorderRadius.circular(12),
          ),
          child: SwitchListTile(
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 16,
              vertical: 10,
            ),
            value: _isPrivate,
            activeColor: Colors.white,
            activeTrackColor: const Color(0xFF25F4EE),
            inactiveThumbColor: Colors.white,
            inactiveTrackColor: Colors.grey[700],
            onChanged: (value) {
              setState(() => _isPrivate = value);
            },
            title: const Text(
              'Cuenta privada',
              style: TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.w600,
              ),
            ),
            subtitle: Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Text(
                'Con una cuenta privada, solo los usuarios que apruebes podrán seguirte y ver tus videos. Esto no afectará a tus seguidores actuales.',
                style: TextStyle(
                  color: Colors.grey[400],
                  fontSize: 13,
                  height: 1.4,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}`,
  },
  {
    id: 'blocked_accounts_screen',
    path: 'lib/screens/blocked_accounts_screen.dart',
    phase: 'Ajustes · BlockedAccountsScreen (Cuentas bloqueadas)',
    language: 'dart',
    summary:
      'Pantalla Cuentas bloqueadas en modo oscuro (#121212) con estado vacío centrado e ícono gris de silueta de usuario.',
    code: `import 'package:flutter/material.dart';

class BlockedAccountsScreen extends StatelessWidget {
  const BlockedAccountsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF121212),
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Cuentas bloqueadas',
          style: TextStyle(
            color: Colors.white,
            fontSize: 17,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircleAvatar(
                radius: 42,
                backgroundColor: const Color(0xFF1E1E1E),
                child: Icon(
                  Icons.person_outline,
                  color: Colors.grey[500],
                  size: 46,
                ),
              ),
              const SizedBox(height: 16),
              const Text(
                'No hay cuentas bloqueadas',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}`,
  },
  {
    id: 'mentions_settings_screen',
    path: 'lib/screens/mentions_settings_screen.dart',
    phase: 'Ajustes · MentionsSettingsScreen (Menciones)',
    language: 'dart',
    summary:
      'Pantalla Menciones en modo oscuro (#121212 / #1E1E1E) con contenedor de permisos de mención y subtítulo explicativo.',
    code: `import 'package:flutter/material.dart';

class MentionsSettingsScreen extends StatelessWidget {
  const MentionsSettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF121212),
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Menciones',
          style: TextStyle(
            color: Colors.white,
            fontSize: 17,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: const Color(0xFF1E1E1E),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Expanded(
                    child: Text(
                      'Permite las menciones desde',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  Text(
                    'Todo el m...',
                    style: TextStyle(color: Colors.grey[400], fontSize: 13),
                  ),
                  const SizedBox(width: 4),
                  Icon(Icons.chevron_right, color: Colors.grey[500], size: 20),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                'Elige quién puede mencionarte en sus descripciones, stickers, comentarios y Stories',
                style: TextStyle(
                  color: Colors.grey[400],
                  fontSize: 13,
                  height: 1.4,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}`,
  },
  {
    id: 'comments_settings_screen',
    path: 'lib/screens/comments_settings_screen.dart',
    phase: 'Ajustes · CommentsSettingsScreen (Comentarios + Filtros)',
    language: 'dart',
    summary:
      'StatefulWidget en modo oscuro (#121212 / #1E1E1E) con selector de audiencia en showModalBottomSheet blanco (Todo el mundo / Amigos 6 >) y 4 filas de filtros.',
    code: `import 'package:flutter/material.dart';

class CommentsSettingsScreen extends StatefulWidget {
  const CommentsSettingsScreen({super.key});

  @override
  State<CommentsSettingsScreen> createState() => _CommentsSettingsScreenState();
}

class _CommentsSettingsScreenState extends State<CommentsSettingsScreen> {
  String _selectedAudience = 'everyone'; // 'everyone' | 'friends'
  bool _creatorControlMode = false;
  bool _filterSpam = true;

  void _openAudienceSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (sheetContext) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 40,
                      height: 4,
                      margin: const EdgeInsets.only(bottom: 12),
                      decoration: BoxDecoration(
                        color: Colors.grey[300],
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                    Stack(
                      alignment: Alignment.center,
                      children: [
                        const Text(
                          'Comentarios',
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Align(
                          alignment: Alignment.centerRight,
                          child: IconButton(
                            icon: const Icon(Icons.close, color: Colors.black87),
                            onPressed: () => Navigator.pop(sheetContext),
                            padding: EdgeInsets.zero,
                            constraints: const BoxConstraints(),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),

                    // Opción 1: Todo el mundo
                    RadioListTile<String>(
                      contentPadding: EdgeInsets.zero,
                      controlAffinity: ListTileControlAffinity.trailing,
                      activeColor: const Color(0xFFFE2C55),
                      value: 'everyone',
                      groupValue: _selectedAudience,
                      title: const Text(
                        'Todo el mundo',
                        style: TextStyle(
                          color: Colors.black87,
                          fontSize: 15,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      onChanged: (val) {
                        if (val == null) return;
                        setState(() => _selectedAudience = val);
                        Navigator.pop(sheetContext);
                      },
                    ),

                    // Opción 2: Amigos 6 >
                    RadioListTile<String>(
                      contentPadding: EdgeInsets.zero,
                      controlAffinity: ListTileControlAffinity.trailing,
                      activeColor: const Color(0xFFFE2C55),
                      value: 'friends',
                      groupValue: _selectedAudience,
                      title: Row(
                        children: const [
                          Text(
                            'Amigos 6',
                            style: TextStyle(
                              color: Colors.black87,
                              fontSize: 15,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          SizedBox(width: 4),
                          Icon(
                            Icons.chevron_right,
                            color: Colors.black54,
                            size: 18,
                          ),
                        ],
                      ),
                      subtitle: const Text(
                        'Seguidores a los que también sigues',
                        style: TextStyle(color: Colors.grey, fontSize: 12),
                      ),
                      onChanged: (val) {
                        if (val == null) return;
                        setState(() => _selectedAudience = val);
                        Navigator.pop(sheetContext);
                      },
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF121212),
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Comentarios',
          style: TextStyle(
            color: Colors.white,
            fontSize: 17,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
        children: [
          // Opción 1: Permite los comentarios desde
          InkWell(
            onTap: _openAudienceSheet,
            borderRadius: BorderRadius.circular(12),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
              decoration: BoxDecoration(
                color: const Color(0xFF1E1E1E),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  const Expanded(
                    child: Text(
                      'Permite los comentarios desde',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  Text(
                    _selectedAudience == 'everyone'
                        ? 'Todo el m...'
                        : 'Amigos',
                    style: TextStyle(color: Colors.grey[400], fontSize: 13),
                  ),
                  const SizedBox(width: 4),
                  Icon(Icons.chevron_right, color: Colors.grey[500], size: 20),
                ],
              ),
            ),
          ),

          // Sección "Filtros de comentarios"
          Padding(
            padding: const EdgeInsets.only(left: 4, top: 22, bottom: 8),
            child: Text(
              'Filtros de comentarios',
              style: TextStyle(
                color: Colors.grey[400],
                fontSize: 13,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          Container(
            decoration: BoxDecoration(
              color: const Color(0xFF1E1E1E),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              children: [
                // Fila 1: Modo Control para creadores
                _buildFilterSwitchRow(
                  title: 'Modo Control para creadores',
                  subtitle:
                      'Activa esta opción para ocultar automáticamente comentarios ofensivos o poco relevantes hasta que decidas aprobarlos.',
                  value: _creatorControlMode,
                  onChanged: (v) => setState(() => _creatorControlMode = v),
                ),
                _buildDivider(),

                // Fila 2: Filtra comentarios no deseados
                _buildFilterSwitchRow(
                  title: 'Filtra comentarios no deseados',
                  subtitle:
                      'Oculta comentarios que el sistema detecte como spam o contenido inapropiado antes de mostrarse en tus videos.',
                  value: _filterSpam,
                  onChanged: (v) => setState(() => _filterSpam = v),
                ),
                _buildDivider(),

                // Fila 3: Filtra palabras clave específicas
                _buildFilterNavRow(
                  title: 'Filtra palabras clave específicas',
                  subtitle:
                      'Agrega palabras o frases que quieras ocultar automáticamente en los comentarios de todas tus publicaciones.',
                ),
                _buildDivider(),

                // Fila 4: Revisar comentarios filtrados
                _buildFilterNavRow(
                  title: 'Revisar comentarios filtrados',
                  subtitle: 'Se mostrarán solo los comentarios aprobados',
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDivider() {
    return Divider(
      height: 1,
      thickness: 1,
      color: Colors.white.withOpacity(0.05),
      indent: 16,
    );
  }

  Widget _buildFilterSwitchRow({
    required String title,
    required String subtitle,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return InkWell(
      onTap: () => onChanged(!value),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    style: TextStyle(
                      color: Colors.grey[400],
                      fontSize: 12,
                      height: 1.35,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 12),
            Switch(
              value: value,
              activeColor: Colors.white,
              activeTrackColor: const Color(0xFF25F4EE),
              inactiveThumbColor: Colors.white,
              inactiveTrackColor: Colors.grey[700],
              onChanged: onChanged,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterNavRow({
    required String title,
    required String subtitle,
  }) {
    return InkWell(
      onTap: () {},
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    style: TextStyle(
                      color: Colors.grey[400],
                      fontSize: 12,
                      height: 1.35,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 12),
            Icon(Icons.chevron_right, color: Colors.grey[600], size: 20),
          ],
        ),
      ),
    );
  }
}`,
  },
  {
    id: 'direct_messages_settings_screen',
    path: 'lib/screens/direct_messages_settings_screen.dart',
    phase: 'Ajustes · Mensajes directos',
    language: 'dart',
    summary:
      'Pantalla Mensajes directos con Ajustes de permisos, Estado de lectura (Switch true), Estado de actividad (Público >), Modo seguro (Switch true) y Palabras clave filtradas.',
    code: `import 'package:flutter/material.dart';

class DirectMessagesSettingsScreen extends StatefulWidget {
  const DirectMessagesSettingsScreen({super.key});

  @override
  State<DirectMessagesSettingsScreen> createState() =>
      _DirectMessagesSettingsScreenState();
}

class _DirectMessagesSettingsScreenState
    extends State<DirectMessagesSettingsScreen> {
  bool _readStatus = true;
  bool _safeMode = true;
  String _activityStatus = 'Público';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF121212),
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Mensajes directos',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            decoration: BoxDecoration(
              color: const Color(0xFF1E1E1E),
              borderRadius: BorderRadius.circular(12),
            ),
            child: ListTile(
              title: const Text(
                'Ajustes de permisos',
                style: TextStyle(color: Colors.white, fontSize: 15),
              ),
              trailing: Icon(Icons.chevron_right, color: Colors.grey[500]),
              onTap: () {},
            ),
          ),
          const SizedBox(height: 20),
          Text(
            'Preferencias de mensajes',
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 13,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 8),
          Container(
            decoration: BoxDecoration(
              color: const Color(0xFF1E1E1E),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              children: [
                SwitchListTile(
                  value: _readStatus,
                  activeTrackColor: const Color(0xFFFF5722),
                  title: const Text(
                    'Estado de lectura',
                    style: TextStyle(color: Colors.white, fontSize: 15),
                  ),
                  subtitle: Text(
                    'Las personas pueden ver cuándo leíste sus mensajes si ambos tienen esta función activada.',
                    style: TextStyle(color: Colors.grey[400], fontSize: 12),
                  ),
                  onChanged: (val) => setState(() => _readStatus = val),
                ),
                const Divider(height: 1, color: Colors.white10),
                ListTile(
                  title: const Text(
                    'Estado de actividad',
                    style: TextStyle(color: Colors.white, fontSize: 15),
                  ),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        _activityStatus,
                        style: TextStyle(color: Colors.grey[400], fontSize: 13),
                      ),
                      const SizedBox(width: 4),
                      Icon(Icons.chevron_right, color: Colors.grey[500]),
                    ],
                  ),
                  onTap: () {
                    setState(() {
                      _activityStatus = _activityStatus == 'Público'
                          ? 'Solo amigos'
                          : 'Público';
                    });
                  },
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          Text(
            'Herramientas de seguridad',
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 13,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 8),
          Container(
            decoration: BoxDecoration(
              color: const Color(0xFF1E1E1E),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              children: [
                SwitchListTile(
                  value: _safeMode,
                  activeTrackColor: const Color(0xFFFF5722),
                  title: const Text(
                    'Modo seguro',
                    style: TextStyle(color: Colors.white, fontSize: 15),
                  ),
                  subtitle: Text(
                    'Filtra automáticamente mensajes que podrían contener contenido ofensivo.',
                    style: TextStyle(color: Colors.grey[400], fontSize: 12),
                  ),
                  onChanged: (val) => setState(() => _safeMode = val),
                ),
                const Divider(height: 1, color: Colors.white10),
                ListTile(
                  title: const Text(
                    'Palabras clave filtradas',
                    style: TextStyle(color: Colors.white, fontSize: 15),
                  ),
                  trailing: Icon(Icons.chevron_right, color: Colors.grey[500]),
                  onTap: () {},
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}`,
  },
  {
    id: 'reuse_content_screen',
    path: 'lib/screens/reuse_content_screen.dart',
    phase: 'Ajustes · Reutilizar contenido',
    language: 'dart',
    summary:
      'Pantalla Reutilizar contenido con selector de audiencia ("Todo el m...") e historial de reutilización.',
    code: `import 'package:flutter/material.dart';

class ReuseContentScreen extends StatelessWidget {
  const ReuseContentScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF121212),
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Reutilizar contenido',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            decoration: BoxDecoration(
              color: const Color(0xFF1E1E1E),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              children: [
                ListTile(
                  title: const Text(
                    'Permite reutilizar contenido desde',
                    style: TextStyle(color: Colors.white, fontSize: 15),
                  ),
                  subtitle: Text(
                    'Elige quién puede reutilizar tus videos y fotos en nuevas creaciones.',
                    style: TextStyle(color: Colors.grey[400], fontSize: 12),
                  ),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        'Todo el m...',
                        style: TextStyle(color: Colors.grey[400], fontSize: 13),
                      ),
                      const SizedBox(width: 4),
                      Icon(Icons.chevron_right, color: Colors.grey[500]),
                    ],
                  ),
                  onTap: () {},
                ),
                const Divider(height: 1, color: Colors.white10),
                ListTile(
                  title: const Text(
                    'Historial de reutilización de contenido',
                    style: TextStyle(color: Colors.white, fontSize: 15),
                  ),
                  subtitle: Text(
                    'Consulta qué creadores han utilizado tus clips o sonidos.',
                    style: TextStyle(color: Colors.grey[400], fontSize: 12),
                  ),
                  trailing: Icon(Icons.chevron_right, color: Colors.grey[500]),
                  onTap: () {},
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}`,
  },
  {
    id: 'downloads_settings_screen',
    path: 'lib/screens/downloads_settings_screen.dart',
    phase: 'Ajustes · Descargas',
    language: 'dart',
    summary:
      'Pantalla Descargas con Switch Descargas de videos (true por defecto) y subtítulo explicativo.',
    code: `import 'package:flutter/material.dart';

class DownloadsSettingsScreen extends StatefulWidget {
  const DownloadsSettingsScreen({super.key});

  @override
  State<DownloadsSettingsScreen> createState() =>
      _DownloadsSettingsScreenState();
}

class _DownloadsSettingsScreenState extends State<DownloadsSettingsScreen> {
  bool _downloadsEnabled = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF121212),
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Descargas',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            decoration: BoxDecoration(
              color: const Color(0xFF1E1E1E),
              borderRadius: BorderRadius.circular(12),
            ),
            child: SwitchListTile(
              value: _downloadsEnabled,
              activeTrackColor: const Color(0xFFFF5722),
              title: const Text(
                'Descargas de videos',
                style: TextStyle(color: Colors.white, fontSize: 15),
              ),
              subtitle: Text(
                'Permite que otras personas descarguen tus videos y los compartan en otras plataformas. Si desactivas esta opción, nadie podrá descargar tus publicaciones futuras.',
                style: TextStyle(color: Colors.grey[400], fontSize: 12),
              ),
              onChanged: (val) => setState(() => _downloadsEnabled = val),
            ),
          ),
        ],
      ),
    );
  }
}`,
  },
  {
    id: 'privacy_audience_bottom_sheet',
    path: 'lib/screens/privacy_audience_bottom_sheet.dart',
    phase: 'Ajustes · Bottom Sheets Blancos',
    language: 'dart',
    summary:
      'showPrivacyAudienceBottomSheet con fondo blanco para Lista Siguiendo y Videos que te gustaron, Radio Buttons interactivos y botón X.',
    code: `import 'package:flutter/material.dart';

void showPrivacyAudienceBottomSheet({
  required BuildContext context,
  required String title,
  required String question,
  required String footerNote,
  required String currentValue,
  required ValueChanged<String> onSelected,
}) {
  showModalBottomSheet(
    context: context,
    backgroundColor: Colors.white,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
    ),
    builder: (sheetContext) {
      return SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Stack(
                alignment: Alignment.center,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: Colors.black,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Align(
                    alignment: Alignment.centerRight,
                    child: IconButton(
                      onPressed: () => Navigator.pop(sheetContext),
                      icon: const Icon(Icons.close, color: Colors.black87),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                question,
                style: const TextStyle(
                  color: Colors.black87,
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 8),
              RadioListTile<String>(
                value: 'Todo el mundo',
                groupValue: currentValue,
                activeColor: const Color(0xFFFF5722),
                contentPadding: EdgeInsets.zero,
                controlAffinity: ListTileControlAffinity.trailing,
                title: const Text(
                  'Todo el mundo',
                  style: TextStyle(color: Colors.black, fontWeight: FontWeight.w600),
                ),
                onChanged: (val) {
                  if (val != null) onSelected(val);
                  Navigator.pop(sheetContext);
                },
              ),
              RadioListTile<String>(
                value: 'Solo tú',
                groupValue: currentValue,
                activeColor: const Color(0xFFFF5722),
                contentPadding: EdgeInsets.zero,
                controlAffinity: ListTileControlAffinity.trailing,
                title: const Text(
                  'Solo tú',
                  style: TextStyle(color: Colors.black, fontWeight: FontWeight.w600),
                ),
                onChanged: (val) {
                  if (val != null) onSelected(val);
                  Navigator.pop(sheetContext);
                },
              ),
              const SizedBox(height: 8),
              Text(
                footerNote,
                style: TextStyle(color: Colors.grey[600], fontSize: 12),
              ),
            ],
          ),
        ),
      );
    },
  );
}`,
  },
  {
    id: 'viewers_settings_screen',
    path: 'lib/screens/viewers_settings_screen.dart',
    phase: 'Ajustes · Espectadores',
    language: 'dart',
    summary:
      'Pantalla Espectadores con aviso superior descartable (X) y Switch Historial de espectadores (true por defecto).',
    code: `import 'package:flutter/material.dart';

class ViewersSettingsScreen extends StatefulWidget {
  const ViewersSettingsScreen({super.key});

  @override
  State<ViewersSettingsScreen> createState() => _ViewersSettingsScreenState();
}

class _ViewersSettingsScreenState extends State<ViewersSettingsScreen> {
  bool _showBanner = true;
  bool _viewerHistory = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF121212),
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Espectadores',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (_showBanner)
            Container(
              margin: const EdgeInsets.only(bottom: 16),
              padding: const EdgeInsets.fromLTRB(16, 14, 10, 14),
              decoration: BoxDecoration(
                color: const Color(0xFF27272A),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Text(
                      'Ahora los historiales de visitas al perfil y visualizaciones de publicaciones se fusionan en un único panel de espectadores.',
                      style: TextStyle(color: Colors.grey[300], fontSize: 13),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, color: Colors.white70, size: 20),
                    onPressed: () => setState(() => _showBanner = false),
                  ),
                ],
              ),
            ),
          Container(
            decoration: BoxDecoration(
              color: const Color(0xFF1E1E1E),
              borderRadius: BorderRadius.circular(12),
            ),
            child: SwitchListTile(
              value: _viewerHistory,
              activeTrackColor: const Color(0xFFFF5722),
              title: const Text(
                'Historial de espectadores',
                style: TextStyle(color: Colors.white, fontSize: 15),
              ),
              subtitle: Text(
                'Mira quién vio tus publicaciones durante los últimos 7 días y permite que tus seguidores vean cuando tú visualizas sus clips.',
                style: TextStyle(color: Colors.grey[400], fontSize: 12),
              ),
              onChanged: (val) => setState(() => _viewerHistory = val),
            ),
          ),
        ],
      ),
    );
  }
}`,
  },
  {
    id: 'music_settings_screen',
    path: 'lib/screens/music_settings_screen.dart',
    phase: 'Ajustes · Música',
    language: 'dart',
    summary:
      'Pantalla Música con sección Aplicación de música, ListTile Agregar a la aplicación de música y acción Vincular >.',
    code: `import 'package:flutter/material.dart';

class MusicSettingsScreen extends StatefulWidget {
  const MusicSettingsScreen({super.key});

  @override
  State<MusicSettingsScreen> createState() => _MusicSettingsScreenState();
}

class _MusicSettingsScreenState extends State<MusicSettingsScreen> {
  bool _linked = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF121212),
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Música',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(
            'Aplicación de música',
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 13,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 8),
          Container(
            decoration: BoxDecoration(
              color: const Color(0xFF1E1E1E),
              borderRadius: BorderRadius.circular(12),
            ),
            child: ListTile(
              title: const Text(
                'Agregar a la aplicación de música',
                style: TextStyle(color: Colors.white, fontSize: 15),
              ),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    _linked ? 'Vinculada' : 'Vincular',
                    style: TextStyle(
                      color: _linked ? const Color(0xFFE91E63) : Colors.grey[300],
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(width: 4),
                  Icon(Icons.chevron_right, color: Colors.grey[500]),
                ],
              ),
              onTap: () => setState(() => _linked = !_linked),
            ),
          ),
        ],
      ),
    );
  }
}`,
  },
  {
    id: 'inbox_settings_screen',
    path: 'lib/screens/inbox_settings_screen.dart',
    phase: 'Ajustes · Bandeja de entrada y mensajes',
    language: 'dart',
    summary:
      'StatefulWidget con dos tarjetas seleccionables (Personal vs Profesional), viñetas exactas y Radio Buttons rosas.',
    code: `import 'package:flutter/material.dart';

class InboxSettingsScreen extends StatefulWidget {
  const InboxSettingsScreen({super.key});

  @override
  State<InboxSettingsScreen> createState() => _InboxSettingsScreenState();
}

class _InboxSettingsScreenState extends State<InboxSettingsScreen> {
  String _selectedMode = 'personal';

  Widget _buildExperienceCard({
    required String id,
    required String title,
    required List<String> bullets,
  }) {
    final bool isSelected = _selectedMode == id;
    const Color pinkAccent = Color(0xFFE91E63);

    return Card(
      color: const Color(0xFF1E1E1E),
      margin: const EdgeInsets.only(bottom: 14),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: BorderSide(
          color: isSelected ? pinkAccent : Colors.white10,
          width: 1.5,
        ),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () => setState(() => _selectedMode = id),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      title,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  Radio<String>(
                    value: id,
                    groupValue: _selectedMode,
                    activeColor: pinkAccent,
                    fillColor: WidgetStateProperty.resolveWith<Color>(
                      (states) => isSelected ? pinkAccent : Colors.grey,
                    ),
                    onChanged: (val) {
                      if (val != null) setState(() => _selectedMode = val);
                    },
                  ),
                ],
              ),
              const SizedBox(height: 8),
              ...bullets.map(
                (b) => Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('• ', style: TextStyle(color: Colors.white70)),
                      Expanded(
                        child: Text(
                          b,
                          style: TextStyle(color: Colors.grey[300], fontSize: 13),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF121212),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'Selecciona una experiencia de mensajería',
            style: TextStyle(
              color: Colors.white,
              fontSize: 22,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 20),
          _buildExperienceCard(
            id: 'personal',
            title: 'Personal: chatea con amigos',
            bullets: [
              'Herramientas de mensajería básicas',
              'Recibir todas las notificaciones',
            ],
          ),
          _buildExperienceCard(
            id: 'profesional',
            title: 'Profesional: interactúa con tus seguidores',
            bullets: [
              'Herramientas avanzadas de mensajería y respuestas rápidas',
              'Carpetas separadas para mensajes principales y solicitudes',
              'Control de notificaciones para creadores',
            ],
          ),
        ],
      ),
    );
  }
}`,
  },
  {
    id: 'audience_control_screen',
    path: 'lib/screens/audience_control_screen.dart',
    phase: 'Ajustes · Control del público',
    language: 'dart',
    summary:
      'Pantalla Control del público con Switch Mayores de 18 años en false por defecto.',
    code: `import 'package:flutter/material.dart';

class AudienceControlScreen extends StatefulWidget {
  const AudienceControlScreen({super.key});

  @override
  State<AudienceControlScreen> createState() => _AudienceControlScreenState();
}

class _AudienceControlScreenState extends State<AudienceControlScreen> {
  bool _adultsOnly = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF121212),
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Control del público',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            decoration: BoxDecoration(
              color: const Color(0xFF1E1E1E),
              borderRadius: BorderRadius.circular(12),
            ),
            child: SwitchListTile(
              value: _adultsOnly,
              activeTrackColor: const Color(0xFFE91E63),
              title: const Text(
                'Mayores de 18 años',
                style: TextStyle(color: Colors.white, fontSize: 15),
              ),
              subtitle: Text(
                'Activa este ajuste si tu contenido está pensado únicamente para público adulto. Las publicaciones restringidas solo serán visibles para usuarios mayores de 18 años.',
                style: TextStyle(color: Colors.grey[400], fontSize: 12),
              ),
              onChanged: (val) => setState(() => _adultsOnly = val),
            ),
          ),
        ],
      ),
    );
  }
}`,
  },
  {
    id: 'ads_settings_screen',
    path: 'lib/screens/ads_settings_screen.dart',
    phase: 'Ajustes · Plan y anuncios',
    language: 'dart',
    summary:
      'Pantalla Plan y anuncios con temas de anuncios, datos personales, silenciar anunciantes, 2 switches y acciones fuera de Viroklipz.',
    code: `import 'package:flutter/material.dart';

class AdsSettingsScreen extends StatefulWidget {
  const AdsSettingsScreen({super.key});

  @override
  State<AdsSettingsScreen> createState() => _AdsSettingsScreenState();
}

class _AdsSettingsScreenState extends State<AdsSettingsScreen> {
  bool _offAppTargetedAds = true;
  bool _personalizedAds = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF121212),
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Plan y anuncios',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(
            'Administra los anuncios que ves',
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 13,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 8),
          Container(
            decoration: BoxDecoration(
              color: const Color(0xFF1E1E1E),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              children: [
                ListTile(
                  title: const Text(
                    'Gestionar los temas de los anuncios',
                    style: TextStyle(color: Colors.white, fontSize: 15),
                  ),
                  subtitle: Text(
                    'Elige los intereses y categorías de anuncios que prefieres ver.',
                    style: TextStyle(color: Colors.grey[400], fontSize: 12),
                  ),
                  trailing: Icon(Icons.chevron_right, color: Colors.grey[500]),
                  onTap: () {},
                ),
                const Divider(height: 1, color: Colors.white10),
                ListTile(
                  title: const Text(
                    'Modificar los datos personales',
                    style: TextStyle(color: Colors.white, fontSize: 15),
                  ),
                  subtitle: Text(
                    'Actualiza cómo se utiliza tu perfil para personalizar promociones.',
                    style: TextStyle(color: Colors.grey[400], fontSize: 12),
                  ),
                  trailing: Icon(Icons.chevron_right, color: Colors.grey[500]),
                  onTap: () {},
                ),
                const Divider(height: 1, color: Colors.white10),
                ListTile(
                  title: const Text(
                    'Silenciar anunciantes',
                    style: TextStyle(color: Colors.white, fontSize: 15),
                  ),
                  subtitle: Text(
                    'Silencia marcas específicas cuyos anuncios no deseas ver.',
                    style: TextStyle(color: Colors.grey[400], fontSize: 12),
                  ),
                  trailing: Icon(Icons.chevron_right, color: Colors.grey[500]),
                  onTap: () {},
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          Text(
            'Administra tus datos fuera de Viroklipz',
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 13,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 8),
          Container(
            decoration: BoxDecoration(
              color: const Color(0xFF1E1E1E),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              children: [
                SwitchListTile(
                  value: _offAppTargetedAds,
                  activeTrackColor: const Color(0xFFE91E63),
                  title: const Text(
                    'Anuncios dirigidos fuera de Viroklipz',
                    style: TextStyle(color: Colors.white, fontSize: 15),
                  ),
                  subtitle: Text(
                    'Los anunciantes pueden mostrar promociones basadas en tu actividad fuera de la plataforma.',
                    style: TextStyle(color: Colors.grey[400], fontSize: 12),
                  ),
                  onChanged: (val) =>
                      setState(() => _offAppTargetedAds = val),
                ),
                const Divider(height: 1, color: Colors.white10),
                SwitchListTile(
                  value: _personalizedAds,
                  activeTrackColor: const Color(0xFFE91E63),
                  title: const Text(
                    'Anuncios personalizados',
                    style: TextStyle(color: Colors.white, fontSize: 15),
                  ),
                  subtitle: Text(
                    'Usa tus intereses y actividad en Viroklipz para mostrar anuncios más relevantes.',
                    style: TextStyle(color: Colors.grey[400], fontSize: 12),
                  ),
                  onChanged: (val) => setState(() => _personalizedAds = val),
                ),
                const Divider(height: 1, color: Colors.white10),
                ListTile(
                  title: const Text(
                    'Desconectar anunciantes',
                    style: TextStyle(color: Colors.white, fontSize: 15),
                  ),
                  trailing: Icon(Icons.chevron_right, color: Colors.grey[500]),
                  onTap: () {},
                ),
                const Divider(height: 1, color: Colors.white10),
                ListTile(
                  title: const Text(
                    'Borrar datos de actividad fuera de Viroklipz',
                    style: TextStyle(color: Colors.white, fontSize: 15),
                  ),
                  trailing: Icon(Icons.chevron_right, color: Colors.grey[500]),
                  onTap: () {},
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}`,
  },
  {
    id: 'playback_settings_screen',
    path: 'lib/screens/playback_settings_screen.dart',
    phase: 'Ajustes · Reproducción',
    language: 'dart',
    summary:
      'Pantalla Reproducción con 4 switches de silencio inicial, ajuste automático de volumen, rotación y etiquetas.',
    code: `import 'package:flutter/material.dart';

class PlaybackSettingsScreen extends StatefulWidget {
  const PlaybackSettingsScreen({super.key});

  @override
  State<PlaybackSettingsScreen> createState() => _PlaybackSettingsScreenState();
}

class _PlaybackSettingsScreenState extends State<PlaybackSettingsScreen> {
  bool _openMuted = false;
  bool _autoVolume = true;
  bool _autoRotate = false;
  bool _showObjectTags = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF121212),
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Reproducción',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            decoration: BoxDecoration(
              color: const Color(0xFF1E1E1E),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              children: [
                SwitchListTile(
                  value: _openMuted,
                  activeTrackColor: const Color(0xFFE91E63),
                  title: const Text(
                    'Abrir Viroklipz en silencio',
                    style: TextStyle(color: Colors.white, fontSize: 15),
                  ),
                  subtitle: Text(
                    'Los videos permanecerán silenciados hasta que presiones el control de volumen.',
                    style: TextStyle(color: Colors.grey[400], fontSize: 12),
                  ),
                  onChanged: (val) => setState(() => _openMuted = val),
                ),
                const Divider(height: 1, color: Colors.white10),
                SwitchListTile(
                  value: _autoVolume,
                  activeTrackColor: const Color(0xFFE91E63),
                  title: const Text(
                    'Ajuste automático del volumen',
                    style: TextStyle(color: Colors.white, fontSize: 15),
                  ),
                  subtitle: Text(
                    'Equilibra automáticamente el nivel de audio entre distintos clips.',
                    style: TextStyle(color: Colors.grey[400], fontSize: 12),
                  ),
                  onChanged: (val) => setState(() => _autoVolume = val),
                ),
                const Divider(height: 1, color: Colors.white10),
                SwitchListTile(
                  value: _autoRotate,
                  activeTrackColor: const Color(0xFFE91E63),
                  title: const Text(
                    'Rotación automática',
                    style: TextStyle(color: Colors.white, fontSize: 15),
                  ),
                  subtitle: Text(
                    'Adapta la orientación de pantalla al girar el dispositivo.',
                    style: TextStyle(color: Colors.grey[400], fontSize: 12),
                  ),
                  onChanged: (val) => setState(() => _autoRotate = val),
                ),
                const Divider(height: 1, color: Colors.white10),
                SwitchListTile(
                  value: _showObjectTags,
                  activeTrackColor: const Color(0xFFE91E63),
                  title: const Text(
                    'Mostrar etiquetas de objetos',
                    style: TextStyle(color: Colors.white, fontSize: 15),
                  ),
                  subtitle: Text(
                    'Muestra información contextual sobre productos y elementos en pantalla.',
                    style: TextStyle(color: Colors.grey[400], fontSize: 12),
                  ),
                  onChanged: (val) => setState(() => _showObjectTags = val),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}`,
  },
  {
    id: 'display_settings_screen',
    path: 'lib/screens/display_settings_screen.dart',
    phase: 'Ajustes · Mostrar',
    language: 'dart',
    summary:
      'Pantalla Mostrar con selector visual de Aspecto (Claro y Oscuro) mediante Radio y Switch Usar ajustes del dispositivo.',
    code: `import 'package:flutter/material.dart';

class DisplaySettingsScreen extends StatefulWidget {
  const DisplaySettingsScreen({super.key});

  @override
  State<DisplaySettingsScreen> createState() => _DisplaySettingsScreenState();
}

class _DisplaySettingsScreenState extends State<DisplaySettingsScreen> {
  String _selectedTheme = 'oscuro';
  bool _useDeviceSettings = false;

  Widget _buildThemeMockup({
    required String id,
    required String label,
    required bool isDarkPreview,
  }) {
    final bool selected = _selectedTheme == id;
    const Color pinkAccent = Color(0xFFE91E63);

    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _selectedTheme = id),
        child: Column(
          children: [
            Container(
              height: 132,
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: isDarkPreview
                    ? const Color(0xFF141416)
                    : const Color(0xFFF4F4F5),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: selected ? pinkAccent : Colors.white12,
                  width: 2,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 18,
                        height: 18,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: isDarkPreview
                              ? Colors.white24
                              : Colors.black12,
                        ),
                      ),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Container(
                          height: 8,
                          decoration: BoxDecoration(
                            color: isDarkPreview
                                ? Colors.white24
                                : Colors.black12,
                            borderRadius: BorderRadius.circular(4),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Expanded(
                    child: Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: isDarkPreview
                            ? const Color(0xFF27272A)
                            : Colors.white,
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    width: 48,
                    height: 6,
                    decoration: BoxDecoration(
                      color: pinkAccent,
                      borderRadius: BorderRadius.circular(3),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),
            Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
            ),
            Radio<String>(
              value: id,
              groupValue: _selectedTheme,
              activeColor: pinkAccent,
              onChanged: (val) {
                if (val != null) setState(() => _selectedTheme = val);
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF121212),
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Mostrar',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(
            'Aspecto',
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 13,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFF1E1E1E),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              children: [
                _buildThemeMockup(
                  id: 'claro',
                  label: 'Claro',
                  isDarkPreview: false,
                ),
                const SizedBox(width: 16),
                _buildThemeMockup(
                  id: 'oscuro',
                  label: 'Oscuro',
                  isDarkPreview: true,
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Container(
            decoration: BoxDecoration(
              color: const Color(0xFF1E1E1E),
              borderRadius: BorderRadius.circular(12),
            ),
            child: SwitchListTile(
              value: _useDeviceSettings,
              activeTrackColor: const Color(0xFFE91E63),
              title: const Text(
                'Usar ajustes del dispositivo',
                style: TextStyle(color: Colors.white, fontSize: 15),
              ),
              subtitle: Text(
                'Adapta automáticamente el aspecto de Viroklipz al tema de tu teléfono.',
                style: TextStyle(color: Colors.grey[400], fontSize: 12),
              ),
              onChanged: (val) => setState(() => _useDeviceSettings = val),
            ),
          ),
        ],
      ),
    );
  }
}`,
  },
  {
    id: 'language_settings_screen',
    path: 'lib/screens/language_settings_screen.dart',
    phase: 'Ajustes · Idiomas',
    language: 'dart',
    summary:
      'Pantalla Idiomas con Idioma de la aplicación (Español >) y sección Traducción.',
    code: `import 'package:flutter/material.dart';

class LanguageSettingsScreen extends StatefulWidget {
  const LanguageSettingsScreen({super.key});

  @override
  State<LanguageSettingsScreen> createState() => _LanguageSettingsScreenState();
}

class _LanguageSettingsScreenState extends State<LanguageSettingsScreen> {
  bool _alwaysTranslate = false;

  Widget _buildTrailingValue(String value) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          value,
          style: TextStyle(color: Colors.grey[400], fontSize: 13),
        ),
        const SizedBox(width: 4),
        Icon(Icons.chevron_right, color: Colors.grey[500]),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF121212),
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Idiomas',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            decoration: BoxDecoration(
              color: const Color(0xFF1E1E1E),
              borderRadius: BorderRadius.circular(12),
            ),
            child: ListTile(
              title: const Text(
                'Idioma de la aplicación',
                style: TextStyle(color: Colors.white, fontSize: 15),
              ),
              trailing: _buildTrailingValue('Español'),
              onTap: () {},
            ),
          ),
          const SizedBox(height: 20),
          Text(
            'Traducción',
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 13,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 8),
          Container(
            decoration: BoxDecoration(
              color: const Color(0xFF1E1E1E),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              children: [
                SwitchListTile(
                  value: _alwaysTranslate,
                  activeTrackColor: const Color(0xFFE91E63),
                  title: const Text(
                    'Traducir siempre las publicaciones',
                    style: TextStyle(color: Colors.white, fontSize: 15),
                  ),
                  subtitle: Text(
                    'Traduce automáticamente descripciones y comentarios a tu idioma preferido.',
                    style: TextStyle(color: Colors.grey[400], fontSize: 12),
                  ),
                  onChanged: (val) => setState(() => _alwaysTranslate = val),
                ),
                const Divider(height: 1, color: Colors.white10),
                ListTile(
                  title: const Text(
                    'Traducir a',
                    style: TextStyle(color: Colors.white, fontSize: 15),
                  ),
                  trailing: _buildTrailingValue('Español'),
                  onTap: () {},
                ),
                const Divider(height: 1, color: Colors.white10),
                ListTile(
                  title: const Text(
                    'No traducir',
                    style: TextStyle(color: Colors.white, fontSize: 15),
                  ),
                  trailing: _buildTrailingValue('Español'),
                  onTap: () {},
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}`,
  },
  {
    id: 'accessibility_settings_screen',
    path: 'lib/screens/accessibility_settings_screen.dart',
    phase: 'Ajustes · Accesibilidad',
    language: 'dart',
    summary:
      'Pantalla Accesibilidad con secciones Aspecto, Contenido y Movimiento y valores predeterminados exactos.',
    code: `import 'package:flutter/material.dart';

class AccessibilitySettingsScreen extends StatefulWidget {
  const AccessibilitySettingsScreen({super.key});

  @override
  State<AccessibilitySettingsScreen> createState() =>
      _AccessibilitySettingsScreenState();
}

class _AccessibilitySettingsScreenState
    extends State<AccessibilitySettingsScreen> {
  bool _highContrast = false;
  bool _skipPhotosensitive = false;
  bool _subtitles = false;
  bool _reducedMotion = true;
  bool _fasterScroll = true;
  bool _animatedThumbnails = false;

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Text(
        title,
        style: TextStyle(
          color: Colors.grey[400],
          fontSize: 13,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF121212),
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Accesibilidad',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildSectionTitle('Aspecto'),
          Container(
            decoration: BoxDecoration(
              color: const Color(0xFF1E1E1E),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              children: [
                ListTile(
                  title: const Text(
                    'Tamaño de texto',
                    style: TextStyle(color: Colors.white, fontSize: 15),
                  ),
                  trailing: Icon(Icons.chevron_right, color: Colors.grey[500]),
                  onTap: () {},
                ),
                const Divider(height: 1, color: Colors.white10),
                SwitchListTile(
                  value: _highContrast,
                  activeTrackColor: const Color(0xFFE91E63),
                  title: const Text(
                    'Aumenta el contraste de color',
                    style: TextStyle(color: Colors.white, fontSize: 15),
                  ),
                  onChanged: (val) => setState(() => _highContrast = val),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          _buildSectionTitle('Contenido'),
          Container(
            decoration: BoxDecoration(
              color: const Color(0xFF1E1E1E),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              children: [
                SwitchListTile(
                  value: _skipPhotosensitive,
                  activeTrackColor: const Color(0xFFE91E63),
                  title: const Text(
                    'Omitir publicaciones no aptas para fotosensibles',
                    style: TextStyle(color: Colors.white, fontSize: 15),
                  ),
                  onChanged: (val) =>
                      setState(() => _skipPhotosensitive = val),
                ),
                const Divider(height: 1, color: Colors.white10),
                SwitchListTile(
                  value: _subtitles,
                  activeTrackColor: const Color(0xFFE91E63),
                  title: const Text(
                    'Subtítulos',
                    style: TextStyle(color: Colors.white, fontSize: 15),
                  ),
                  onChanged: (val) => setState(() => _subtitles = val),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          _buildSectionTitle('Movimiento'),
          Container(
            decoration: BoxDecoration(
              color: const Color(0xFF1E1E1E),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              children: [
                SwitchListTile(
                  value: _reducedMotion,
                  activeTrackColor: const Color(0xFFE91E63),
                  title: const Text(
                    'Reduced motion',
                    style: TextStyle(color: Colors.white, fontSize: 15),
                  ),
                  onChanged: (val) => setState(() => _reducedMotion = val),
                ),
                const Divider(height: 1, color: Colors.white10),
                SwitchListTile(
                  value: _fasterScroll,
                  activeTrackColor: const Color(0xFFE91E63),
                  title: const Text(
                    'Mayor velocidad de desplazamiento',
                    style: TextStyle(color: Colors.white, fontSize: 15),
                  ),
                  onChanged: (val) => setState(() => _fasterScroll = val),
                ),
                const Divider(height: 1, color: Colors.white10),
                SwitchListTile(
                  value: _animatedThumbnails,
                  activeTrackColor: const Color(0xFFE91E63),
                  title: const Text(
                    'Miniaturas animadas',
                    style: TextStyle(color: Colors.white, fontSize: 15),
                  ),
                  onChanged: (val) =>
                      setState(() => _animatedThumbnails = val),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}`,
  },
  {
    id: 'contacts_location_settings_screen',
    path: 'lib/screens/contacts_location_settings_screen.dart',
    phase: 'Ajustes · Contactos y ubicación',
    language: 'dart',
    summary:
      'Pantalla Contactos y ubicación con secciones Recomienda tu cuenta a otros y Sincronizar contactos y amigos de Facebook.',
    code: `import 'package:flutter/material.dart';

class ContactsLocationSettingsScreen extends StatefulWidget {
  const ContactsLocationSettingsScreen({super.key});

  @override
  State<ContactsLocationSettingsScreen> createState() =>
      _ContactsLocationSettingsScreenState();
}

class _ContactsLocationSettingsScreenState
    extends State<ContactsLocationSettingsScreen> {
  bool _contacts = true;
  bool _facebookFriends = true;
  bool _linkOpeners = true;
  bool _syncContacts = true;

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Text(
        title,
        style: TextStyle(
          color: Colors.grey[400],
          fontSize: 13,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF121212),
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Contactos y ubicación',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildSectionTitle('Recomienda tu cuenta a otros'),
          Container(
            decoration: BoxDecoration(
              color: const Color(0xFF1E1E1E),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              children: [
                SwitchListTile(
                  value: _contacts,
                  activeTrackColor: const Color(0xFFE91E63),
                  title: const Text(
                    'Contactos',
                    style: TextStyle(color: Colors.white, fontSize: 15),
                  ),
                  onChanged: (val) => setState(() => _contacts = val),
                ),
                const Divider(height: 1, color: Colors.white10),
                SwitchListTile(
                  value: _facebookFriends,
                  activeTrackColor: const Color(0xFFE91E63),
                  title: const Text(
                    'Amigos de Facebook',
                    style: TextStyle(color: Colors.white, fontSize: 15),
                  ),
                  onChanged: (val) => setState(() => _facebookFriends = val),
                ),
                const Divider(height: 1, color: Colors.white10),
                SwitchListTile(
                  value: _linkOpeners,
                  activeTrackColor: const Color(0xFFE91E63),
                  title: const Text(
                    'Usuarios que abrieron o te enviaron enlaces',
                    style: TextStyle(color: Colors.white, fontSize: 15),
                  ),
                  onChanged: (val) => setState(() => _linkOpeners = val),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          _buildSectionTitle('Sincronizar contactos y amigos de Facebook'),
          Container(
            decoration: BoxDecoration(
              color: const Color(0xFF1E1E1E),
              borderRadius: BorderRadius.circular(12),
            ),
            child: SwitchListTile(
              value: _syncContacts,
              activeTrackColor: const Color(0xFFE91E63),
              title: const Text(
                'Sincronizar contactos',
                style: TextStyle(color: Colors.white, fontSize: 15),
              ),
              subtitle: Text(
                'Sube y sincroniza periódicamente tus contactos para encontrar amigos en Viroklipz.',
                style: TextStyle(color: Colors.grey[400], fontSize: 12),
              ),
              onChanged: (val) => setState(() => _syncContacts = val),
            ),
          ),
        ],
      ),
    );
  }
}`,
  },
  {
    id: 'lite_mode_screen',
    path: 'lib/screens/lite_mode_screen.dart',
    phase: 'Ajustes · Modo lite',
    language: 'dart',
    summary:
      'Pantalla Modo lite con SwitchListTile activado por defecto y subtítulo descriptivo.',
    code: `import 'package:flutter/material.dart';

class LiteModeScreen extends StatefulWidget {
  const LiteModeScreen({super.key});

  @override
  State<LiteModeScreen> createState() => _LiteModeScreenState();
}

class _LiteModeScreenState extends State<LiteModeScreen> {
  bool _liteModeEnabled = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF121212),
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Modo lite',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            decoration: BoxDecoration(
              color: const Color(0xFF1E1E1E),
              borderRadius: BorderRadius.circular(12),
            ),
            child: SwitchListTile(
              value: _liteModeEnabled,
              activeTrackColor: const Color(0xFFE91E63),
              title: const Text(
                'Modo lite',
                style: TextStyle(color: Colors.white, fontSize: 15),
              ),
              subtitle: Text(
                'Optimiza el rendimiento de Viroklipz, reduce el uso de batería y disminuye el consumo de datos al reproducir videos en redes lentas.',
                style: TextStyle(color: Colors.grey[400], fontSize: 12),
              ),
              onChanged: (val) => setState(() => _liteModeEnabled = val),
            ),
          ),
        ],
      ),
    );
  }
}`,
  },
  {
    id: 'data_saver_screen',
    path: 'lib/screens/data_saver_screen.dart',
    phase: 'Ajustes · Ahorro de datos',
    language: 'dart',
    summary:
      'Pantalla Ahorro de datos con SwitchListTile desactivado por defecto y subtítulo.',
    code: `import 'package:flutter/material.dart';

class DataSaverScreen extends StatefulWidget {
  const DataSaverScreen({super.key});

  @override
  State<DataSaverScreen> createState() => _DataSaverScreenState();
}

class _DataSaverScreenState extends State<DataSaverScreen> {
  bool _dataSaverEnabled = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF121212),
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Ahorro de datos',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            decoration: BoxDecoration(
              color: const Color(0xFF1E1E1E),
              borderRadius: BorderRadius.circular(12),
            ),
            child: SwitchListTile(
              value: _dataSaverEnabled,
              activeTrackColor: const Color(0xFFE91E63),
              title: const Text(
                'Ahorro de datos',
                style: TextStyle(color: Colors.white, fontSize: 15),
              ),
              subtitle: Text(
                'Reduce el consumo de datos móviles cuando no estés conectado a una red Wi-Fi. Es posible que los videos tarden un poco más en cargarse o se muestren en menor resolución.',
                style: TextStyle(color: Colors.grey[400], fontSize: 12),
              ),
              onChanged: (val) => setState(() => _dataSaverEnabled = val),
            ),
          ),
        ],
      ),
    );
  }
}`,
  },
  {
    id: 'clear_space_screen',
    path: 'lib/screens/clear_space_screen.dart',
    phase: 'Ajustes · Liberar espacio',
    language: 'dart',
    summary:
      'Pantalla Liberar espacio con barra de progreso simulada, tarjeta Caché con botón Borrar y texto informativo.',
    code: `import 'package:flutter/material.dart';

class ClearSpaceScreen extends StatefulWidget {
  const ClearSpaceScreen({super.key});

  @override
  State<ClearSpaceScreen> createState() => _ClearSpaceScreenState();
}

class _ClearSpaceScreenState extends State<ClearSpaceScreen> {
  bool _cacheCleared = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF121212),
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Liberar espacio',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(
            'Datos de Viroklipz',
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 14,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            _cacheCleared ? '0.0 MB' : 'Calculando...',
            style: const TextStyle(
              color: Colors.white,
              fontSize: 28,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: LinearProgressIndicator(
              value: _cacheCleared ? 0.08 : 0.62,
              minHeight: 10,
              backgroundColor: const Color(0xFF27272A),
              valueColor: AlwaysStoppedAnimation<Color>(Colors.grey[500]!),
            ),
          ),
          const SizedBox(height: 24),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFF1E1E1E),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Caché:',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        _cacheCleared
                            ? 'La memoria caché temporal se ha limpiado correctamente.'
                            : 'Borrar la memoria caché para liberar espacio. Esto no afectará a tu experiencia en Viroklipz.',
                        style: TextStyle(color: Colors.grey[400], fontSize: 12),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _cacheCleared
                        ? Colors.grey[800]
                        : const Color(0xFFE91E63),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  onPressed: _cacheCleared
                      ? null
                      : () {
                          setState(() => _cacheCleared = true);
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('Memoria caché liberada'),
                            ),
                          );
                        },
                  child: Text(_cacheCleared ? 'Listo' : 'Borrar'),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Text(
            'La memoria caché incluye archivos temporales descargados mientras navegas para acelerar la carga de videos e imágenes. Al borrarla no se eliminarán tus borradores, publicaciones ni cuenta.',
            style: TextStyle(color: Colors.grey[500], fontSize: 12),
          ),
        ],
      ),
    );
  }
}`,
  },
  {
    id: 'wallpaper_settings_screen',
    path: 'lib/screens/wallpaper_settings_screen.dart',
    phase: 'Ajustes · Fondo de pantalla',
    language: 'dart',
    summary:
      'Pantalla Fondo de pantalla con estado vacío (engranaje punteado) y botones para SearchWallpaperScreen y HowToWallpaperBottomSheet.',
    code: `import 'package:flutter/material.dart';
import 'how_to_wallpaper_bottom_sheet.dart';
import 'search_wallpaper_screen.dart';

class WallpaperSettingsScreen extends StatelessWidget {
  const WallpaperSettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF121212),
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Fondo de pantalla',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings_outlined, color: Colors.white),
            onPressed: () {},
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 32),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 84,
                      height: 84,
                      decoration: BoxDecoration(
                        color: const Color(0xFF1E1E1E),
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: Colors.grey[700]!,
                          width: 2,
                        ),
                      ),
                      child: Icon(
                        Icons.settings_suggest_outlined,
                        size: 42,
                        color: Colors.grey[400],
                      ),
                    ),
                    const SizedBox(height: 20),
                    const Text(
                      'Aún no hay fondos de pantalla',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 17,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Tus fondos de pantalla descargados se mostrarán aquí',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.grey[400], fontSize: 13),
                    ),
                  ],
                ),
              ),
            ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFE91E63),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const SearchWallpaperScreen(),
                        ),
                      );
                    },
                    child: const Text(
                      'Buscar fondos de pantalla',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                  const SizedBox(height: 10),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF27272A),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    onPressed: () => showHowToWallpaperBottomSheet(context),
                    child: const Text(
                      'Descubre cómo establecer un fondo de pantalla',
                      style: TextStyle(fontSize: 13),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}`,
  },
  {
    id: 'how_to_wallpaper_bottom_sheet',
    path: 'lib/screens/how_to_wallpaper_bottom_sheet.dart',
    phase: 'Ajustes · Cómo establecer fondo de pantalla',
    language: 'dart',
    summary:
      'showModalBottomSheet oscuro con los pasos 1 y 2 para establecer un video como fondo de pantalla.',
    code: `import 'package:flutter/material.dart';

void showHowToWallpaperBottomSheet(BuildContext context) {
  showModalBottomSheet(
    context: context,
    backgroundColor: const Color(0xFF1E1E1E),
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
    ),
    builder: (sheetContext) {
      return SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  margin: const EdgeInsets.only(bottom: 12),
                  decoration: BoxDecoration(
                    color: Colors.grey[700],
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              Row(
                children: [
                  const Expanded(
                    child: Text(
                      'Cómo establecer un fondo de pantalla',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, color: Colors.white70),
                    onPressed: () => Navigator.pop(sheetContext),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: const [
                  Text(
                    '1. Pulsa ',
                    style: TextStyle(color: Colors.white, fontSize: 14),
                  ),
                  Icon(Icons.reply, color: Color(0xFFE91E63), size: 18),
                  Text(
                    ' en un video',
                    style: TextStyle(color: Colors.white, fontSize: 14),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Container(
                height: 110,
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: const Color(0xFF121212),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.white10),
                ),
                child: const Align(
                  alignment: Alignment.bottomRight,
                  child: CircleAvatar(
                    radius: 16,
                    backgroundColor: Color(0xFFE91E63),
                    child: Icon(Icons.reply, color: Colors.white, size: 16),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: const [
                  Text(
                    '2. Pulsa ',
                    style: TextStyle(color: Colors.white, fontSize: 14),
                  ),
                  Icon(Icons.play_arrow, color: Color(0xFFFF5722), size: 20),
                  Expanded(
                    child: Text(
                      ' para establecer este video como fondo',
                      style: TextStyle(color: Colors.white, fontSize: 14),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
                decoration: BoxDecoration(
                  color: const Color(0xFF121212),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.white10),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: const [
                    Icon(Icons.group_add_outlined, color: Colors.white54),
                    Icon(Icons.bookmark_border, color: Colors.white54),
                    CircleAvatar(
                      radius: 16,
                      backgroundColor: Color(0xFFE91E63),
                      child: Icon(Icons.play_arrow, color: Colors.white, size: 18),
                    ),
                    Icon(Icons.more_horiz, color: Colors.white54),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
    },
  );
}`,
  },
  {
    id: 'search_wallpaper_screen',
    path: 'lib/screens/search_wallpaper_screen.dart',
    phase: 'Ajustes · Buscar fondos de pantalla',
    language: 'dart',
    summary:
      'Pantalla SearchWallpaperScreen con barra de búsqueda Live Wallpaper, TabBar de 4 pestañas y GridView de 2 columnas.',
    code: `import 'package:flutter/material.dart';

class SearchWallpaperScreen extends StatefulWidget {
  const SearchWallpaperScreen({super.key});

  @override
  State<SearchWallpaperScreen> createState() => _SearchWallpaperScreenState();
}

class _SearchWallpaperScreenState extends State<SearchWallpaperScreen> {
  final TextEditingController _searchController =
      TextEditingController(text: 'Live Wallpaper');

  final List<Map<String, dynamic>> _items = const [
    {
      'title': 'Cyber Astronaut',
      'author': '@neon_pulse',
      'likes': '18.4K',
      'isVideo': true,
      'image':
          'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=600&auto=format&fit=crop',
    },
    {
      'title': 'Templo Dorado',
      'author': '@zen_visuals',
      'likes': '9.2K',
      'isVideo': true,
      'image':
          'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&auto=format&fit=crop',
    },
    {
      'title': 'Ciudad Nocturna 4K',
      'author': '@mateo_fx',
      'likes': '24.1K',
      'isVideo': true,
      'image':
          'https://images.unsplash.com/photo-1519608487953-e999c86e7455?w=600&auto=format&fit=crop',
    },
    {
      'title': 'Aesthetic Sunset',
      'author': '@valeria_art',
      'likes': '12.7K',
      'isVideo': false,
      'image':
          'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=600&auto=format&fit=crop',
    },
  ];

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Widget _buildWallpaperGrid() {
    return GridView.builder(
      padding: const EdgeInsets.all(12),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 0.68,
      ),
      itemCount: _items.length,
      itemBuilder: (context, index) {
        final item = _items[index];
        return Container(
          decoration: BoxDecoration(
            color: const Color(0xFF1E1E1E),
            borderRadius: BorderRadius.circular(12),
          ),
          clipBehavior: Clip.antiAlias,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    Image.network(item['image'] as String, fit: BoxFit.cover),
                    if (item['isVideo'] == true)
                      const Positioned(
                        top: 8,
                        right: 8,
                        child: CircleAvatar(
                          radius: 12,
                          backgroundColor: Colors.black54,
                          child: Icon(
                            Icons.volume_up,
                            color: Colors.white,
                            size: 14,
                          ),
                        ),
                      ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      item['title'] as String,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Text(
                            item['author'] as String,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: Colors.grey[400],
                              fontSize: 11,
                            ),
                          ),
                        ),
                        Row(
                          children: [
                            const Icon(
                              Icons.favorite,
                              color: Color(0xFFE91E63),
                              size: 12,
                            ),
                            const SizedBox(width: 3),
                            Text(
                              item['likes'] as String,
                              style: TextStyle(
                                color: Colors.grey[300],
                                fontSize: 11,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      child: Scaffold(
        backgroundColor: const Color(0xFF121212),
        appBar: AppBar(
          backgroundColor: const Color(0xFF121212),
          elevation: 0,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.white),
            onPressed: () => Navigator.pop(context),
          ),
          title: Container(
            height: 38,
            decoration: BoxDecoration(
              color: const Color(0xFF1E1E1E),
              borderRadius: BorderRadius.circular(10),
            ),
            child: TextField(
              controller: _searchController,
              style: const TextStyle(color: Colors.white, fontSize: 13),
              decoration: const InputDecoration(
                prefixIcon: Icon(Icons.search, color: Colors.grey, size: 18),
                border: InputBorder.none,
                contentPadding: EdgeInsets.symmetric(vertical: 9),
              ),
            ),
          ),
          bottom: const TabBar(
            indicatorColor: Color(0xFFE91E63),
            labelColor: Colors.white,
            unselectedLabelColor: Colors.grey,
            labelStyle: TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
            tabs: [
              Tab(text: 'Tendencias'),
              Tab(text: 'Videos'),
              Tab(text: 'Fotos'),
              Tab(text: 'Usuarios'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            _buildWallpaperGrid(),
            _buildWallpaperGrid(),
            _buildWallpaperGrid(),
            _buildWallpaperGrid(),
          ],
        ),
      ),
    );
  }
}`,
  },
  {
    id: 'help_center_screen',
    path: 'lib/screens/help_center_screen.dart',
    phase: 'Ajustes · Centro de ayuda (3 pestañas)',
    language: 'dart',
    summary:
      'DefaultTabController con pestañas Guía de uso, Monetización y Otros, preguntas frecuentes de Viroklipz, Ver más y botón Chatea con nosotros.',
    code: `import 'package:flutter/material.dart';
import 'help_category_screen.dart';

class HelpCenterScreen extends StatelessWidget {
  const HelpCenterScreen({super.key});

  void _openMore(BuildContext context, int initialTabIndex) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) =>
            HelpCategoryScreen(initialTabIndex: initialTabIndex),
      ),
    );
  }

  Widget _buildFaqTab({
    required BuildContext context,
    required List<String> items,
    required int categoryTabIndex,
  }) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          decoration: BoxDecoration(
            color: const Color(0xFF1E1E1E),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Column(
            children: List.generate(items.length, (index) {
              return Column(
                children: [
                  ListTile(
                    title: Text(
                      items[index],
                      style: const TextStyle(color: Colors.white, fontSize: 14),
                    ),
                    trailing:
                        Icon(Icons.chevron_right, color: Colors.grey[500]),
                    onTap: () => _openMore(context, categoryTabIndex),
                  ),
                  if (index < items.length - 1)
                    const Divider(height: 1, color: Colors.white10),
                ],
              );
            }),
          ),
        ),
        const SizedBox(height: 14),
        ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF1E1E1E),
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 13),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
          ),
          onPressed: () => _openMore(context, categoryTabIndex),
          child: const Text('Ver más'),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    const List<String> guideFaqs = [
      'Cómo crear y publicar videos en Viroklipz',
      'Edición, filtros, música y efectos',
      'Configurar tu perfil y privacidad',
      'Administrar notificaciones y feed Radar',
      'Seguridad y verificación de la cuenta',
    ];

    const List<String> monetizationFaqs = [
      'Viroklipz Plus',
      'Artículos no recibidos',
      'Commercial Content Library',
      'About AI-generated content',
      'Propiedad intelectual',
    ];

    const List<String> otherFaqs = [
      '¿Qué tipos de suscripciones existen?',
      '¿Por qué no puedo renovar mi suscripción?',
      '¿Cómo me suscribo a la comunidad de un creador...?',
      '¿Dónde puedo ver mis suscripciones?',
      '¿Cómo puedo cancelar una suscripción...?',
    ];

    return DefaultTabController(
      length: 3,
      child: Scaffold(
        backgroundColor: const Color(0xFF121212),
        appBar: AppBar(
          backgroundColor: const Color(0xFF121212),
          elevation: 0,
          centerTitle: true,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.white),
            onPressed: () => Navigator.pop(context),
          ),
          title: const Text(
            'Centro de ayuda',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
          ),
          bottom: const TabBar(
            indicatorColor: Color(0xFFE91E63),
            labelColor: Colors.white,
            unselectedLabelColor: Colors.grey,
            labelStyle: TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
            tabs: [
              Tab(text: 'Guía de uso'),
              Tab(text: 'Monetización'),
              Tab(text: 'Otros'),
            ],
          ),
        ),
        body: Column(
          children: [
            Expanded(
              child: TabBarView(
                children: [
                  _buildFaqTab(
                    context: context,
                    items: guideFaqs,
                    categoryTabIndex: 2,
                  ),
                  _buildFaqTab(
                    context: context,
                    items: monetizationFaqs,
                    categoryTabIndex: 0,
                  ),
                  _buildFaqTab(
                    context: context,
                    items: otherFaqs,
                    categoryTabIndex: 1,
                  ),
                ],
              ),
            ),
            SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
                child: SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFE91E63),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    icon: const Icon(Icons.chat_bubble_outline, size: 18),
                    label: const Text(
                      'Chatea con nosotros',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    onPressed: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Iniciando chat de soporte...'),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}`,
  },
  {
    id: 'help_category_screen',
    path: 'lib/screens/help_category_screen.dart',
    phase: 'Ajustes · Categorías de ayuda',
    language: 'dart',
    summary:
      'DefaultTabController con 3 pestañas (Cuenta, Privacidad y seguridad, Publicaciones), lista de preguntas, Ver más y botón Chatea con nosotros.',
    code: `import 'package:flutter/material.dart';

class HelpCategoryScreen extends StatelessWidget {
  final int initialTabIndex;

  const HelpCategoryScreen({super.key, this.initialTabIndex = 0});

  Widget _buildTabContent() {
    final items = const [
      'Informar de un problema técnico',
      'Estado de tu cuenta',
      'Edición, publicación y eliminación',
      'Seguridad de la cuenta',
    ];

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          decoration: BoxDecoration(
            color: const Color(0xFF1E1E1E),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Column(
            children: List.generate(items.length, (i) {
              return Column(
                children: [
                  ListTile(
                    title: Text(
                      items[i],
                      style: const TextStyle(color: Colors.white, fontSize: 14),
                    ),
                    trailing:
                        Icon(Icons.chevron_right, color: Colors.grey[500]),
                    onTap: () {},
                  ),
                  if (i < items.length - 1)
                    const Divider(height: 1, color: Colors.white10),
                ],
              );
            }),
          ),
        ),
        const SizedBox(height: 14),
        ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF1E1E1E),
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 12),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
          ),
          onPressed: () {},
          child: const Text('Ver más'),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      initialIndex: initialTabIndex,
      child: Scaffold(
        backgroundColor: const Color(0xFF121212),
        appBar: AppBar(
          backgroundColor: const Color(0xFF121212),
          elevation: 0,
          centerTitle: true,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.white),
            onPressed: () => Navigator.pop(context),
          ),
          title: const Text(
            'Categorías de ayuda',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
          ),
          bottom: const TabBar(
            indicatorColor: Color(0xFFE91E63),
            labelColor: Colors.white,
            unselectedLabelColor: Colors.grey,
            labelStyle: TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
            tabs: [
              Tab(text: 'Cuenta'),
              Tab(text: 'Privacidad y seguridad'),
              Tab(text: 'Publicaciones'),
            ],
          ),
        ),
        body: Column(
          children: [
            Expanded(
              child: TabBarView(
                children: [
                  _buildTabContent(),
                  _buildTabContent(),
                  _buildTabContent(),
                ],
              ),
            ),
            SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
                child: SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFE91E63),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    icon: const Icon(Icons.chat_bubble_outline, size: 18),
                    label: const Text(
                      'Chatea con nosotros',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    onPressed: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Iniciando chat de soporte...'),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}`,
  },
  {
    id: 'switch_account_bottom_sheet',
    path: 'lib/screens/switch_account_bottom_sheet.dart',
    phase: 'Ajustes · Cambiar de cuenta Bottom Sheet',
    language: 'dart',
    summary:
      'showModalBottomSheet oscuro conectado a AuthProvider (hasta 10 cuentas), check rojo activo, insignia roja 1 y Agregar cuenta.',
    code: `import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';

void showSwitchAccountBottomSheet(BuildContext context) {
  showModalBottomSheet(
    context: context,
    backgroundColor: const Color(0xFF1E1E1E),
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
    ),
    builder: (sheetContext) {
      return Consumer<AuthProvider>(
        builder: (context, auth, _) {
          return SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 40,
                    height: 4,
                    margin: const EdgeInsets.only(bottom: 14),
                    decoration: BoxDecoration(
                      color: Colors.grey[700],
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  Stack(
                    alignment: Alignment.center,
                    children: [
                      const Text(
                        'Cambiar de cuenta',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Align(
                        alignment: Alignment.centerRight,
                        child: IconButton(
                          onPressed: () => Navigator.pop(sheetContext),
                          icon: const Icon(Icons.close, color: Colors.white),
                          padding: EdgeInsets.zero,
                          constraints: const BoxConstraints(),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  ConstrainedBox(
                    constraints: const BoxConstraints(maxHeight: 320),
                    child: ListView(
                      shrinkWrap: true,
                      children: [
                        ...auth.savedAccounts.map((account) {
                          final bool isActive =
                              auth.currentUser?.id == account.id;
                          return ListTile(
                            contentPadding:
                                const EdgeInsets.symmetric(horizontal: 4),
                            leading: CircleAvatar(
                              radius: 22,
                              backgroundImage: NetworkImage(account.avatarUrl),
                            ),
                            title: Text(
                              account.username,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 15,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            trailing: isActive
                                ? const Icon(
                                    Icons.check,
                                    color: Color(0xFFFE2C55),
                                    size: 22,
                                  )
                                : account.unreadCount > 0
                                    ? Container(
                                        width: 22,
                                        height: 22,
                                        alignment: Alignment.center,
                                        decoration: const BoxDecoration(
                                          color: Color(0xFFFE2C55),
                                          shape: BoxShape.circle,
                                        ),
                                        child: Text(
                                          '\${account.unreadCount}',
                                          style: const TextStyle(
                                            color: Colors.white,
                                            fontSize: 12,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      )
                                    : null,
                            onTap: () {
                              auth.switchAccount(account);
                              Navigator.pop(sheetContext);
                            },
                          );
                        }),
                        ListTile(
                          contentPadding:
                              const EdgeInsets.symmetric(horizontal: 4),
                          leading: CircleAvatar(
                            radius: 22,
                            backgroundColor: Colors.grey[800],
                            child: const Icon(Icons.add, color: Colors.white),
                          ),
                          title: const Text(
                            'Agregar cuenta',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 15,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          onTap: () {
                            Navigator.pop(sheetContext);
                            final bool limitReached =
                                auth.savedAccounts.length >=
                                    AuthProvider.maxSavedAccounts;
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text(
                                  limitReached
                                      ? 'Error: máximo 10 cuentas guardadas'
                                      : 'Función para añadir cuenta',
                                ),
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      );
    },
  );
}`,
  },
  {
    id: 'coin_package_model',
    path: 'lib/models/coin_package.dart',
    phase: 'Monetización · Modelo CoinPackage',
    language: 'dart',
    summary:
      'Modelo CoinPackage con cantidad principal, bonus extra y precio USD compartido entre GetCoinsScreen y BalanceScreen.',
    code: `class CoinPackage {
  final String id;
  final int coins;
  final int bonus;
  final String priceText;

  const CoinPackage({
    required this.id,
    required this.coins,
    required this.bonus,
    required this.priceText,
  });

  int get totalCoins => coins + bonus;
}

const List<CoinPackage> kCoinPackages = [
  CoinPackage(id: 'pkg_10', coins: 10, bonus: 5, priceText: 'USD 0,08'),
  CoinPackage(id: 'pkg_50', coins: 50, bonus: 15, priceText: 'USD 0,39'),
  CoinPackage(id: 'pkg_100', coins: 100, bonus: 30, priceText: 'USD 0,79'),
  CoinPackage(id: 'pkg_500', coins: 500, bonus: 150, priceText: 'USD 3,99'),
  CoinPackage(id: 'pkg_1000', coins: 1000, bonus: 300, priceText: 'USD 7,99'),
  CoinPackage(id: 'pkg_2000', coins: 2000, bonus: 600, priceText: 'USD 14,99'),
];`,
  },
  {
    id: 'get_coins_screen',
    path: 'lib/screens/get_coins_screen.dart',
    phase: 'Monetización · GetCoinsScreen (Obtener Monedas + Calculadora)',
    language: 'dart',
    summary:
      'Pantalla GetCoinsScreen en modo oscuro (#121212) con precios económicos, GridView de 3 columnas, calculadora personalizada con 10% de descuento (>1000) y botón degradado naranja/rosa.',
    code: `import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/coin_package.dart';
import '../theme/app_colors.dart';

class GetCoinsScreen extends StatefulWidget {
  const GetCoinsScreen({super.key});

  @override
  State<GetCoinsScreen> createState() => _GetCoinsScreenState();
}

class _GetCoinsScreenState extends State<GetCoinsScreen> {
  static const double _baseRateUsd = 0.0079;

  int? _selectedIndex = 0;
  final TextEditingController _customCoinsController = TextEditingController();
  int _customCoins = 0;

  @override
  void dispose() {
    _customCoinsController.dispose();
    super.dispose();
  }

  CoinPackage? get _selectedPackage =>
      _selectedIndex != null ? kCoinPackages[_selectedIndex!] : null;

  bool get _hasDiscount => _customCoins > 1000;

  double get _customTotalUsd {
    final double rawTotal = _customCoins * _baseRateUsd;
    return _hasDiscount ? rawTotal * 0.90 : rawTotal;
  }

  void _selectPackage(int index) {
    _customCoinsController.clear();
    setState(() {
      _selectedIndex = index;
      _customCoins = 0;
    });
  }

  void _onCustomCoinsChanged(String value) {
    final int parsed = int.tryParse(value.trim()) ?? 0;
    setState(() {
      _selectedIndex = null;
      _customCoins = parsed;
    });
  }

  void _triggerSimulatedCheckout() {
    if (_selectedPackage == null && _customCoins <= 0) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Redirigiendo a pasarela de pago... (Simulación)'),
        backgroundColor: Color(0xFF27272A),
      ),
    );
  }

  Widget _buildCoinIcon({double size = 22}) {
    return Container(
      width: size,
      height: size,
      decoration: const BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          colors: [Color(0xFFFDE047), Color(0xFFF59E0B), Color(0xFFEA580C)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      alignment: Alignment.center,
      child: Text(
        'V',
        style: TextStyle(
          color: const Color(0xFF451A03),
          fontWeight: FontWeight.w900,
          fontSize: size * 0.54,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final CoinPackage? pkg = _selectedPackage;
    final String formattedCustomTotal = _customTotalUsd.toStringAsFixed(2);
    final bool isButtonEnabled = pkg != null || _customCoins > 0;

    final String buttonText;
    if (pkg != null) {
      buttonText = 'Consigue \${pkg.totalCoins} Monedas (\${pkg.priceText})';
    } else if (_customCoins > 0) {
      buttonText = 'Consigue \$_customCoins Monedas (USD \$formattedCustomTotal)';
    } else {
      buttonText = 'Ingresa una cantidad o elige un paquete';
    }

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.background,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Obtener Monedas',
          style: TextStyle(
            color: Colors.white,
            fontSize: 17,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.history_rounded, color: Colors.white),
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Historial de transacciones: Sin recargas'),
                  backgroundColor: Color(0xFF27272A),
                ),
              );
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                // 1. Sección Saldo
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.white10),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Saldo de Monedas',
                        style: TextStyle(
                          color: Colors.white70,
                          fontSize: 13,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          _buildCoinIcon(size: 32),
                          const SizedBox(width: 10),
                          const Text(
                            '0',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 30,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 14),

                // 2. Banner de Regalo
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 14,
                  ),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFFFCE7F3), Color(0xFFFFE4EC)],
                    ),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            Text(
                              'Rosas de bonus y Monedas en la primera recarga...',
                              style: TextStyle(
                                color: Color(0xFF881337),
                                fontSize: 13,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            SizedBox(height: 4),
                            Text(
                              'Precios más económicos que nunca en Viroklipz',
                              style: TextStyle(
                                color: Color(0xFFBE123C),
                                fontSize: 11,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 12),
                      Container(
                        width: 44,
                        height: 44,
                        decoration: const BoxDecoration(
                          color: Colors.white,
                          shape: BoxShape.circle,
                        ),
                        alignment: Alignment.center,
                        child: const Text('🌹', style: TextStyle(fontSize: 24)),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),

                // 3. Sección Recarga (Grid 3 columnas)
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: const [
                    Text(
                      'RECARGAR',
                      style: TextStyle(
                        color: Colors.white60,
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 0.6,
                      ),
                    ),
                    Text(
                      'Incluye bono extra',
                      style: TextStyle(
                        color: AppColors.magenta,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: kCoinPackages.length,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    crossAxisSpacing: 10,
                    mainAxisSpacing: 10,
                    childAspectRatio: 1.0,
                  ),
                  itemBuilder: (context, index) {
                    final item = kCoinPackages[index];
                    final bool isSelected = index == _selectedIndex;
                    return InkWell(
                      borderRadius: BorderRadius.circular(14),
                      onTap: () => _selectPackage(index),
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 6,
                          vertical: 10,
                        ),
                        decoration: BoxDecoration(
                          color: isSelected
                              ? AppColors.magenta.withValues(alpha: 0.14)
                              : AppColors.surface,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                            color: isSelected
                                ? const Color(0xFFFE2C55)
                                : Colors.white12,
                            width: isSelected ? 2 : 1,
                          ),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                _buildCoinIcon(size: 16),
                                const SizedBox(width: 4),
                                Text(
                                  '\${item.coins}',
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 16,
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 2),
                            Text(
                              '+\${item.bonus} Bono',
                              style: const TextStyle(
                                color: Color(0xFFFE2C55),
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              item.priceText,
                              style: const TextStyle(
                                color: Colors.white70,
                                fontSize: 11,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
                const SizedBox(height: 20),

                // 4. Calculadora de monedas personalizada
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: const Color(0xFF17171A),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.white10),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Calculadora personalizada',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Ingresa la cantidad de monedas que deseas comprar:',
                        style: TextStyle(
                          color: Colors.grey[400],
                          fontSize: 12,
                        ),
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Expanded(
                            child: TextField(
                              controller: _customCoinsController,
                              keyboardType: TextInputType.number,
                              inputFormatters: [
                                FilteringTextInputFormatter.digitsOnly,
                              ],
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 15,
                                fontWeight: FontWeight.w600,
                              ),
                              onChanged: _onCustomCoinsChanged,
                              decoration: InputDecoration(
                                hintText: 'Ej. 250',
                                hintStyle: TextStyle(color: Colors.grey[500]),
                                filled: true,
                                fillColor: const Color(0xFF1E1E1E),
                                contentPadding: const EdgeInsets.symmetric(
                                  horizontal: 14,
                                  vertical: 12,
                                ),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12),
                                  borderSide:
                                      const BorderSide(color: Colors.white12),
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12),
                                  borderSide:
                                      const BorderSide(color: Colors.white12),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12),
                                  borderSide: const BorderSide(
                                    color: AppColors.magenta,
                                    width: 1.5,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text(
                                'Total a pagar: USD \$formattedCustomTotal',
                                style: const TextStyle(
                                  color: AppColors.magenta,
                                  fontSize: 12.5,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                _hasDiscount
                                    ? '10% de descuento aplicado'
                                    : '+1000 monedas = 10% dto.',
                                style: TextStyle(
                                  color: _hasDiscount
                                      ? Colors.greenAccent[400]
                                      : Colors.grey[500],
                                  fontSize: 10.5,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),

                // 5. Texto Legal
                const Text(
                  'Al recargar, confirmas que eres mayor de 18 años y aceptas los Términos de Artículos Virtuales de Viroklipz. Las monedas no son reembolsables ni canjeables por dinero en efectivo.',
                  style: TextStyle(
                    color: Colors.white38,
                    fontSize: 11,
                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),

          // 6. Botón Inferior con degradado naranja/rosa
          Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 20),
            decoration: const BoxDecoration(
              color: AppColors.background,
              border: Border(top: BorderSide(color: Colors.white10)),
            ),
            child: Opacity(
              opacity: isButtonEnabled ? 1.0 : 0.5,
              child: GestureDetector(
                onTap: isButtonEnabled ? _triggerSimulatedCheckout : null,
                child: Container(
                  height: 50,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [AppColors.orange, AppColors.magenta],
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                    ),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  alignment: Alignment.center,
                  child: Text(
                    buttonText,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}`,
  },
  {
    id: 'balance_screen',
    path: 'lib/screens/balance_screen.dart',
    phase: 'Monetización · BalanceScreen (Saldo + Bottom Sheet Informativo)',
    language: 'dart',
    summary:
      'Pantalla BalanceScreen con fondo en degradado suave, Saldo estimado VES con toggle de visibilidad, tarjeta de Monedas, tarjeta de Transacciones y showModalBottomSheet informativo.',
    code: `import 'package:flutter/material.dart';
import 'get_coins_screen.dart';
import 'transaction_history_screen.dart';

class BalanceScreen extends StatefulWidget {
  const BalanceScreen({super.key});

  @override
  State<BalanceScreen> createState() => _BalanceScreenState();
}

class _BalanceScreenState extends State<BalanceScreen> {
  static bool _hasShownIntroSheet = false;
  bool _showBalance = true;

  @override
  void initState() {
    super.initState();
    if (!_hasShownIntroSheet) {
      _hasShownIntroSheet = true;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          _showTransactionsInfoSheet();
        }
      });
    }
  }

  void _showTransactionsInfoSheet() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.white,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (sheetContext) {
        return SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Botón X en la esquina superior derecha
                Align(
                  alignment: Alignment.topRight,
                  child: IconButton(
                    onPressed: () => Navigator.of(sheetContext).pop(),
                    icon: const Icon(Icons.close, color: Color(0xFF52525B)),
                    splashRadius: 20,
                  ),
                ),

                // Ilustración central: documento con filtro
                SizedBox(
                  width: 84,
                  height: 84,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      Container(
                        width: 72,
                        height: 72,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          gradient: const LinearGradient(
                            colors: [Color(0xFFFFF1F2), Color(0xFFF3E8FF)],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                        ),
                        child: const Icon(
                          Icons.description_outlined,
                          size: 38,
                          color: Color(0xFF18181B),
                        ),
                      ),
                      Positioned(
                        right: 2,
                        bottom: 2,
                        child: Container(
                          width: 30,
                          height: 30,
                          decoration: BoxDecoration(
                            color: const Color(0xFFFE2C55),
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.white, width: 2.5),
                          ),
                          child: const Icon(
                            Icons.tune_rounded,
                            size: 15,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 18),

                const Text(
                  'Administra mejor tus transacciones',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Color(0xFF09090B),
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Filtra tus transacciones por tipos de transacción o tipos de actividad.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Color(0xFF71717A),
                    fontSize: 13.5,
                    height: 1.4,
                  ),
                ),
                const SizedBox(height: 24),

                // Botón rojo/rosa ancho "Entendido"
                SizedBox(
                  width: double.infinity,
                  height: 48,
                  child: ElevatedButton(
                    onPressed: () => Navigator.of(sheetContext).pop(),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFFE2C55),
                      foregroundColor: Colors.white,
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: const Text(
                      'Entendido',
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildCoinIcon({double size = 24}) {
    return Container(
      width: size,
      height: size,
      decoration: const BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          colors: [Color(0xFFFDE047), Color(0xFFF59E0B), Color(0xFFEA580C)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      alignment: Alignment.center,
      child: Text(
        'V',
        style: TextStyle(
          color: const Color(0xFF451A03),
          fontWeight: FontWeight.w900,
          fontSize: size * 0.52,
        ),
      ),
    );
  }

  void _openGetCoins() {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const GetCoinsScreen()),
    );
  }

  void _openTransactionHistory() {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const TransactionHistoryScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Color(0xFFFFF1F4),
            Color(0xFFF7F5FC),
            Color(0xFFF4F4F5),
          ],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          centerTitle: true,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back, color: Color(0xFF09090B)),
            onPressed: () => Navigator.of(context).pop(),
          ),
          title: const Text(
            'Saldo',
            style: TextStyle(
              color: Color(0xFF09090B),
              fontSize: 17,
              fontWeight: FontWeight.w700,
            ),
          ),
          actions: [
            IconButton(
              icon: const Icon(
                Icons.settings_outlined,
                color: Color(0xFF18181B),
              ),
              onPressed: _showTransactionsInfoSheet,
            ),
          ],
        ),
        body: ListView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
          children: [
            // Saldo estimado VES + ícono de ojo
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Text(
                        'Saldo estimado VES',
                        style: TextStyle(
                          color: Color(0xFF52525B),
                          fontSize: 13,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const SizedBox(width: 6),
                      GestureDetector(
                        onTap: () {
                          setState(() => _showBalance = !_showBalance);
                        },
                        child: Icon(
                          _showBalance
                              ? Icons.visibility_outlined
                              : Icons.visibility_off_outlined,
                          color: const Color(0xFF52525B),
                          size: 18,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  InkWell(
                    onTap: _openGetCoins,
                    borderRadius: BorderRadius.circular(8),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            _showBalance ? '0.00' : '••••',
                            style: const TextStyle(
                              color: Color(0xFF09090B),
                              fontSize: 34,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          const Icon(
                            Icons.chevron_right_rounded,
                            color: Color(0xFF71717A),
                            size: 26,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),

            // Tarjeta 1: Monedas
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0xFFE4E4E7)),
              ),
              child: Row(
                children: [
                  Container(
                    width: 42,
                    height: 42,
                    decoration: const BoxDecoration(
                      color: Color(0xFFFFFBEB),
                      shape: BoxShape.circle,
                    ),
                    alignment: Alignment.center,
                    child: _buildCoinIcon(size: 22),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Monedas',
                          style: TextStyle(
                            color: Color(0xFF71717A),
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          _showBalance ? '0' : '••',
                          style: const TextStyle(
                            color: Color(0xFF09090B),
                            fontSize: 24,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ],
                    ),
                  ),
                  TextButton(
                    onPressed: _openGetCoins,
                    child: const Text(
                      'Obtener Monedas →',
                      style: TextStyle(
                        color: Color(0xFFFE2C55),
                        fontSize: 12.5,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),

            // Tarjeta 2: Transacciones
            InkWell(
              onTap: _openTransactionHistory,
              borderRadius: BorderRadius.circular(16),
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 18,
                ),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: const Color(0xFFE4E4E7)),
                ),
                child: const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Transacciones',
                      style: TextStyle(
                        color: Color(0xFF09090B),
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    Row(
                      children: [
                        Text(
                          'Ver todo',
                          style: TextStyle(
                            color: Color(0xFF71717A),
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        SizedBox(width: 2),
                        Icon(
                          Icons.chevron_right_rounded,
                          color: Color(0xFFA1A1AA),
                          size: 18,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}`,
  },
  {
    id: 'transaction_history_screen',
    path: 'lib/screens/transaction_history_screen.dart',
    phase: 'Monetización · TransactionHistoryScreen (Historial con Filtros)',
    language: 'dart',
    summary:
      'StatefulWidget con AppBar y botón de filtro, fila horizontal de chips seleccionables, estado vacío con sobre gris y botón rojo "Selecciona otro filtro", y footer informativo.',
    code: `import 'package:flutter/material.dart';

class TransactionHistoryScreen extends StatefulWidget {
  const TransactionHistoryScreen({super.key});

  @override
  State<TransactionHistoryScreen> createState() =>
      _TransactionHistoryScreenState();
}

class _TransactionHistoryScreenState extends State<TransactionHistoryScreen> {
  static const List<String> _filters = [
    'Todo',
    'Comprar',
    'Recompensas',
    'Pago',
    'Ajuste de la plataforma',
    'Reembolsar',
    'Deducción',
  ];

  String _selectedFilter = 'Todo';

  void _openFilterPickerSheet() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (sheetContext) {
        return SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 14, 20, 16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'Filtrar por tipo de transacción',
                      style: TextStyle(
                        color: Color(0xFF09090B),
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    IconButton(
                      onPressed: () => Navigator.of(sheetContext).pop(),
                      icon: const Icon(Icons.close, color: Color(0xFF71717A)),
                    ),
                  ],
                ),
                const Divider(height: 1),
                ..._filters.map((filter) {
                  final isSelected = _selectedFilter == filter;
                  return ListTile(
                    contentPadding: EdgeInsets.zero,
                    title: Text(
                      filter,
                      style: TextStyle(
                        color: const Color(0xFF09090B),
                        fontSize: 14,
                        fontWeight:
                            isSelected ? FontWeight.w700 : FontWeight.w500,
                      ),
                    ),
                    trailing: isSelected
                        ? const Icon(
                            Icons.check_rounded,
                            color: Color(0xFFFE2C55),
                          )
                        : null,
                    onTap: () {
                      setState(() => _selectedFilter = filter);
                      Navigator.of(sheetContext).pop();
                    },
                  );
                }),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Color(0xFF09090B)),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: const Text(
          'Historial de transacciones',
          style: TextStyle(
            color: Color(0xFF09090B),
            fontSize: 16.5,
            fontWeight: FontWeight.w700,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(
              Icons.tune_rounded,
              color: Color(0xFF18181B),
            ),
            onPressed: _openFilterPickerSheet,
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(height: 1, color: const Color(0xFFF4F4F5)),
        ),
      ),
      body: Column(
        children: [
          // Fila de filtros horizontal con SingleChildScrollView
          Container(
            width: double.infinity,
            decoration: const BoxDecoration(
              color: Colors.white,
              border: Border(
                bottom: BorderSide(color: Color(0xFFF4F4F5)),
              ),
            ),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: Row(
                children: _filters.map((filter) {
                  final bool isSelected = _selectedFilter == filter;
                  return Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: GestureDetector(
                      onTap: () {
                        setState(() => _selectedFilter = filter);
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 14,
                          vertical: 8,
                        ),
                        decoration: BoxDecoration(
                          color: isSelected
                              ? Colors.black
                              : const Color(0xFFF4F4F5),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          filter,
                          style: TextStyle(
                            color: isSelected
                                ? Colors.white
                                : const Color(0xFF3F3F46),
                            fontSize: 12.5,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
          ),

          // Estado vacío centrado
          Expanded(
            child: Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 80,
                      height: 80,
                      decoration: const BoxDecoration(
                        color: Color(0xFFFAFAFA),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.mail_outline_rounded,
                        size: 46,
                        color: Color(0xFFD4D4D8),
                      ),
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'Aún no hay transacciones',
                      style: TextStyle(
                        color: Color(0xFF18181B),
                        fontSize: 15.5,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    if (_selectedFilter != 'Todo') ...[
                      const SizedBox(height: 4),
                      Text(
                        'Filtro activo: \$_selectedFilter',
                        style: const TextStyle(
                          color: Color(0xFF71717A),
                          fontSize: 12.5,
                        ),
                      ),
                    ],
                    const SizedBox(height: 6),
                    TextButton(
                      onPressed: _openFilterPickerSheet,
                      child: const Text(
                        'Selecciona otro filtro',
                        style: TextStyle(
                          color: Color(0xFFFE2C55),
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          // Footer informativo
          const SafeArea(
            top: false,
            child: Padding(
              padding: EdgeInsets.fromLTRB(24, 10, 24, 18),
              child: Text(
                'Saldo no es un producto financiero. Los detalles que se muestran son solo para fines informativos.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFFA1A1AA),
                  fontSize: 11.5,
                  height: 1.4,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}`,
  },
  {
    id: 'privacy_center_screen',
    path: 'lib/screens/privacy_center_screen.dart',
    phase: 'Ajustes · Centro de privacidad Viroklipz',
    language: 'dart',
    summary:
      'SingleChildScrollView editorial con AppBar personalizada, Hero, bloques informativos, política multilingüe y footer Viroklipz © 2026.',
    code: `import 'package:flutter/material.dart';

class PrivacyCenterScreen extends StatefulWidget {
  const PrivacyCenterScreen({super.key});

  @override
  State<PrivacyCenterScreen> createState() => _PrivacyCenterScreenState();
}

class _PrivacyCenterScreenState extends State<PrivacyCenterScreen> {
  String _lang = 'ES';

  Widget _buildFooterGroup(String title, List<String> items) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 24),
      child: Column(
        children: [
          Text(
            title,
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 15,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 10),
          ...items.map(
            (item) => Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Text(
                item,
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey[400], fontSize: 13),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF121212),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Centro de privacidad',
          style: TextStyle(
            color: Colors.white,
            fontSize: 15,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.menu, color: Colors.white),
            onPressed: () {},
          ),
          Container(
            width: 26,
            height: 26,
            margin: const EdgeInsets.symmetric(vertical: 14),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(6),
              gradient: const LinearGradient(
                colors: [Color(0xFFFF5722), Color(0xFFE91E63), Color(0xFF673AB7)],
              ),
            ),
            child: const Icon(Icons.shield, color: Colors.white, size: 15),
          ),
          const SizedBox(width: 8),
          Center(
            child: GestureDetector(
              onTap: () {
                setState(() {
                  _lang = _lang == 'ES' ? 'EN' : 'ES';
                });
              },
              child: Container(
                margin: const EdgeInsets.only(right: 12),
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.white30),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Text(
                  _lang,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Hero Section
            SizedBox(
              height: 360,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  Image.network(
                    'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=900&auto=format&fit=crop',
                    fit: BoxFit.cover,
                  ),
                  Container(color: Colors.black.withOpacity(0.6)),
                  const Center(
                    child: Padding(
                      padding: EdgeInsets.symmetric(horizontal: 24),
                      child: Text(
                        'Viroklipz protege tu privacidad',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 30,
                          fontWeight: FontWeight.bold,
                          height: 1.2,
                        ),
                      ),
                    ),
                  ),
                  const Positioned(
                    bottom: 20,
                    left: 0,
                    right: 0,
                    child: Icon(
                      Icons.keyboard_arrow_down,
                      color: Colors.white,
                      size: 30,
                    ),
                  ),
                ],
              ),
            ),

            // Bloque de texto en negro puro
            Container(
              color: Colors.black,
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 36),
              child: const Text(
                'En Viroklipz, tu privacidad es una prioridad absoluta. Trabajamos cada día para proteger tu información personal, ofrecerte controles transparentes y garantizar una experiencia segura en toda nuestra comunidad.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white70,
                  fontSize: 15,
                  height: 1.5,
                ),
              ),
            ),

            // Imagen central (dos personas usando laptops)
            Container(
              color: Colors.black,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: Image.network(
                  'https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=900&auto=format&fit=crop',
                  height: 210,
                  fit: BoxFit.cover,
                ),
              ),
            ),

            // Sección Qué hacemos
            Container(
              color: Colors.black,
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 36),
              child: Column(
                children: [
                  const Text(
                    'Qué hacemos',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 26,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    'Diseñamos herramientas avanzadas de seguridad y privacidad integradas en tu cuenta para que decidas quién ve tu contenido, cómo se gestionan tus permisos y qué datos compartes dentro de Viroklipz.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.grey[400],
                      fontSize: 14,
                      height: 1.5,
                    ),
                  ),
                ],
              ),
            ),

            // Sección Política de privacidad multilingüe (fondo claro)
            Container(
              color: const Color(0xFFF4F4F5),
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 40),
              child: Column(
                children: [
                  const Text(
                    'La Política de privacidad está disponible en diferentes idiomas',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      height: 1.3,
                    ),
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.black,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 28,
                        vertical: 14,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(24),
                      ),
                    ),
                    onPressed: () {},
                    child: const Text(
                      'Más información ↗',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
            ),

            // Footer Menu + Copyright
            Container(
              color: Colors.black,
              padding: const EdgeInsets.fromLTRB(24, 36, 24, 40),
              child: Column(
                children: [
                  _buildFooterGroup('Compañía', [
                    'Acerca de Viroklipz',
                    'Sala de prensa',
                    'Empleos',
                    'Contacto',
                  ]),
                  _buildFooterGroup('Programas', [
                    'Viroklipz for Good',
                    'Viroklipz Plus',
                    'Creadores',
                    'Publicidad',
                  ]),
                  _buildFooterGroup('Recursos', [
                    'Centro de ayuda',
                    'Centro de seguridad',
                    'Normas de la comunidad',
                    'Transparencia',
                  ]),
                  _buildFooterGroup('Avisos legales', [
                    'Términos del servicio',
                    'Política de privacidad',
                    'Política de cookies',
                    'Propiedad intelectual',
                  ]),
                  const Divider(color: Colors.white12),
                  const SizedBox(height: 16),
                  Text(
                    '© 2026 Viroklipz',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.grey[500], fontSize: 12),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}`,
  },
  {
    id: 'main_screen',
    path: 'lib/screens/main_screen.dart',
    phase: 'Paso 4 · MainScreen (BottomAppBar Viroklipz + Glow)',
    language: 'dart',
    summary:
      'MainScreen con terminología Comunidad, acentos #FF5722 y botón circular central con degradado de marca y efecto glow que abre CameraScreen.',
    code: `import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import 'camera_screen.dart';
import 'feed_screen.dart';
import 'friends_feed_screen.dart';
import 'messages_screen.dart';
import 'profile_screen.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _selectedIndex = 0; // 0 = Inicio, 1 = Comunidad, 2 = Mensajes, 3 = Perfil
  bool _isCreateOpen = false;

  Future<void> _openCamera() async {
    setState(() => _isCreateOpen = true);

    final bool? published = await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        fullscreenDialog: true,
        builder: (context) => const CameraScreen(),
      ),
    );

    if (!mounted) return;
    setState(() {
      _isCreateOpen = false;
      if (published == true) {
        _selectedIndex = 0;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: IndexedStack(
        index: _selectedIndex,
        children: [
          FeedScreen(
            isFeedVisible: _selectedIndex == 0 && !_isCreateOpen,
            onOpenCamera: _openCamera,
          ),
          FriendsFeedScreen(
            isFeedVisible: _selectedIndex == 1 && !_isCreateOpen,
            onOpenCamera: _openCamera,
          ),
          const MessagesScreen(),
          const ProfileScreen(embeddedInMainShell: true),
        ],
      ),
      bottomNavigationBar: BottomAppBar(
        color: AppColors.background,
        padding: EdgeInsets.zero,
        height: 62,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _buildNavItem(Icons.home_outlined, 'Inicio', 0),
            _buildNavItem(Icons.people_outline, 'Comunidad', 1),
            GestureDetector(
              onTap: _openCamera,
              child: Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: AppColors.brandGradient,
                  border: Border.all(
                    color: Colors.white.withValues(alpha: 0.25),
                    width: 1.5,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: AppColors.orange.withValues(alpha: 0.55),
                      blurRadius: 16,
                      spreadRadius: 1,
                    ),
                    BoxShadow(
                      color: AppColors.magenta.withValues(alpha: 0.4),
                      blurRadius: 24,
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.auto_awesome,
                  color: Colors.white,
                  size: 22,
                ),
              ),
            ),
            _buildNavItem(Icons.chat_bubble_outline, 'Mensajes', 2),
            _buildNavItem(Icons.person_outline, 'Perfil', 3),
          ],
        ),
      ),
    );
  }

  Widget _buildNavItem(IconData icon, String label, int index) {
    final bool isSelected = _selectedIndex == index;
    final Color itemColor = isSelected ? AppColors.orange : Colors.grey;

    return GestureDetector(
      onTap: () => setState(() => _selectedIndex = index),
      behavior: HitTestBehavior.opaque,
      child: SizedBox(
        width: 68,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: itemColor),
            const SizedBox(height: 2),
            Text(
              label,
              style: TextStyle(
                color: itemColor,
                fontSize: 10,
                fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}`,
  },
  {
    id: 'royalty_free_media_service',
    path: 'lib/services/royalty_free_media_service.dart',
    phase: 'Servicios · Jamendo, Freesound y Overlays MP4',
    language: 'dart',
    summary:
      'Consulta música libre de derechos en Jamendo API y efectos de sonido en Freesound API usando http, además de catalogar overlays visuales MP4 (Mixkit / Pexels).',
    code: `import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config/env_config.dart';

class MissingApiKeyException implements Exception {
  final String providerName;
  MissingApiKeyException(this.providerName);

  @override
  String toString() =>
      'Falta configurar la API Key de \$providerName en EnvConfig (--dart-define).';
}

class RoyaltyFreeSound {
  final String id;
  final String title;
  final String artist;
  final String audioUrl;
  final int durationSeconds;
  final String category; // 'music' | 'sfx'

  const RoyaltyFreeSound({
    required this.id,
    required this.title,
    required this.artist,
    required this.audioUrl,
    required this.durationSeconds,
    required this.category,
  });
}

class VideoEffectOverlay {
  final String id;
  final String name;
  final String tag;
  final String thumbnailUrl;
  final String videoUrl;

  const VideoEffectOverlay({
    required this.id,
    required this.name,
    required this.tag,
    required this.thumbnailUrl,
    required this.videoUrl,
  });
}

class RoyaltyFreeMediaService {
  static bool get hasJamendoKey =>
      EnvConfig.jamendoClientId.isNotEmpty &&
      !EnvConfig.jamendoClientId.startsWith('TU_');

  static bool get hasFreesoundKey =>
      EnvConfig.freesoundApiKey.isNotEmpty &&
      !EnvConfig.freesoundApiKey.startsWith('TU_');

  /// Consulta música libre de derechos usando la API oficial de Jamendo v3.0
  Future<List<RoyaltyFreeSound>> fetchJamendoMusic({String query = ''}) async {
    if (!hasJamendoKey) {
      throw MissingApiKeyException('Jamendo');
    }

    final Uri uri = Uri.https('api.jamendo.com', '/v3.0/tracks/', {
      'client_id': EnvConfig.jamendoClientId,
      'format': 'json',
      'limit': '20',
      'audioformat': 'mp32',
      if (query.trim().isNotEmpty) 'search': query.trim(),
    });

    final http.Response response = await http.get(uri);
    if (response.statusCode != 200) {
      throw Exception('Error Jamendo HTTP \${response.statusCode}');
    }

    final Map<String, dynamic> decoded =
        jsonDecode(response.body) as Map<String, dynamic>;
    final List<dynamic> results =
        (decoded['results'] as List<dynamic>?) ?? <dynamic>[];

    return results
        .map((dynamic item) {
          final map = item as Map<String, dynamic>;
          return RoyaltyFreeSound(
            id: (map['id'] ?? '').toString(),
            title: (map['name'] ?? 'Pista sin título').toString(),
            artist: (map['artist_name'] ?? 'Artista Jamendo').toString(),
            audioUrl: (map['audio'] ?? '').toString(),
            durationSeconds:
                int.tryParse((map['duration'] ?? '0').toString()) ?? 0,
            category: 'music',
          );
        })
        .where((s) => s.audioUrl.isNotEmpty)
        .toList();
  }

  /// Consulta efectos de sonido usando la API oficial de Freesound v2
  Future<List<RoyaltyFreeSound>> fetchFreesoundEffects({
    String query = 'whoosh',
  }) async {
    if (!hasFreesoundKey) {
      throw MissingApiKeyException('Freesound');
    }

    final String effectiveQuery =
        query.trim().isEmpty ? 'cinematic impact' : query.trim();

    final Uri uri = Uri.https('freesound.org', '/apiv2/search/text/', {
      'query': effectiveQuery,
      'fields': 'id,name,username,previews,duration',
      'page_size': '20',
      'token': EnvConfig.freesoundApiKey,
    });

    final http.Response response = await http.get(uri);
    if (response.statusCode != 200) {
      throw Exception('Error Freesound HTTP \${response.statusCode}');
    }

    final Map<String, dynamic> decoded =
        jsonDecode(response.body) as Map<String, dynamic>;
    final List<dynamic> results =
        (decoded['results'] as List<dynamic>?) ?? <dynamic>[];

    return results
        .map((dynamic item) {
          final map = item as Map<String, dynamic>;
          final previews =
              (map['previews'] as Map<String, dynamic>?) ?? <String, dynamic>{};
          final String url = (previews['preview-hq-mp3'] ??
                  previews['preview-lq-mp3'] ??
                  '')
              .toString();
          final double rawDuration =
              double.tryParse((map['duration'] ?? '0').toString()) ?? 0;

          return RoyaltyFreeSound(
            id: (map['id'] ?? '').toString(),
            title: (map['name'] ?? 'Efecto').toString(),
            artist: '@\${(map['username'] ?? 'freesound').toString()}',
            audioUrl: url,
            durationSeconds: rawDuration.round(),
            category: 'sfx',
          );
        })
        .where((s) => s.audioUrl.isNotEmpty)
        .toList();
  }

  /// Pistas de demostración libres de derechos cuando aún no se configura la API Key
  static const List<RoyaltyFreeSound> sampleMusicFallback = [
    RoyaltyFreeSound(
      id: 'demo_m1',
      title: 'Neon Horizon (Synth)',
      artist: 'Viroklipz Royalty-Free',
      audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
      durationSeconds: 32,
      category: 'music',
    ),
    RoyaltyFreeSound(
      id: 'demo_m2',
      title: 'Midnight Pulse',
      artist: 'Creative Commons Audio',
      audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3',
      durationSeconds: 45,
      category: 'music',
    ),
    RoyaltyFreeSound(
      id: 'demo_m3',
      title: 'Urban Drift Lo-Fi',
      artist: 'Studio Libre',
      audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3',
      durationSeconds: 28,
      category: 'music',
    ),
  ];

  static const List<RoyaltyFreeSound> sampleEffectsFallback = [
    RoyaltyFreeSound(
      id: 'demo_e1',
      title: 'Transición Whoosh Cine',
      artist: 'SFX Pack CC0',
      audioUrl:
          'https://assets.mixkit.co/active_storage/sfx/2568/2568-preview.mp3',
      durationSeconds: 2,
      category: 'sfx',
    ),
    RoyaltyFreeSound(
      id: 'demo_e2',
      title: 'Destello Mágico',
      artist: 'SFX Pack CC0',
      audioUrl:
          'https://assets.mixkit.co/active_storage/sfx/2019/2019-preview.mp3',
      durationSeconds: 3,
      category: 'sfx',
    ),
    RoyaltyFreeSound(
      id: 'demo_e3',
      title: 'Impacto Bass Drop',
      artist: 'SFX Pack CC0',
      audioUrl:
          'https://assets.mixkit.co/active_storage/sfx/2571/2571-preview.mp3',
      durationSeconds: 2,
      category: 'sfx',
    ),
  ];

  /// Galería de overlays visuales MP4 (Mixkit / Pexels libre de derechos)
  static const List<VideoEffectOverlay> effectOverlays = [
    VideoEffectOverlay(
      id: 'light_leaks',
      name: 'Destellos Cálidos',
      tag: 'Light Leak',
      thumbnailUrl:
          'https://images.pexels.com/photos/3377405/pexels-photo-3377405.jpeg?auto=compress&cs=tinysrgb&w=400',
      videoUrl:
          'https://assets.mixkit.co/videos/preview/mixkit-warm-light-leaks-overlay-34597-large.mp4',
    ),
    VideoEffectOverlay(
      id: 'neon_particles',
      name: 'Partículas Neón',
      tag: 'Neón',
      thumbnailUrl:
          'https://images.pexels.com/photos/2156881/pexels-photo-2156881.jpeg?auto=compress&cs=tinysrgb&w=400',
      videoUrl:
          'https://assets.mixkit.co/videos/preview/mixkit-glittering-golden-particles-background-41213-large.mp4',
    ),
    VideoEffectOverlay(
      id: 'bokeh_nights',
      name: 'Bokeh Nocturno',
      tag: 'Bokeh',
      thumbnailUrl:
          'https://images.pexels.com/photos/1763075/pexels-photo-1763075.jpeg?auto=compress&cs=tinysrgb&w=400',
      videoUrl:
          'https://assets.mixkit.co/videos/preview/mixkit-colorful-bokeh-lights-blurred-background-41214-large.mp4',
    ),
    VideoEffectOverlay(
      id: 'vhs_retro',
      name: 'Estática Retro',
      tag: 'VHS',
      thumbnailUrl:
          'https://images.pexels.com/photos/2510428/pexels-photo-2510428.jpeg?auto=compress&cs=tinysrgb&w=400',
      videoUrl:
          'https://assets.mixkit.co/videos/preview/mixkit-old-film-scratches-and-dust-overlay-42748-large.mp4',
    ),
  ];
}`,
  },
  {
    id: 'sound_picker_sheet',
    path: 'lib/widgets/sound_picker_sheet.dart',
    phase: 'Widgets · Galería de Sonidos (Jamendo + Freesound + just_audio)',
    language: 'dart',
    summary:
      'Bottom Sheet con pestañas Música (Jamendo) y Efectos (Freesound), buscador via http, preescucha instantánea con just_audio y selección con botón "Usar".',
    code: `import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import '../services/royalty_free_media_service.dart';
import '../theme/app_colors.dart';

class SoundPickerSheet extends StatefulWidget {
  final String? initialSelectedUrl;

  const SoundPickerSheet({super.key, this.initialSelectedUrl});

  @override
  State<SoundPickerSheet> createState() => _SoundPickerSheetState();
}

class _SoundPickerSheetState extends State<SoundPickerSheet>
    with SingleTickerProviderStateMixin {
  final RoyaltyFreeMediaService _mediaService = RoyaltyFreeMediaService();
  final TextEditingController _searchController = TextEditingController();
  final AudioPlayer _previewPlayer = AudioPlayer();
  late final TabController _tabController;

  List<RoyaltyFreeSound> _musicTracks = [];
  List<RoyaltyFreeSound> _sfxTracks = [];
  bool _isLoadingMusic = true;
  bool _isLoadingSfx = true;
  String? _musicWarning;
  String? _sfxWarning;

  String? _playingId;
  String? _loadingAudioId;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _loadMusic();
    _loadSfx();
  }

  @override
  void dispose() {
    _previewPlayer.dispose();
    _tabController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _stopPreviewAudio() async {
    try {
      await _previewPlayer.stop();
    } catch (_) {}
    if (mounted) {
      setState(() {
        _playingId = null;
        _loadingAudioId = null;
      });
    }
  }

  Future<void> _togglePreview(RoyaltyFreeSound sound) async {
    if (_playingId == sound.id) {
      await _stopPreviewAudio();
      return;
    }

    await _stopPreviewAudio();
    setState(() => _loadingAudioId = sound.id);

    try {
      await _previewPlayer.setUrl(sound.audioUrl);
      await _previewPlayer.setLoopMode(LoopMode.off);
      if (!mounted) return;
      setState(() {
        _playingId = sound.id;
        _loadingAudioId = null;
      });
      await _previewPlayer.play();
    } catch (e) {
      if (!mounted) return;
      setState(() => _loadingAudioId = null);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: const Color(0xFFDC2626),
          content: Text('No se pudo reproducir con just_audio: \$e'),
        ),
      );
    }
  }

  Future<void> _loadMusic({String query = ''}) async {
    setState(() {
      _isLoadingMusic = true;
      _musicWarning = null;
    });
    try {
      final list = await _mediaService.fetchJamendoMusic(query: query);
      if (!mounted) return;
      setState(() {
        _musicTracks = list;
        _isLoadingMusic = false;
      });
    } on MissingApiKeyException catch (e) {
      if (!mounted) return;
      setState(() {
        _musicTracks = RoyaltyFreeMediaService.sampleMusicFallback;
        _musicWarning = '\${e.toString()} Mostrando pistas de muestra.';
        _isLoadingMusic = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _musicTracks = RoyaltyFreeMediaService.sampleMusicFallback;
        _musicWarning = 'Sin conexión a Jamendo. Mostrando pistas de muestra.';
        _isLoadingMusic = false;
      });
    }
  }

  Future<void> _loadSfx({String query = ''}) async {
    setState(() {
      _isLoadingSfx = true;
      _sfxWarning = null;
    });
    try {
      final list = await _mediaService.fetchFreesoundEffects(query: query);
      if (!mounted) return;
      setState(() {
        _sfxTracks = list;
        _isLoadingSfx = false;
      });
    } on MissingApiKeyException catch (e) {
      if (!mounted) return;
      setState(() {
        _sfxTracks = RoyaltyFreeMediaService.sampleEffectsFallback;
        _sfxWarning = '\${e.toString()} Mostrando efectos de muestra.';
        _isLoadingSfx = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _sfxTracks = RoyaltyFreeMediaService.sampleEffectsFallback;
        _sfxWarning = 'Sin conexión a Freesound. Mostrando efectos de muestra.';
        _isLoadingSfx = false;
      });
    }
  }

  void _onSearchSubmitted(String value) {
    if (_tabController.index == 0) {
      _loadMusic(query: value);
    } else {
      _loadSfx(query: value);
    }
  }

  Future<void> _selectSound(RoyaltyFreeSound sound) async {
    await _stopPreviewAudio();
    if (!mounted) return;
    Navigator.pop(context, sound);
  }

  String _formatDuration(int seconds) {
    final int mins = seconds ~/ 60;
    final int secs = seconds % 60;
    return '\$mins:\${secs.toString().padLeft(2, '0')}';
  }

  Widget _buildTrackList({
    required List<RoyaltyFreeSound> tracks,
    required bool isLoading,
    String? warning,
  }) {
    if (isLoading) {
      return const Center(
        child: CircularProgressIndicator(color: AppColors.magenta),
      );
    }

    return Column(
      children: [
        if (warning != null)
          Container(
            width: double.infinity,
            margin: const EdgeInsets.fromLTRB(16, 8, 16, 4),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: Colors.amber.withValues(alpha: 0.14),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: Colors.amber.withValues(alpha: 0.35)),
            ),
            child: Text(
              warning,
              style: const TextStyle(color: Colors.amber, fontSize: 11.5),
            ),
          ),
        Expanded(
          child: tracks.isEmpty
              ? const Center(
                  child: Text(
                    'No se encontraron sonidos',
                    style: TextStyle(color: Colors.white54),
                  ),
                )
              : ListView.separated(
                  padding: const EdgeInsets.all(16),
                  itemCount: tracks.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 10),
                  itemBuilder: (context, index) {
                    final sound = tracks[index];
                    final bool isPlaying = _playingId == sound.id;
                    final bool isLoadingAudio = _loadingAudioId == sound.id;
                    final bool isSelected =
                        widget.initialSelectedUrl == sound.audioUrl;

                    return Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: const Color(0xFF1E1E1E),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                          color: isSelected
                              ? AppColors.magenta
                              : Colors.white.withValues(alpha: 0.08),
                        ),
                      ),
                      child: Row(
                        children: [
                          GestureDetector(
                            onTap: () => _togglePreview(sound),
                            child: Container(
                              width: 44,
                              height: 44,
                              decoration: BoxDecoration(
                                gradient: isPlaying
                                    ? AppColors.brandGradient
                                    : null,
                                color: isPlaying
                                    ? null
                                    : Colors.white.withValues(alpha: 0.08),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: isLoadingAudio
                                  ? const Padding(
                                      padding: EdgeInsets.all(11),
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2,
                                        color: Colors.white,
                                      ),
                                    )
                                  : Icon(
                                      isPlaying
                                          ? Icons.stop_rounded
                                          : Icons.play_arrow_rounded,
                                      color: Colors.white,
                                      size: 26,
                                    ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  sound.title,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                const SizedBox(height: 3),
                                Text(
                                  '\${sound.artist} · \${_formatDuration(sound.durationSeconds)}',
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    color: Colors.white60,
                                    fontSize: 12,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 8),
                          TextButton(
                            onPressed: () => _togglePreview(sound),
                            child: Text(
                              isPlaying ? 'Detener' : 'Reproducir',
                              style: const TextStyle(
                                color: Color(0xFF25F4EE),
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                          ElevatedButton(
                            onPressed: () => _selectSound(sound),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppColors.magenta,
                              foregroundColor: Colors.white,
                              padding: const EdgeInsets.symmetric(
                                horizontal: 12,
                                vertical: 8,
                              ),
                              minimumSize: Size.zero,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                            ),
                            child: const Text(
                              'Usar',
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.78,
      decoration: const BoxDecoration(
        color: Color(0xFF121212),
        borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
      ),
      child: Column(
        children: [
          const SizedBox(height: 10),
          Container(
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: Colors.white24,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            'Sonidos libres de derechos',
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.w800,
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: TextField(
              controller: _searchController,
              onSubmitted: _onSearchSubmitted,
              style: const TextStyle(color: Colors.white, fontSize: 14),
              decoration: InputDecoration(
                hintText: 'Buscar música (Jamendo) o efectos (Freesound)...',
                hintStyle: const TextStyle(color: Colors.white38, fontSize: 13),
                prefixIcon: const Icon(Icons.search, color: Colors.white54),
                filled: true,
                fillColor: const Color(0xFF1E1E1E),
                contentPadding: const EdgeInsets.symmetric(vertical: 10),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
          TabBar(
            controller: _tabController,
            indicatorColor: AppColors.magenta,
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white54,
            tabs: const [
              Tab(text: 'Música'),
              Tab(text: 'Efectos'),
            ],
          ),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildTrackList(
                  tracks: _musicTracks,
                  isLoading: _isLoadingMusic,
                  warning: _musicWarning,
                ),
                _buildTrackList(
                  tracks: _sfxTracks,
                  isLoading: _isLoadingSfx,
                  warning: _sfxWarning,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}`,
  },
  {
    id: 'effects_gallery_sheet',
    path: 'lib/widgets/effects_gallery_sheet.dart',
    phase: 'Widgets · Galería de Efectos Visuales (Overlays MP4)',
    language: 'dart',
    summary:
      'Bottom Sheet con miniaturas de overlays de video (Mixkit/Pexels) y opción para limpiar efecto, devolviendo el efecto seleccionado para superponerlo en Stack.',
    code: `import 'package:flutter/material.dart';
import '../services/royalty_free_media_service.dart';
import '../theme/app_colors.dart';

class EffectsPickerResult {
  final VideoEffectOverlay? effect;
  const EffectsPickerResult(this.effect);
}

class EffectsGallerySheet extends StatelessWidget {
  final String? selectedEffectId;

  const EffectsGallerySheet({super.key, this.selectedEffectId});

  @override
  Widget build(BuildContext context) {
    const overlays = RoyaltyFreeMediaService.effectOverlays;

    return Container(
      height: MediaQuery.of(context).size.height * 0.56,
      decoration: const BoxDecoration(
        color: Color(0xFF121212),
        borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
      ),
      child: Column(
        children: [
          const SizedBox(height: 10),
          Container(
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: Colors.white24,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Efectos visuales (Overlays)',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                TextButton(
                  onPressed: () =>
                      Navigator.pop(context, const EffectsPickerResult(null)),
                  child: const Text(
                    'Quitar efecto',
                    style: TextStyle(
                      color: AppColors.magenta,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.fromLTRB(16, 6, 16, 20),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                crossAxisSpacing: 10,
                mainAxisSpacing: 12,
                childAspectRatio: 0.78,
              ),
              itemCount: overlays.length + 1,
              itemBuilder: (context, index) {
                if (index == 0) {
                  final bool isNone = selectedEffectId == null;
                  return GestureDetector(
                    onTap: () =>
                        Navigator.pop(context, const EffectsPickerResult(null)),
                    child: Container(
                      decoration: BoxDecoration(
                        color: const Color(0xFF1E1E1E),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                          color: isNone ? const Color(0xFF25F4EE) : Colors.white12,
                          width: isNone ? 2 : 1,
                        ),
                      ),
                      child: const Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.block_rounded,
                            color: Colors.white70,
                            size: 28,
                          ),
                          SizedBox(height: 8),
                          Text(
                            'Ninguno',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                }

                final VideoEffectOverlay effect = overlays[index - 1];
                final bool isSelected = selectedEffectId == effect.id;

                return GestureDetector(
                  onTap: () => Navigator.pop(context, EffectsPickerResult(effect)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Expanded(
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(
                              color: isSelected
                                  ? const Color(0xFF25F4EE)
                                  : Colors.white12,
                              width: isSelected ? 2.2 : 1,
                            ),
                          ),
                          child: Stack(
                            fit: StackFit.expand,
                            children: [
                              Container(
                                decoration: BoxDecoration(
                                  gradient: _gradientForEffect(effect.id),
                                ),
                                child: Center(
                                  child: Icon(
                                    _iconForEffect(effect.id),
                                    color: Colors.white.withValues(alpha: 0.9),
                                    size: 32,
                                  ),
                                ),
                              ),
                              Positioned(
                                top: 6,
                                left: 6,
                                child: Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 6,
                                    vertical: 2,
                                  ),
                                  decoration: BoxDecoration(
                                    color: Colors.black.withValues(alpha: 0.65),
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: Text(
                                    effect.tag,
                                    style: const TextStyle(
                                      color: Color(0xFF25F4EE),
                                      fontSize: 9.5,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        effect.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: isSelected
                              ? const Color(0xFF25F4EE)
                              : Colors.white,
                          fontSize: 11.5,
                          fontWeight:
                              isSelected ? FontWeight.w700 : FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  static LinearGradient _gradientForEffect(String effectId) {
    switch (effectId) {
      case 'light_leaks':
        return const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFFFF6B35), Color(0xFFE91E63)],
        );
      case 'neon_particles':
        return const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF25F4EE), Color(0xFF673AB7)],
        );
      case 'bokeh_nights':
        return const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFFE91E63), Color(0xFF38BDF8)],
        );
      case 'vhs_retro':
      default:
        return const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFFF59E0B), Color(0xFFEF4444)],
        );
    }
  }

  static IconData _iconForEffect(String effectId) {
    switch (effectId) {
      case 'light_leaks':
        return Icons.flare_rounded;
      case 'neon_particles':
        return Icons.auto_awesome_rounded;
      case 'bokeh_nights':
        return Icons.blur_on_rounded;
      case 'vhs_retro':
      default:
        return Icons.movie_filter_rounded;
    }
  }
}`,
  },
  {
    id: 'video_card',
    path: 'lib/widgets/video_card.dart',
    phase: 'Widgets · VideoCard (Firestore Datos Reales + VideoPlayer)',
    language: 'dart',
    summary:
      'Reproductor MP4 conectado a Firestore: recibe videoUrl, username, caption, likes, comments, avatarUrl y uid; renderiza avatar, Fuego Like dinámico en Firestore, Comentarios, descarga y metadatos del creador.',
    code: `import 'dart:io';
import 'dart:ui';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart' hide AuthProvider;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:video_player/video_player.dart';
import 'package:visibility_detector/visibility_detector.dart';
import '../providers/user_provider.dart';
import '../providers/video_provider.dart';
import '../services/video_download_service.dart';
import '../theme/app_colors.dart';
import 'comments_bottom_sheet.dart';

class VideoCard extends StatefulWidget {
  final String? videoId;
  final String? postId;
  final String videoUrl;
  final String username;
  final String caption;
  final int likes;
  final int comments;
  final String avatarUrl;
  final String uid;
  final List<String> likedBy;
  final String? audioName;
  final String? effectUsed;
  final String? effectVideoUrl;
  final bool isActive;

  const VideoCard({
    super.key,
    this.videoId,
    this.postId,
    required this.videoUrl,
    this.username = 'usuario',
    this.caption = '',
    this.likes = 0,
    this.comments = 0,
    this.avatarUrl = '',
    this.uid = '',
    this.likedBy = const [],
    this.audioName,
    this.effectUsed,
    this.effectVideoUrl,
    this.isActive = true,
  });

  @override
  State<VideoCard> createState() => _VideoCardState();
}

class _VideoCardState extends State<VideoCard> {
  VideoPlayerController? _controller;
  VideoPlayerController? _effectController;
  final VideoDownloadService _downloadService = VideoDownloadService();

  bool _isInitialized = false;
  bool _hasError = false;
  bool _isEffectInitialized = false;
  bool _isPausedByUser = false;
  bool _isVisible = false;
  bool _isDownloading = false;
  double _downloadProgress = 0.0;
  String? _topBannerMessage;
  bool _topBannerSuccess = false;
  double _fireScale = 1.0;

  String get _resolvedVideoId => widget.videoId ?? widget.postId ?? '';

  void _onControllerUpdated() {
    if (!mounted) return;
    final VideoPlayerController? controller = _controller;
    if (controller != null && controller.value.hasError && !_hasError) {
      setState(() => _hasError = true);
    }
  }

  Future<void> _initVideoController(String url) async {
    if (mounted) {
      setState(() {
        _isInitialized = false;
        _hasError = false;
      });
    }

    if (url.trim().isEmpty) {
      if (mounted) {
        setState(() => _hasError = true);
      }
      return;
    }

    try {
      final bool isRemote = url.startsWith('http');
      final VideoPlayerController controller = isRemote
          ? VideoPlayerController.networkUrl(Uri.parse(url))
          : VideoPlayerController.file(File(url));

      _controller = controller;
      controller.addListener(_onControllerUpdated);

      await controller.initialize();
      if (!mounted) return;

      await controller.setLooping(true);
      await controller.setVolume(0.0);

      setState(() {
        _isInitialized = true;
        _hasError = false;
      });

      if (_isVisible && widget.isActive && !_isPausedByUser) {
        await controller.play();
      }
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _isInitialized = false;
        _hasError = true;
      });
    }
  }

  Future<void> _retryVideo() async {
    final VideoPlayerController? old = _controller;
    _controller = null;
    if (old != null) {
      old.removeListener(_onControllerUpdated);
      await old.dispose();
    }
    await _initVideoController(widget.videoUrl);
  }

  @override
  void initState() {
    super.initState();
    _initVideoController(widget.videoUrl);

    if (widget.effectVideoUrl != null && widget.effectVideoUrl!.isNotEmpty) {
      _effectController = VideoPlayerController.networkUrl(
        Uri.parse(widget.effectVideoUrl!),
      );
      _effectController!.initialize().then((_) {
        if (!mounted) return;
        _effectController!
          ..setLooping(true)
          ..setVolume(0.0);
        setState(() => _isEffectInitialized = true);
        if (_isVisible && widget.isActive && !_isPausedByUser) {
          _effectController!.play();
        }
      }).catchError((_) {});
    }
  }

  @override
  void didUpdateWidget(covariant VideoCard oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.videoUrl != oldWidget.videoUrl) {
      final VideoPlayerController? old = _controller;
      _controller = null;
      if (old != null) {
        old.removeListener(_onControllerUpdated);
        old.dispose();
      }
      _initVideoController(widget.videoUrl);
      return;
    }
    final VideoPlayerController? controller = _controller;
    if (!_isInitialized || controller == null) return;
    if (widget.isActive != oldWidget.isActive) {
      if (widget.isActive && _isVisible && !_isPausedByUser) {
        controller.play();
        if (_isEffectInitialized) _effectController?.play();
      } else if (!widget.isActive && controller.value.isPlaying) {
        controller.pause();
        _effectController?.pause();
      }
    }
  }

  @override
  void dispose() {
    _controller?.removeListener(_onControllerUpdated);
    _effectController?.dispose();
    _controller?.dispose();
    super.dispose();
  }

  void _handleVisibilityChanged(VisibilityInfo visibilityInfo) {
    final bool visible = visibilityInfo.visibleFraction > 0.5;
    _isVisible = visible;
    final VideoPlayerController? controller = _controller;
    if (!mounted || !_isInitialized || controller == null) return;

    if (visible && widget.isActive && !_isPausedByUser) {
      if (!controller.value.isPlaying) {
        controller.play();
        if (_isEffectInitialized) _effectController?.play();
      }
    } else {
      if (controller.value.isPlaying) {
        controller.pause();
        _effectController?.pause();
      }
    }
  }

  void _togglePlayPause() {
    final VideoPlayerController? controller = _controller;
    if (!_isInitialized || _hasError || controller == null) return;
    setState(() {
      if (controller.value.isPlaying) {
        controller.pause();
        _effectController?.pause();
        _isPausedByUser = true;
      } else {
        controller.play();
        if (_isEffectInitialized) _effectController?.play();
        _isPausedByUser = false;
      }
    });
  }

  void _triggerFireAnimation() {
    setState(() => _fireScale = 1.32);
    Future.delayed(const Duration(milliseconds: 160), () {
      if (mounted) {
        setState(() => _fireScale = 1.0);
      }
    });
  }

  void _handleFireLikeTap(VideoProvider videoProvider) {
    _triggerFireAnimation();
    videoProvider.toggleLike(_resolvedVideoId);
  }

  String _formatCount(int value) {
    if (value >= 1000000) return '\${(value / 1000000).toStringAsFixed(1)}M';
    if (value >= 1000) return '\${(value / 1000).toStringAsFixed(1)}K';
    return value.toString();
  }

  void _openCommentsSheet() {
    if (_resolvedVideoId.isEmpty) return;
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => CommentsBottomSheet(videoId: _resolvedVideoId),
    );
  }

  Future<void> _handleDownload() async {
    if (_isDownloading || widget.videoUrl.isEmpty) return;

    setState(() {
      _isDownloading = true;
      _downloadProgress = 0.0;
      _topBannerMessage = 'Descargando video...';
      _topBannerSuccess = false;
    });

    try {
      await _downloadService.downloadAndSaveToGallery(
        videoUrl: widget.videoUrl,
        onProgress: (progress) {
          if (mounted) {
            setState(() => _downloadProgress = progress);
          }
        },
      );

      if (!mounted) return;
      setState(() {
        _isDownloading = false;
        _topBannerMessage = 'Video descargado con éxito';
        _topBannerSuccess = true;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('¡Video guardado en tu galería!'),
          backgroundColor: Color(0xFF10B981),
        ),
      );

      Future.delayed(const Duration(seconds: 2), () {
        if (mounted && _topBannerSuccess) {
          setState(() => _topBannerMessage = null);
        }
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _isDownloading = false;
        _topBannerMessage = null;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('No se pudo descargar el video'),
          backgroundColor: Color(0xFFEF4444),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final videoProvider = context.watch<VideoProvider>();
    final userProvider = context.watch<UserProvider>();
    final String? currentUid = FirebaseAuth.instance.currentUser?.uid;
    final bool isOwnPost = currentUid != null && widget.uid == currentUid;
    final bool isLiked = currentUid != null
        ? widget.likedBy.contains(currentUid)
        : videoProvider.isLiked(_resolvedVideoId);

    final bool hasEffect =
        widget.effectUsed != null &&
        widget.effectUsed!.isNotEmpty &&
        widget.effectUsed != 'Ninguno';

    return VisibilityDetector(
      key: Key('video_\${_resolvedVideoId.isNotEmpty ? _resolvedVideoId : widget.videoUrl}'),
      onVisibilityChanged: _handleVisibilityChanged,
      child: Stack(
        fit: StackFit.expand,
        children: [
          // 1. Reproductor de Video con VideoPlayerController
          GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: _togglePlayPause,
            child: Container(
              color: const Color(0xFF1F1F23),
              child: _hasError
                  ? Center(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 24),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(
                              Icons.error_outline_rounded,
                              color: Color(0xFFA1A1AA),
                              size: 44,
                            ),
                            const SizedBox(height: 12),
                            const Text(
                              'Error al cargar el video. Intenta de nuevo.',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: Color(0xFFE4E4E7),
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            const SizedBox(height: 14),
                            ElevatedButton.icon(
                              onPressed: _retryVideo,
                              icon: const Icon(Icons.refresh_rounded, size: 18),
                              label: const Text('Reintentar'),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFFFE2C55),
                                foregroundColor: Colors.white,
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 18,
                                  vertical: 10,
                                ),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(20),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    )
                  : (!_isInitialized || _controller == null)
                      ? Container(
                          color: const Color(0xFF1F1F23),
                          child: const Center(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                  Icons.movie_creation_outlined,
                                  color: Color(0xFF52525B),
                                  size: 44,
                                ),
                                SizedBox(height: 14),
                                SizedBox(
                                  width: 24,
                                  height: 24,
                                  child: CircularProgressIndicator(
                                    color: Color(0xFFFF5722),
                                    strokeWidth: 2.5,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        )
                      : Stack(
                          fit: StackFit.expand,
                          children: [
                            SizedBox.expand(
                              child: FittedBox(
                                fit: BoxFit.cover,
                                clipBehavior: Clip.hardEdge,
                                child: SizedBox(
                                  width: _controller!.value.size.width > 0
                                      ? _controller!.value.size.width
                                      : 1080,
                                  height: _controller!.value.size.height > 0
                                      ? _controller!.value.size.height
                                      : 1920,
                                  child: AspectRatio(
                                    aspectRatio: _controller!.value.aspectRatio > 0
                                        ? _controller!.value.aspectRatio
                                        : 9 / 16,
                                    child: VideoPlayer(_controller!),
                                  ),
                                ),
                              ),
                            ),
                            if (hasEffect)
                              Positioned.fill(
                                child: IgnorePointer(
                                  child: Opacity(
                                    opacity: 0.35,
                                    child: Container(
                                      decoration: const BoxDecoration(
                                        backgroundBlendMode: BlendMode.screen,
                                        gradient: LinearGradient(
                                          begin: Alignment.topLeft,
                                          end: Alignment.bottomRight,
                                          colors: [
                                            Color(0x9925F4EE),
                                            Color(0x55E91E63),
                                            Color(0x88FF5722),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            if (_isEffectInitialized && _effectController != null)
                              Positioned.fill(
                                child: IgnorePointer(
                                  child: Opacity(
                                    opacity: 0.42,
                                    child: FittedBox(
                                      fit: BoxFit.cover,
                                      clipBehavior: Clip.hardEdge,
                                      child: SizedBox(
                                        width: _effectController!.value.size.width > 0
                                            ? _effectController!.value.size.width
                                            : 1080,
                                        height: _effectController!.value.size.height > 0
                                            ? _effectController!.value.size.height
                                            : 1920,
                                        child: AspectRatio(
                                          aspectRatio:
                                              _effectController!.value.aspectRatio > 0
                                                  ? _effectController!.value.aspectRatio
                                                  : 9 / 16,
                                          child: VideoPlayer(_effectController!),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            if (_isPausedByUser)
                              Center(
                                child: Icon(
                                  Icons.play_arrow_rounded,
                                  size: 92,
                                  color: Colors.white.withValues(alpha: 0.65),
                                ),
                              ),
                          ],
                        ),
            ),
          ),

          // 2. Scrim superior sutil y gradiente semi-transparente inferior en Stack para legibilidad
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            height: 110,
            child: IgnorePointer(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.black.withValues(alpha: 0.42),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
          ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            height: 240,
            child: IgnorePointer(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.transparent,
                      Colors.black.withValues(alpha: 0.48),
                      Colors.black.withValues(alpha: 0.88),
                    ],
                    stops: const [0.0, 0.45, 1.0],
                  ),
                ),
              ),
            ),
          ),

          // 3. Banner de descarga
          if (_topBannerMessage != null)
            Positioned(
              top: 64,
              left: 24,
              right: 24,
              child: Center(
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  decoration: BoxDecoration(
                    color: const Color(0xFF18181B).withValues(alpha: 0.94),
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: Colors.white12),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (!_topBannerSuccess) ...[
                        const Icon(
                          Icons.arrow_downward_rounded,
                          color: AppColors.orange,
                          size: 16,
                        ),
                        const SizedBox(width: 6),
                        SizedBox(
                          width: 14,
                          height: 14,
                          child: CircularProgressIndicator(
                            value: _downloadProgress > 0
                                ? _downloadProgress
                                : null,
                            strokeWidth: 2.2,
                            color: AppColors.orange,
                          ),
                        ),
                      ] else
                        const Icon(
                          Icons.check_circle_outline_rounded,
                          color: Color(0xFF34D399),
                          size: 16,
                        ),
                      const SizedBox(width: 8),
                      Text(
                        _topBannerMessage!,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),

          // 4. Barra lateral derecha: Avatar del creador + Fuego (Likes) + Comentarios + Descarga
          Positioned(
            right: 12,
            bottom: 20,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(24),
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 14),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(
                      color: Colors.white.withValues(alpha: 0.18),
                    ),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // Avatar (avatarUrl del creador) + Seguir
                      Builder(
                        builder: (context) {
                          final String resolvedAvatar = isOwnPost &&
                                  userProvider.avatarUrl.isNotEmpty
                              ? userProvider.avatarUrl
                              : widget.avatarUrl;
                          final bool isFollowing =
                              videoProvider.isFollowing(widget.uid);

                          return GestureDetector(
                            onTap: isOwnPost
                                ? null
                                : () => videoProvider.toggleFollow(widget.uid),
                            child: Stack(
                              alignment: Alignment.bottomCenter,
                              children: [
                                Container(
                                  width: 44,
                                  height: 44,
                                  margin: EdgeInsets.only(
                                    bottom: isOwnPost ? 0 : 8,
                                  ),
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: const Color(0xFF27272A),
                                    border: Border.all(
                                      color: Colors.white,
                                      width: 1.5,
                                    ),
                                    image: resolvedAvatar.isNotEmpty
                                        ? DecorationImage(
                                            image: NetworkImage(resolvedAvatar),
                                            fit: BoxFit.cover,
                                          )
                                        : null,
                                  ),
                                  child: resolvedAvatar.isEmpty
                                      ? const Icon(
                                          Icons.person,
                                          color: Colors.white,
                                        )
                                      : null,
                                ),
                                if (!isOwnPost)
                                  Container(
                                    width: 20,
                                    height: 20,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      gradient: isFollowing
                                          ? null
                                          : AppColors.brandGradient,
                                      color: isFollowing ? Colors.white : null,
                                    ),
                                    child: Icon(
                                      isFollowing ? Icons.check : Icons.add,
                                      color: isFollowing
                                          ? Colors.black
                                          : Colors.white,
                                      size: 14,
                                    ),
                                  ),
                              ],
                            ),
                          );
                        },
                      ),
                      const SizedBox(height: 16),

                      // Botón de Fuego (Likes dinámicos desde Firestore con animación de escala al tocar)
                      GestureDetector(
                        onTap: () => _handleFireLikeTap(videoProvider),
                        child: Column(
                          children: [
                            AnimatedScale(
                              scale: _fireScale,
                              duration: const Duration(milliseconds: 160),
                              curve: Curves.easeOutBack,
                              child: Icon(
                                Icons.local_fire_department_rounded,
                                color: isLiked ? AppColors.orange : Colors.white,
                                size: 32,
                              ),
                            ),
                            const SizedBox(height: 3),
                            Text(
                              _formatCount(widget.likes),
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),

                      // Botón de Comentarios (valor real desde Firestore)
                      GestureDetector(
                        onTap: _openCommentsSheet,
                        child: Column(
                          children: [
                            const Icon(
                              Icons.chat_bubble_outline_rounded,
                              color: Colors.white,
                              size: 28,
                            ),
                            const SizedBox(height: 3),
                            Text(
                              _formatCount(widget.comments),
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),

                      // Botón Descargar
                      GestureDetector(
                        onTap: _isDownloading ? null : _handleDownload,
                        child: Column(
                          children: [
                            if (_isDownloading)
                              SizedBox(
                                width: 28,
                                height: 28,
                                child: CircularProgressIndicator(
                                  value: _downloadProgress > 0
                                      ? _downloadProgress
                                      : null,
                                  strokeWidth: 2.8,
                                  color: AppColors.orange,
                                  backgroundColor: Colors.white24,
                                ),
                              )
                            else
                              const Icon(
                                Icons.download_rounded,
                                color: Colors.white,
                                size: 30,
                              ),
                            const SizedBox(height: 4),
                            Text(
                              _isDownloading ? 'Descargando' : 'Descargar',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 11,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),

          // 5. Parte inferior izquierda: @username, caption y audio
          Positioned(
            left: 14,
            right: 92,
            bottom: 18,
            child: IgnorePointer(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    '@\${widget.username}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 6),
                  if (widget.caption.isNotEmpty)
                    Text(
                      widget.caption,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: Colors.white, fontSize: 14),
                    ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      const Icon(
                        Icons.music_note_rounded,
                        color: AppColors.orange,
                        size: 16,
                      ),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          (widget.audioName != null &&
                                  widget.audioName!.isNotEmpty)
                              ? widget.audioName!
                              : 'Sonido original · Viroklipz',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: Colors.white70,
                            fontSize: 13,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}`,
  },
  {
    id: 'video_overlay',
    path: 'lib/widgets/video_overlay.dart',
    phase: 'Widgets · Glassmorphism Feed Overlay + Firestore Likes, Comentarios & Follow',
    language: 'dart',
    summary:
      'Overlay en tiempo real con StreamBuilder para likesCount/likedBy (Fuego naranja/blanco), CommentsBottomSheet (videos/{videoId}/comments + commentsCount) y Follow atómico (following/followers).',
    code: `import 'dart:ui';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart' hide AuthProvider;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/video_post.dart';
import '../providers/user_provider.dart';
import '../providers/video_provider.dart';
import '../services/video_download_service.dart';
import '../theme/app_colors.dart';
import 'comments_bottom_sheet.dart';

class VideoOverlay extends StatefulWidget {
  final VideoPost post;

  const VideoOverlay({super.key, required this.post});

  @override
  State<VideoOverlay> createState() => _VideoOverlayState();
}

class _VideoOverlayState extends State<VideoOverlay> {
  final VideoDownloadService _downloadService = VideoDownloadService();
  bool _isDownloading = false;
  double _downloadProgress = 0.0;
  String? _topBannerMessage;
  bool _topBannerSuccess = false;
  double _fireScale = 1.0;

  void _triggerFireAnimation() {
    setState(() => _fireScale = 1.32);
    Future.delayed(const Duration(milliseconds: 160), () {
      if (mounted) {
        setState(() => _fireScale = 1.0);
      }
    });
  }

  String _formatCount(int value) {
    if (value >= 1000000) return '\${(value / 1000000).toStringAsFixed(1)}M';
    if (value >= 1000) return '\${(value / 1000).toStringAsFixed(1)}K';
    return value.toString();
  }

  void _openCommentsSheet() {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => CommentsBottomSheet(videoId: widget.post.id),
    );
  }

  Future<void> _handleDownload() async {
    if (_isDownloading) return;

    setState(() {
      _isDownloading = true;
      _downloadProgress = 0.0;
      _topBannerMessage = 'Descargando video...';
      _topBannerSuccess = false;
    });

    try {
      await _downloadService.downloadAndSaveToGallery(
        videoUrl: widget.post.videoUrl,
        onProgress: (progress) {
          if (mounted) {
            setState(() => _downloadProgress = progress);
          }
        },
      );

      if (!mounted) return;
      setState(() {
        _isDownloading = false;
        _topBannerMessage = 'Video descargado con éxito';
        _topBannerSuccess = true;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('¡Video guardado en tu galería!'),
          backgroundColor: Color(0xFF10B981),
        ),
      );

      Future.delayed(const Duration(seconds: 2), () {
        if (mounted && _topBannerSuccess) {
          setState(() => _topBannerMessage = null);
        }
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _isDownloading = false;
        _topBannerMessage = null;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('No se pudo descargar el video'),
          backgroundColor: Color(0xFFEF4444),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final post = widget.post;
    final videoProvider = context.watch<VideoProvider>();
    final String? currentUid = FirebaseAuth.instance.currentUser?.uid;
    final bool isOwnPost = post.author.id == videoProvider.currentUser.id ||
        (currentUid != null && post.author.id == currentUid);

    return Stack(
      children: [
        Positioned(
          top: 0,
          left: 0,
          right: 0,
          height: 110,
          child: IgnorePointer(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withValues(alpha: 0.42),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
        ),
        Positioned(
          left: 0,
          right: 0,
          bottom: 0,
          height: 240,
          child: IgnorePointer(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.transparent,
                    Colors.black.withValues(alpha: 0.48),
                    Colors.black.withValues(alpha: 0.88),
                  ],
                  stops: const [0.0, 0.45, 1.0],
                ),
              ),
            ),
          ),
        ),

        // Overlay superior de progreso / éxito de descarga
        if (_topBannerMessage != null)
          Positioned(
            top: 64,
            left: 24,
            right: 24,
            child: Center(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  color: const Color(0xFF18181B).withValues(alpha: 0.94),
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: Colors.white12),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (!_topBannerSuccess) ...[
                      const Icon(
                        Icons.arrow_downward_rounded,
                        color: AppColors.orange,
                        size: 16,
                      ),
                      const SizedBox(width: 6),
                      SizedBox(
                        width: 14,
                        height: 14,
                        child: CircularProgressIndicator(
                          value: _downloadProgress > 0 ? _downloadProgress : null,
                          strokeWidth: 2.2,
                          color: AppColors.orange,
                        ),
                      ),
                    ] else
                      const Icon(
                        Icons.check_circle_outline_rounded,
                        color: Color(0xFF34D399),
                        size: 16,
                      ),
                    const SizedBox(width: 8),
                    Text(
                      _topBannerMessage!,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

        Positioned(
          right: 12,
          bottom: 20,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(24),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 14),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(
                    color: Colors.white.withValues(alpha: 0.18),
                  ),
                ),
                child: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
                  stream: FirebaseFirestore.instance
                      .collection('videos')
                      .doc(post.id)
                      .snapshots(),
                  builder: (context, videoSnapshot) {
                    final videoData = videoSnapshot.data?.data();
                    final List<String> likedBy = List<String>.from(
                      videoData?['likedBy'] ?? post.likedBy,
                    );
                    final bool isLiked = currentUid != null
                        ? (videoData != null
                            ? likedBy.contains(currentUid)
                            : videoProvider.isLiked(post.id))
                        : videoProvider.isLiked(post.id);
                    final int likesCount =
                        (videoData?['likes'] as num?)?.toInt() ??
                            (videoData?['likesCount'] as num?)?.toInt() ??
                            post.likes;
                    final int commentsCount =
                        (videoData?['comments'] as num?)?.toInt() ??
                            (videoData?['commentsCount'] as num?)?.toInt() ??
                            post.comments;

                    return Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        // Avatar del autor + botón Seguir en tiempo real (users/{miUid}/following/{suUid})
                        Builder(
                          builder: (context) {
                            final userProvider = context.watch<UserProvider>();

                            Widget buildAvatarCircle(
                              String resolvedAvatarUrl, {
                              required bool isFollowing,
                            }) {
                              return Stack(
                                alignment: Alignment.bottomCenter,
                                children: [
                                  Container(
                                    width: 44,
                                    height: 44,
                                    margin: EdgeInsets.only(
                                      bottom: isOwnPost ? 0 : 8,
                                    ),
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: const Color(0xFF27272A),
                                      border: Border.all(
                                        color: Colors.white,
                                        width: 1.5,
                                      ),
                                      image: resolvedAvatarUrl.isNotEmpty
                                          ? DecorationImage(
                                              image: NetworkImage(
                                                resolvedAvatarUrl,
                                              ),
                                              fit: BoxFit.cover,
                                            )
                                          : null,
                                    ),
                                    child: resolvedAvatarUrl.isEmpty
                                        ? const Icon(
                                            Icons.person,
                                            color: Colors.white,
                                          )
                                        : null,
                                  ),
                                  if (!isOwnPost)
                                    Container(
                                      width: 20,
                                      height: 20,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        gradient: isFollowing
                                            ? null
                                            : AppColors.brandGradient,
                                        color:
                                            isFollowing ? Colors.white : null,
                                      ),
                                      child: Icon(
                                        isFollowing ? Icons.check : Icons.add,
                                        color: isFollowing
                                            ? Colors.black
                                            : Colors.white,
                                        size: 14,
                                      ),
                                    ),
                                ],
                              );
                            }

                            if (isOwnPost) {
                              final String myAvatar =
                                  userProvider.avatarUrl.isNotEmpty
                                      ? userProvider.avatarUrl
                                      : post.author.avatarUrl;
                              return buildAvatarCircle(
                                myAvatar,
                                isFollowing: false,
                              );
                            }

                            return GestureDetector(
                              onTap: () =>
                                  videoProvider.toggleFollow(post.author.id),
                              child: StreamBuilder<
                                  DocumentSnapshot<Map<String, dynamic>>>(
                                stream: FirebaseFirestore.instance
                                    .collection('users')
                                    .doc(post.author.id)
                                    .snapshots(),
                                builder: (context, authorSnapshot) {
                                  final String firestoreAvatar =
                                      (authorSnapshot.data
                                                  ?.data()?['avatarUrl'] ??
                                              '')
                                          .toString();
                                  final String effectiveAvatar =
                                      firestoreAvatar.isNotEmpty
                                          ? firestoreAvatar
                                          : post.author.avatarUrl;

                                  if (currentUid == null) {
                                    return buildAvatarCircle(
                                      effectiveAvatar,
                                      isFollowing: videoProvider
                                          .isFollowing(post.author.id),
                                    );
                                  }

                                  return StreamBuilder<
                                      DocumentSnapshot<Map<String, dynamic>>>(
                                    stream: FirebaseFirestore.instance
                                        .collection('users')
                                        .doc(currentUid)
                                        .collection('following')
                                        .doc(post.author.id)
                                        .snapshots(),
                                    builder: (context, followSnap) {
                                      final bool isFollowing = followSnap
                                              .hasData
                                          ? followSnap.data!.exists
                                          : videoProvider
                                              .isFollowing(post.author.id);
                                      return buildAvatarCircle(
                                        effectiveAvatar,
                                        isFollowing: isFollowing,
                                      );
                                    },
                                  );
                                },
                              ),
                            );
                          },
                        ),
                        const SizedBox(height: 16),

                        // Botón de Llama (Blanco a Naranja en tiempo real con animación de escala al tocar)
                        GestureDetector(
                          onTap: () {
                            _triggerFireAnimation();
                            videoProvider.toggleLike(post.id);
                          },
                          child: Column(
                            children: [
                              AnimatedScale(
                                scale: _fireScale,
                                duration: const Duration(milliseconds: 160),
                                curve: Curves.easeOutBack,
                                child: Icon(
                                  Icons.local_fire_department_rounded,
                                  color: isLiked ? AppColors.orange : Colors.white,
                                  size: 32,
                                ),
                              ),
                              const SizedBox(height: 3),
                              Text(
                                _formatCount(likesCount),
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 11,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),

                        // Botón de Comentarios (Abre BottomSheet + contador en tiempo real)
                        GestureDetector(
                          onTap: _openCommentsSheet,
                          child: Column(
                            children: [
                              const Icon(
                                Icons.chat_bubble_outline_rounded,
                                color: Colors.white,
                                size: 28,
                              ),
                              const SizedBox(height: 3),
                              Text(
                                _formatCount(commentsCount),
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 11,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),

                        // Botón Descargar a Galería
                        GestureDetector(
                          onTap: _isDownloading ? null : _handleDownload,
                          child: Column(
                            children: [
                              if (_isDownloading)
                                SizedBox(
                                  width: 28,
                                  height: 28,
                                  child: CircularProgressIndicator(
                                    value: _downloadProgress > 0
                                        ? _downloadProgress
                                        : null,
                                    strokeWidth: 2.8,
                                    color: AppColors.orange,
                                    backgroundColor: Colors.white24,
                                  ),
                                )
                              else
                                const Icon(
                                  Icons.download_rounded,
                                  color: Colors.white,
                                  size: 30,
                                ),
                              const SizedBox(height: 4),
                              Text(
                                _isDownloading ? 'Descargando' : 'Descargar',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 11,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    );
                  },
                ),
              ),
            ),
          ),
        ),
        Positioned(
          left: 14,
          right: 92,
          bottom: 18,
          child: IgnorePointer(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  '@\${post.author.username}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  post.caption,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Colors.white, fontSize: 14),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    const Icon(
                      Icons.music_note_rounded,
                      color: AppColors.orange,
                      size: 16,
                    ),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text(
                        (post.audioName != null && post.audioName!.isNotEmpty)
                            ? post.audioName!
                            : 'Sonido original · Viroklipz',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.white70,
                          fontSize: 13,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}`,
  },
  {
    id: 'comments_bottom_sheet',
    path: 'lib/widgets/comments_bottom_sheet.dart',
    phase: 'Widgets · CommentsBottomSheet (Firestore Subcolección)',
    language: 'dart',
    summary:
      'Bottom Sheet en tiempo real con StreamBuilder leyendo videos/{videoId}/comments, TextField inferior para enviar (uid, username, text, createdAt) y actualización de commentsCount.',
    code: `import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/video_provider.dart';

class CommentsBottomSheet extends StatefulWidget {
  final String videoId;

  const CommentsBottomSheet({super.key, required this.videoId});

  @override
  State<CommentsBottomSheet> createState() => _CommentsBottomSheetState();
}

class _CommentsBottomSheetState extends State<CommentsBottomSheet> {
  final TextEditingController _commentController = TextEditingController();
  bool _isSending = false;

  @override
  void dispose() {
    _commentController.dispose();
    super.dispose();
  }

  Future<void> _submitComment() async {
    final text = _commentController.text.trim();
    if (text.isEmpty || _isSending) return;

    setState(() => _isSending = true);
    _commentController.clear();

    try {
      await context.read<VideoProvider>().addComment(
            videoId: widget.videoId,
            text: text,
          );
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('No se pudo publicar el comentario'),
            backgroundColor: Color(0xFFEF4444),
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _isSending = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final bottomInset = MediaQuery.of(context).viewInsets.bottom;

    return Container(
      height: MediaQuery.of(context).size.height * 0.65 + bottomInset,
      padding: EdgeInsets.only(bottom: bottomInset),
      decoration: const BoxDecoration(
        color: Color(0xFF18181B),
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: Column(
        children: [
          const SizedBox(height: 10),
          Container(
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: Colors.white24,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          // Cabecera con contador en tiempo real
          StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
            stream: FirebaseFirestore.instance
                .collection('videos')
                .doc(widget.videoId)
                .snapshots(),
            builder: (context, snapshot) {
              final int count =
                  (snapshot.data?.data()?['commentsCount'] as num?)?.toInt() ??
                      0;
              return Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 8, 8),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      '\$count comentarios',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    IconButton(
                      onPressed: () => Navigator.of(context).pop(),
                      icon: const Icon(Icons.close, color: Colors.white70),
                    ),
                  ],
                ),
              );
            },
          ),
          const Divider(height: 1, color: Colors.white12),

          // Lista de comentarios con StreamBuilder en videos/{videoId}/comments
          Expanded(
            child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
              stream: FirebaseFirestore.instance
                  .collection('videos')
                  .doc(widget.videoId)
                  .collection('comments')
                  .orderBy('createdAt', descending: true)
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting &&
                    !snapshot.hasData) {
                  return const Center(
                    child: CircularProgressIndicator(
                      color: Color(0xFFFF5722),
                    ),
                  );
                }

                final docs = snapshot.data?.docs ?? [];
                if (docs.isEmpty) {
                  return const Center(
                    child: Text(
                      'Sé el primero en comentar',
                      style: TextStyle(color: Colors.white54, fontSize: 13),
                    ),
                  );
                }

                return ListView.separated(
                  padding: const EdgeInsets.all(16),
                  itemCount: docs.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 14),
                  itemBuilder: (context, index) {
                    final data = docs[index].data();
                    final String username =
                        (data['username'] ?? 'usuario').toString();
                    final String text = (data['text'] ?? '').toString();

                    return Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        CircleAvatar(
                          radius: 16,
                          backgroundColor: const Color(0xFF27272A),
                          child: Text(
                            username.isNotEmpty
                                ? username.substring(0, 1).toUpperCase()
                                : 'U',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                '@\$username',
                                style: const TextStyle(
                                  color: Colors.white60,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                text,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 13.5,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    );
                  },
                );
              },
            ),
          ),

          // Campo inferior para escribir comentario
          SafeArea(
            top: false,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: const BoxDecoration(
                color: Color(0xFF0F0F12),
                border: Border(top: BorderSide(color: Colors.white12)),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _commentController,
                      style: const TextStyle(color: Colors.white, fontSize: 14),
                      decoration: InputDecoration(
                        hintText: 'Añade un comentario...',
                        hintStyle: const TextStyle(color: Colors.white38),
                        filled: true,
                        fillColor: const Color(0xFF27272A),
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 10,
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(24),
                          borderSide: BorderSide.none,
                        ),
                      ),
                      onSubmitted: (_) => _submitComment(),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton(
                    onPressed: _isSending ? null : _submitComment,
                    style: IconButton.styleFrom(
                      backgroundColor: const Color(0xFFFF2D55),
                      foregroundColor: Colors.white,
                    ),
                    icon: _isSending
                        ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.white,
                            ),
                          )
                        : const Icon(Icons.send_rounded, size: 18),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}`,
  },
  {
    id: 'push_notification_service',
    path: 'lib/services/push_notification_service.dart',
    phase: 'Push FCM · PushNotificationService (Permisos + Token + Foreground + Clic)',
    language: 'dart',
    summary:
      'Servicio completo de Firebase Cloud Messaging y flutter_local_notifications: solicita permisos, guarda users/{uid}/fcmToken, muestra alertas en primer plano y navega a VideoDetailScreen o ProfileScreen al tocar la notificación.',
    code: `import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import '../firebase_options.dart';
import '../screens/profile_screen.dart';
import '../screens/video_detail_screen.dart';

/// Handler top-level obligatorio para mensajes recibidos con la app cerrada o en segundo plano.
@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
}

class PushNotificationService {
  PushNotificationService._();
  static final PushNotificationService instance = PushNotificationService._();

  /// Llave global conectada a MaterialApp.navigatorKey para navegar desde notificaciones
  static final GlobalKey<NavigatorState> navigatorKey =
      GlobalKey<NavigatorState>();

  static const AndroidNotificationChannel _highImportanceChannel =
      AndroidNotificationChannel(
    'viroklipz_high_importance',
    'Notificaciones Viroklipz',
    description: 'Alertas de likes, comentarios y nuevos seguidores.',
    importance: Importance.max,
  );

  final FirebaseMessaging _messaging = FirebaseMessaging.instance;
  final FlutterLocalNotificationsPlugin _localNotifications =
      FlutterLocalNotificationsPlugin();

  bool _isInitialized = false;

  Future<void> initialize() async {
    if (_isInitialized) return;
    _isInitialized = true;

    const AndroidInitializationSettings androidSettings =
        AndroidInitializationSettings('@mipmap/ic_launcher');
    const DarwinInitializationSettings iosSettings =
        DarwinInitializationSettings();

    await _localNotifications.initialize(
      const InitializationSettings(
        android: androidSettings,
        iOS: iosSettings,
      ),
      onDidReceiveNotificationResponse: (NotificationResponse response) {
        if (response.payload == null || response.payload!.isEmpty) return;
        try {
          final Map<String, dynamic> data =
              jsonDecode(response.payload!) as Map<String, dynamic>;
          _navigateFromData(data);
        } catch (_) {}
      },
    );

    final AndroidFlutterLocalNotificationsPlugin? androidPlugin =
        _localNotifications.resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>();
    await androidPlugin?.createNotificationChannel(_highImportanceChannel);

    await _messaging.setForegroundNotificationPresentationOptions(
      alert: true,
      badge: true,
      sound: true,
    );

    // 1. Notificación recibida con la app abierta (Foreground) -> flutter_local_notifications
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      final RemoteNotification? notification = message.notification;
      if (notification == null) return;

      _localNotifications.show(
        notification.hashCode,
        notification.title ?? 'Viroklipz',
        notification.body ?? '',
        NotificationDetails(
          android: AndroidNotificationDetails(
            _highImportanceChannel.id,
            _highImportanceChannel.name,
            channelDescription: _highImportanceChannel.description,
            importance: Importance.max,
            priority: Priority.high,
            icon: '@mipmap/ic_launcher',
          ),
          iOS: const DarwinNotificationDetails(
            presentAlert: true,
            presentBadge: true,
            presentSound: true,
          ),
        ),
        payload: jsonEncode(message.data),
      );
    });

    // 2. Clic en la notificación cuando la app estaba en segundo plano
    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      _navigateFromData(message.data);
    });

    // 3. Clic en la notificación que abrió la app desde estado completamente cerrado (Terminated)
    final RemoteMessage? initialMessage = await _messaging.getInitialMessage();
    if (initialMessage != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _navigateFromData(initialMessage.data);
      });
    }
  }

  /// Solicita permiso al usuario al iniciar sesión y guarda el fcmToken en users/{uid}/fcmToken
  Future<void> requestPermissionAndSaveToken(String uid) async {
    if (uid.trim().isEmpty) return;

    final NotificationSettings settings = await _messaging.requestPermission(
      alert: true,
      badge: true,
      sound: true,
      provisional: false,
    );

    final bool granted =
        settings.authorizationStatus == AuthorizationStatus.authorized ||
            settings.authorizationStatus == AuthorizationStatus.provisional;
    if (!granted) return;

    try {
      final String? token = await _messaging.getToken();
      if (token != null && token.isNotEmpty) {
        await FirebaseFirestore.instance.collection('users').doc(uid).set(
          {
            'fcmToken': token,
            'fcmUpdatedAt': FieldValue.serverTimestamp(),
          },
          SetOptions(merge: true),
        );
      }

      // Mantener sincronizado el token si FCM lo rota automáticamente
      _messaging.onTokenRefresh.listen((String newToken) async {
        await FirebaseFirestore.instance.collection('users').doc(uid).set(
          {
            'fcmToken': newToken,
            'fcmUpdatedAt': FieldValue.serverTimestamp(),
          },
          SetOptions(merge: true),
        );
      });
    } catch (_) {
      // Silencioso en simuladores sin APNs/Google Play Services
    }
  }

  void _navigateFromData(Map<String, dynamic> data) {
    final NavigatorState? navigator = navigatorKey.currentState;
    if (navigator == null) return;

    final String type = (data['type'] ?? '').toString();
    final String videoId = (data['videoId'] ?? '').toString();
    final String senderUid = (data['senderUid'] ?? '').toString();
    final String senderName = (data['senderName'] ?? '').toString();

    if ((type == 'like' || type == 'comment') && videoId.isNotEmpty) {
      navigator.push(
        MaterialPageRoute(
          builder: (_) => VideoDetailScreen(videoId: videoId),
        ),
      );
      return;
    }

    if (type == 'follow' && (senderName.isNotEmpty || senderUid.isNotEmpty)) {
      navigator.push(
        MaterialPageRoute(
          builder: (_) => ProfileScreen(
            embeddedInMainShell: false,
            username: senderName.isNotEmpty ? senderName : null,
            userId: senderUid.isNotEmpty ? senderUid : null,
          ),
        ),
      );
    }
  }
}`,
  },
  {
    id: 'video_detail_screen',
    path: 'lib/screens/video_detail_screen.dart',
    phase: 'Push FCM · Navegación directa al Video',
    language: 'dart',
    summary:
      'Pantalla destino cuando el usuario toca una notificación Push de like o comentario (lee videos/{videoId} en tiempo real).',
    code: `import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import '../widgets/video_card.dart';

class VideoDetailScreen extends StatelessWidget {
  final String videoId;

  const VideoDetailScreen({super.key, required this.videoId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
            stream: FirebaseFirestore.instance
                .collection('videos')
                .doc(videoId)
                .snapshots(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting &&
                  !snapshot.hasData) {
                return const Center(
                  child: CircularProgressIndicator(color: AppColors.orange),
                );
              }

              final doc = snapshot.data;
              if (doc == null || !doc.exists) {
                return const Center(
                  child: Text(
                    'Este video ya no está disponible.',
                    style: TextStyle(color: Colors.white70, fontSize: 14),
                  ),
                );
              }

              final data = doc.data() ?? <String, dynamic>{};
              final String videoUrl = (data['videoUrl'] ?? '').toString();
              final String username =
                  (data['username'] ?? 'usuario').toString();
              final String caption = (data['caption'] ?? '').toString();
              final int likes =
                  ((data['likes'] ?? data['likesCount'] ?? 0) as num).toInt();
              final int comments =
                  ((data['comments'] ?? data['commentsCount'] ?? 0) as num)
                      .toInt();
              final String avatarUrl = (data['avatarUrl'] ?? '').toString();
              final String uid =
                  (data['uid'] ?? data['authorId'] ?? '').toString();
              final List<String> likedBy = List<String>.from(
                data['likedBy'] ?? const <String>[],
              );

              return VideoCard(
                key: ValueKey(doc.id),
                videoId: doc.id,
                videoUrl: videoUrl,
                username: username,
                caption: caption,
                likes: likes,
                comments: comments,
                avatarUrl: avatarUrl,
                uid: uid,
                likedBy: likedBy,
                audioName: (data['audioName'] ?? '').toString(),
                effectUsed: (data['effectUsed'] ?? '').toString(),
                effectVideoUrl: (data['effectVideoUrl'] ?? '').toString(),
                isActive: true,
              );
            },
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: IconButton(
                onPressed: () => Navigator.of(context).pop(),
                style: IconButton.styleFrom(
                  backgroundColor: Colors.black54,
                ),
                icon: const Icon(
                  Icons.arrow_back_ios_new_rounded,
                  color: Colors.white,
                  size: 20,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}`,
  },
  {
    id: 'cloud_functions_index',
    path: 'functions/index.js',
    phase: 'Backend Node.js · Cloud Functions (Firestore -> FCM)',
    language: 'javascript',
    summary:
      'Escucha onDocumentCreated en notifications/{notificationId}, consulta users/{receiverUid}.fcmToken y envía la notificación Push con Firebase Admin SDK.',
    code: `const { onDocumentCreated } = require("firebase-functions/v2/firestore");
const { initializeApp } = require("firebase-admin/app");
const { getFirestore, FieldValue } = require("firebase-admin/firestore");
const { getMessaging } = require("firebase-admin/messaging");

initializeApp();

const db = getFirestore();

/**
 * Se dispara automáticamente al crearse un documento en: notifications/{notificationId}
 * Campos esperados: senderUid, senderName, receiverUid, type ('like' | 'comment' | 'follow'), videoId?
 */
exports.sendPushNotification = onDocumentCreated(
  "notifications/{notificationId}",
  async (event) => {
    const snapshot = event.data;
    if (!snapshot) return null;

    const data = snapshot.data();
    const receiverUid = data.receiverUid;
    const senderUid = data.senderUid || "";
    const senderName = data.senderName || "Alguien";
    const type = data.type || "like";
    const videoId = data.videoId || "";

    // Evitar enviar notificaciones al mismo usuario que ejecutó la acción
    if (!receiverUid || (senderUid && senderUid === receiverUid)) {
      return null;
    }

    // 1. Buscar el fcmToken del receptor en users/{receiverUid}
    const userDoc = await db.collection("users").doc(receiverUid).get();
    if (!userDoc.exists) {
      return null;
    }

    const fcmToken = userDoc.data().fcmToken;
    if (!fcmToken) {
      console.log("Usuario sin fcmToken registrado:", receiverUid);
      return null;
    }

    // 2. Construir título y cuerpo según el tipo de interacción
    let title = "Viroklipz";
    let body = senderName + " interactuó contigo.";

    if (type === "like") {
      title = "¡Nuevo Fuego! 🔥";
      body = "@" + senderName + " le dio like a tu video.";
    } else if (type === "comment") {
      title = "Nuevo comentario 💬";
      body = "@" + senderName + " comentó en tu video.";
    } else if (type === "follow") {
      title = "¡Nuevo seguidor! ✨";
      body = "@" + senderName + " comenzó a seguirte.";
    }

    // 3. Armar el payload FCM (con data para deep-linking en Flutter)
    const message = {
      token: fcmToken,
      notification: {
        title: title,
        body: body,
      },
      data: {
        type: String(type),
        videoId: String(videoId),
        senderUid: String(senderUid),
        senderName: String(senderName),
      },
      android: {
        priority: "high",
        notification: {
          channelId: "viroklipz_high_importance",
          sound: "default",
        },
      },
      apns: {
        payload: {
          aps: {
            sound: "default",
            badge: 1,
          },
        },
      },
    };

    try {
      const response = await getMessaging().send(message);
      console.log("Push FCM enviada:", response);
      return response;
    } catch (error) {
      console.error("Error enviando Push FCM:", error);
      // Limpiar token inválido si la app fue desinstalada
      if (
        error.code === "messaging/registration-token-not-registered" ||
        error.code === "messaging/invalid-registration-token"
      ) {
        await db.collection("users").doc(receiverUid).update({
          fcmToken: FieldValue.delete(),
        });
      }
      return null;
    }
  }
);`,
  },
  {
    id: 'cloud_functions_package',
    path: 'functions/package.json',
    phase: 'Backend Node.js · Dependencias Cloud Functions',
    language: 'json',
    summary:
      'Configuración de Node.js 20 con firebase-admin y firebase-functions para desplegar sendPushNotification.',
    code: `{
  "name": "viroklipz-functions",
  "description": "Cloud Functions de Viroklipz para Notificaciones Push FCM",
  "main": "index.js",
  "engines": {
    "node": "20"
  },
  "dependencies": {
    "firebase-admin": "^12.6.0",
    "firebase-functions": "^6.0.1"
  }
}`,
  },
  {
    id: 'permissions_config',
    path: 'android_ios_permissions.xml',
    phase: 'Permisos Nativos · Android & iOS (FCM + Cámara + Galería)',
    language: 'xml',
    summary:
      'Bloques exactos para AndroidManifest.xml (incluyendo POST_NOTIFICATIONS y canal FCM) e Info.plist requeridos por FCM, mobile_scanner, image_picker y gal.',
    code: `<!-- ============================================================ -->
<!-- 1. ANDROID: android/app/src/main/AndroidManifest.xml          -->
<!-- Pegar dentro de <manifest ...> justo arriba de <application> -->
<!-- ============================================================ -->

<!-- Permiso obligatorio en Android 13+ (API 33+) para Notificaciones Push FCM -->
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />

<!-- Permisos de cámara, flash y micrófono para grabación y escaneo QR (Android 13+ compatible) -->
<uses-permission android:name="android.permission.CAMERA" />
<uses-permission android:name="android.permission.FLASHLIGHT" />
<uses-permission android:name="android.permission.RECORD_AUDIO" />
<uses-feature android:name="android.hardware.camera.any" android:required="false" />
<uses-feature android:name="android.hardware.camera" android:required="false" />
<uses-feature android:name="android.hardware.camera.autofocus" android:required="false" />

<!-- Permiso de red para Dio y Firebase -->
<uses-permission android:name="android.permission.INTERNET" />

<!-- Android 12 e inferiores (API <= 32) -->
<uses-permission
    android:name="android.permission.WRITE_EXTERNAL_STORAGE"
    android:maxSdkVersion="32" />
<uses-permission
    android:name="android.permission.READ_EXTERNAL_STORAGE"
    android:maxSdkVersion="32" />

<!-- Android 13+ (API 33+): permisos granulares de medios -->
<uses-permission android:name="android.permission.READ_MEDIA_VIDEO" />
<uses-permission android:name="android.permission.READ_MEDIA_IMAGES" />

<!-- Android 11+ / 13+: Visibilidad de intents para selector de cámara/galería -->
<queries>
    <intent>
        <action android:name="android.media.action.IMAGE_CAPTURE" />
    </intent>
    <intent>
        <action android:name="android.media.action.VIDEO_CAPTURE" />
    </intent>
</queries>

<!-- Dentro de <application ...> en AndroidManifest.xml (canal FCM por defecto) -->
<meta-data
    android:name="com.google.firebase.messaging.default_notification_channel_id"
    android:value="viroklipz_high_importance" />


<!-- ============================================================ -->
<!-- 2. iOS: ios/Runner/Info.plist & Xcode Capabilities            -->
<!-- En Xcode -> Signing & Capabilities -> "+ Capability":         -->
<!--   1) Push Notifications                                       -->
<!--   2) Background Modes -> marcar "Remote notifications"        -->
<!-- Pegar dentro de la etiqueta <dict> principal en Info.plist:   -->
<!-- ============================================================ -->

<key>NSCameraUsageDescription</key>
<string>Viroklipz necesita acceso a la cámara para grabar tus videos.</string>

<key>NSMicrophoneUsageDescription</key>
<string>Viroklipz necesita acceso al micrófono para grabar audio en tus videos.</string>

<key>NSPhotoLibraryAddUsageDescription</key>
<string>Viroklipz necesita permiso para guardar los videos descargados en tu galería.</string>

<key>NSPhotoLibraryUsageDescription</key>
<string>Viroklipz necesita acceso a tu galería para seleccionar y guardar videos.</string>`,
  },
  {
    id: 'firebase_setup_config',
    path: 'firebase_setup_guide.yaml',
    phase: 'Firebase · CLI FlutterFire + Cloud Functions + Gradle',
    language: 'yaml',
    summary:
      'Comandos para flutterfire_cli, instalación de firebase_messaging y despliegue de Cloud Functions (firebase deploy --only functions).',
    code: `# ============================================================
# 1. TERMINAL: INSTALACIÓN DE PAQUETES Y FLUTTERFIRE CLI
# ============================================================
# 1) Instalar Firebase CLI (si no lo tienes):
#    npm install -g firebase-tools
#    firebase login
#
# 2) Instalar FlutterFire CLI:
#    dart pub global activate flutterfire_cli
#
# 3) Agregar paquetes en la raíz del proyecto Flutter:
#    flutter pub add firebase_core firebase_auth cloud_firestore firebase_messaging flutter_local_notifications
#
# 4) Vincular proyecto y generar lib/firebase_options.dart:
#    flutterfire configure

# ============================================================
# 2. DESPLIEGUE DE CLOUD FUNCTIONS (NODE.JS)
# ============================================================
# 1) Inicializar Functions en la raíz (si aún no existe la carpeta functions/):
#    firebase init functions
#    -> Seleccionar JavaScript
#
# 2) Instalar dependencias dentro de functions/:
#    cd functions
#    npm install firebase-admin firebase-functions
#
# 3) Desplegar la función sendPushNotification:
#    firebase deploy --only functions
#
# (Nota: Cloud Functions v2 requiere el plan Blaze de Firebase)

# ============================================================
# 3. ARCHIVOS NATIVOS (SI CONFIGURAS MANUALMENTE)
# ============================================================
# Android -> Copiar google-services.json en:
#   android/app/google-services.json
#
# iOS -> Abrir ios/Runner.xcworkspace en Xcode, arrastrar
#   GoogleService-Info.plist dentro de la carpeta Runner/ (Copy items if needed):
#   ios/Runner/GoogleService-Info.plist

# ============================================================
# 4. ANDROID GRADLE (android/app/build.gradle)
# ============================================================
# En android/build.gradle (dentro de buildscript -> dependencies):
#   classpath 'com.google.gms:google-services:4.4.2'
#
# En android/app/build.gradle:
#   android {
#       compileSdkVersion 34
#       defaultConfig {
#           minSdkVersion 21 // (o 23 recomendado para Firebase + Camera)
#           targetSdkVersion 34
#       }
#   }
#
# (En Flutter reciente con plugins DSL en android/settings.gradle):
#   id "com.google.gms.google-services" version "4.4.2" apply false
# Y en android/app/build.gradle -> plugins { ... }:
#   id "com.google.gms.google-services"`,
  },
  {
    id: 'firestore_rules',
    path: 'firestore.rules',
    phase: 'Producción · Reglas de Seguridad Cloud Firestore',
    language: 'rules',
    summary:
      'Reglas estrictas para producción: exige autenticación, protege la edición de perfil por propietario, permite leer videos y restringe edición/borrado al creador, y protege comentarios por uid.',
    code: `rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {

    // Helpers de seguridad
    function isAuthenticated() {
      return request.auth != null;
    }

    function isOwner(userId) {
      return isAuthenticated() && request.auth.uid == userId;
    }

    // Bloqueo por defecto: ninguna colección no declarada queda expuesta
    match /{document=**} {
      allow read, write: if false;
    }

    // 1. PERFILES DE USUARIO:
    //    Solo usuarios autenticados pueden leer; cada usuario solo puede crear/editar/eliminar SU propio perfil.
    match /users/{userId} {
      allow read: if isAuthenticated();
      allow create, update, delete: if isOwner(userId);

      // Subcolección following: solo el propietario de su lista puede seguir/dejar de seguir
      match /following/{targetUid} {
        allow read: if isAuthenticated();
        allow write: if isOwner(userId);
      }

      // Subcolección followers: un usuario autenticado solo puede agregarse/quitarse como seguidor suyo
      match /followers/{followerUid} {
        allow read: if isAuthenticated();
        allow write: if isOwner(followerUid);
      }
    }

    // 2. VIDEOS Y COMENTARIOS:
    //    Cualquiera puede leer los videos; solo usuarios autenticados crean videos
    //    y solo el creador (authorId) puede editar o eliminar su propio video.
    match /videos/{videoId} {
      allow read: if true;

      allow create: if isAuthenticated() && (
        request.resource.data.authorId == request.auth.uid ||
        request.resource.data.uid == request.auth.uid
      );

      // El creador puede editar todo su video; otros usuarios autenticados solo
      // pueden actualizar likedBy, likes/likesCount y comments/commentsCount al interactuar.
      allow update: if isAuthenticated() && (
        resource.data.authorId == request.auth.uid ||
        resource.data.uid == request.auth.uid ||
        request.resource.data.diff(resource.data).affectedKeys()
          .hasOnly(['likedBy', 'likes', 'likesCount', 'comments', 'commentsCount'])
      );

      allow delete: if isAuthenticated() && (
        resource.data.authorId == request.auth.uid ||
        resource.data.uid == request.auth.uid
      );

      // Comentarios: solo usuarios autenticados pueden leer y crear; solo el autor puede borrar/editar el suyo
      match /comments/{commentId} {
        allow read: if isAuthenticated();
        allow create: if isAuthenticated()
          && request.resource.data.uid == request.auth.uid;
        allow update, delete: if isAuthenticated()
          && resource.data.uid == request.auth.uid;
      }
    }

    // 3. NOTIFICACIONES PUSH (disparadores de Cloud Functions):
    //    Solo usuarios autenticados crean alertas con su senderUid; solo el receptor puede leer/actualizar/borrar.
    match /notifications/{notificationId} {
      allow create: if isAuthenticated()
        && request.resource.data.senderUid == request.auth.uid;
      allow read, update, delete: if isAuthenticated()
        && resource.data.receiverUid == request.auth.uid;
    }

    // 4. CHATS Y MENSAJES 1 A 1:
    //    Solo usuarios autenticados participantes pueden leer y escribir.
    match /chats/{chatId} {
      allow read, write: if isAuthenticated();

      match /messages/{messageId} {
        allow read, write: if isAuthenticated();
      }
    }
  }
}`,
  },
  {
    id: 'legal_screen',
    path: 'lib/screens/legal_screen.dart',
    phase: 'Legal · LegalScreen Reutilizable (StatefulWidget + SingleChildScrollView)',
    language: 'dart',
    summary:
      'Pantalla LegalScreen reutilizable (StatefulWidget) con AppBar oscura, SingleChildScrollView + Padding y texto formateado con títulos en negrita y colores claros para Términos y Condiciones y Política de Privacidad.',
    code: `import 'package:flutter/material.dart';

class LegalTexts {
  static const String termsAndConditions = '''
**TÉRMINOS Y CONDICIONES DE USO DE VIROKLIPZ**
Última actualización: Noviembre 2026

**1. Aceptación de los términos**
Al descargar, registrarte o utilizar la aplicación móvil Viroklipz, aceptas quedar vinculado por estos Términos y Condiciones de Uso y por nuestra Política de Privacidad. Si no estás de acuerdo con alguno de estos términos, por favor no utilices la plataforma.

**2. Elegibilidad y edad mínima**
Para crear una cuenta y publicar contenido en Viroklipz debes tener al menos 13 años de edad (o la edad mínima legal aplicable en tu país). Los usuarios menores de 18 años declaran contar con la autorización expresa de su padre, madre o tutor legal.

**3. Cuenta de usuario y seguridad**
Eres responsable de mantener la confidencialidad de tus credenciales de acceso y de toda actividad realizada desde tu cuenta. Debes notificarnos de inmediato si detectas un uso no autorizado de tu perfil.

**4. Contenido generado por los usuarios**
Conservas la titularidad de los videos, audios, descripciones y comentarios que publiques en Viroklipz. No obstante, al publicar contenido en la plataforma nos concedes una licencia mundial, no exclusiva y gratuita para alojarlo, reproducirlo y mostrarlo dentro de la aplicación.

Queda estrictamente prohibido publicar contenido que:
• Sea ilegal, difamatorio, violento, sexualmente explícito o promueva el odio.
• Infrinja derechos de autor, marcas comerciales o derechos de terceros.
• Suplante la identidad de otra persona o distribuya spam o software malicioso.

**5. Moderación y eliminación de cuenta**
Viroklipz se reserva el derecho de retirar contenido que infrinja las normas de la comunidad y de suspender o cancelar cuentas reincidentes. Puedes eliminar tu cuenta en cualquier momento desde el menú lateral en la opción "Eliminar cuenta".

**6. Funciones virtuales y modificaciones**
Los saldos, monedas o herramientas de estudio mostrados en la aplicación están sujetos a disponibilidad y pueden actualizarse o modificarse para mejorar el servicio.

**7. Contacto**
Si tienes dudas sobre estos Términos y Condiciones, puedes contactarnos a través del Centro de Ayuda dentro de la aplicación.
''';

  static const String privacyPolicy = '''
**POLÍTICA DE PRIVACIDAD DE VIROKLIPZ**
Última actualización: Noviembre 2026

**1. Información que recopilamos**
En Viroklipz respetamos tu privacidad y recopilamos únicamente los datos necesarios para brindarte el servicio:
• Datos de cuenta: correo electrónico, nombre de usuario, nombre visible, biografía y foto de perfil.
• Contenido publicado: videos, descripciones, hashtags, comentarios, "Me gusta" y relaciones de seguimiento.
• Datos técnicos: token de notificaciones push (FCM) para enviarte alertas de actividad cuando lo autorices.

**2. Uso de cámara, micrófono, galería y almacenamiento**
Viroklipz solicita acceso a la cámara, micrófono y galería del dispositivo únicamente cuando decides grabar un clip, seleccionar un video existente, escanear un código QR de perfil o guardar un video en tu galería. No grabamos ni accedemos a estos sensores en segundo plano sin tu acción directa.

**3. Finalidad del tratamiento de datos**
Utilizamos tu información para:
• Autenticar tu sesión de forma segura mediante Firebase Authentication.
• Almacenar y reproducir tus videos mediante Firebase Storage y Cloud Firestore.
• Mostrar tu perfil, seguidores y notificaciones en tiempo real.
• Prevenir abusos, spam y mantener la seguridad de la comunidad.

**4. Compartición de información**
No vendemos ni alquilamos tus datos personales a terceros. Tu nombre de usuario, avatar y videos públicos son visibles para otros usuarios de Viroklipz. Los proveedores de infraestructura (como Google Firebase) procesan los datos bajo estrictas medidas de seguridad y cifrado.

**5. Retención y eliminación de datos**
Conservamos tus datos mientras tu cuenta permanezca activa. Puedes actualizar tu perfil, revocar permisos del sistema operativo o eliminar permanentemente tu cuenta y datos asociados desde el menú lateral ("Eliminar cuenta").

**6. Privacidad de menores**
No recopilamos de manera consciente información personal de niños menores de la edad mínima legal sin el consentimiento de sus padres o tutores.

**7. Cambios en esta política**
Podemos actualizar esta Política de Privacidad periódicamente. Cualquier cambio relevante será notificado dentro de la aplicación.
''';
}

class LegalScreen extends StatefulWidget {
  final String title;
  final String content;

  const LegalScreen({
    super.key,
    required this.title,
    required this.content,
  });

  @override
  State<LegalScreen> createState() => _LegalScreenState();
}

class _LegalScreenState extends State<LegalScreen> {
  final ScrollController _scrollController = ScrollController();

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  List<TextSpan> _buildFormattedSpans(String rawText) {
    final List<TextSpan> spans = <TextSpan>[];
    final RegExp boldRegex = RegExp(r'\\*\\*(.*?)\\*\\*');
    int lastIndex = 0;

    for (final RegExpMatch match in boldRegex.allMatches(rawText)) {
      if (match.start > lastIndex) {
        spans.add(
          TextSpan(
            text: rawText.substring(lastIndex, match.start),
            style: const TextStyle(
              color: Color(0xFFD4D4D8),
              fontSize: 14.5,
              height: 1.65,
            ),
          ),
        );
      }

      spans.add(
        TextSpan(
          text: match.group(1) ?? '',
          style: const TextStyle(
            color: Colors.white,
            fontSize: 15.5,
            fontWeight: FontWeight.w700,
            height: 1.65,
          ),
        ),
      );

      lastIndex = match.end;
    }

    if (lastIndex < rawText.length) {
      spans.add(
        TextSpan(
          text: rawText.substring(lastIndex),
          style: const TextStyle(
            color: Color(0xFFD4D4D8),
            fontSize: 14.5,
            height: 1.65,
          ),
        ),
      );
    }

    return spans;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF121212),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          widget.title,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 17,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          controller: _scrollController,
          padding: const EdgeInsets.all(20),
          child: Text.rich(
            TextSpan(children: _buildFormattedSpans(widget.content)),
          ),
        ),
      ),
    );
  }
}`,
  },
  {
    id: 'privacy_policy_screen',
    path: 'lib/screens/privacy_policy_screen.dart',
    phase: 'Legal · PrivacyPolicyScreen (AppBar + SingleChildScrollView)',
    language: 'dart',
    summary:
      'Pantalla de Política de privacidad de Viroklipz conectada al botón Centro de privacidad en Ajustes.',
    code: `import 'package:flutter/material.dart';
import '../theme/app_colors.dart';

class PrivacyPolicyScreen extends StatelessWidget {
  const PrivacyPolicyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.background,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: const Text(
          'Política de privacidad',
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _LegalHeaderCard(
              icon: Icons.privacy_tip_outlined,
              title: 'Política de Privacidad de Viroklipz',
              subtitle: 'Última actualización: Noviembre 2026',
            ),
            const SizedBox(height: 16),
            _LegalSectionCard(
              title: '1. Recopilación de datos en Viroklipz',
              body:
                  'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Viroklipz recopila únicamente la información necesaria para operar tu perfil de creador, como tu correo electrónico, nombre de usuario, avatar, videos subidos y token FCM para notificaciones push. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
            ),
            const SizedBox(height: 12),
            _LegalSectionCard(
              title: '2. Cámara, micrófono, galería y código QR',
              body:
                  'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Viroklipz solicita acceso a cámara, micrófono y galería exclusivamente para grabar videos, escanear perfiles QR y guardar contenido cuando tú lo autorizas. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore.',
            ),
            const SizedBox(height: 12),
            _LegalSectionCard(
              title: '3. Seguridad, menores de edad y eliminación de cuenta',
              body:
                  'Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Puedes solicitar la eliminación permanente de tu cuenta y datos personales en cualquier momento desde Ajustes o el menú de Perfil en Viroklipz.',
            ),
            const SizedBox(height: 24),
            const Center(
              child: Text(
                '© 2026 Viroklipz · Todos los derechos reservados',
                style: TextStyle(color: Color(0xFF71717A), fontSize: 12),
              ),
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}

class _LegalHeaderCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;

  const _LegalHeaderCard({
    required this.icon,
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white10),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              gradient: AppColors.brandGradient,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: Colors.white, size: 22),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: const TextStyle(
                    color: Color(0xFFA1A1AA),
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _LegalSectionCard extends StatelessWidget {
  final String title;
  final String body;

  const _LegalSectionCard({
    required this.title,
    required this.body,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 14.5,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            body,
            style: const TextStyle(
              color: Color(0xFFD4D4D8),
              fontSize: 13.5,
              height: 1.55,
            ),
          ),
        ],
      ),
    );
  }
}`,
  },
  {
    id: 'terms_of_service_screen',
    path: 'lib/screens/terms_of_service_screen.dart',
    phase: 'Legal · TermsOfServiceScreen (AppBar + SingleChildScrollView)',
    language: 'dart',
    summary:
      'Pantalla de Términos del Servicio de Viroklipz conectada al botón Términos y políticas en Ajustes.',
    code: `import 'package:flutter/material.dart';
import '../theme/app_colors.dart';

class TermsOfServiceScreen extends StatelessWidget {
  const TermsOfServiceScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.background,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: const Text(
          'Términos y políticas',
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.white10),
              ),
              child: Row(
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      gradient: AppColors.brandGradient,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(
                      Icons.description_outlined,
                      color: Colors.white,
                      size: 22,
                    ),
                  ),
                  const SizedBox(width: 14),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Términos del Servicio de Viroklipz',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        SizedBox(height: 2),
                        Text(
                          'Vigente desde Noviembre 2026',
                          style: TextStyle(
                            color: Color(0xFFA1A1AA),
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            _buildSection(
              '1. Aceptación de los Términos de Viroklipz',
              'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Al crear una cuenta o navegar por Viroklipz, aceptas estos Términos del Servicio y las Normas de la Comunidad. Los usuarios menores de 18 años deben contar con autorización verificada de su representante legal.',
            ),
            const SizedBox(height: 12),
            _buildSection(
              '2. Contenido generado por usuarios y derechos de autor',
              'Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Cada creador conserva la titularidad de sus videos y es responsable del material publicado en Viroklipz.',
            ),
            const SizedBox(height: 12),
            _buildSection(
              '3. Monedas virtuales, moderación y cierre de cuentas',
              'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Viroklipz podrá suspender cuentas que incumplan las políticas de seguridad.',
            ),
            const SizedBox(height: 24),
            const Center(
              child: Text(
                '© 2026 Viroklipz · Términos del Servicio',
                style: TextStyle(color: Color(0xFF71717A), fontSize: 12),
              ),
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  static Widget _buildSection(String title, String body) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 14.5,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            body,
            style: const TextStyle(
              color: Color(0xFFD4D4D8),
              fontSize: 13.5,
              height: 1.55,
            ),
          ),
        ],
      ),
    );
  }
}`,
  },
  {
    id: 'android_release_guide',
    path: 'android_release_guide.yaml',
    phase: 'Producción · Keystore + Build AAB + Checklist Tiendas',
    language: 'yaml',
    summary:
      'Comandos exactos para crear el upload-keystore.jks, configurar key.properties / build.gradle, compilar app-release.aab e ipa, y checklist de aprobación en Google Play.',
    code: `# ============================================================
# 1. CREAR KEYSTORE DE FIRMA (upload-keystore.jks)
# ============================================================
# Ejecutar una sola vez en la raíz o carpeta android/app/ (guardar respaldo seguro):
#
# keytool -genkey -v -keystore android/app/upload-keystore.jks \
#   -keyalg RSA -keysize 2048 -validity 10000 -alias upload
#
# (En Windows usar ^ en lugar de \ o ejecutar en una sola línea)

# ============================================================
# 2. CONFIGURAR android/key.properties (NO SUBIR A GIT)
# ============================================================
# storePassword=TU_CONTRASEÑA_DEL_KEYSTORE
# keyPassword=TU_CONTRASEÑA_DE_LA_LLAVE
# keyAlias=upload
# storeFile=upload-keystore.jks

# ============================================================
# 3. FIRMA EN android/app/build.gradle
# ============================================================
# Agregar arriba de android { ... }:
#   def keystoreProperties = new Properties()
#   def keystorePropertiesFile = rootProject.file('key.properties')
#   if (keystorePropertiesFile.exists()) {
#       keystoreProperties.load(new FileInputStream(keystorePropertiesFile))
#   }
#
# Dentro de android { signingConfigs { release { ... } } buildTypes { release { ... } } }:
#   signingConfigs {
#       release {
#           keyAlias keystoreProperties['keyAlias']
#           keyPassword keystoreProperties['keyPassword']
#           storeFile keystoreProperties['storeFile'] ? file(keystoreProperties['storeFile']) : null
#           storePassword keystoreProperties['storePassword']
#       }
#   }
#   buildTypes {
#       release {
#           signingConfig signingConfigs.release
#           minifyEnabled true
#           shrinkResources true
#       }
#   }

# ============================================================
# 4. GENERAR ANDROID APP BUNDLE (.aab) PARA GOOGLE PLAY
# ============================================================
# 1) Limpiar caché y verificar dependencias:
#    flutter clean && flutter pub get
#
# 2) Compilar el archivo .aab firmado de producción:
#    flutter build appbundle --release
#
#    (Recomendado con ofuscación de código Dart):
#    flutter build appbundle --release --obfuscate --split-debug-info=build/app/outputs/symbols
#
# Ruta generada lista para subir a Google Play Console:
#    build/app/outputs/bundle/release/app-release.aab
#
# (Para iOS / App Store Connect en macOS):
#    flutter build ipa --release

# ============================================================
# 5. CHECKLIST FINAL ANTES DE ENVIAR A GOOGLE PLAY CONSOLE
# ============================================================
# 1) Ícono (512x512 PNG) + Gráfico de funciones (1024x500 PNG) y capturas reales.
# 2) URL pública de Política de Privacidad + enlace funcional dentro de la app.
# 3) Formulario de Seguridad de los Datos (Data Safety) y eliminación de cuenta declarada.
# 4) Cuestionario de Clasificación de Contenido (IARC) y declaración de público/menores.
# 5) Cuenta de prueba activa (usuario/contraseña) y verificación de targetSdkVersion >= 34.`,
  },
];
