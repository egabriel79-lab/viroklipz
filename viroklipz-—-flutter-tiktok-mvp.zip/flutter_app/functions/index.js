const { onDocumentCreated } = require("firebase-functions/v2/firestore");
const { initializeApp } = require("firebase-admin/app");
const { getFirestore, FieldValue } = require("firebase-admin/firestore");
const { getMessaging } = require("firebase-admin/messaging");

initializeApp();

const db = getFirestore();

/**
 * Se dispara automáticamente al crearse un documento en: notifications/{notificationId}
 * Campos esperados: senderUid, senderName, receiverUid, type ('like' | 'comment' | 'follow'), videoId?
 */
exports.sendPushNotification = onDocumentCreated(
  "notifications/{notificationId}",
  async (event) => {
    const snapshot = event.data;
    if (!snapshot) return null;

    const data = snapshot.data();
    const receiverUid = data.receiverUid;
    const senderUid = data.senderUid || "";
    const senderName = data.senderName || "Alguien";
    const type = data.type || "like";
    const videoId = data.videoId || "";

    // Evitar enviar notificaciones al mismo usuario que ejecutó la acción
    if (!receiverUid || (senderUid && senderUid === receiverUid)) {
      return null;
    }

    // 1. Buscar el fcmToken del receptor en users/{receiverUid}
    const userDoc = await db.collection("users").doc(receiverUid).get();
    if (!userDoc.exists) {
      return null;
    }

    const fcmToken = userDoc.data().fcmToken;
    if (!fcmToken) {
      console.log("Usuario sin fcmToken registrado:", receiverUid);
      return null;
    }

    // 2. Construir título y cuerpo según el tipo de interacción
    let title = "Viroklipz";
    let body = senderName + " interactuó contigo.";

    if (type === "like") {
      title = "¡Nuevo Fuego! 🔥";
      body = "@" + senderName + " le dio like a tu video.";
    } else if (type === "comment") {
      title = "Nuevo comentario 💬";
      body = "@" + senderName + " comentó en tu video.";
    } else if (type === "follow") {
      title = "¡Nuevo seguidor! ✨";
      body = "@" + senderName + " comenzó a seguirte.";
    }

    // 3. Armar el payload FCM (con data para deep-linking en Flutter)
    const message = {
      token: fcmToken,
      notification: {
        title: title,
        body: body,
      },
      data: {
        type: String(type),
        videoId: String(videoId),
        senderUid: String(senderUid),
        senderName: String(senderName),
      },
      android: {
        priority: "high",
        notification: {
          channelId: "viroklipz_high_importance",
          sound: "default",
        },
      },
      apns: {
        payload: {
          aps: {
            sound: "default",
            badge: 1,
          },
        },
      },
    };

    try {
      const response = await getMessaging().send(message);
      console.log("Push FCM enviada:", response);
      return response;
    } catch (error) {
      console.error("Error enviando Push FCM:", error);
      // Limpiar token inválido si la app fue desinstalada
      if (
        error.code === "messaging/registration-token-not-registered" ||
        error.code === "messaging/invalid-registration-token"
      ) {
        await db.collection("users").doc(receiverUid).update({
          fcmToken: FieldValue.delete(),
        });
      }
      return null;
    }
  }
);