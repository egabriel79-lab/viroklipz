-- 1. Tabla pública de perfiles vinculada a auth.users
create table if not exists public.users (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  avatar_url text,
  created_at timestamptz not null default now()
);

-- 2. Tabla de videos del feed
create table if not exists public.videos (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users(id) on delete cascade,
  username text not null,
  video_url text not null,
  description text not null default '',
  audio_name text not null default 'Sonido original',
  likes_count integer not null default 0,
  created_at timestamptz not null default now()
);

create index if not exists videos_created_at_idx
  on public.videos (created_at desc);

-- 3. Trigger para crear perfil en public.users automáticamente al registrarse
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.users (id, username)
  values (
    new.id,
    coalesce(
      new.raw_user_meta_data ->> 'username',
      split_part(new.email, '@', 1)
    )
  );
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- 4. Row Level Security (RLS)
alter table public.users enable row level security;
alter table public.videos enable row level security;

-- Lectura pública para el feed y perfiles
create policy "Perfiles visibles para todos"
  on public.users for select
  using (true);

create policy "Videos visibles para todos"
  on public.videos for select
  using (true);

-- Solo usuarios autenticados insertan sus propios videos
create policy "Usuarios autenticados crean sus videos"
  on public.videos for insert
  to authenticated
  with check (auth.uid() = user_id);

-- Solo el dueño puede actualizar o borrar su video
create policy "Solo el dueño edita su video"
  on public.videos for update
  to authenticated
  using (auth.uid() = user_id);