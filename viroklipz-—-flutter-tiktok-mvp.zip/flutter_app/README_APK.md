# Viroklipz — Proyecto Flutter Completo (Android APK)

Esta carpeta (`flutter_app/`) contiene el proyecto Flutter nativo completo con:
- `pubspec.yaml`
- `lib/` (`main.dart`, modelos, providers, servicios y todas las pantallas y widgets)
- `android/` (`AndroidManifest.xml`, `build.gradle`, `settings.gradle`, `gradle.properties`, `MainActivity.kt`, permisos de cámara/micrófono/galería/FCM y SDK 34)
- `firestore.rules` y `functions/`

## Cómo compilar el APK en tu computadora

1. **Instala Flutter SDK y Android Studio** (con Android SDK 34).
2. **Abre una terminal dentro de esta carpeta `flutter_app/`**:
   ```bash
   cd flutter_app
   ```
3. **Genera el Gradle wrapper y `local.properties` si aún no existen** (no sobrescribe `lib/`, `pubspec.yaml` ni `android/app/src/main/AndroidManifest.xml`):
   ```bash
   flutter create . --platforms=android --org=com.viroklipz
   ```
4. **Instala las dependencias**:
   ```bash
   flutter pub get
   ```
5. **Configura Firebase (`lib/firebase_options.dart` y `android/app/google-services.json`)**:
   ```bash
   dart pub global activate flutterfire_cli
   flutterfire configure
   ```
   Luego descomenta `id "com.google.gms.google-services"` en `android/app/build.gradle`.
6. **Compila el APK para Android**:
   ```bash
   flutter build apk --release
   ```
   El APK listo para instalar quedará en:
   `build/app/outputs/flutter-apk/app-release.apk`
